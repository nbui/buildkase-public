"""The log keeps every line. The terminal shows the subset marked for display.

`print` during a bound run is copied into the log. `detail` writes the log only.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

_logs: list[Path] = []


class _Tee:
    """Copy terminal writes into the bound logs."""

    def __init__(self, stream: TextIO):
        self._stream = stream

    def write(self, data: str) -> int:
        self._stream.write(data)
        _write(data)
        return len(data)

    def flush(self) -> None:
        self._stream.flush()

    def isatty(self) -> bool:
        return self._stream.isatty()

    def fileno(self) -> int:
        return self._stream.fileno()

    @property
    def encoding(self) -> str:
        return getattr(self._stream, "encoding", "utf-8")

    def __getattr__(self, name: str):
        return getattr(self._stream, name)


def install() -> None:
    if isinstance(sys.stdout, _Tee):
        return
    sys.stdout = _Tee(sys.stdout)


def bind(path: Path) -> None:
    """Record into `path` until `unbind`. A step log sits above the run log."""
    install()
    _logs.append(path)


def unbind() -> None:
    if _logs:
        _logs.pop()


def bound() -> bool:
    """True while a run log is recording."""
    return bool(_logs)


def detail(message: str) -> None:
    """Log only. The terminal does not show this line."""
    text = message.rstrip("\n")
    if not text:
        return
    _write(text + "\n")


def _write(data: str) -> None:
    if not data:
        return
    seen: set[str] = set()
    for path in _logs:
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as handle:
                handle.write(data)
        except OSError:
            continue
