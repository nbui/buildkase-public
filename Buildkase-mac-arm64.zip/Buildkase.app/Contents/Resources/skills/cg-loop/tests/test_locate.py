#!/usr/bin/env python3
"""/locate finds a region in an image and stores the pixel position."""

from __future__ import annotations

import os
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

import cg_loop.locate as locate  # noqa: E402
from cg_loop.browser_helper import click_located, css_from_image, locate_click_command  # noqa: E402
from cg_loop.compiled import ensure_compiled, run_locate, validate_compiled  # noqa: E402
from cg_loop.locate import (  # noqa: E402
    locate_prompt,
    mark_image,
    marked_path,
    parse_boxes,
    position_from_output,
    project_box,
)
from cg_loop.terminal import expand_command  # noqa: E402
from cg_loop.workflow import load_workflow, parse_step, project_root  # noqa: E402

SLEEP = project_root() / "workflows" / "wf-sleep-story.yaml"
IMAGE = (
    "/Users/nghia/Downloads/workspace/social_content_gen/workflows/cache/wf-sleep-story/"
    "compiled/wf_post_sleep_story_short/steps/"
    "wf_post_sleep_story_short_click_close_96676c255b-1.jpg"
)
LINE = f"/locate close button,  '{IMAGE}' into $loc"


class LocateParseTest(unittest.TestCase):
    def test_sleep_story_step(self) -> None:
        step = parse_step(LINE)
        self.assertEqual(step.tool, "locate")
        self.assertEqual(step.kind, "locate")
        self.assertEqual(step.extra, "close button")
        self.assertEqual(step.command, IMAGE)
        self.assertEqual(step.var, "loc")
        group = load_workflow(SLEEP).named_groups()["browser_locate_test2_routine"]
        self.assertEqual(group.steps[0].kind, "locate")
        self.assertEqual(group.steps[0].var, "loc")
        self.assertEqual(group.steps[1].kind, "term")

    def test_rejects_a_step_with_no_variable(self) -> None:
        with self.assertRaises(ValueError):
            parse_step("/locate close button, 'shot.jpg'")


class LocateBoxTest(unittest.TestCase):
    def test_prompt_names_the_thing(self) -> None:
        self.assertEqual(locate_prompt("close button"), "Locate the close button.")
        self.assertEqual(locate_prompt("Locate the person"), "Locate the person.")

    def test_projects_the_model_grid_onto_pixels(self) -> None:
        raw = "<ref>Locate the person</ref><box><0><0><1000><1000></box>"
        self.assertEqual(parse_boxes(raw), [(0, 0, 1000, 1000)])
        box = project_box(0, 0, 1000, 1000, width=100, height=50)
        self.assertEqual(box["x"], 50)
        self.assertEqual(box["y"], 25)
        found = position_from_output(raw, width=100, height=50, query="close button", image="shot.jpg")
        self.assertEqual(found["text"], "50,25 box=0,0,100,50")
        printed = expand_command("print $loc", {}, {"loc": found})
        self.assertEqual(printed, "print 50,25 box=0,0,100,50")

    def test_second_box_is_counted(self) -> None:
        raw = "<box><0><0><10><10></box><box><20><20><30><30></box>"
        found = position_from_output(raw, width=1000, height=1000, query="x", image="y")
        self.assertEqual(len(found["boxes"]), 2)
        self.assertIn("(+1 more)", found["text"])


class LocateRunTest(unittest.TestCase):
    def test_dry_run_does_not_load_the_model(self) -> None:
        result = run_locate(
            {"dry_run": True, "env": {}, "variables": {}},
            query="close button",
            image=IMAGE,
            var="loc",
        )
        self.assertEqual(result["outputs"]["status"], "proposed")
        self.assertNotIn("blocked", result)

    def test_missing_image_is_blocked(self) -> None:
        result = run_locate(
            {"env": {}, "variables": {}},
            query="close button",
            image="/tmp/cg-loop-missing-locate.jpg",
            var="loc",
        )
        self.assertTrue(result["blocked"])

    def test_stores_the_center(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "shot.jpg"
            image.write_bytes(b"jpeg")

            def fake(query: str, path: str) -> dict:
                return position_from_output(
                    "<box><100><200><300><400></box>",
                    width=1000,
                    height=1000,
                    query=query,
                    image=path,
                )

            with patch("cg_loop.locate.locate_image", fake):
                result = run_locate(
                    {"env": {}, "variables": {}},
                    query="close button",
                    image=str(image),
                    var="loc",
                )
        self.assertEqual(result["variables"]["loc"]["x"], 200)
        self.assertEqual(result["variables"]["loc"]["y"], 300)
        self.assertEqual(result["outputs"]["status"], "ok")

    def test_mark_image_draws_the_box(self) -> None:
        from PIL import Image

        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "shot.jpg"
            Image.new("RGB", (200, 160), (20, 20, 20)).save(source)
            out = mark_image(source, [{"x1": 40, "y1": 30, "x2": 140, "y2": 110}])
            self.assertEqual(Path(out), marked_path(source))
            marked = Image.open(out)
            edge = marked.getpixel((40, 70))
            inside = marked.getpixel((90, 70))
        self.assertGreater(edge[0], 200)
        self.assertLess(edge[1], 80)
        self.assertLess(inside[0], 40)

    def test_compile_calls_run_locate(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_find:\n  - /locate close button, 'shot.jpg' into $loc\n",
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_find"]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("run_locate", text)
            self.assertIn("close button", text)


class Mouse:
    def __init__(self) -> None:
        self.clicked: tuple[float, float] | None = None

    def click(self, x: float, y: float) -> None:
        self.clicked = (x, y)


class Page:
    def __init__(self, jpeg: bytes, viewport: dict[str, float]) -> None:
        self.mouse = Mouse()
        self.jpeg = jpeg
        self.viewport = viewport

    def evaluate(self, script: str) -> dict[str, float]:
        del script
        return self.viewport

    def screenshot(self, **kwargs: object) -> bytes:
        del kwargs
        return self.jpeg


class Tab:
    def __init__(self, page: Page) -> None:
        self.page = page

    def observe(self) -> dict[str, str]:
        return {"url": "https://studio.youtube.com", "title": "Studio", "text": ""}


class LocateClickTest(unittest.TestCase):
    def test_commands(self) -> None:
        self.assertTrue(locate_click_command("/browser click $loc"))
        self.assertTrue(locate_click_command("/browser click 1883,1506 box=1816,1470,1950,1542 /tmp/a.jpg"))
        self.assertTrue(locate_click_command('/browser /locate "videos" and click'))
        self.assertTrue(locate_click_command('/browser /locate "arrow down icon next to Create post"'))
        self.assertFalse(locate_click_command('/browser locate "arrow down icon next to Create post"'))
        self.assertFalse(locate_click_command("/browser click Create"))
        self.assertFalse(locate_click_command("/browser click the Shorts filter"))
        self.assertFalse(locate_click_command("/browser Click arrow down icon next to Create post"))

    def test_scales_screenshot_pixels_onto_the_page(self) -> None:
        css_x, css_y = css_from_image(
            1883,
            1506,
            image_width=2978,
            image_height=2418,
            viewport_width=1489,
            viewport_height=1209,
            dpr=2,
        )
        self.assertAlmostEqual(css_x, 941.5)
        self.assertAlmostEqual(css_y, 753)

    def test_click_loc_uses_the_saved_center(self) -> None:
        page = Page(b"", {"w": 1489, "h": 1209, "dpr": 2})
        result = click_located(
            "/browser click $loc",
            Tab(page),
            variables={
                "loc": {
                    "x": 1883,
                    "y": 1506,
                    "width": 2978,
                    "height": 2418,
                    "text": "1883,1506 box=1816,1470,1950,1542",
                }
            },
        )
        self.assertEqual(result["status"], "done")
        self.assertIsNotNone(page.mouse.clicked)
        assert page.mouse.clicked is not None
        self.assertAlmostEqual(page.mouse.clicked[0], 941.5)
        self.assertAlmostEqual(page.mouse.clicked[1], 753)

    def test_locate_and_click_screenshots_then_clicks(self) -> None:
        from PIL import Image

        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "page.jpg"
            Image.new("RGB", (200, 100), (10, 10, 10)).save(image, quality=90)
            page = Page(image.read_bytes(), {"w": 100, "h": 50, "dpr": 2})

            def fake(query: str, path: str) -> dict:
                self.assertEqual(query, "videos")
                return {
                    "x": 100,
                    "y": 40,
                    "width": 200,
                    "height": 100,
                    "box": {"x1": 80, "y1": 20, "x2": 120, "y2": 60},
                    "text": "100,40 box=80,20,120,60",
                    "marked": str(Path(path).with_name("page.locate.jpg")),
                    "query": query,
                    "image": path,
                }

            with patch("cg_loop.locate.locate_image", fake):
                result = click_located(
                    '/browser /locate "videos" and click',
                    Tab(page),
                    env={"DATA": tmp},
                )
        self.assertEqual(result["status"], "done")
        assert page.mouse.clicked is not None
        self.assertAlmostEqual(page.mouse.clicked[0], 50)
        self.assertAlmostEqual(page.mouse.clicked[1], 20)
        self.assertTrue(result["outputs"]["screenshots"])

    def test_locate_screenshots_and_does_not_click(self) -> None:
        from PIL import Image

        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "page.jpg"
            Image.new("RGB", (200, 100), (10, 10, 10)).save(image, quality=90)
            page = Page(image.read_bytes(), {"w": 100, "h": 50, "dpr": 2})

            def fake(query: str, path: str) -> dict:
                self.assertEqual(query, "arrow down icon next to Create post")
                self.assertTrue(Path(path).is_file())
                return {
                    "x": 40,
                    "y": 20,
                    "width": 200,
                    "height": 100,
                    "box": {"x1": 20, "y1": 10, "x2": 60, "y2": 30},
                    "text": "40,20 box=20,10,60,30",
                    "marked": str(Path(path).with_name("page.locate.jpg")),
                    "query": query,
                    "image": path,
                }

            with patch("cg_loop.locate.locate_image", fake):
                result = click_located(
                    '/browser /locate "arrow down icon next to Create post"',
                    Tab(page),
                    env={"DATA": tmp},
                )
        self.assertEqual(result["status"], "done")
        self.assertIsNone(page.mouse.clicked)
        self.assertEqual(result["actions"][0]["operation"], "LOCATE")
        self.assertEqual(result["outputs"]["locate"], "40,20 box=20,10,60,30")
        self.assertTrue(result["outputs"]["screenshots"])

    def test_locate_screenshot_is_saved_beside_the_step_log(self) -> None:
        from PIL import Image

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data = root / "data"
            data.mkdir()
            log_json = root / "logs" / "steps" / "07_locate_oldest.json"
            image = root / "page.jpg"
            Image.new("RGB", (200, 100), (10, 10, 10)).save(image, quality=90)
            page = Page(image.read_bytes(), {"w": 100, "h": 50, "dpr": 2})

            def fake(query: str, path: str) -> dict:
                marked = str(Path(path).with_name(f"{Path(path).stem}.locate.jpg"))
                Path(marked).write_bytes(b"boxed")
                return {
                    "x": 40,
                    "y": 20,
                    "width": 200,
                    "height": 100,
                    "box": {"x1": 20, "y1": 10, "x2": 60, "y2": 30},
                    "text": f"40,20 box=20,10,60,30 {marked}",
                    "marked": marked,
                    "query": query,
                    "image": path,
                }

            with patch("cg_loop.locate.locate_image", fake):
                result = click_located(
                    '/browser /locate "oldest date box"',
                    Tab(page),
                    env={"DATA": str(data), "CG_LOOP_STEP_JSON": str(log_json)},
                )
            shot = log_json.with_suffix(".jpg")
            marked = shot.with_name(f"{shot.stem}.locate.jpg")
            self.assertEqual(shot.read_bytes(), image.read_bytes())
            self.assertEqual(result["outputs"]["screenshots"], [str(shot), str(marked)])
            self.assertFalse(any(data.iterdir()))

    def test_compile_does_not_ask_jev(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_find:\n"
                "  - /browser click $loc\n"
                '  - /browser /locate "videos" and click\n'
                '  - /browser /locate "arrow down icon next to Create post"\n',
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_find"]
            for step in group.steps:
                created = ensure_compiled(group, step, index=0, env=group.env)
                self.assertEqual(validate_compiled(created.path, step), "")
                text = created.path.read_text(encoding="utf-8")
                self.assertIn("click_located", text)
                self.assertNotIn("replay_browser_actions", text)


class LocateDaemonTest(unittest.TestCase):
    def setUp(self) -> None:
        self._old_dir = os.environ.get("CG_LOOP_LOCATE_DIR")
        self._tmp = tempfile.TemporaryDirectory()
        os.environ["CG_LOOP_LOCATE_DIR"] = self._tmp.name
        locate._MODEL = None
        locate._IN_SERVER = False
        locate._DAEMON_READY = False

    def tearDown(self) -> None:
        locate._MODEL = None
        locate._IN_SERVER = False
        locate._DAEMON_READY = False
        if self._old_dir is None:
            os.environ.pop("CG_LOOP_LOCATE_DIR", None)
        else:
            os.environ["CG_LOOP_LOCATE_DIR"] = self._old_dir
        self._tmp.cleanup()

    def test_a_live_process_is_not_started_again(self) -> None:
        locate._DAEMON_READY = True
        with patch.object(locate, "_pid_alive", return_value=True), patch.object(
            locate, "_spawn"
        ) as spawn, patch.object(locate, "_ping") as ping:
            self.assertFalse(locate._ensure_daemon())
        spawn.assert_not_called()
        ping.assert_not_called()

    def test_a_busy_process_is_not_started_again(self) -> None:
        with patch.object(locate, "_ping", return_value=None), patch.object(
            locate, "_pid_alive", return_value=True
        ), patch.object(locate, "_spawn") as spawn:
            self.assertFalse(locate._ensure_daemon())
        spawn.assert_not_called()

    def test_the_first_caller_starts_one_process(self) -> None:
        with patch.object(locate, "_ping", return_value=None), patch.object(
            locate, "_pid_alive", return_value=False
        ), patch.object(locate, "_spawn") as spawn, patch.object(
            locate, "_wait_ping", return_value=True
        ):
            self.assertTrue(locate._ensure_daemon())
        spawn.assert_called_once()
        self.assertTrue(locate._DAEMON_READY)

    def test_two_requests_load_the_weights_once(self) -> None:
        loads = {"n": 0}

        def fake_local(query: str, path: Path) -> dict:
            if locate._MODEL is None:
                loads["n"] += 1
                locate._MODEL = ("weights", "processor")
            return {"query": query, "image": str(path), "text": "1,2", "x": 1, "y": 2, "box": {"x1": 0}}

        thread = threading.Thread(target=locate._serve, daemon=True)
        with patch.object(locate, "_locate_local", fake_local):
            thread.start()
            try:
                deadline = time.time() + 5
                while time.time() < deadline and locate._ping() is None:
                    time.sleep(0.05)
                self.assertIsNotNone(locate._ping())
                self.assertFalse(locate._ping()["loaded"])
                first = locate._rpc({"query": "close", "image": "shot.jpg"}, timeout=5)
                second = locate._rpc({"query": "videos", "image": "shot.jpg"}, timeout=5)
                self.assertEqual(loads["n"], 1)
                self.assertEqual(first["x"], 1)
                self.assertEqual(second["query"], "videos")
                self.assertTrue(locate._ping()["loaded"])
                locate._DAEMON_READY = False
                with patch.object(locate, "_spawn") as spawn:
                    self.assertFalse(locate._ensure_daemon())
                spawn.assert_not_called()
            finally:
                try:
                    locate._rpc({"cmd": "stop"}, timeout=5)
                except OSError:
                    pass
        thread.join(timeout=5)
        self.assertFalse(thread.is_alive())

    def test_openrouter_model_asks_for_a_box(self) -> None:
        from PIL import Image

        from cg_loop.locate import locate_image

        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "shot.jpg"
            Image.new("RGB", (100, 50), "white").save(path, format="JPEG")

            def chat(base: str, model: str, prompt: str, image: bytes, **kwargs: object) -> str:
                self.assertEqual(model, "google/gemma-3-27b-it")
                self.assertIn("<box>", prompt)
                self.assertTrue(image)
                self.assertEqual(kwargs.get("provider"), "openrouter")
                return "<box><100><200><300><400></box>"

            with patch("cg_loop.gemma.chat_completion", chat):
                with patch.object(locate, "_locate_via_daemon", side_effect=AssertionError("daemon")):
                    found = locate_image(
                        "close button",
                        str(path),
                        {"LOCATE_MODEL": "openrouter/google/gemma-3-27b-it", "OPENROUTER_API_KEY": "sk"},
                    )
        self.assertEqual(found["box"], {"x1": 10, "y1": 10, "x2": 30, "y2": 20})
        self.assertIn("box=10,10,30,20", found["text"])


if __name__ == "__main__":
    unittest.main()
