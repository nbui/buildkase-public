#!/usr/bin/env python3
"""/browser /lmstudio-gemma-4 sends a screenshot to the Gemma model in LM Studio."""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

import cg_loop.gemma as gemma  # noqa: E402
from cg_loop.agent import _workflow_needs_browser  # noqa: E402
from cg_loop.compiled import ensure_compiled, run_browser_gemma, run_openrouter, validate_compiled  # noqa: E402
from cg_loop.gemma import (  # noqa: E402
    accepts_value,
    chat_completion,
    complete_text,
    extraction_prompt,
    lmstudio_url,
    model_id,
    parse_extraction,
)
from cg_loop.terminal import expand_command  # noqa: E402
from cg_loop.workflow import load_workflow, parse_step, project_root  # noqa: E402

SLEEP = project_root() / "workflows" / "wf-sleep-story.yaml"
LINE = (
    "/browser /lmstudio-gemma-4 extract scheduled latest date "
    "in YYYY-MM-DD HH:MM:SS format into $post_date print $post_date"
)


class GemmaParseTest(unittest.TestCase):
    def test_sleep_story_step(self) -> None:
        step = parse_step(LINE)
        self.assertEqual(step.tool, "browser")
        self.assertEqual(step.kind, "browser_gemma")
        self.assertEqual(step.command, "lmstudio-gemma-4")
        self.assertEqual(step.var, "post_date")
        self.assertEqual(step.extra, "extract scheduled latest date in YYYY-MM-DD HH:MM:SS format")
        group = load_workflow(SLEEP).named_groups()["post_sleep_story_short_instagram_routine"]
        self.assertEqual(group.env["LM_STUDIO_BASE_URL"], "http://127.0.0.1:1234/v1")

    def test_locate_stays_a_browser_goal(self) -> None:
        step = parse_step('/browser /locate "videos" and click')
        self.assertEqual(step.kind, "goal")

    def test_rejects_a_step_with_no_variable(self) -> None:
        step = parse_step("/browser /lmstudio-gemma-4 extract the date")
        self.assertEqual(step.kind, "goal")
        old = parse_step("/browser /gemma-4 extract the date in YYYY-MM-DD HH:MM:SS format into $post_date")
        self.assertEqual(old.kind, "goal")
        other = parse_step(
            "/browser /embeddinggemma-2 extract the date in YYYY-MM-DD HH:MM:SS format into $post_date"
        )
        self.assertEqual(other.kind, "goal")

    def test_lmstudio_model_suffix_is_the_loaded_id(self) -> None:
        step = parse_step(
            "/browser /lmstudio-qwen3.8-27b-mlx extract the latest scheduled date "
            "in YYYY-MM-DD HH:MM:SS format into $post_date print $post_date"
        )
        self.assertEqual(step.kind, "browser_gemma")
        self.assertEqual(step.tool, "browser")
        self.assertEqual(step.command, "lmstudio-qwen3.8-27b-mlx")
        self.assertEqual(step.var, "post_date")
        self.assertEqual(step.extra, "extract the latest scheduled date in YYYY-MM-DD HH:MM:SS format")
        short = parse_step("/browser /lmstudio-qwen extract the date into $post_date")
        self.assertEqual(short.command, "lmstudio-qwen")
        self.assertEqual(model_id(short.command), "qwen")

    def test_local_bonsai_keeps_the_model_id(self) -> None:
        step = parse_step(
            "/browser /local/prism-ml/Ternary-Bonsai-2-9B-mlx-2bit Read the Date cell into $post_date"
        )
        self.assertEqual(step.kind, "browser_gemma")
        self.assertEqual(step.command, "local/prism-ml/Ternary-Bonsai-2-9B-mlx-2bit")
        self.assertEqual(step.var, "post_date")
        self.assertEqual(step.extra, "Read the Date cell")


class GemmaExtractTest(unittest.TestCase):
    def test_prompt_asks_for_json(self) -> None:
        prompt = extraction_prompt("extract the latest date")
        self.assertIn("extract the latest date", prompt)
        self.assertIn('"value"', prompt)

    def test_json_value_is_the_stored_text(self) -> None:
        raw = '{"value": "2026-10-14T15:30", "items": ["2026-10-13 09:00:00", "2026-10-14 15:30:00"]}'
        found = parse_extraction(raw)
        self.assertEqual(found["text"], "2026-10-14 15:30:00")
        self.assertEqual(len(found["items"]), 2)
        self.assertTrue(accepts_value("YYYY-MM-DD HH:MM:SS", found["text"]))

    def test_latest_stamp_wins_when_value_is_empty(self) -> None:
        raw = '{"value": "", "items": ["2026-10-13 09:00:00", "2026-10-16 18:05:00"]}'
        found = parse_extraction(raw)
        self.assertEqual(found["text"], "2026-10-16 18:05:00")

    def test_month_name_on_the_first_item_becomes_midnight(self) -> None:
        raw = """```json
{
  "value": "",
  "items": [
    {
      "date": "Oct 25, 2026",
      "visibility": "Scheduled"
    }
  ]
}
```"""
        found = parse_extraction(raw)
        self.assertEqual(found["text"], "2026-10-25 00:00:00")
        self.assertTrue(accepts_value("Rewrite that date as YYYY-MM-DD HH:MM:SS", found["text"]))

    def test_fenced_json(self) -> None:
        raw = '```json\n{"value": "Schedule"}\n```'
        found = parse_extraction(raw)
        self.assertEqual(found["text"], "Schedule")
        self.assertFalse(accepts_value("return YYYY-MM-DD HH:MM:SS", found["text"]))

    def test_plain_reply_is_kept_when_there_is_no_json(self) -> None:
        found = parse_extraction("Tuesday at 11:34 AM")
        self.assertEqual(found["text"], "Tuesday at 11:34 AM")
        empty = parse_extraction('{"value": ""}')
        self.assertEqual(empty["text"], "")

    def test_model_alias(self) -> None:
        self.assertEqual(model_id("lmstudio-gemma-4"), gemma.MODEL_ID)
        with patch.dict(os.environ, {"LM_STUDIO_BASE_URL": ""}):
            self.assertEqual(lmstudio_url({}), gemma.DEFAULT_URL)
        self.assertEqual(lmstudio_url({"LM_STUDIO_BASE_URL": "http://127.0.0.1:9/v1"}), "http://127.0.0.1:9/v1")
        with patch.dict(os.environ, {"CG_LOOP_GEMMA_MODEL": "local/gemma"}):
            self.assertEqual(model_id("lmstudio-gemma-4"), "local/gemma")
            self.assertEqual(model_id("lmstudio-qwen3.8-27b-mlx"), "qwen3.8-27b-mlx")
        self.assertEqual(model_id("lmstudio-qwen3.8-27b-mlx"), "qwen3.8-27b-mlx")
        self.assertEqual(model_id("lmstudio-qwen"), "qwen")
        with self.assertRaises(ValueError):
            model_id("gemma-4")
        with self.assertRaises(ValueError):
            model_id("lmstudio-")

    def test_posts_the_screenshot_to_lmstudio(self) -> None:
        captured: dict = {}

        class Response:
            def __enter__(self) -> "Response":
                return self

            def __exit__(self, *exc: object) -> bool:
                return False

            def read(self) -> bytes:
                return b'{"choices":[{"message":{"content":"{\\"value\\": \\"2026-10-14 16:05:00\\"}"}}]}'

        def fake_open(request: object, timeout: float = 0) -> Response:
            captured["url"] = request.full_url  # type: ignore[attr-defined]
            captured["body"] = json.loads(request.data.decode("utf-8"))  # type: ignore[attr-defined]
            captured["timeout"] = timeout
            return Response()

        with patch("cg_loop.gemma.urllib.request.urlopen", fake_open):
            text = chat_completion("http://127.0.0.1:9/v1", "gemma-4", "extract the date", b"jpeg")
        self.assertEqual(text, '{"value": "2026-10-14 16:05:00"}')
        self.assertEqual(captured["timeout"], gemma.REQUEST_TIMEOUT)
        self.assertEqual(captured["url"], "http://127.0.0.1:9/v1/chat/completions")
        self.assertEqual(captured["body"]["model"], "gemma-4")
        image = captured["body"]["messages"][0]["content"][1]["image_url"]["url"]
        self.assertTrue(image.startswith("data:image/jpeg;base64,"))

    def test_qwen_slug_is_sent_as_the_model_id(self) -> None:
        captured: dict = {}

        class Response:
            def __enter__(self) -> "Response":
                return self

            def __exit__(self, *exc: object) -> bool:
                return False

            def read(self) -> bytes:
                return b'{"choices":[{"message":{"content":"{\\"value\\": \\"2026-10-14 16:05:00\\"}"}}]}'

        def fake_open(request: object, timeout: float = 0) -> Response:
            captured["body"] = json.loads(request.data.decode("utf-8"))  # type: ignore[attr-defined]
            return Response()

        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "shot.jpg"
            image.write_bytes(b"jpeg")
            with patch("cg_loop.gemma.urllib.request.urlopen", fake_open):
                found = gemma.extract_image(
                    "lmstudio-qwen3.8-27b-mlx",
                    "extract the date in YYYY-MM-DD HH:MM:SS format",
                    str(image),
                    {"LM_STUDIO_BASE_URL": "http://127.0.0.1:9/v1"},
                )
        self.assertEqual(found["model"], "qwen3.8-27b-mlx")
        self.assertEqual(found["text"], "2026-10-14 16:05:00")
        self.assertEqual(captured["body"]["model"], "qwen3.8-27b-mlx")

    def test_local_model_sends_the_screenshot_to_hug(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "shot.jpg"
            image.write_bytes(b"jpeg")
            with patch("cg_loop.hug.ask_hug", return_value='{"value": "2026-10-22 00:00:00"}') as ask:
                found = gemma.extract_image(
                    "local/prism-ml/Ternary-Bonsai-2-9B-mlx-2bit",
                    "extract the date in YYYY-MM-DD HH:MM:SS format",
                    str(image),
                )
        ask.assert_called_once()
        model_name, prompt, files = ask.call_args.args
        self.assertEqual(model_name, "prism-ml/Ternary-Bonsai-2-9B-mlx-2bit")
        self.assertIn("YYYY-MM-DD", prompt)
        self.assertEqual(files, [str(image)])
        self.assertEqual(found["value"], "2026-10-22 00:00:00")
        self.assertEqual(found["local"], "prism-ml/Ternary-Bonsai-2-9B-mlx-2bit")


class GemmaRunTest(unittest.TestCase):
    def test_dry_run_does_not_load_the_model(self) -> None:
        with patch("cg_loop.gemma.extract_image") as extract:
            result = run_browser_gemma(
                {"dry_run": True, "env": {}, "variables": {}},
                "lmstudio-gemma-4",
                "extract scheduled latest date in YYYY-MM-DD HH:MM:SS format",
                "post_date",
            )
        extract.assert_not_called()
        self.assertEqual(result["outputs"]["status"], "dry-run")

    def test_screenshot_is_sent_and_the_date_is_stored(self) -> None:
        class Page:
            def screenshot(self, **kwargs: object) -> bytes:
                self.kwargs = kwargs
                return b"jpeg"

        page = Page()

        class Tab:
            def __init__(self) -> None:
                self.page = page

        def fake(slug: str, instruction: str, image: str, env: dict | None = None) -> dict:
            self.assertEqual(slug, "lmstudio-gemma-4")
            self.assertEqual(env["LM_STUDIO_BASE_URL"], "http://127.0.0.1:9/v1")
            self.assertIn("YYYY-MM-DD", instruction)
            self.assertEqual(Path(image).read_bytes(), b"jpeg")
            return parse_extraction('{"value": "2026-10-14 16:05:00", "items": ["2026-10-14 16:05:00"]}')

        with tempfile.TemporaryDirectory() as tmp:
            log_json = Path(tmp) / "steps" / "08_lmstudio.json"
            with patch("cg_loop.gemma.extract_image", fake):
                result = run_browser_gemma(
                    {
                        "dry_run": False,
                        "env": {
                            "LM_STUDIO_BASE_URL": "http://127.0.0.1:9/v1",
                            "CG_LOOP_STEP_JSON": str(log_json),
                        },
                        "variables": {},
                        "browser": Tab(),
                        "data": tmp,
                    },
                    "lmstudio-gemma-4",
                    "extract scheduled latest date in YYYY-MM-DD HH:MM:SS format",
                    "post_date",
                )
            logged = log_json.with_suffix(".jpg")
            self.assertEqual(logged.read_bytes(), b"jpeg")
        self.assertEqual(page.kwargs, {"type": "jpeg", "quality": 80})
        stored = result["variables"]["post_date"]
        self.assertEqual(stored["text"], "2026-10-14 16:05:00")
        self.assertEqual(expand_command("print $post_date", {}, {"post_date": stored}), "print 2026-10-14 16:05:00")
        self.assertEqual(result["outputs"]["status"], "ok")
        self.assertEqual(result["outputs"]["screenshots"], [str(logged)])
        self.assertIn("YYYY-MM-DD HH:MM:SS", result["outputs"]["prompt"])
        self.assertIn('"value"', result["outputs"]["prompt"])

    def test_a_non_timestamp_is_blocked(self) -> None:
        class Page:
            def screenshot(self, **_kwargs: object) -> bytes:
                return b"jpeg"

        class Tab:
            page = Page()

        with tempfile.TemporaryDirectory() as tmp, patch(
            "cg_loop.gemma.extract_image",
            return_value=parse_extraction('{"value": "tomorrow"}'),
        ):
            result = run_browser_gemma(
                {"browser": Tab(), "data": tmp, "env": {}, "variables": {}},
                "lmstudio-gemma-4",
                "extract scheduled latest date in YYYY-MM-DD HH:MM:SS format",
                "post_date",
            )
        self.assertTrue(result["blocked"])
        self.assertIn("tomorrow", result["outputs"]["message"])

    def test_compiles_without_asking_jev(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_post:\n  - " + LINE + "\n",
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_post"]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("run_browser_gemma(ctx,", text)
            self.assertIn("'lmstudio-gemma-4'", text)
            self.assertIn("'post_date'", text)
            self.assertNotIn("browser_helper", text)


class OpenRouterParseTest(unittest.TestCase):
    def test_browser_keeps_the_model_id(self) -> None:
        step = parse_step(
            "/browser /openrouter-google/gemma-3-27b-it read the calendar into $post_date"
        )
        self.assertEqual(step.kind, "browser_gemma")
        self.assertEqual(step.tool, "browser")
        self.assertEqual(step.command, "openrouter-google/gemma-3-27b-it")
        self.assertEqual(step.extra, "read the calendar")
        self.assertEqual(step.var, "post_date")

    def test_text_call_does_not_need_a_browser(self) -> None:
        step = parse_step("/openrouter-deepseek/deepseek-v3.2 summarize the notes into $plan")
        self.assertEqual(step.kind, "openrouter")
        self.assertEqual(step.tool, "openrouter")
        self.assertEqual(step.command, "openrouter-deepseek/deepseek-v3.2")
        self.assertEqual(step.extra, "summarize the notes")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_ask:\n  - /openrouter-meta/muse-spark-1.2-contributor answer into $reply\n",
                encoding="utf-8",
            )
            workflow = load_workflow(path)
        self.assertFalse(_workflow_needs_browser(workflow))

    def test_missing_into_is_an_error(self) -> None:
        with self.assertRaises(ValueError) as caught:
            parse_step("/openrouter-deepseek/deepseek-v3.2 summarize the notes")
        self.assertIn("into $", str(caught.exception))
        with self.assertRaises(ValueError):
            parse_step("/openrouter-gemma hello into $reply")
        with self.assertRaises(ValueError):
            parse_step("/browser /openrouter-google/gemma-3-27b-it read this")


class OpenRouterCallTest(unittest.TestCase):
    def _response(self, payload: bytes) -> object:
        class Response:
            def __enter__(self) -> "Response":
                return self

            def __exit__(self, *exc: object) -> bool:
                return False

            def read(self) -> bytes:
                return payload

        return Response

    def test_text_call_posts_no_image(self) -> None:
        captured: dict = {}

        def fake_open(request: object, timeout: float = 0) -> object:
            captured["url"] = request.full_url  # type: ignore[attr-defined]
            captured["body"] = json.loads(request.data.decode("utf-8"))  # type: ignore[attr-defined]
            captured["title"] = request.get_header("X-openrouter-title")  # type: ignore[attr-defined]
            captured["timeout"] = timeout
            return self._response(b'{"choices":[{"message":{"content":"the reply"}}]}')()

        with patch("cg_loop.gemma.urllib.request.urlopen", fake_open):
            found = complete_text(
                "openrouter-meta/muse-spark-1.2-contributor",
                "summarize the notes",
                {"OPENROUTER_API_KEY": "test-key"},
            )
        self.assertEqual(found["text"], "the reply")
        self.assertEqual(found["model"], "meta/muse-spark-1.2-contributor")
        self.assertEqual(captured["url"], "https://openrouter.ai/api/v1/chat/completions")
        self.assertEqual(captured["body"]["model"], "meta/muse-spark-1.2-contributor")
        self.assertEqual(captured["body"]["messages"][0]["content"], "summarize the notes")
        self.assertEqual(captured["title"], "cg-loop")
        self.assertEqual(captured["timeout"], gemma.REQUEST_TIMEOUT)

    def test_browser_call_posts_the_screenshot(self) -> None:
        captured: dict = {}

        def fake_open(request: object, timeout: float = 0) -> object:
            captured["url"] = request.full_url  # type: ignore[attr-defined]
            captured["body"] = json.loads(request.data.decode("utf-8"))  # type: ignore[attr-defined]
            return self._response(b'{"choices":[{"message":{"content":"{\\"value\\": \\"2026-10-14 16:05:00\\"}"}}]}')()

        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "shot.jpg"
            image.write_bytes(b"jpeg")
            with patch("cg_loop.gemma.urllib.request.urlopen", fake_open):
                found = gemma.extract_image(
                    "openrouter-google/gemma-3-27b-it",
                    "extract the date in YYYY-MM-DD HH:MM:SS format",
                    str(image),
                    {"OPENROUTER_API_KEY": "test-key"},
                )
        self.assertEqual(found["text"], "2026-10-14 16:05:00")
        self.assertEqual(captured["url"], "https://openrouter.ai/api/v1/chat/completions")
        self.assertEqual(captured["body"]["model"], "google/gemma-3-27b-it")
        content = captured["body"]["messages"][0]["content"]
        self.assertTrue(content[1]["image_url"]["url"].startswith("data:image/jpeg;base64,"))

    def test_missing_key_is_an_error(self) -> None:
        with self.assertRaises(RuntimeError) as caught:
            complete_text("openrouter-google/gemma-3-27b-it", "hi", {"OPENROUTER_API_KEY": ""})
        self.assertIn("OPENROUTER_API_KEY", str(caught.exception))

    def test_text_runner_stores_the_reply(self) -> None:
        def fake(slug: str, instruction: str, env: dict | None = None) -> dict:
            self.assertEqual(slug, "openrouter-deepseek/deepseek-v3.2")
            self.assertEqual(instruction, "summarize the notes")
            return {"text": "done", "raw": "done", "value": "done", "model": "deepseek/deepseek-v3.2"}

        with patch("cg_loop.gemma.complete_text", fake):
            result = run_openrouter(
                {"dry_run": False, "env": {}, "variables": {}},
                "openrouter-deepseek/deepseek-v3.2",
                "summarize the notes",
                "plan",
            )
        self.assertEqual(result["outputs"]["status"], "ok")
        self.assertEqual(result["variables"]["plan"]["text"], "done")
        self.assertNotIn("screenshots", result["outputs"])
        self.assertEqual(
            expand_command("print $plan", {}, {"plan": result["variables"]["plan"]}),
            "print done",
        )

    def test_text_runner_reads_a_markdown_prompt(self) -> None:
        def fake(slug: str, instruction: str, env: dict | None = None) -> dict:
            self.assertEqual(instruction, "Title: Night Market\nLength: 2000")
            return {"text": "done", "raw": "done", "value": "done", "model": "meta/muse"}

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "story-prompt.md"
            path.write_text("Title: $STORY_TITLE\nLength: $STORY_WORDS\n", encoding="utf-8")
            with patch("cg_loop.gemma.complete_text", fake):
                result = run_openrouter(
                    {
                        "dry_run": False,
                        "env": {"STORY_WORDS": "2000"},
                        "variables": {"STORY_TITLE": "Night Market"},
                    },
                    "openrouter-meta/muse-spark-1.2-contributor",
                    str(path),
                    "story",
                )
        self.assertEqual(result["outputs"]["status"], "ok")
        self.assertEqual(result["inputs"]["prompt"], "Title: Night Market\nLength: 2000")
        self.assertTrue(result["inputs"]["prompt_file"].endswith("story-prompt.md"))

    def test_done_does_not_call_the_model(self) -> None:
        with patch("cg_loop.gemma.complete_text") as complete:
            result = run_openrouter(
                {"dry_run": False, "env": {}, "variables": {}},
                "openrouter-meta/muse-spark-1.2-contributor",
                "DONE",
                "story_idea",
            )
        complete.assert_not_called()
        self.assertEqual(result["variables"]["story_idea"]["value"], "DONE")

    def test_compiles_without_a_browser(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_ask:\n"
                "  - /openrouter-google/gemma-3-27b-it name the day into $day\n",
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_ask"]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("run_openrouter(ctx,", text)
            self.assertIn("openrouter-google/gemma-3-27b-it", text)
            self.assertNotIn("browser_helper", text)
            self.assertNotIn("run_browser_gemma", text)


if __name__ == "__main__":
    unittest.main()
