"""One background process for local models.

Jobs talk to it over a Unix socket. The first request for a model loads the
weights. A later request, including from another run, uses those weights.
Locate, Clef, Hug, Laya, and Von share this process.

The process starts on the first job that needs it, or from the Models tab.
It stays up until it is stopped. `CG_LOOP_RESIDENT=1` turns the job path on.
"""

from __future__ import annotations

import gc
import json
import os
import select
import shutil
import signal
import socket
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any

_SERVING = False
_META: dict[str, dict[str, Any]] = {}
_UNLOAD_FAILED: set[str] = set()
_SWEEP_SECONDS = 5.0
_READY = False
_PING_TIMEOUT = 2.0
_START_TIMEOUT = 30.0
_CALL_TIMEOUT = 600.0
_READ_LIMIT = 32_000_000


def use_resident() -> bool:
    """True when this job should call the background process."""
    if _SERVING:
        return False
    return os.environ.get("CG_LOOP_RESIDENT", "").strip().lower() in {"1", "true", "yes", "on"}


def serving() -> bool:
    """True inside the background process."""
    return _SERVING


def catalog() -> list[dict[str, str]]:
    """Every local model. Configured ids keep their tool and kind.

    A repo in the Hugging Face cache is listed even when it is not in the
    tool config. OpenRouter ids are left out.
    """
    from .clef import DEFAULT_CLEF_MODEL
    from .hug import _BUILTIN
    from .locate import MODEL_ID

    locate_id = MODEL_ID
    clef_id = DEFAULT_CLEF_MODEL
    hug_rows: list[tuple[str, str]] = []
    try:
        from .app_config import tool_model, tool_models

        locate_id = tool_model("locate") or locate_id
        clef_id = tool_model("clef") or clef_id
        hug_rows = [(spec.name, spec.kind or "text") for spec in tool_models("hug").values()]
    except Exception:
        hug_rows = []
    rows: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(model_id: str, tool: str, kind: str) -> None:
        name = (model_id or "").strip()
        if not name or name in seen:
            return
        if tool not in {"laya", "von"} and not _local_hf(name):
            return
        seen.add(name)
        rows.append({"id": name, "tool": tool, "kind": kind or "text"})

    add(locate_id, "locate", "image")
    add(clef_id, "clef", "image")
    for name, kind in hug_rows:
        add(name, "hug", kind)
    for spec in _BUILTIN.values():
        add(spec.name, "hug", spec.kind)
    for model_id in _cached_model_ids():
        add(model_id, "hug", _kind_on_disk(model_id))
    add("laya", "laya", "decision")
    add("von", "von", "decision")
    return rows


def disk_bytes(model_id: str, tool: str) -> int:
    """Bytes on disk for one model. Hugging Face blobs are counted once."""
    if tool == "laya":
        return _package_bytes("laya")
    if tool == "von":
        return _package_bytes("von")
    return _tree_bytes(_hf_repo(model_id))


def folder_report(model_id: str) -> dict[str, Any]:
    """Absolute folder for one model. The Models tab opens this in Finder."""
    name = (model_id or "").strip()
    entry = _known(name)
    folder = _model_folder(entry["id"], entry["tool"])
    if folder is None:
        raise RuntimeError(f"{name} has no folder on disk")
    return {"ok": True, "path": str(folder)}


def status_report() -> dict[str, Any]:
    """The table the Models tab shows. This does not start the process.

    A running process reports which weights are loaded. The rows themselves
    come from the current catalog, so a model saved on disk shows up without
    waiting for that process to restart.
    """
    payload: dict[str, Any] | None = None
    if _ping() is not None:
        try:
            found = _rpc({"cmd": "status"}, timeout=30)
        except OSError:
            found = None
        if isinstance(found, dict) and found.get("ok"):
            payload = found
    if payload is None:
        pid = _read_pid() if _pid_alive() else None
        payload = {
            "ok": True,
            "running": pid is not None,
            "pid": pid,
            "rss_bytes": _process_rss(pid) if pid else 0,
            **_policy_fields(),
        }
    live_rows = payload.get("models") if isinstance(payload.get("models"), list) else []
    payload["models"] = _catalog_rows(live_rows)
    return payload


def load_report(model_id: str) -> dict[str, Any]:
    """Start the process if needed, load `model_id`, and return the table."""
    _ensure_started()
    payload = _rpc({"cmd": "load", "id": model_id, "download": True}, timeout=_CALL_TIMEOUT)
    if payload.get("error"):
        raise RuntimeError(str(payload["error"]))
    return payload


def unload_report(model_id: str) -> dict[str, Any]:
    """Drop one loaded model and return the table."""
    if _ping() is None and not _pid_alive():
        return status_report()
    _ensure_started()
    payload = _rpc({"cmd": "unload", "id": model_id}, timeout=60)
    if payload.get("error"):
        raise RuntimeError(str(payload["error"]))
    return payload


def delete_report(model_id: str) -> dict[str, Any]:
    """Unload one model if it is loaded, delete its files, and return the table."""
    name = (model_id or "").strip()
    if not name:
        raise RuntimeError("delete needs a model id")
    entry = _known(name)
    if entry["tool"] in {"laya", "von"}:
        raise RuntimeError(f"{name} is installed with the app")
    if _ping() is not None:
        payload = _rpc({"cmd": "unload", "id": name}, timeout=60)
        if payload.get("error"):
            raise RuntimeError(str(payload["error"]))
    if not _delete_cached_repo(name):
        raise RuntimeError(f"{name} is not on disk")
    return status_report()


def stop_report() -> dict[str, Any]:
    """Kill the background process and return the table."""
    _force_stop()
    return status_report()


def restart_report() -> dict[str, Any]:
    """Kill the process and start a fresh one. Loaded weights are dropped."""
    _force_stop()
    _ensure_started()
    return status_report()


def chat_report(
    model_id: str,
    message: str,
    files: list[str] | None = None,
    messages: list[Any] | None = None,
) -> dict[str, Any]:
    """Ask one local model. The reply is text, or an image path for a drawing model.

    `messages` is the thread so far. This turn is added to it, so a follow-up
    sees the earlier exchange. A vision, locate, or clef model reads the
    uploaded files. Laya and Von do not take a chat message. The weights load
    in the background process.
    """
    name = (model_id or "").strip()
    entry = _known(name)
    paths = _existing_files(list(files or []))
    prompt = message or ""
    if not prompt.strip() and not paths and not _chat_thread(messages):
        raise RuntimeError("chat needs a message")
    tool = entry["tool"]
    kind = entry["kind"]
    if tool in {"laya", "von"}:
        raise RuntimeError(f"{name} does not take a chat message")
    if tool in {"locate", "clef"} and not paths:
        raise RuntimeError(f"{name} needs an image")
    thread = _chat_thread(messages)
    if prompt.strip():
        thread.append({"role": "user", "content": prompt.strip()})
    elif paths and (not thread or thread[-1]["role"] != "user"):
        thread.append({"role": "user", "content": "Describe this image."})
    _ensure_started()
    image = ""
    if tool == "hug":
        request: dict[str, Any] = {
            "cmd": "hug",
            "model": name,
            "message": _picture_prompt(prompt, thread) if kind == "generate" else prompt,
            "files": paths,
            "download": True,
        }
        if kind != "generate" and len(thread) > 1:
            request["messages"] = thread
        if kind == "generate":
            folder = _runtime_dir() / "chat"
            folder.mkdir(parents=True, exist_ok=True)
            request["out"] = str(folder / f"{uuid.uuid4().hex}.png")
        payload = _rpc(request, timeout=_CALL_TIMEOUT)
        if payload.get("error"):
            raise RuntimeError(str(payload["error"]))
        text = str(payload.get("text") or "")
        drawn = Path(text).expanduser() if kind == "generate" and text else None
        if drawn is not None and drawn.is_file():
            image = str(drawn)
            text = ""
    elif tool == "locate":
        payload = _rpc(
            {"cmd": "locate", "query": _plain_thread(thread) or prompt, "image": paths[0]},
            timeout=_CALL_TIMEOUT,
        )
        if payload.get("error"):
            raise RuntimeError(str(payload["error"]))
        text, image = _chat_locate(payload.get("result"))
    elif tool == "clef":
        payload = _rpc(
            {
                "cmd": "clef",
                "model": name,
                "question": _plain_thread(thread) or prompt,
                "image": paths[0],
            },
            timeout=_CALL_TIMEOUT,
        )
        if payload.get("error"):
            raise RuntimeError(str(payload["error"]))
        text = str(payload.get("answer") or "")
    else:
        raise RuntimeError(f"{name} does not take a chat message")
    return {"ok": True, "model": name, "text": text, "image": image}


def _chat_thread(messages: list[Any] | None) -> list[dict[str, str]]:
    """Earlier turns. The current message is appended by the caller."""
    thread: list[dict[str, str]] = []
    for item in messages or []:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        if role == "model":
            role = "assistant"
        if role not in {"system", "user", "assistant"}:
            continue
        content = item.get("content")
        text = content.strip() if isinstance(content, str) else ""
        if text:
            thread.append({"role": role, "content": text})
    return thread


def _plain_thread(thread: list[dict[str, str]]) -> str:
    """One prompt for a model that takes a single question."""
    if not thread:
        return ""
    if len(thread) == 1 and thread[0]["role"] == "user":
        return thread[0]["content"]
    labels = {"system": "System", "user": "User", "assistant": "Assistant"}
    return "\n\n".join(f"{labels[item['role']]}: {item['content']}" for item in thread)


def _picture_prompt(message: str, thread: list[dict[str, str]]) -> str:
    """Drawing prompt. A follow-up keeps the earlier requests."""
    users = [
        item["content"]
        for item in thread
        if item["role"] == "user" and item["content"] not in {"", "[image]"}
    ]
    if len(users) <= 1:
        return message or (users[0] if users else "")
    return "\n\n".join(users)


def _existing_files(files: list[str]) -> list[str]:
    paths: list[str] = []
    for item in files:
        raw = str(item or "").strip()
        if not raw:
            continue
        path = Path(raw).expanduser()
        if not path.is_file():
            raise RuntimeError(f"file not found: {raw}")
        paths.append(str(path))
    return paths


def _chat_locate(result: Any) -> tuple[str, str]:
    if not isinstance(result, dict):
        return str(result or ""), ""
    marked = str(result.get("marked") or "")
    image = str(Path(marked).expanduser()) if marked and Path(marked).expanduser().is_file() else ""
    text = str(result.get("text") or "").strip()
    if not text:
        text = json.dumps(result, default=_json_default)
    return text, image


def call(cmd: str, fields: dict[str, Any] | None = None, *, timeout: float = _CALL_TIMEOUT) -> dict[str, Any]:
    """Send one request. The process starts when it is not already up."""
    _ensure_started()
    payload = _rpc({"cmd": cmd, **(fields or {})}, timeout=timeout)
    if payload.get("error"):
        raise RuntimeError(str(payload["error"]))
    return payload


def announce(payload: dict[str, Any], model_id: str) -> None:
    """Write one line to the job log. `ready` means the weights were already loaded."""
    state = "ready" if payload.get("reused") else "loaded"
    print(f"MODELS {state} {model_id}", flush=True)


def spill_image(image: bytes) -> Path:
    """Write image bytes where the background process can read them."""
    folder = _runtime_dir() / "images"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{uuid.uuid4().hex}.img"
    path.write_bytes(image)
    return path


def _local_hf(model_id: str) -> bool:
    name = (model_id or "").strip()
    if not name or name.startswith("openrouter/") or any(ch.isspace() for ch in name):
        return False
    return "/" in name


def _known(model_id: str) -> dict[str, str]:
    name = (model_id or "").strip()
    for entry in catalog():
        if entry["id"] == name:
            return entry
    if name.startswith("openrouter/"):
        raise RuntimeError(f"{name} is not a local model")
    if _local_hf(name):
        return {"id": name, "tool": "hug", "kind": "text"}
    raise RuntimeError(f"unknown local model {name}")


def _model_url(model_id: str) -> str:
    """Hugging Face page for a repo id. Built-in names such as laya have none."""
    name = (model_id or "").strip()
    if not name or "/" not in name or any(ch.isspace() for ch in name):
        return ""
    return "https://huggingface.co/" + name


def _accepts_files(entry: dict[str, str]) -> bool:
    """True when a chat can attach an image for the model to read."""
    tool = entry.get("tool") or ""
    kind = entry.get("kind") or ""
    if tool in {"locate", "clef"}:
        return True
    return tool == "hug" and kind == "image"


def _public_row(entry: dict[str, str], meta: dict[str, Any] | None) -> dict[str, Any]:
    size = disk_bytes(entry["id"], entry["tool"])
    if meta is not None:
        status = "loaded"
    elif size > 0:
        status = "on disk"
    else:
        status = "missing"
    loaded_at = ""
    memory = 0
    if meta is not None:
        memory = int(meta.get("memory_bytes") or 0)
        stamp = float(meta.get("loaded_at") or 0)
        if stamp:
            loaded_at = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(stamp))
    return {
        "id": entry["id"],
        "tool": entry["tool"],
        "kind": entry["kind"],
        "url": _model_url(entry["id"]),
        "files": _accepts_files(entry),
        "status": status,
        "disk_bytes": size,
        "memory_bytes": memory,
        "loaded_at": loaded_at,
        "path": _folder_text(entry["id"], entry["tool"]),
    }


def _status_payload() -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry in catalog():
        seen.add(entry["id"])
        rows.append(_public_row(entry, _META.get(entry["id"])))
    for model_id, meta in _META.items():
        if model_id in seen:
            continue
        rows.append(_public_row(_known(model_id), meta))
    return {
        "ok": True,
        "running": True,
        "pid": os.getpid(),
        "rss_bytes": _rss_bytes(),
        "models": rows,
        **_policy_fields(),
    }


def memory_policy() -> tuple[bool, int]:
    """Whether unused models unload, and the system-memory percent that triggers it.

    A missing file uses the same defaults as Settings: on, at 80%.
    """
    path = _runtime_dir() / "memory.json"
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return True, 80
    if not isinstance(raw, dict):
        return True, 80
    smart = raw.get("smart", True)
    if not isinstance(smart, bool):
        smart = True
    try:
        limit = int(raw.get("limit", 80))
    except (TypeError, ValueError):
        limit = 80
    return smart, min(95, max(50, limit))


def system_memory_percent() -> float:
    """Percent of system memory that is not free, speculative, or inactive."""
    try:
        if sys.platform == "darwin":
            pagesize = int(subprocess.check_output(["sysctl", "-n", "hw.pagesize"], text=True).strip())
            total = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True).strip())
            text = subprocess.check_output(["vm_stat"], text=True)
            return _percent_from_pages(total, pagesize, text)
        if sys.platform.startswith("linux"):
            return _percent_from_meminfo(Path("/proc/meminfo").read_text(encoding="utf-8"))
    except (OSError, ValueError, subprocess.SubprocessError):
        return 0.0
    return 0.0


def _percent_from_pages(total: int, pagesize: int, text: str) -> float:
    pages: dict[str, int] = {}
    for line in text.splitlines():
        if ":" not in line:
            continue
        name, value = line.split(":", 1)
        number = value.strip().rstrip(".").replace(",", "")
        try:
            pages[name.strip()] = int(number)
        except ValueError:
            continue
    free = pages.get("Pages free", 0) + pages.get("Pages speculative", 0) + pages.get("Pages inactive", 0)
    if total <= 0 or pagesize <= 0:
        return 0.0
    available = free * pagesize
    return max(0, total - available) * 100.0 / total


def _percent_from_meminfo(text: str) -> float:
    values: dict[str, int] = {}
    for line in text.splitlines():
        if ":" not in line:
            continue
        name, value = line.split(":", 1)
        parts = value.split()
        if not parts:
            continue
        try:
            values[name.strip()] = int(parts[0])
        except ValueError:
            continue
    total = values.get("MemTotal", 0)
    available = values.get("MemAvailable")
    if total <= 0 or available is None:
        return 0.0
    return max(0, total - available) * 100.0 / total


def _policy_fields() -> dict[str, Any]:
    smart, limit = memory_policy()
    return {
        "smart_memory": smart,
        "memory_limit": limit,
        "system_memory": round(system_memory_percent(), 1),
    }


def _request_model(request: dict[str, Any]) -> str:
    """The model this request is about to use. A sweep must leave it loaded."""
    cmd = str(request.get("cmd") or "")
    if cmd == "load":
        return str(request.get("id") or "").strip()
    if cmd == "hug":
        return str(request.get("model") or "").strip()
    if cmd == "clef":
        return str(request.get("model") or "").strip()
    if cmd in {"laya", "von"}:
        return cmd
    if cmd == "locate":
        model_id = (os.environ.get("LOCATE_MODEL") or "").strip()
        if model_id:
            return model_id
        for entry in catalog():
            if entry["tool"] == "locate":
                return entry["id"]
    return ""


def _sweep(keep: str = "") -> list[str]:
    """Unload least-recently-used models until system memory is under the limit."""
    smart, limit = memory_policy()
    if not smart:
        return []
    freed: list[str] = []
    failed: set[str] = set()
    while system_memory_percent() >= limit:
        candidates = [
            (float(meta.get("used_at") or meta.get("loaded_at") or 0), model_id)
            for model_id, meta in _META.items()
            if model_id != keep and model_id not in failed
        ]
        if not candidates:
            break
        candidates.sort()
        model_id = candidates[0][1]
        percent = system_memory_percent()
        try:
            _unload(model_id)
        except Exception as exc:
            failed.add(model_id)
            if model_id not in _UNLOAD_FAILED:
                _UNLOAD_FAILED.add(model_id)
                print(f"MODELS keep {model_id}: {exc}", flush=True)
            continue
        freed.append(model_id)
        print(f"MODELS unload {model_id} memory {percent:.0f}%", flush=True)
    return freed


def _touch(model_id: str, *, download: bool) -> bool:
    """Load when missing. Return True when the weights were already resident."""
    if model_id in _META:
        _META[model_id]["used_at"] = time.time()
        return True
    _activate(model_id, download=download)
    return False


def _activate(model_id: str, *, download: bool) -> None:
    if model_id in _META:
        return
    row = _known(model_id)
    print(f"MODELS load {row['tool']} {model_id}", flush=True)
    before = _rss_bytes()
    _load_into_process(row, download=download)
    after = _rss_bytes()
    now = time.time()
    _META[model_id] = {"memory_bytes": max(0, after - before), "loaded_at": now, "used_at": now}


def _load_into_process(row: dict[str, str], *, download: bool) -> None:
    tool = row["tool"]
    model_id = row["id"]
    if tool == "locate":
        _load_locate(model_id)
    elif tool == "clef":
        from .clef import ensure_clef_model

        ensure_clef_model(model_id)
    elif tool == "hug":
        _load_hug(model_id, download=download)
    elif tool == "laya":
        from .model import ensure_laya_router

        ensure_laya_router()
    elif tool == "von":
        from .model import _load_von_weights

        _load_von_weights()
    else:
        raise RuntimeError(f"{model_id} has no loader")


def _load_locate(model_id: str) -> None:
    from . import locate

    os.environ["LOCATE_MODEL"] = model_id
    if locate._MODEL is not None:
        return
    try:
        locate._model()
    except ImportError:
        from .model import _install_package

        _install_package("mlx-vlm")
        _install_package("pillow")
        locate._model()


def _load_hug(model_id: str, *, download: bool) -> None:
    from . import hug

    spec = hug.runtime_spec(model_id)
    if hug.runtime_backend(spec) == "diffusers":
        hug._ensure_diffusers_loaded(model_id, download=download)
    elif spec.kind == "generate":
        hug._ensure_generate_loaded(model_id, download=download)
    elif spec.kind == "image":
        _generate, load = hug._load_image_backend(model_id, download=download)
        hug._cached("image", model_id, load)
    else:
        _generate, load = hug._load_text_backend(model_id, download=download)
        hug._cached("text", model_id, load)


def _unload(model_id: str) -> None:
    row = _known(model_id)
    tool = row["tool"]
    if tool == "locate":
        from . import locate

        locate._MODEL = None
    elif tool == "clef":
        from . import clef

        clef._MODEL = None
        clef._MODEL_ID = ""
    elif tool == "hug":
        from . import hug

        for key in list(hug._LOADED):
            if len(key) >= 2 and key[1] == model_id:
                hug._LOADED.pop(key, None)
    elif tool == "laya":
        from . import model

        model._LAYA_ROUTER = None
    elif tool == "von":
        raise RuntimeError("von stays loaded until the models process stops")
    _META.pop(model_id, None)
    gc.collect()
    try:
        import mlx.core as mx

        clearer = getattr(getattr(mx, "metal", None), "clear_cache", None)
        if callable(clearer):
            clearer()
    except Exception:
        return


def _handle(request: dict[str, Any]) -> dict[str, Any]:
    from .app_config import apply_model_storage

    apply_model_storage()
    cmd = str(request.get("cmd") or "")
    if cmd == "ping":
        return {"ok": True, "pid": os.getpid(), "rss_bytes": _rss_bytes()}
    if cmd == "status":
        return _status_payload()
    if cmd == "load":
        model_id = str(request.get("id") or "").strip()
        if not model_id:
            raise RuntimeError("load needs a model id")
        _activate(model_id, download=_download_flag(request))
        return _status_payload()
    if cmd == "unload":
        model_id = str(request.get("id") or "").strip()
        if not model_id:
            raise RuntimeError("unload needs a model id")
        _unload(model_id)
        return _status_payload()
    if cmd == "hug":
        return _hug_command(request)
    if cmd == "locate":
        return _locate_command(request)
    if cmd == "clef":
        return _clef_command(request)
    if cmd == "laya":
        return _decision_command("laya", request)
    if cmd == "von":
        return _decision_command("von", request)
    raise RuntimeError(f"unknown models command {cmd}")


def _optional_int(value: Any) -> int | None:
    if isinstance(value, bool) or value is None or value == "":
        return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    if number <= 0:
        return None
    return number


def _download_flag(request: dict[str, Any]) -> bool:
    if "download" in request:
        return bool(request.get("download"))
    from .hug import hug_download_enabled

    return hug_download_enabled(None)


def _hug_command(request: dict[str, Any]) -> dict[str, Any]:
    from . import hug

    model_id = str(request.get("model") or "").strip()
    reused = _touch(model_id, download=_download_flag(request))
    message = str(request.get("message") or "")
    files = [str(item) for item in request.get("files") or []]
    out = str(request.get("out") or "")
    raw_params = request.get("params") or {}
    extra: dict[str, str] = {}
    if isinstance(raw_params, dict):
        extra = {str(key): "" if value is None else str(value) for key, value in raw_params.items()}
    spec = hug.runtime_spec(model_id)
    raw_messages = request.get("messages")
    messages = raw_messages if isinstance(raw_messages, list) else None
    if spec.kind == "generate":
        text = hug._generate_picture(
            model_id, message, out, download=_download_flag(request), extra=extra
        )
    elif spec.kind == "image":
        text = hug._generate_image(
            model_id, message, files, download=False, extra=extra, messages=messages
        )
    else:
        text = hug._generate_text(
            model_id,
            message,
            download=False,
            extra=extra,
            messages=messages,
            max_tokens=_optional_int(request.get("max_tokens")),
        )
    return {"ok": True, "reused": reused, "text": text}


def _locate_command(request: dict[str, Any]) -> dict[str, Any]:
    from . import locate

    model_id = (os.environ.get("LOCATE_MODEL") or "").strip()
    if not model_id:
        for entry in catalog():
            if entry["tool"] == "locate":
                model_id = entry["id"]
                break
    if not model_id:
        from .locate import MODEL_ID

        model_id = MODEL_ID
    reused = _touch(model_id, download=True)
    found = locate._locate_local(str(request.get("query") or ""), Path(str(request.get("image") or "")))
    return {"ok": True, "reused": reused, "result": found}


def _clef_command(request: dict[str, Any]) -> dict[str, Any]:
    from .clef import DEFAULT_CLEF_MODEL, ask_clef

    model_id = str(request.get("model") or DEFAULT_CLEF_MODEL).strip() or DEFAULT_CLEF_MODEL
    reused = _touch(model_id, download=True)
    options = request.get("options") or []
    if not isinstance(options, list):
        options = []
    image_path = Path(str(request.get("image") or ""))
    answer, score = ask_clef(
        str(request.get("question") or ""),
        [str(item) for item in options],
        image_path.read_bytes(),
        state=str(request.get("state") or ""),
        env={"CLEF_MODEL": model_id},
    )
    return {"ok": True, "reused": reused, "answer": answer, "score": score}


def _decision_command(name: str, request: dict[str, Any]) -> dict[str, Any]:
    from . import model

    reused = _touch(name, download=True)
    body = {
        "model": name,
        "state": request.get("state") or {},
        "questions": request.get("questions") or {},
    }
    if name == "von":
        result = model._von_post(body)
    else:
        result = model._laya_post(body)
    return {"ok": True, "reused": reused, "result": result}


def _hub_dir() -> Path:
    """The Hugging Face hub cache. Settings win, then the usual cache variables."""
    from .app_config import model_storage_dir

    chosen = model_storage_dir()
    if chosen is not None:
        return chosen / "hub"
    explicit = (os.environ.get("HF_HUB_CACHE") or "").strip()
    if explicit:
        return Path(explicit).expanduser()
    home = (os.environ.get("HF_HOME") or "").strip()
    if home:
        return Path(home).expanduser() / "hub"
    return Path.home() / ".cache" / "huggingface" / "hub"


def _hf_repo(model_id: str) -> Path:
    return _hub_dir() / ("models--" + model_id.replace("/", "--"))


def _delete_cached_repo(model_id: str) -> bool:
    """Remove one cached repo and the blobs only that repo used."""
    hub = _hub_dir()
    folder = _hf_repo(model_id)
    if not hub.is_dir() or not folder.exists():
        return False
    _drop_revisions(model_id, hub)
    if folder.exists():
        _remove_tree(folder)
    lock = hub / ".locks" / folder.name
    if lock.exists():
        _remove_tree(lock)
    return True


def _drop_revisions(model_id: str, hub: Path) -> None:
    try:
        from huggingface_hub import scan_cache_dir
    except ImportError:
        return
    try:
        info = scan_cache_dir(hub)
    except Exception:
        return
    hashes = [
        revision.commit_hash
        for repo in info.repos
        if repo.repo_id == model_id and repo.repo_type == "model"
        for revision in repo.revisions
    ]
    if hashes:
        info.delete_revisions(*hashes).execute()


def _remove_tree(path: Path) -> None:
    """Delete a cache folder. The path has to stay inside the hub directory."""
    hub = _hub_dir().resolve()
    if path.is_symlink():
        raise RuntimeError(f"refusing to delete {path}")
    target = path.resolve()
    if target == hub or hub not in target.parents:
        raise RuntimeError(f"refusing to delete {target}")
    allowed = target.name.startswith("models--") or (
        target.parent.name == ".locks" and target.parent.parent == hub and target.name.startswith("models--")
    )
    if not allowed:
        raise RuntimeError(f"refusing to delete {target}")
    shutil.rmtree(target)


def _cached_model_ids() -> list[str]:
    """Repo ids that already have a folder in the hub cache."""
    hub = _hub_dir()
    if not hub.is_dir():
        return []
    found: list[str] = []
    try:
        folders = sorted(hub.iterdir(), key=lambda path: path.name.lower())
    except OSError:
        return []
    for path in folders:
        if not path.is_dir() or not path.name.startswith("models--"):
            continue
        model_id = _repo_id_from_folder(path.name)
        if model_id:
            found.append(model_id)
    return found


def _repo_id_from_folder(folder: str) -> str:
    rest = folder[len("models--") :]
    org, sep, name = rest.partition("--")
    if not sep or not org or not name or "/" in org or "/" in name:
        return ""
    return f"{org}/{name}"


def _kind_on_disk(model_id: str) -> str:
    """Kind from files already on disk. Nothing is downloaded."""
    try:
        from .hug import _classify_repo
    except Exception:
        return "text"
    files = _local_repo_files(model_id)
    config = _local_root_config(model_id, files)
    try:
        kind, _backend = _classify_repo(files, config)
    except Exception:
        return "text"
    return kind or "text"


def _local_repo_files(model_id: str) -> list[str]:
    root = _hf_repo(model_id)
    trees = root / "trees"
    found: list[str] = []
    if trees.is_dir():
        for path in trees.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            names = list((data.get("files") or {}).keys()) if isinstance(data, dict) else []
            if len(names) > len(found):
                found = [str(name) for name in names]
    if found:
        return found
    return _snapshot_names(root)


def _snapshot_names(root: Path) -> list[str]:
    snapshots = root / "snapshots"
    if not snapshots.is_dir():
        return []
    try:
        folders = [path for path in snapshots.iterdir() if path.is_dir()]
    except OSError:
        return []
    for snapshot in folders:
        names: list[str] = []
        try:
            children = list(snapshot.iterdir())
        except OSError:
            continue
        for child in children:
            names.append(child.name)
            if child.is_dir() and child.name in {"vae", "transformer", "unet"}:
                try:
                    for item in child.iterdir():
                        names.append(f"{child.name}/{item.name}")
                except OSError:
                    continue
        if names:
            return names
    return []


def _local_root_config(model_id: str, files: list[str]) -> dict | None:
    if not any(name.replace("\\", "/") == "config.json" for name in files):
        return None
    snapshots = _hf_repo(model_id) / "snapshots"
    if not snapshots.is_dir():
        return None
    try:
        folders = [path for path in snapshots.iterdir() if path.is_dir()]
    except OSError:
        return None
    for snapshot in folders:
        path = snapshot / "config.json"
        if not path.is_file():
            continue
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return loaded if isinstance(loaded, dict) else None
    return None


def _catalog_rows(live_rows: list[Any]) -> list[dict[str, Any]]:
    """Catalog rows, with loaded memory taken from the running process."""
    live: dict[str, dict[str, Any]] = {}
    for item in live_rows:
        if isinstance(item, dict) and item.get("id"):
            live[str(item["id"])] = item
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry in catalog():
        seen.add(entry["id"])
        current = live.get(entry["id"])
        loaded = isinstance(current, dict) and current.get("status") == "loaded"
        row = _public_row(entry, {"memory_bytes": 0, "loaded_at": 0} if loaded else None)
        if loaded and current is not None:
            row["loaded_at"] = str(current.get("loaded_at") or "")
            try:
                row["memory_bytes"] = int(current.get("memory_bytes") or 0)
            except (TypeError, ValueError):
                row["memory_bytes"] = 0
        rows.append(row)
    for model_id, current in live.items():
        if model_id in seen or current.get("status") != "loaded":
            continue
        rows.append(_ensure_chat_fields(current))
    return rows


def _ensure_chat_fields(row: dict[str, Any]) -> dict[str, Any]:
    """Fill the URL and file flag when a running process omitted them."""
    item = dict(row)
    item["url"] = str(item.get("url") or _model_url(str(item.get("id") or "")))
    if "files" not in row:
        item["files"] = _accepts_files(
            {
                "id": str(item.get("id") or ""),
                "tool": str(item.get("tool") or ""),
                "kind": str(item.get("kind") or ""),
            }
        )
    else:
        item["files"] = bool(item.get("files"))
    if not item.get("path"):
        item["path"] = _folder_text(str(item.get("id") or ""), str(item.get("tool") or ""))
    return item


def _folder_text(model_id: str, tool: str) -> str:
    folder = _model_folder(model_id, tool)
    return str(folder) if folder is not None else ""


def _model_folder(model_id: str, tool: str) -> Path | None:
    """Directory Finder should open. Hugging Face repos stay in the hub cache."""
    if tool in {"laya", "von"}:
        folder = _package_dir(tool)
        return folder if folder is not None and folder.is_dir() else None
    folder = _hf_repo(model_id)
    return folder if folder.is_dir() else None


def _package_dir(name: str) -> Path | None:
    spec = _package_spec(name)
    if spec is None:
        return None
    locations = list(spec.submodule_search_locations or [])
    if locations:
        folder = Path(locations[0])
        return folder if folder.is_dir() else None
    origin = spec.origin or ""
    if origin and origin != "namespace":
        path = Path(origin)
        return path.parent if path.is_file() else None
    return None


def _package_bytes(name: str) -> int:
    spec = _package_spec(name)
    if spec is None:
        return 0
    locations = list(spec.submodule_search_locations or [])
    if locations:
        return _tree_bytes(Path(locations[0]))
    origin = spec.origin or ""
    if origin and origin != "namespace":
        path = Path(origin)
        return path.stat().st_size if path.is_file() else 0
    return 0


def _package_spec(name: str):
    import importlib.util

    try:
        return importlib.util.find_spec(name)
    except (ImportError, ValueError):
        return None


def _tree_bytes(root: Path) -> int:
    """Logical size of `root`. A blob and the snapshots that link to it count once.

    A shared-store symlink is followed, so the payload counts even when it lives
    beside the repo. A broken link adds nothing.
    """
    if not root.exists():
        return 0
    total = 0
    seen: set[tuple[int, int]] = set()
    for dirpath, _dirs, files in os.walk(root, followlinks=False):
        for name in files:
            path = Path(dirpath) / name
            try:
                info = path.stat()
            except OSError:
                continue
            key = (info.st_dev, info.st_ino)
            if key in seen:
                continue
            seen.add(key)
            total += info.st_size
    return total


def _rss_bytes() -> int:
    return _process_rss(os.getpid())


def _process_rss(pid: int | None) -> int:
    if not pid:
        return 0
    try:
        raw = subprocess.check_output(["ps", "-o", "rss=", "-p", str(pid)], text=True)
    except (OSError, subprocess.CalledProcessError, ValueError):
        return 0
    text = raw.strip().split()
    if not text:
        return 0
    try:
        return int(text[0]) * 1024
    except ValueError:
        return 0


def _runtime_dir() -> Path:
    from .app_config import models_runtime_dir

    return models_runtime_dir()


def _socket_path() -> Path:
    return _runtime_dir() / "models.sock"


def _pid_path() -> Path:
    return _runtime_dir() / "models.pid"


def _read_pid() -> int | None:
    try:
        return int(_pid_path().read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _force_stop() -> None:
    """Ask the process to exit, then kill it if it is still there."""
    global _READY
    if _ping() is not None:
        try:
            _rpc({"cmd": "stop"}, timeout=5)
        except OSError:
            pass
        _wait_dead(1.5)
    for sig in (signal.SIGTERM, signal.SIGKILL):
        pid = _read_pid()
        if pid is None or not _pid_alive() or pid == os.getpid():
            break
        _signal_pid(pid, sig)
        _wait_dead(1.5)
    if not _pid_alive():
        _pid_path().unlink(missing_ok=True)
        _socket_path().unlink(missing_ok=True)
    _READY = False


def _wait_dead(seconds: float) -> None:
    deadline = time.time() + seconds
    while time.time() < deadline and (_ping() is not None or _pid_alive()):
        time.sleep(0.05)


def _signal_pid(pid: int, sig: int) -> None:
    if pid <= 1 or pid == os.getpid():
        return
    try:
        pgid = os.getpgid(pid)
    except OSError:
        return
    try:
        if pgid == pid:
            os.killpg(pid, sig)
        else:
            os.kill(pid, sig)
    except OSError:
        return


def _pid_alive() -> bool:
    pid = _read_pid()
    if pid is None or pid == os.getpid():
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:
        stat = subprocess.check_output(["ps", "-o", "stat=", "-p", str(pid)], text=True)
    except (OSError, subprocess.CalledProcessError):
        return False
    return not stat.strip().startswith("Z")


def _ensure_started() -> None:
    """Start the model process on first use. A live process is left running.

    A process that started before the tool code or the tool config changed is
    stopped first. It would keep the old model params in memory.
    """
    global _READY
    if _process_ready() and _sources_match_process():
        _READY = True
        return
    with _lock():
        if _process_ready() and _sources_match_process():
            _READY = True
            return
        if _process_ready():
            print("MODELS restart", flush=True)
            _force_stop()
        _spawn()
        if not _wait_ping(_START_TIMEOUT):
            raise RuntimeError("local models process did not start")
        _READY = True


def _process_ready() -> bool:
    if _READY and _pid_alive():
        return True
    if _ping() is not None:
        return True
    return _pid_alive()


def _sources_match_process() -> bool:
    """True when this process started after the tool files it loaded."""
    try:
        started = _pid_path().stat().st_mtime
    except OSError:
        return False
    for path in _source_files():
        try:
            if path.stat().st_mtime > started:
                return False
        except OSError:
            continue
    return True


def _source_files() -> list[Path]:
    """The files a running models process has already imported."""
    from .app_config import app_config_path

    here = Path(__file__).resolve().parent
    return [here / "hug.py", here / "resident.py", here / "app_config.py", app_config_path()]


def _spawn() -> None:
    python = (os.environ.get("CG_LOOP_MODELS_PYTHON") or "").strip() or sys.executable
    runtime = _runtime_dir()
    runtime.mkdir(parents=True, exist_ok=True)
    sock = _socket_path()
    if sock.exists():
        sock.unlink()
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["CG_LOOP_MODELS_DIR"] = str(runtime)
    env["CG_LOOP_RESIDENT"] = "0"
    lib = str(Path(__file__).resolve().parents[1])
    previous = env.get("PYTHONPATH") or ""
    env["PYTHONPATH"] = lib if not previous else lib + os.pathsep + previous
    log = open(runtime / "models.log", "ab", buffering=0)
    subprocess.Popen(
        [python, "-m", "cg_loop.resident", "--serve"],
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=log,
        start_new_session=True,
        close_fds=True,
        env=env,
    )
    log.close()


def _wait_ping(seconds: float) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        if _ping() is not None:
            return True
        time.sleep(0.1)
    return False


def _ping() -> dict[str, Any] | None:
    try:
        payload = _rpc({"cmd": "ping"}, timeout=_PING_TIMEOUT)
    except OSError:
        return None
    if payload.get("ok"):
        return payload
    return None


def _lock() -> Any:
    import fcntl

    runtime = _runtime_dir()
    runtime.mkdir(parents=True, exist_ok=True)
    handle = open(runtime / "models.lock", "a", encoding="utf-8")
    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
    return _Lock(handle)


class _Lock:
    def __init__(self, handle: Any) -> None:
        self._handle = handle

    def __enter__(self) -> "_Lock":
        return self

    def __exit__(self, *exc: object) -> None:
        import fcntl

        fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
        self._handle.close()


def _rpc(message: dict[str, Any], *, timeout: float) -> dict[str, Any]:
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect(str(_socket_path()))
        sock.sendall((json.dumps(message) + "\n").encode("utf-8"))
        buf = b""
        while b"\n" not in buf:
            chunk = sock.recv(65536)
            if not chunk:
                break
            buf += chunk
            if len(buf) > _READ_LIMIT:
                break
    finally:
        sock.close()
    line = buf.decode("utf-8").strip()
    if not line.startswith("MODELS_JSON "):
        raise RuntimeError(f"models process returned {line[:200]!r}")
    payload = json.loads(line[len("MODELS_JSON ") :])
    if not isinstance(payload, dict):
        raise RuntimeError("models process returned a non-object")
    return payload


def _serve() -> None:
    """Answer model requests. Weights load on the first request and stay."""
    global _SERVING
    _SERVING = True
    os.environ["CG_LOOP_RESIDENT"] = "0"
    runtime = _runtime_dir()
    runtime.mkdir(parents=True, exist_ok=True)
    sock_path = _socket_path()
    if sock_path.exists():
        sock_path.unlink()
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(str(sock_path))
    try:
        os.chmod(sock_path, 0o600)
    except OSError:
        pass
    server.listen(16)
    _pid_path().write_text(str(os.getpid()), encoding="utf-8")
    print(f"MODELS serve {sock_path}", file=sys.stderr, flush=True)
    try:
        while True:
            try:
                ready, _, _ = select.select([server], [], [], _SWEEP_SECONDS)
            except (OSError, ValueError):
                break
            if not ready:
                _sweep()
                continue
            try:
                conn, _addr = server.accept()
            except OSError:
                break
            with conn:
                raw = _read_line(conn)
                if not raw:
                    continue
                try:
                    request = json.loads(raw)
                except json.JSONDecodeError as exc:
                    _send(conn, {"error": f"models request was not json: {exc}"})
                    continue
                if not isinstance(request, dict):
                    _send(conn, {"error": "models request was not an object"})
                    continue
                if request.get("cmd") == "stop":
                    _send(conn, {"ok": True, "running": False})
                    break
                try:
                    if request.get("cmd") != "ping":
                        _sweep(keep=_request_model(request))
                    _send(conn, _handle(request))
                except Exception as exc:
                    _send(conn, {"error": str(exc)})
    finally:
        _SERVING = False
        server.close()
        sock_path.unlink(missing_ok=True)
        _pid_path().unlink(missing_ok=True)


def _read_line(conn: socket.socket) -> str:
    buf = b""
    while b"\n" not in buf:
        chunk = conn.recv(65536)
        if not chunk:
            break
        buf += chunk
        if len(buf) > _READ_LIMIT:
            break
    return buf.split(b"\n", 1)[0].decode("utf-8").strip()


def _send(conn: socket.socket, payload: dict[str, Any]) -> None:
    line = "MODELS_JSON " + json.dumps(payload, default=_json_default) + "\n"
    conn.sendall(line.encode("utf-8"))


def _json_default(value: object) -> str:
    return str(value)


def main(argv: list[str] | None = None) -> None:
    from .app_config import apply_app_env

    apply_app_env()
    args = list(sys.argv[1:] if argv is None else argv)
    if "--serve" in args:
        _serve()
        return
    if "--status" in args:
        print(json.dumps(status_report()))
        return
    if "--load" in args:
        index = args.index("--load")
        if index + 1 >= len(args):
            raise SystemExit("models --load needs a model id")
        print(json.dumps(load_report(args[index + 1])))
        return
    if "--unload" in args:
        index = args.index("--unload")
        if index + 1 >= len(args):
            raise SystemExit("models --unload needs a model id")
        print(json.dumps(unload_report(args[index + 1])))
        return
    if "--delete" in args:
        index = args.index("--delete")
        if index + 1 >= len(args):
            raise SystemExit("models --delete needs a model id")
        print(json.dumps(delete_report(args[index + 1])))
        return
    if "--folder" in args:
        index = args.index("--folder")
        if index + 1 >= len(args):
            raise SystemExit("models --folder needs a model id")
        print(json.dumps(folder_report(args[index + 1])))
        return
    if "--stop" in args:
        print(json.dumps(stop_report()))
        return
    if "--restart" in args:
        print(json.dumps(restart_report()))
        return
    if "--chat" in args:
        try:
            body = json.loads(sys.stdin.read() or "{}")
        except json.JSONDecodeError as exc:
            raise SystemExit(f"models --chat needs JSON on stdin: {exc}") from exc
        if not isinstance(body, dict):
            raise SystemExit("models --chat needs a JSON object")
        raw_files = body.get("files") or []
        if not isinstance(raw_files, list):
            raise SystemExit("models --chat files must be a list")
        raw_messages = body.get("messages") or []
        if not isinstance(raw_messages, list):
            raise SystemExit("models --chat messages must be a list")
        print(
            json.dumps(
                chat_report(
                    str(body.get("id") or ""),
                    str(body.get("message") or ""),
                    [str(item) for item in raw_files],
                    messages=raw_messages,
                )
            )
        )
        return
    raise SystemExit(
        "usage: python -m cg_loop.resident --status|--serve|--load ID|--unload ID|--delete ID|--folder ID|--stop|--restart|--chat"
    )


if __name__ == "__main__":
    main()
