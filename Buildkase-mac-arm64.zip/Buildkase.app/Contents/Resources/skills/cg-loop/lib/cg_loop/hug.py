"""Ask one Hugging Face model.

`/hug +model prism-ml/Bonsai-4B-mlx-1bit +m Find location of X` sends that
prompt to Bonsai and keeps the text reply. `+m instructions.md` reads a longer
instruction from a markdown, JSON, or text file. `{{name}}` and `$name` in
that file are filled from the workflow context, so the whole prompt can live
in the file. YAML is not required. A `.yaml` file is read as text and is not
parsed. `+model` can be left off when the workflow config or a
`set-config hug-model=` already names the model.

Each model accepts its own params. A text model takes `+m`. An image model
takes `+files`. A generate model draws an image from `+m` and writes it to
`+out`. `into $var` stores that path. `requires` under `tool-details`
`hug.models` are the params that must be present. Any other `+param` is kept
even when that list does not name it. `file`, `steps`, `guidance`, and
`scheduler` on that same entry are how a diffusers model runs. A step can
replace `file`, `steps`, or `guidance`. A model that is not listed is still
loaded from the repo, and those run settings stay unset. A text repo loads
with `mlx-lm`. A vision repo loads with `mlx-vlm`. An image repo loads with
`mlx-gen` when that runtime knows the id, and with `diffusers` for a pipeline
or a single checkpoint.

Text weights load through `mlx-lm`. Image weights load through `mlx-vlm`.
Generated images load through `mlx-gen`. Jobs keep the weights in one
background process. The first use loads the model there. A later run uses
it when it is already loaded.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import shlex
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .app_config import ModelSpec
from .quoting import finditer_outside, search_outside, unquote_param

DEFAULT_HUG_MODEL = "prism-ml/Bonsai-4B-mlx-1bit"
TERNARY_BONSAI_8B = "prism-ml/Ternary-Bonsai-8B-mlx-2bit"
BONSAI2_9B = "prism-ml/Ternary-Bonsai-2-9B-mlx-2bit"
BONSAI_IMAGE = "prism-ml/bonsai-image-ternary-4B-mlx-2bit"
_MAX_TOKENS = 256
_GENERATE_WIDTH = 1024
_GENERATE_HEIGHT = 1024
_GENERATE_STEPS = 4
_GENERATE_GUIDANCE = 1.0
_GENERATE_SEED = 42
_SIZE_STEP = 16
_SIZE_LONG = 1024
_SIZE_MIN = 256
_SIZE_MAX = 2048
# Platform pixels are snapped to a multiple of 16, which is what the image model draws.
# mlx-lm's text snapshot skips these packed files. The repo has no root config.json.
# mlx-gen also requires the repo sidecars. added_tokens.json and chat_template.jinja
# live under tokenizer/ in the repo; _link_generate_sidecars copies them to the root,
# which is where mlx-gen's cache check looks.
_GENERATE_FILES = (
    "vae/*.safetensors",
    "vae/*.json",
    "transformer-packed-mflux/*.safetensors",
    "transformer-packed-mflux/*.json",
    "text_encoder-mlx-4bit/*.safetensors",
    "text_encoder-mlx-4bit/*.json",
    "tokenizer/**",
    "scheduler/*.json",
    "manifest.json",
    "README.md",
    "LICENSE",
    "NOTICE.md",
    "added_tokens.json",
    "chat_template.jinja",
)
_GENERATE_SIDECARS = ("added_tokens.json", "chat_template.jinja")
# name, width, height, aliases. A step can also pass WxH or an aspect such as 9:16.
_IMAGE_SIZES: tuple[tuple[str, int, int, tuple[str, ...]], ...] = (
    ("instagram-post", 1080, 1080, ("instagram post", "ig-post", "ig post", "post")),
    ("instagram-portrait", 1080, 1350, ("instagram portrait", "ig-portrait", "ig portrait")),
    ("instagram-landscape", 1080, 566, ("instagram landscape", "ig-landscape", "ig landscape")),
    ("instagram-story", 1080, 1920, ("instagram story", "ig-story", "ig story", "story")),
    ("instagram-reel", 1080, 1920, ("instagram reel", "ig-reel", "ig reel", "reel")),
    ("meta-ad", 1080, 1080, ("meta ad", "metaad", "facebook ad", "ad")),
    ("meta-ad-feed", 1200, 628, ("meta ad feed", "meta feed")),
    ("meta-ad-story", 1080, 1920, ("meta ad story", "meta story")),
    ("meta-ad-portrait", 1080, 1350, ("meta ad portrait", "meta portrait")),
    ("facebook-post", 1200, 630, ("facebook post",)),
    ("facebook-story", 1080, 1920, ("facebook story",)),
    ("tiktok", 1080, 1920, ("tiktok video",)),
    ("youtube-short", 1080, 1920, ("youtube short",)),
    ("youtube-thumbnail", 1280, 720, ("youtube thumbnail", "thumbnail")),
    ("linkedin-post", 1200, 627, ("linkedin post", "linkedin")),
    ("pinterest", 1000, 1500, ("pinterest pin", "pin")),
    ("x-post", 1600, 900, ("x post", "twitter", "twitter post")),
    ("square", 1024, 1024, ()),
)
_MLX_LM = "mlx-lm"
_MLX_VLM = "mlx-vlm>=0.7.8,<0.8"
_MLX_GEN = "mlx-gen"
_PRISM_MLX = "mlx @ git+https://github.com/PrismML-Eng/mlx.git@prism"
_FLAG_RE = re.compile(r"(?<!\S)\+([A-Za-z][A-Za-z0-9_-]*)\b", re.IGNORECASE)
_KNOWN_FLAGS = frozenset({"model", "m", "files", "file", "print", "out"})
_INTO_RE = re.compile(
    r"\s+into\s+\$(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*$",
    re.IGNORECASE,
)
_LOADED: dict[tuple, object] = {}
_DETECTED: dict[str, ModelSpec] = {}
# A checkpoint name that carries one of these is an image model, not mlx-lm text.
_DIFFUSION_MARKERS = (
    "sdxl",
    "sd15",
    "sd_xl",
    "stable-diffusion",
    "stable_diffusion",
    "unet",
    "lightning",
    "flux",
    "lora",
)
_PROMPT_SUFFIXES = {".md", ".markdown", ".json", ".txt", ".text", ".yaml", ".yml"}

# Used when tool-details does not list this id. An unlisted id is classified
# from the repo files at run time. See `runtime_spec`.
_BUILTIN: dict[str, ModelSpec] = {
    DEFAULT_HUG_MODEL: ModelSpec(
        name=DEFAULT_HUG_MODEL,
        kind="text",
        params=("m",),
        requires=("m",),
    ),
    TERNARY_BONSAI_8B: ModelSpec(
        name=TERNARY_BONSAI_8B,
        kind="text",
        params=("m",),
        requires=("m",),
    ),
    BONSAI2_9B: ModelSpec(
        name=BONSAI2_9B,
        kind="image",
        params=("m", "files"),
        requires=("files",),
    ),
    BONSAI_IMAGE: ModelSpec(
        name=BONSAI_IMAGE,
        kind="generate",
        params=("m", "out"),
        requires=("m",),
    ),
}


@dataclass(frozen=True)
class HugCall:
    """One `/hug` step. An empty model means the workflow `hug-model`."""

    model: str
    message: str
    files: tuple[str, ...]
    out: str
    var: str
    printed: bool = False
    extra: dict[str, str] | None = None


def parse_hug_command(body: str) -> HugCall:
    """`[+model id] [+m prompt] [+files path ...] [+out path] [+print] [+name value] [into $name]`.

    `+model` is one Hugging Face id. `+m` is the prompt, or a path to a
    markdown or text file, through the next param. `+files` is one or more
    image paths. `+file` is the same param. `+out` is where a generate model
    writes the image. `+print` writes the reply to the log. Any other `+name`
    is kept even when the model definition does not list it. `into $name`
    stores the text reply, or the image path for a generate model.
    """
    text = (body or "").strip()
    var = ""
    into = search_outside(_INTO_RE, text)
    if into:
        var = into.group("var")
        text = text[: into.start()].rstrip()
    matches = finditer_outside(_FLAG_RE, text)
    if not matches:
        raise ValueError(
            "hug needs +m or +files: "
            "/hug +model prism-ml/Bonsai-4B-mlx-1bit +m Find location of X"
        )
    leading = text[: matches[0].start()].strip()
    if leading:
        raise ValueError(
            "hug params start with +: "
            "/hug +model prism-ml/Bonsai-4B-mlx-1bit +m Find location of X"
        )
    chunks: dict[str, str] = {}
    for index, match in enumerate(matches):
        name = match.group(1).lower().replace("-", "_")
        if name == "file":
            name = "files"
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        if name in chunks:
            raise ValueError(f"hug +{name} is repeated")
        chunks[name] = text[start:end].strip()
    model = _model_token(chunks["model"]) if "model" in chunks else ""
    message = _message_text(chunks["m"]) if "m" in chunks else ""
    files = _file_list(chunks["files"]) if "files" in chunks else ()
    out = _out_text(chunks["out"]) if "out" in chunks else ""
    printed = _print_flag(chunks["print"]) if "print" in chunks else False
    extra = {
        name: unquote_param(value)
        for name, value in chunks.items()
        if name not in _KNOWN_FLAGS
    }
    if not message and not files and not out and not extra:
        raise ValueError("hug needs +m or +files")
    call = HugCall(
        model=model,
        message=message,
        files=files,
        out=out,
        var=var,
        printed=printed,
        extra=extra,
    )
    if model:
        spec = model_params(model)
        # An unlisted id is classified from the repo when the step runs.
        if spec.declared:
            check_params(spec, message=message, files=files, out=out, extra=extra)
    return call


def model_params(model_id: str) -> ModelSpec:
    """Params for this Hugging Face id.

    `tool-details` `hug.models` replaces the built-in spec. An id that is not
    listed stays text here. `runtime_spec` reads the repo and may switch it to
    image or generate. Other `+params` are still kept.
    """
    name = (model_id or "").strip()
    if not name or "/" not in name or any(ch.isspace() for ch in name):
        raise ValueError(
            "hug model needs a Hugging Face id such as prism-ml/Bonsai-4B-mlx-1bit"
        )
    configured = _configured_models().get(name)
    if configured is not None:
        return configured
    builtin = _BUILTIN.get(name)
    if builtin is not None:
        return builtin
    return ModelSpec(name=name, kind="text", params=("m",), requires=("m",), declared=False)


def runtime_spec(model_id: str) -> ModelSpec:
    """The spec to run. A listed model stays as declared. Any other id is read from the repo."""
    spec = model_params(model_id)
    if spec.declared:
        return spec
    found = _DETECTED.get(spec.name)
    if found is not None:
        return found
    found = _detect_spec(spec.name)
    _DETECTED[spec.name] = found
    return found


def runtime_backend(spec: ModelSpec) -> str:
    """Which loader runs this model. An empty backend follows `kind`."""
    if spec.backend:
        return spec.backend
    if spec.kind == "generate":
        return "mlx-gen"
    if spec.kind == "image":
        return "mlx-vlm"
    return "mlx-lm"


def check_params(
    spec: ModelSpec,
    *,
    message: str,
    files: tuple[str, ...] | list[str],
    out: str = "",
    extra: dict[str, str] | None = None,
) -> None:
    """Require the params this model lists. A param it does not list is kept."""
    given: set[str] = set()
    if (message or "").strip():
        given.add("m")
    if files:
        given.add("files")
    if (out or "").strip():
        given.add("out")
    for name, value in (extra or {}).items():
        if str(value).strip():
            given.add(name)
    missing = [name for name in spec.requires if name not in given]
    if missing:
        shown = ", ".join(f"+{name}" for name in missing)
        raise ValueError(f"{spec.name} needs {shown}")


def resolve_model(explicit: str, env: dict[str, str] | None) -> str:
    """`+model`, then `HUG_MODEL` from config or set-config, then tool-details."""
    name = (explicit or "").strip()
    if name:
        return name
    found = str((env or {}).get("HUG_MODEL") or "").strip()
    if not found:
        from .app_config import tool_model

        found = tool_model("hug")
    if not found:
        found = DEFAULT_HUG_MODEL
    return found


def hug_download_enabled(env: dict[str, str] | None) -> bool:
    """True unless config `hug-download` is off. Missing means download."""
    if env is not None and "HUG_DOWNLOAD" in env:
        raw = env.get("HUG_DOWNLOAD")
    else:
        raw = os.environ.get("HUG_DOWNLOAD")
    if raw is None or str(raw).strip() == "":
        return True
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def ask_hug(
    model_id: str,
    message: str,
    files: list[str],
    *,
    out: str = "",
    download: bool = True,
    extra: dict[str, str] | None = None,
    messages: list[dict[str, str]] | None = None,
    max_tokens: int | None = None,
) -> str:
    """Run the model. The caller has already checked files exist.

    `download` installs a missing backend and lets the loader fetch the weights.
    A generate model returns the path of the image it wrote.
    `messages` keeps system and user turns for a text model. A short Hug answer
    stays one user turn. `max_tokens` raises the reply budget for a script.
    """
    spec = runtime_spec(model_id)
    dynamic = dict(extra or {})
    check_params(spec, message=message, files=files, out=out, extra=dynamic)
    if spec.kind == "generate":
        _prepare_generate_params(dynamic)
    turns = _turn_list(message, messages) if messages else []
    limit = max_tokens if isinstance(max_tokens, int) and max_tokens > 0 else None
    from .resident import announce, call, use_resident

    if use_resident():
        request: dict[str, Any] = {
            "model": model_id,
            "message": message,
            "files": list(files),
            "out": out,
            "download": download,
            "params": {name: _coerce_param(value) for name, value in dynamic.items()},
        }
        if turns:
            request["messages"] = turns
        if limit is not None:
            request["max_tokens"] = limit
        payload = call("hug", request)
        announce(payload, model_id)
        return str(payload.get("text") or "")
    if spec.kind == "generate":
        return _generate_picture(model_id, message, out, download=download, extra=dynamic)
    if spec.kind == "image":
        return _generate_image(
            model_id,
            message,
            files,
            download=download,
            extra=dynamic,
            messages=turns or None,
        )
    return _generate_text(
        model_id,
        message,
        download=download,
        extra=dynamic,
        messages=turns or None,
        max_tokens=limit,
    )


def _configured_models() -> dict[str, ModelSpec]:
    from .app_config import load_app_config

    spec = load_app_config().tools.get("hug")
    if spec is None:
        return {}
    return {item.name: item for item in spec.models}


def _model_token(raw: str) -> str:
    text = unquote_param(raw)
    if not text or any(ch.isspace() for ch in text):
        raise ValueError(
            "hug +model needs one Hugging Face id, such as prism-ml/Bonsai-4B-mlx-1bit"
        )
    return text


def _message_text(raw: str) -> str:
    return unquote_param(raw)


def _print_flag(raw: str) -> bool:
    if (raw or "").strip():
        raise ValueError("hug +print takes no value")
    return True


def _out_text(raw: str) -> str:
    text = unquote_param(raw)
    if not text or any(ch in text for ch in "\n\r"):
        raise ValueError("hug +out needs a file path")
    return text


def resolve_generate_output(
    explicit: str,
    *,
    prompt: str,
    folder: Path,
    base: Path | None,
) -> str:
    """Where a generate model writes. `+out` wins. Otherwise a file under `folder`."""
    text = (explicit or "").strip()
    if text:
        path = Path(text).expanduser()
        if not path.is_absolute():
            path = (base or folder) / path
    else:
        digest = hashlib.sha256((prompt or "image").encode()).hexdigest()[:8]
        path = folder / f"image-{digest}.png"
    return str(path.resolve())


_FIELD_RE = re.compile(
    r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}|\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)"
)


def is_template_file(text: str) -> bool:
    """True when `text` is a path to a markdown, JSON, or other prompt file."""
    return _is_prompt_file(text)


def load_prompt(
    raw: str,
    *,
    base: Path | None = None,
    env: dict[str, str] | None = None,
    variables: dict[str, Any] | None = None,
) -> tuple[str, str]:
    """The instruction text, and the file it came from.

    A sentence stays the prompt. A path such as `instructions.md` or
    `instructions.json` is read as the prompt. Markdown is the usual file.
    `.txt` and `.yaml` are read the same way. YAML is not parsed. JSON string
    values are filled, and a JSON string is the prompt text. `{{name}}` and
    `$name` in that text are filled from the workflow variables and config
    before the model sees the prompt.
    """
    text = (raw or "").strip()
    if not text or not _is_prompt_file(text):
        return fill_prompt(text, env, variables), ""
    path = _prompt_path(text, base)
    if path is None or not path.is_file():
        shown = path or Path(text).expanduser()
        raise FileNotFoundError(f"hug prompt not found: {shown}")
    rendered = _read_template_file(path, env, variables).strip()
    if not rendered:
        raise ValueError(f"hug prompt file is empty: {path}")
    return rendered, str(path)


def read_template(
    source: str | Path,
    ctx: dict[str, Any] | None = None,
    *,
    env: dict[str, str] | None = None,
    variables: dict[str, Any] | None = None,
    base: Path | None = None,
) -> str:
    """Read markdown or JSON and replace template variables from context.

    The file is the prompt. ``{{name}}``, ``${name}``, and ``$name`` come from
    variables, then config, then the process env. A name that is missing stays
    as written. A markdown file is filled as text. JSON string values are
    filled. A JSON string is returned as that text. Any other JSON document is
    returned as text with those values filled.
    """
    merged_env, names = _template_sources(ctx, env, variables)
    text = str(source or "").strip()
    if not text:
        raise ValueError("template is empty")
    if not _is_prompt_file(text):
        return fill_prompt(text, merged_env, names)
    path = _prompt_path(text, base)
    if path is None or not path.is_file():
        shown = path or Path(text).expanduser()
        raise FileNotFoundError(f"template not found: {shown}")
    return _read_template_file(path, merged_env, names).strip()


def _template_sources(
    ctx: dict[str, Any] | None,
    env: dict[str, str] | None,
    variables: dict[str, Any] | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    state = ctx or {}
    merged_env: dict[str, Any] = {}
    if isinstance(state.get("env"), dict):
        merged_env.update(state["env"])
    if env:
        merged_env.update(env)
    names: dict[str, Any] = {}
    if isinstance(state.get("variables"), dict):
        names.update(state["variables"])
    if variables:
        names.update(variables)
    return merged_env, names


def _read_template_file(
    path: Path,
    env: dict[str, Any] | None,
    variables: dict[str, Any] | None,
) -> str:
    try:
        body = path.read_text(encoding="utf-8")
    except UnicodeError as exc:
        raise ValueError(f"template must be a text file, such as .md or .json: {path}") from exc
    if path.suffix.lower() == ".json":
        return _fill_json_text(body, env, variables, path)
    return fill_prompt(body, env, variables)


def _fill_json_text(
    body: str,
    env: dict[str, Any] | None,
    variables: dict[str, Any] | None,
    path: Path,
) -> str:
    try:
        data = json.loads(body)
    except json.JSONDecodeError as exc:
        raise ValueError(f"json template is not valid: {path}") from exc
    filled = _fill_json_value(data, env, variables)
    if isinstance(filled, str):
        return filled
    return json.dumps(filled, ensure_ascii=False, indent=2)


def _fill_json_value(
    value: Any,
    env: dict[str, Any] | None,
    variables: dict[str, Any] | None,
) -> Any:
    if isinstance(value, str):
        return fill_prompt(value, env, variables)
    if isinstance(value, list):
        return [_fill_json_value(item, env, variables) for item in value]
    if isinstance(value, dict):
        return {key: _fill_json_value(item, env, variables) for key, item in value.items()}
    return value


def fill_prompt(
    text: str,
    env: dict[str, str] | None = None,
    variables: dict[str, Any] | None = None,
) -> str:
    """Replace `{{name}}` and `$name` from variables, then config, then the process env.

    A name that is not in context stays as written. A stored object becomes JSON text.
    """

    def repl(match: re.Match[str]) -> str:
        name = match.group(1) or match.group(2) or match.group(3)
        value = _context_value(name, env, variables)
        if value is None:
            return match.group(0)
        return value

    return _FIELD_RE.sub(repl, text)


def _context_value(
    name: str,
    env: dict[str, str] | None,
    variables: dict[str, Any] | None,
) -> str | None:
    keys = [name]
    upper = name.upper()
    lower = name.lower()
    if upper not in keys:
        keys.append(upper)
    if lower not in keys:
        keys.append(lower)
    for source in (variables or {}, env or {}, os.environ):
        for key in keys:
            if key in source:
                return _prompt_text(source[key])
    return None


def _prompt_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        shown = value.get("url") or value.get("text") or value.get("title")
        if shown:
            return str(shown)
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, list):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _is_prompt_file(text: str) -> bool:
    """A single path with a text suffix, or an explicit relative or absolute path."""
    if any(ch.isspace() for ch in text) or "\n" in text:
        return False
    path = Path(text).expanduser()
    if path.suffix.lower() in _PROMPT_SUFFIXES:
        return True
    return text.startswith(("/", "./", "../", "~/"))


def _prompt_path(text: str, base: Path | None) -> Path | None:
    path = Path(text).expanduser()
    if path.is_absolute():
        return path
    if base is not None:
        beside = base / path
        if beside.is_file():
            return beside
    if path.is_file():
        return path
    if base is not None:
        return base / path
    return path


def _file_list(raw: str) -> tuple[str, ...]:
    text = (raw or "").strip()
    if not text:
        raise ValueError("hug +files needs a file path")
    try:
        parts = shlex.split(text, posix=True)
    except ValueError as exc:
        raise ValueError(f"hug +files {exc}") from exc
    files: list[str] = []
    for part in parts:
        for piece in part.split(","):
            item = piece.strip()
            if item:
                files.append(item)
    if not files:
        raise ValueError("hug +files needs a file path")
    return tuple(files)


@dataclass(frozen=True)
class _DiffusersPlan:
    """How to draw one image repo. An empty filename is a diffusers pipeline.

    `file`, `steps`, `guidance`, and `scheduler` come from the tool config when
    the model is listed. A step param replaces the matching setting.
    """

    filename: str
    steps: int | None
    guidance: float | None
    scheduler: str


def _detect_spec(model_id: str) -> ModelSpec:
    """Pick text, image, or generate from the files in the Hugging Face repo."""
    files = _repo_files(model_id)
    config = _repo_config(model_id) if _root_has(files, "config.json") else None
    kind, backend = _classify_repo(files, config)
    if kind == "generate" and backend != "mlx-gen" and _maybe_mlxgen(model_id, files):
        backend = "mlx-gen"
    if kind == "generate":
        return ModelSpec(
            name=model_id,
            kind="generate",
            params=("m", "out"),
            requires=("m",),
            declared=False,
            backend=backend,
        )
    if kind == "image":
        return ModelSpec(
            name=model_id,
            kind="image",
            params=("m", "files"),
            requires=("files",),
            declared=False,
            backend=backend,
        )
    return ModelSpec(
        name=model_id,
        kind="text",
        params=("m",),
        requires=("m",),
        declared=False,
        backend=backend,
    )


def _classify_repo(files: list[str], config: dict | None = None) -> tuple[str, str]:
    """Kind and backend from a repo file list. `config` is the root config.json when it exists."""
    names = [item.replace("\\", "/") for item in files]
    roots = {name for name in names if "/" not in name}
    lowered = [name.lower() for name in names]
    if any(name.startswith("vae/") or "transformer-packed" in name for name in lowered):
        return "generate", "mlx-gen"
    if "model_index.json" in roots:
        return "generate", "diffusers"
    if "config.json" not in roots and _has_diffusion_checkpoint(roots):
        return "generate", "diffusers"
    if "config.json" in roots:
        if _vision_config(config):
            return "image", "mlx-vlm"
        return "text", "mlx-lm"
    return "text", "mlx-lm"


def _root_has(files: list[str], name: str) -> bool:
    return any(item.replace("\\", "/") == name for item in files)


def _has_diffusion_checkpoint(roots: set[str]) -> bool:
    for name in roots:
        lower = name.lower()
        if not lower.endswith((".safetensors", ".ckpt", ".bin")):
            continue
        if any(marker in lower for marker in _DIFFUSION_MARKERS):
            return True
    return False


def _vision_config(config: dict | None) -> bool:
    """True when a transformers config is a vision model rather than text."""
    if not isinstance(config, dict):
        return False
    model_type = str(config.get("model_type") or "").lower()
    if any(token in model_type for token in ("vl", "vision", "llava", "pixtral")):
        return True
    architectures = " ".join(str(item) for item in config.get("architectures") or []).lower()
    if any(token in architectures for token in ("vision", "llava", "pixtral")) or re.search(r"vl", architectures):
        return True
    return "vision_config" in config or "image_token_index" in config


def _maybe_mlxgen(model_id: str, files: list[str]) -> bool:
    """True when mlx-gen can load this id. Skip the import for a plain checkpoint repo."""
    lowered = " ".join(files).lower()
    if (
        "flux" not in lowered
        and "flux" not in model_id.lower()
        and "model_index.json" not in files
        and "transformer/" not in lowered
    ):
        return False
    return _mlxgen_resolves(model_id)


def _mlxgen_resolves(model_id: str) -> bool:
    try:
        from mflux.models.common.config.model_config import ModelConfig
    except Exception:
        return False
    try:
        ModelConfig.from_name(model_id)
    except Exception:
        return False
    return True


def _repo_files(model_id: str) -> list[str]:
    """Every file the repo publishes. The cached tree is enough; weights are not downloaded."""
    cached = _cached_tree_files(model_id)
    if cached:
        return cached
    try:
        from huggingface_hub import list_repo_files

        return [str(item) for item in list_repo_files(model_id)]
    except Exception as exc:
        raise RuntimeError(f"{model_id} could not be read from Hugging Face: {exc}") from exc


def _cached_tree_files(model_id: str) -> list[str]:
    """File names from a Hugging Face tree snapshot, including files that are not downloaded yet."""
    from huggingface_hub.constants import HF_HUB_CACHE

    trees = Path(HF_HUB_CACHE) / f"models--{model_id.replace('/', '--')}" / "trees"
    if not trees.is_dir():
        return []
    found: list[str] = []
    for path in trees.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        names = list((data.get("files") or {}).keys()) if isinstance(data, dict) else []
        if len(names) > len(found):
            found = [str(name) for name in names]
    return found


def _repo_config(model_id: str) -> dict | None:
    """The root config.json. A local snapshot wins. Otherwise the hub downloads that one file."""
    for snapshot in _generate_snapshots(model_id):
        path = snapshot / "config.json"
        if path.is_file():
            try:
                loaded = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                return None
            return loaded if isinstance(loaded, dict) else None
    try:
        from huggingface_hub import hf_hub_download

        path = Path(hf_hub_download(model_id, "config.json"))
        loaded = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return loaded if isinstance(loaded, dict) else None


def _diffusers_plan(model_id: str, extra: dict | None) -> _DiffusersPlan:
    """The checkpoint, step count, and guidance for this image repo.

    A listed model uses `file`, `steps`, `guidance`, and `scheduler` from the
    tool config. `+file`, `+steps`, and `+guidance` on the step replace those.
    An unlisted repo does not invent them. One checkpoint can load. Several
    checkpoints need `file` in the tool config.
    """
    spec = model_params(model_id)
    fields = {str(key): value for key, value in (extra or {}).items()}
    requested = _optional_int(_given(fields, "steps", "num_inference_steps"))
    guidance = _optional_float(_given(fields, "guidance", "guidance_scale"))
    file_override = str(_given(fields, "file") or "").strip()
    if spec.declared and spec.backend == "diffusers":
        return _DiffusersPlan(
            filename=file_override or spec.file,
            steps=requested if requested is not None else spec.steps,
            guidance=guidance if guidance is not None else spec.guidance,
            scheduler=spec.scheduler,
        )
    files = _repo_files(model_id)
    roots = [name.replace("\\", "/") for name in files if "/" not in name.replace("\\", "/")]
    if "model_index.json" in roots and not file_override:
        return _DiffusersPlan(filename="", steps=requested, guidance=guidance, scheduler="")
    try:
        filename = file_override or _only_checkpoint(roots)
    except ValueError as exc:
        raise ValueError(f"{model_id}: {exc}") from exc
    return _DiffusersPlan(filename=filename, steps=requested, guidance=guidance, scheduler="")


def _given(fields: dict, *names: str) -> object | None:
    """The first step param that was actually passed."""
    for name in names:
        if name in fields and str(fields[name]).strip() != "":
            return fields[name]
    return None


def _only_checkpoint(names: list[str]) -> str:
    """The one full checkpoint in an unlisted repo.

    A LoRA or a bare UNet is not enough. Several full files need `file` in the
    tool config, because the filename does not say which settings to use.
    """
    weights = [name for name in names if name.lower().endswith((".safetensors", ".ckpt", ".bin"))]
    full = [name for name in weights if _weight_kind(name) == "full"]
    if len(full) == 1:
        return full[0]
    if not full:
        raise ValueError(
            "this repo has no full checkpoint. Set file under tool-details hug.models, "
            "or use a diffusers pipeline."
        )
    shown = ", ".join(sorted(full))
    raise ValueError(
        f"this repo has more than one checkpoint ({shown}). Set file under tool-details hug.models."
    )


def _weight_kind(name: str) -> str:
    lower = name.lower()
    if "_lora" in lower:
        return "lora"
    if "_unet" in lower:
        return "unet"
    return "full"


def _optional_int(value: object) -> int | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text or not re.fullmatch(r"-?\d+", text):
        return None
    return int(text)


def _optional_float(value: object) -> float | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if re.fullmatch(r"-?\d+(?:\.\d+)?", text):
        return float(text)
    return None


def _generate_diffusers(
    model_id: str,
    prompt: str,
    out_path: str,
    *,
    download: bool,
    extra: dict[str, str] | None,
) -> str:
    """Draw with diffusers and return the file that was written."""
    path = Path(out_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = {str(key): str(value) for key, value in (extra or {}).items()}
    _prepare_generate_params(fields)
    pipe, plan = _ensure_diffusers_loaded(model_id, download=download, extra=fields)
    result = _call_diffusers(pipe, prompt, plan, fields)
    images = getattr(result, "images", None)
    if not images:
        raise RuntimeError(f"{model_id} did not return an image")
    images[0].save(path)
    return str(path)


def _ensure_diffusers_loaded(
    model_id: str,
    *,
    download: bool,
    extra: dict | None = None,
):
    """Load the pipeline once. A later step with the same checkpoint reuses it."""
    plan = _diffusers_plan(model_id, extra)
    key = ("diffusers", model_id, plan.filename)
    found = _LOADED.get(key)
    if found is not None:
        return found, plan
    loaded = _load_diffusers_pipeline(model_id, plan, download=download)
    _LOADED[key] = loaded
    return loaded, plan


def _load_diffusers_pipeline(model_id: str, plan: _DiffusersPlan, *, download: bool):
    if download:
        _install_diffusers(model_id)
    else:
        _require_diffusers(model_id)
    import torch
    from diffusers import DiffusionPipeline, EulerDiscreteScheduler

    dtype = torch.float16 if _torch_device() == "cuda" else torch.float32
    label = plan.filename or "pipeline"
    print(f"{model_id}: {label}", flush=True)
    if plan.filename:
        from huggingface_hub import hf_hub_download

        weight = hf_hub_download(model_id, plan.filename, local_files_only=not download)
        pipe = _pipeline_from_checkpoint(model_id, plan.filename, weight, dtype)
        if plan.scheduler:
            scheduler: dict[str, str] = {}
            if "trailing" in plan.scheduler:
                scheduler["timestep_spacing"] = "trailing"
            if "sample" in plan.scheduler:
                scheduler["prediction_type"] = "sample"
            pipe.scheduler = EulerDiscreteScheduler.from_config(pipe.scheduler.config, **scheduler)
    else:
        pipe = DiffusionPipeline.from_pretrained(
            model_id, torch_dtype=dtype, local_files_only=not download
        )
    pipe.to(_torch_device())
    slicer = getattr(pipe, "enable_attention_slicing", None)
    if callable(slicer):
        slicer()
    return pipe


def _pipeline_from_checkpoint(model_id: str, filename: str, weight: str, dtype: object):
    """Load one checkpoint. An SDXL file uses that pipeline. Anything else is inferred."""
    from diffusers import DiffusionPipeline, StableDiffusionXLPipeline

    name = f"{model_id} {filename}".lower()
    if "sdxl" in name or "stable-diffusion-xl" in name:
        return StableDiffusionXLPipeline.from_single_file(weight, torch_dtype=dtype)
    return DiffusionPipeline.from_single_file(weight, torch_dtype=dtype)


def _call_diffusers(pipe: object, prompt: str, plan: _DiffusersPlan, extra: dict):
    import torch

    kwargs: dict[str, object] = {"prompt": prompt}
    if str(extra.get("width") or "").strip():
        kwargs["width"] = int(extra["width"])
    if str(extra.get("height") or "").strip():
        kwargs["height"] = int(extra["height"])
    if plan.steps is not None:
        kwargs["num_inference_steps"] = int(plan.steps)
    if plan.guidance is not None:
        kwargs["guidance_scale"] = float(plan.guidance)
    negative = str(extra.get("negative") or "").strip()
    if negative:
        kwargs["negative_prompt"] = negative
    generator = torch.Generator(device="cpu")
    generator.manual_seed(_resolve_seed(extra.get("seed")))
    kwargs["generator"] = generator
    return pipe(**kwargs)


def _torch_device() -> str:
    import torch

    if torch.cuda.is_available():
        return "cuda"
    mps = getattr(torch.backends, "mps", None)
    if mps is not None and mps.is_available():
        return "mps"
    return "cpu"


def _install_diffusers(model_id: str) -> None:
    try:
        import diffusers  # noqa: F401
    except Exception:
        _pip_install("diffusers")
        _drop_modules("diffusers")
    _require_diffusers(model_id)


def _require_diffusers(model_id: str) -> None:
    try:
        import diffusers  # noqa: F401
    except Exception as exc:
        raise RuntimeError(_missing_backend("diffusers", model_id, exc)) from exc


def _generate_text(
    model_id: str,
    prompt: str,
    *,
    download: bool = True,
    extra: dict[str, str] | None = None,
    messages: list[dict[str, str]] | None = None,
    max_tokens: int | None = None,
) -> str:
    generate, load = _load_text_backend(model_id, download=download)
    model, tokenizer = _cached("text", model_id, load)
    formatted = _chat_prompt(tokenizer, prompt, messages)
    fields = _param_kwargs(extra)
    step_limit = fields.pop("max_tokens", None)
    limit = _token_budget(max_tokens, step_limit)
    return _as_text(generate(model, tokenizer, prompt=formatted, max_tokens=limit, **fields))


def _token_budget(requested: int | None, step_limit: object) -> int:
    """Reply length. A chat script asks for more than a short Hug answer."""
    for value in (requested, step_limit):
        if isinstance(value, bool) or value is None:
            continue
        try:
            number = int(value)
        except (TypeError, ValueError):
            continue
        if number > 0:
            return number
    return _MAX_TOKENS


def _turn_list(prompt: str, messages: list | None) -> list[dict[str, str]]:
    """Chat turns. A bare prompt is one user turn."""
    turns: list[dict[str, str]] = []
    for item in messages or []:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        if role not in {"system", "user", "assistant"}:
            continue
        content = item.get("content")
        text = content.strip() if isinstance(content, str) else ""
        if text:
            turns.append({"role": role, "content": text})
    if turns:
        return turns
    text = (prompt or "").strip()
    if not text:
        return []
    return [{"role": "user", "content": text}]


def _transcript(turns: list[dict[str, str]], prompt: str) -> str:
    """Plain text when a chat template cannot carry the thread."""
    if len(turns) <= 1:
        return prompt
    labels = {"system": "System", "user": "User", "assistant": "Assistant"}
    return "\n\n".join(f"{labels[item['role']]}: {item['content']}" for item in turns)


def _chat_prompt(tokenizer: object, prompt: str, messages: list | None = None) -> str:
    """Send the instruction as a user turn when the model has a chat template.

    A thread of earlier turns is the same conversation, not a new one. A raw
    prompt is continued. A file that already ends with JSON then produces an
    empty reply. The template starts the assistant turn after the instruction.
    """
    turns = _turn_list(prompt, messages)
    plain = _transcript(turns, prompt)
    if not turns or not getattr(tokenizer, "has_chat_template", False):
        return plain
    apply = getattr(tokenizer, "apply_chat_template", None)
    if not callable(apply):
        return plain
    try:
        formatted = apply(turns, tokenize=False, add_generation_prompt=True)
    except Exception:
        return plain
    text = str(formatted or "")
    # Keep the template's trailing newline. Stripping it ends the assistant
    # turn, and a YAML prompt then comes back empty.
    if not text.strip():
        return plain
    return text


def _generate_picture(
    model_id: str,
    prompt: str,
    out_path: str,
    *,
    download: bool = True,
    extra: dict[str, str] | None = None,
) -> str:
    """Draw one image and return the file that was written.

    `mlx-gen` draws a model it knows. A diffusers pipeline or a single-file
    checkpoint, such as SDXL-Lightning, is drawn with `diffusers`.
    """
    destination = (out_path or "").strip()
    if not destination:
        raise ValueError(f"{model_id} needs +out")
    if runtime_backend(runtime_spec(model_id)) == "diffusers":
        return _generate_diffusers(
            model_id, prompt, destination, download=download, extra=extra
        )
    loaded = _ensure_generate_loaded(model_id, download=download)
    _ensure_predict_cache(loaded)
    path = Path(destination).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = {str(key): str(value) for key, value in (extra or {}).items()}
    _prepare_generate_params(fields)
    sampler = _param_kwargs(fields)
    results = loaded.generate_outputs(
        seeds=[_resolve_seed(sampler.get("seed"))],
        prompt=prompt,
        width=int(sampler.get("width", _GENERATE_WIDTH)),
        height=int(sampler.get("height", _GENERATE_HEIGHT)),
        guidance=float(sampler.get("guidance", _GENERATE_GUIDANCE)),
        num_inference_steps=int(sampler.get("steps", sampler.get("num_inference_steps", _GENERATE_STEPS))),
        output=str(path),
    )
    saved = getattr(results[0], "saved_path", None) if results else None
    return str(saved or path)


def _ensure_predict_cache(loaded: object) -> None:
    """Bonsai's loader skips the predict cache Flux2Klein.generate_image expects."""
    model = getattr(loaded, "model", None)
    if model is None or getattr(model, "compiled_predict_cache", None) is not None:
        return
    from mflux.utils.compiled_predict_cache import CompiledPredictCache

    model.compiled_predict_cache = CompiledPredictCache()


def _ensure_generate_loaded(model_id: str, *, download: bool):
    key = ("generate", model_id)
    found = _LOADED.get(key)
    if found is not None:
        return found
    load = _load_generate_backend(model_id, download=download)
    if download:
        _prepare_generate_snapshot(model_id)
    try:
        loaded = _invoke_generate_load(load, model_id, download=download)
    except Exception as exc:
        # mlx-gen refuses to download during generate. A snapshot that has the
        # packed weights can still look incomplete when the repo sidecars are
        # absent. Fetch those, then load once more.
        if not download or not _download_required(exc):
            raise
        _prepare_generate_snapshot(model_id, force=True)
        loaded = _invoke_generate_load(load, model_id, download=True)
    _LOADED[key] = loaded
    return loaded


def _invoke_generate_load(load, model_id: str, *, download: bool):
    """Load the generator. `download` lets mlx-gen fetch a file it still wants."""
    if not download:
        return load(model=model_id)
    from mflux.models.common.download_policy import allow_downloads

    with allow_downloads():
        return load(model=model_id)


def _download_required(exc: BaseException) -> bool:
    return type(exc).__name__ == "DownloadRequiredError" or isinstance(exc, FileNotFoundError)


def _prepare_generate_snapshot(model_id: str, *, force: bool = False) -> None:
    """Cache every file mlx-gen checks, then copy the tokenizer sidecars to the root."""
    _link_generate_sidecars(model_id)
    if force or not _generate_weights_ready(model_id):
        _download_generate_weights(model_id)
        _link_generate_sidecars(model_id)


def _generate_weights_ready(model_id: str) -> bool:
    """True when a snapshot has every file mlx-gen requires before it will load."""
    return any(_snapshot_has_generate_files(path) for path in _generate_snapshots(model_id))


def _generate_snapshots(model_id: str) -> list[Path]:
    from huggingface_hub.constants import HF_HUB_CACHE

    snapshots = Path(HF_HUB_CACHE) / f"models--{model_id.replace('/', '--')}" / "snapshots"
    if not snapshots.is_dir():
        return []
    return [path for path in snapshots.iterdir() if path.is_dir()]


def _snapshot_has_generate_files(snapshot: Path) -> bool:
    return all(_pattern_present(snapshot, pattern) for pattern in _GENERATE_FILES)


def _pattern_present(snapshot: Path, pattern: str) -> bool:
    for match in snapshot.glob(pattern):
        if match.is_dir() or _weight_file(match):
            return True
    return False


def _link_generate_sidecars(model_id: str) -> None:
    """Copy tokenizer sidecars to the snapshot root.

    The repo stores them under tokenizer/. mlx-gen's cache check looks for the
    same names at the root, and a miss makes it refuse to load.
    """
    for snapshot in _generate_snapshots(model_id):
        for name in _GENERATE_SIDECARS:
            dest = snapshot / name
            if _weight_file(dest):
                continue
            source = snapshot / "tokenizer" / name
            if _weight_file(source):
                dest.write_bytes(source.read_bytes())


def _weight_file(path: Path) -> bool:
    return path.is_file() and path.stat().st_size > 0


def _download_generate_weights(model_id: str) -> None:
    """Cache the packed checkpoint. mlx-gen does not download during generate.

    A text-model snapshot leaves this repo without its safetensors and without
    a root config.json. The patterns below are the files the image loader reads.
    """
    print(f"{model_id}: downloading", flush=True)
    _snapshot_download(model_id, list(_GENERATE_FILES))


def _snapshot_download(repo_id: str, allow_patterns: list[str]) -> None:
    from huggingface_hub import snapshot_download

    snapshot_download(repo_id=repo_id, allow_patterns=allow_patterns)


def _generate_image(
    model_id: str,
    prompt: str,
    files: list[str],
    *,
    download: bool = True,
    extra: dict[str, str] | None = None,
    messages: list | None = None,
) -> str:
    generate, load = _load_image_backend(model_id, download=download)
    model, processor = _cached("image", model_id, load)
    formatted = _image_prompt(
        processor, model_id, prompt or "Describe this image.", len(files), messages
    )
    kwargs = _image_generate_kwargs(model_id)
    kwargs.update(_param_kwargs(extra))
    return _as_text(generate(model, processor, formatted, files, **kwargs))


def _draw_seed() -> int:
    """A new seed for `+seed random`. The number is printed so the picture can be repeated."""
    seed = secrets.randbelow(2**31)
    print(f"seed {seed}", flush=True)
    return seed


def _prepare_generate_params(dynamic: dict[str, str]) -> None:
    """Turn `+seed random` and `+size` into numbers. The choices are printed."""
    raw_seed = dynamic.get("seed")
    if raw_seed is not None and str(raw_seed).strip().lower() == "random":
        dynamic["seed"] = str(_draw_seed())
    raw_size = str(dynamic.get("size") or dynamic.get("aspect") or "").strip()
    if raw_size:
        width, height, label = resolve_image_size(raw_size)
        if str(dynamic.get("width") or "").strip():
            width = _snap_side(_side_int(dynamic["width"], "width"))
        if str(dynamic.get("height") or "").strip():
            height = _snap_side(_side_int(dynamic["height"], "height"))
        dynamic["width"] = str(width)
        dynamic["height"] = str(height)
        dynamic.pop("size", None)
        dynamic.pop("aspect", None)
        note = f"size {width}x{height}"
        if label:
            note += f" {label}"
        print(note, flush=True)
        return
    _snap_explicit_canvas(dynamic)


def _snap_explicit_canvas(dynamic: dict[str, str]) -> None:
    changed = False
    width = _GENERATE_WIDTH
    height = _GENERATE_HEIGHT
    if str(dynamic.get("width") or "").strip():
        original = _side_int(dynamic["width"], "width")
        width = _snap_side(original)
        changed = width != original
        dynamic["width"] = str(width)
    if str(dynamic.get("height") or "").strip():
        original = _side_int(dynamic["height"], "height")
        height = _snap_side(original)
        changed = changed or height != original
        dynamic["height"] = str(height)
    if changed:
        print(f"size {dynamic.get('width', width)}x{dynamic.get('height', height)}", flush=True)


def resolve_image_size(raw: str) -> tuple[int, int, str]:
    """A known name, `1080x1920`, or an aspect such as `9:16`.

    The label is the name or aspect. Pixel sizes leave the label empty.
    Each side is a multiple of 16 between 256 and 2048.
    """
    text = " ".join((raw or "").strip().lower().split())
    if not text:
        raise ValueError("hug +size needs a name, WxH, or an aspect such as 9:16")
    known = _size_table().get(text) or _size_table().get(text.replace(" ", "-"))
    if known is not None:
        width, height = _snap_side(known[0]), _snap_side(known[1])
        return width, height, known[2]
    pixels = re.fullmatch(r"(\d+)\s*[x×*]\s*(\d+)", text)
    if pixels:
        return _snap_side(int(pixels.group(1))), _snap_side(int(pixels.group(2))), ""
    aspect = re.fullmatch(r"(\d+(?:\.\d+)?)\s*:\s*(\d+(?:\.\d+)?)", text)
    if aspect:
        width, height = _aspect_pixels(float(aspect.group(1)), float(aspect.group(2)))
        return width, height, text
    raise ValueError(
        "hug +size needs a name such as instagram-story, pixels such as 1080x1920, "
        "or an aspect such as 9:16"
    )


def _size_table() -> dict[str, tuple[int, int, str]]:
    table: dict[str, tuple[int, int, str]] = {}
    for name, width, height, aliases in _IMAGE_SIZES:
        table[name] = (width, height, name)
        for alias in aliases:
            table[alias] = (width, height, name)
    return table


def _aspect_pixels(width_ratio: float, height_ratio: float) -> tuple[int, int]:
    if width_ratio <= 0 or height_ratio <= 0:
        raise ValueError("hug +size aspect needs positive numbers")
    if width_ratio >= height_ratio:
        width = float(_SIZE_LONG)
        height = width * height_ratio / width_ratio
    else:
        height = float(_SIZE_LONG)
        width = height * width_ratio / height_ratio
    return _snap_side(int(round(width))), _snap_side(int(round(height)))


def _side_int(value: str, name: str) -> int:
    text = str(value).strip()
    if not re.fullmatch(r"\d+", text):
        raise ValueError(f"hug +{name} needs a pixel count")
    return int(text)


def _snap_side(value: int) -> int:
    snapped = max(_SIZE_STEP, ((int(value) + _SIZE_STEP // 2) // _SIZE_STEP) * _SIZE_STEP)
    if snapped < _SIZE_MIN or snapped > _SIZE_MAX:
        raise ValueError(f"hug +size needs each side between {_SIZE_MIN} and {_SIZE_MAX}")
    return snapped


def _resolve_seed(value: object) -> int:
    """`+seed` is an integer. `random` draws one. A missing seed stays at 42."""
    if value is None:
        return _GENERATE_SEED
    if isinstance(value, bool):
        raise ValueError("hug +seed needs an integer or random")
    if isinstance(value, int):
        return value
    text = str(value).strip()
    if not text:
        return _GENERATE_SEED
    if text.lower() == "random":
        return _draw_seed()
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    raise ValueError("hug +seed needs an integer or random")


def _param_kwargs(extra: dict[str, str] | None) -> dict[str, object]:
    """Step params the model definition does not have to list."""
    return {name: _coerce_param(value) for name, value in (extra or {}).items() if str(value).strip()}


def _coerce_param(value: str) -> object:
    text = str(value).strip()
    lower = text.lower()
    if lower in {"true", "yes", "on"}:
        return True
    if lower in {"false", "no", "off"}:
        return False
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    if re.fullmatch(r"-?\d+\.\d+", text):
        return float(text)
    return text


def _image_generate_kwargs(model_id: str) -> dict[str, object]:
    """Sampler for this image model.

    Bonsai 2 thinks by default, and a thinking trace does not fit in the reply
    budget. Thinking stays off, with the published non-thinking sampler.
    """
    kwargs: dict[str, object] = {"max_tokens": _MAX_TOKENS, "verbose": False}
    if _is_bonsai2(model_id):
        kwargs.update(
            temperature=0.7,
            top_p=0.8,
            top_k=20,
            presence_penalty=1.5,
            presence_context_size=64,
            repetition_penalty=1.0,
        )
    return kwargs


def _is_bonsai2(model_id: str) -> bool:
    return "ternary-bonsai-2-" in (model_id or "").lower()


def _image_prompt(
    processor: object,
    model_id: str,
    prompt: str,
    count: int,
    messages: list | None = None,
) -> str:
    """Format one vision turn. A thread is passed through when the caller has one."""
    turns = _turn_list(prompt, messages)
    plain = _transcript(turns, prompt)
    body: object = turns if messages else prompt
    try:
        from mlx_vlm.prompt_utils import apply_chat_template
        from mlx_vlm.utils import load_config

        config = load_config(model_id)
        extra: dict[str, object] = {}
        if _is_bonsai2(model_id):
            extra["enable_thinking"] = False
        text = str(apply_chat_template(processor, config, body, num_images=count, **extra))
    except Exception:
        return plain
    if not text.strip():
        return plain
    return text


def _cached(kind: str, model_id: str, load) -> tuple[object, object]:
    key = (kind, model_id)
    found = _LOADED.get(key)
    if found is None:
        found = load(model_id)
        _LOADED[key] = found
    return found


def _as_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    text = getattr(value, "text", None)
    if isinstance(text, str):
        return text.strip()
    return str(value).strip()


def _load_text_backend(model_id: str, *, download: bool):
    try:
        return _import_mlx_lm()
    except Exception as exc:
        if not download:
            raise RuntimeError(_missing_backend("text", model_id, exc)) from exc
        _install_text_backend(model_id)
        try:
            return _import_mlx_lm()
        except Exception as again:
            raise RuntimeError(_missing_backend("text", model_id, again)) from again


def _load_generate_backend(model_id: str, *, download: bool):
    try:
        return _import_mlxgen()
    except Exception as exc:
        if not download:
            raise RuntimeError(_missing_backend("generate", model_id, exc)) from exc
        _pip_install(_MLX_GEN)
        _drop_modules("mlxgen", "mflux")
        try:
            return _import_mlxgen()
        except Exception as again:
            raise RuntimeError(_missing_backend("generate", model_id, again)) from again


def _load_image_backend(model_id: str, *, download: bool):
    try:
        return _import_mlx_vlm()
    except Exception as exc:
        if not download:
            raise RuntimeError(_missing_backend("image", model_id, exc)) from exc
        _pip_install(_MLX_VLM)
        _drop_modules("mlx_vlm")
        try:
            return _import_mlx_vlm()
        except Exception as again:
            raise RuntimeError(_missing_backend("image", model_id, again)) from again


def _import_mlx_lm():
    from mlx_lm import generate, load

    return generate, load


def _import_mlx_vlm():
    from mlx_vlm import generate, load

    return generate, load


def _import_mlxgen():
    from mlxgen import load_generation_model

    return load_generation_model


def _install_text_backend(model_id: str) -> None:
    """Install mlx-lm. 1-bit Bonsai also replaces mlx with the PrismML fork.

    Ternary 2-bit weights, including Ternary Bonsai 8B, load on stock MLX.
    """
    _pip_install(_MLX_LM)
    if _needs_prism_mlx(model_id):
        _ensure_metal_toolchain()
        _pip_install(_PRISM_MLX, upgrade=True, env=_compiler_env())
    _drop_modules("mlx_lm", "mlx")


def _ensure_metal_toolchain() -> None:
    """The PrismML fork compiles Metal kernels and needs Apple's Metal tools.

    Xcode keeps `metal` in a separate download. After that download, `xcrun`
    still misses it until `TOOLCHAINS` names the installed identifier.
    """
    if _metal_ready():
        return
    if not _metal_component_installed():
        print("Metal toolchain: installing", flush=True)
        result = subprocess.run(
            ["xcodebuild", "-downloadComponent", "MetalToolchain"],
            check=False,
        )
        if result.returncode != 0:
            raise RuntimeError(_metal_install_error())
    if not _metal_ready():
        raise RuntimeError(_metal_install_error())


def _compiler_env() -> dict[str, str]:
    """Env for the PrismML build, with the installed Metal toolchain selected."""
    env = os.environ.copy()
    identifier = _metal_toolchain_id()
    if not identifier:
        return env
    parts = [part for part in env.get("TOOLCHAINS", "").split(":") if part]
    if identifier not in parts:
        parts.insert(0, identifier)
    env["TOOLCHAINS"] = ":".join(parts)
    return env


def _metal_ready() -> bool:
    if _metal_version_ok(None):
        return True
    identifier = _metal_toolchain_id()
    if not identifier:
        return False
    env = os.environ.copy()
    env["TOOLCHAINS"] = identifier
    return _metal_version_ok(env)


def _metal_version_ok(env: dict[str, str] | None) -> bool:
    result = subprocess.run(
        ["xcrun", "-sdk", "macosx", "metal", "--version"],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    text = f"{result.stdout or ''}\n{result.stderr or ''}"
    return result.returncode == 0 and "missing Metal Toolchain" not in text


def _metal_component_installed() -> bool:
    return "Status: installed" in _show_metal_component()


def _metal_toolchain_id() -> str:
    for line in _show_metal_component().splitlines():
        if "Toolchain Identifier" in line and ":" in line:
            return line.split(":", 1)[1].strip()
    return ""


def _show_metal_component() -> str:
    result = subprocess.run(
        ["xcodebuild", "-showComponent", "MetalToolchain"],
        check=False,
        capture_output=True,
        text=True,
    )
    return result.stdout or ""


def _metal_install_error() -> str:
    return (
        "MLX needs the Metal toolchain. "
        "Run: xcodebuild -downloadComponent MetalToolchain"
    )


def _needs_prism_mlx(model_id: str) -> bool:
    """1-bit packs need the PrismML fork. Ternary 2-bit loads on stock MLX."""
    return "-1bit" in (model_id or "").lower()


def _pip_install(spec: str, *, upgrade: bool = False, env: dict[str, str] | None = None) -> None:
    cmd = [sys.executable, "-m", "pip", "install"]
    if upgrade:
        cmd.append("--upgrade")
    cmd.append(spec)
    print(f"{spec}: installing", flush=True)
    result = subprocess.run(cmd, check=False, env=env)
    if result.returncode != 0:
        raise RuntimeError(f"{spec} could not be installed")


def _drop_modules(*roots: str) -> None:
    for name in list(sys.modules):
        if any(name == root or name.startswith(root + ".") for root in roots):
            sys.modules.pop(name, None)


def _missing_backend(kind: str, model_id: str, exc: BaseException) -> str:
    if kind == "diffusers":
        return f"{model_id} needs diffusers. {exc}".strip()
    if kind == "generate":
        return f"{model_id} needs mlx-gen. {exc}"
    if kind == "image":
        return f"{model_id} needs mlx-vlm. {exc}"
    if _needs_prism_mlx(model_id):
        return (
            f"{model_id} needs mlx-lm and the PrismML MLX fork "
            "(pip install mlx-lm && pip install "
            "'mlx @ git+https://github.com/PrismML-Eng/mlx.git@prism'). "
            f"{exc}"
        )
    return f"{model_id} needs mlx-lm. {exc}"


def resolve_hug_file(source: str, env: dict[str, str], variables: dict[str, object]) -> str:
    """A path, or a `$name` stored by an earlier step."""
    from .clef import image_path_from_value
    from .terminal import expand_command

    text = (source or "").strip()
    match = re.fullmatch(r"\$([A-Za-z_][A-Za-z0-9_]*)", text)
    if match:
        name = match.group(1)
        if name in variables:
            value: object = variables[name]
        elif name in env:
            value = env[name]
        elif name in os.environ:
            value = os.environ[name]
        else:
            raise FileNotFoundError(f"hug file variable ${name} is not set")
        path = image_path_from_value(value)
        if not path:
            raise FileNotFoundError(f"hug file variable ${name} is not a file path")
        return path
    merged = {str(key): "" if val is None else str(val) for key, val in env.items()}
    return expand_command(text, merged, variables).strip()
