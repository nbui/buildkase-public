"""Ask Cloudflare Clef one question about the open page.

`/clef Subscript text exists?` is yes or no about the open page. `/browser /clef`
uses that page. `/cua /clef` uses the window from the last `/cua` step. `+image`
picks another picture: `+image /browser`, `+image /cua`, `+image $shot`, or
`+image /path/shot.jpg`.
`+options` replaces yes/no with a choice list. Quotes keep a comma inside an
option: `+options "a", "b,", "c"`. `+verify yes` fails the step when the
answer is anything else.

The weights are the 9B 4-bit MLX flash build at
https://huggingface.co/mlx-community/clef-flash-4bit. Jobs load them in the
shared local-models process, the way Layla does, through the `clef_mlx.py`
shipped with that repo. A later job uses them when they are already loaded.
`mlx-vlm` is installed on the first call when it is missing. `tool-details`
`clef.model` is the model id. `openrouter/cloudflare/clef` asks that model
on OpenRouter System One instead of loading local weights.
"""

from __future__ import annotations

import importlib.util
import os
import re
import sys
import time
from pathlib import Path
from typing import Any

from .quoting import finditer_outside, search_outside, unquote_param

DEFAULT_CLEF_MODEL = "mlx-community/clef-flash-4bit"
_MLX_VLM = "mlx-vlm>=0.7.4,<0.8"
_MODEL: Any = None
_MODEL_ID = ""
BROWSER_IMAGE = "/browser"
CUA_IMAGE = "/cua"
_FLAG_RE = re.compile(r"(?:^|\s)\+(options|verify|image)\b", re.IGNORECASE)
_INTO_RE = re.compile(
    r"\s+into\s+\$(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*$",
    re.IGNORECASE,
)


def parse_clef_command(body: str) -> tuple[str, list[str], str, str, str]:
    """`<question> [+options ...] [+image ...] [+verify ...] [into $name]`.

    Returns the question, the choice list (empty means yes/no), the expected
    answer, the image source, and the variable name. An empty image source
    means the open browser page. `/cua` means the window from the last `/cua` step.
    """
    text = (body or "").strip()
    var = ""
    into = search_outside(_INTO_RE, text)
    if into:
        var = into.group("var")
        text = text[: into.start()].rstrip()
    matches = finditer_outside(_FLAG_RE, text)
    if not matches:
        question = unquote_param(text.strip())
        if not question:
            raise ValueError("clef needs a question: /clef Subscript text exists?")
        return question, [], "", "", var
    question = unquote_param(text[: matches[0].start()].strip())
    if not question:
        raise ValueError("clef needs a question: /clef Subscript text exists?")
    chunks: dict[str, str] = {}
    for index, match in enumerate(matches):
        name = match.group(1).lower()
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        if name in chunks:
            raise ValueError(f"clef +{name} is repeated")
        chunks[name] = text[start:end].strip()
    options = parse_option_list(chunks["options"]) if "options" in chunks else []
    verify = ""
    if "verify" in chunks:
        verify = expected_answer(parse_verify_value(chunks["verify"]), options)
    image = parse_image_source(chunks["image"]) if "image" in chunks else ""
    return question, options, verify, image, var


def parse_option_list(raw: str) -> list[str]:
    """`a,b,c` or `"a", "b,", "c"`. A comma inside quotes stays in that option."""
    text = (raw or "").strip()
    if not text:
        raise ValueError('clef +options needs at least two options, for example a,b,c')
    options: list[str] = []
    buf: list[str] = []
    quote = ""
    index = 0
    while index < len(text):
        ch = text[index]
        if quote:
            if ch == "\\" and index + 1 < len(text):
                buf.append(text[index + 1])
                index += 2
                continue
            if ch == quote:
                quote = ""
                index += 1
                continue
            buf.append(ch)
            index += 1
            continue
        if ch in {'"', "'"}:
            if "".join(buf).strip():
                buf.append(ch)
                index += 1
                continue
            buf = []
            quote = ch
            index += 1
            continue
        if ch == ",":
            options.append("".join(buf).strip())
            buf = []
            index += 1
            continue
        buf.append(ch)
        index += 1
    if quote:
        raise ValueError("clef +options has an unclosed quote")
    options.append("".join(buf).strip())
    while options and options[-1] == "":
        options.pop()
    if any(item == "" for item in options):
        raise ValueError("clef +options has an empty option")
    if len(options) < 2:
        raise ValueError('clef +options needs at least two options, for example a,b,c')
    if len(set(options)) != len(options):
        raise ValueError("clef +options repeats an option")
    return options


def parse_verify_value(raw: str) -> str:
    """The answer `+verify` expects. Quotes keep a comma, as in `+verify "b,"`."""
    text = (raw or "").strip()
    if not text:
        raise ValueError("clef +verify needs the expected answer, for example +verify yes")
    if text[0] in {'"', "'"}:
        try:
            value = unquote_param(text, only=True)
        except ValueError as exc:
            message = str(exc)
            if message == "unclosed quote":
                raise ValueError("clef +verify has an unclosed quote") from exc
            if message.startswith("extra text after quote:"):
                raise ValueError(f"clef +verify has extra text: {message.split(':', 1)[1].strip()}") from exc
            raise
        if not value:
            raise ValueError("clef +verify needs the expected answer, for example +verify yes")
        return value
    return text


def expected_answer(verify: str, options: list[str]) -> str:
    """The option or yes/no that `verify` names. A mismatch is a parse error."""
    text = (verify or "").strip()
    if not text:
        raise ValueError("clef +verify needs the expected answer, for example +verify yes")
    if options:
        for option in options:
            if option.casefold() == text.casefold():
                return option
        shown = ", ".join(options)
        raise ValueError(f"clef +verify {text!r} is not one of the options: {shown}")
    if text.casefold() not in {"yes", "no"}:
        raise ValueError("clef +verify for a yes/no question must be yes or no")
    return text.casefold()


def parse_image_source(raw: str) -> str:
    """`+image /browser`, `+image /cua`, `+image $shot`, or `+image /path/shot.jpg`.

    `/browser` is the open page. `/cua` is the window from the last `/cua` step.
    `$shot` is a path stored by an earlier step. A quoted path keeps its spaces.
    """
    text = (raw or "").strip()
    if not text:
        raise ValueError("clef +image needs /browser, /cua, $variable, or a file path")
    if text[0] in {'"', "'"}:
        try:
            text = unquote_param(text, only=True).strip()
        except ValueError as exc:
            message = str(exc)
            if message == "unclosed quote":
                raise ValueError("clef +image has an unclosed quote") from exc
            if message.startswith("extra text after quote:"):
                raise ValueError(f"clef +image has extra text: {message.split(':', 1)[1].strip()}") from exc
            raise
        if not text:
            raise ValueError("clef +image needs /browser, /cua, $variable, or a file path")
    if text.lower() in {"/browser", "browser"}:
        return BROWSER_IMAGE
    if text.lower() in {"/cua", "cua"}:
        return CUA_IMAGE
    return text


def is_browser_image(source: str) -> bool:
    """True when the picture is a screenshot of the open page."""
    return (source or "").strip().lower() in {"", "/browser", "browser"}


def is_cua_image(source: str) -> bool:
    """True when the picture is the window from the last `/cua` step."""
    return (source or "").strip().lower() in {"/cua", "cua"}


def image_path_from_value(value: Any) -> str:
    """A path string, or the path a previous step stored on a dict or list."""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        for key in ("image", "path", "screenshot", "file", "marked"):
            found = value.get(key)
            if isinstance(found, str) and found.strip():
                return found.strip()
        shots = value.get("screenshots")
        if isinstance(shots, list) and shots:
            return image_path_from_value(shots[-1])
    if isinstance(value, list) and value:
        return image_path_from_value(value[-1])
    return ""


def resolve_image_path(source: str, env: dict[str, Any], variables: dict[str, Any]) -> str:
    """The file named by `+image`. A `$name` may itself be the path."""
    from .terminal import expand_command

    text = (source or "").strip()
    match = re.fullmatch(r"\$([A-Za-z_][A-Za-z0-9_]*)", text)
    if match:
        name = match.group(1)
        if name in variables:
            value: Any = variables[name]
        elif name in env:
            value = env[name]
        elif name in os.environ:
            value = os.environ[name]
        else:
            raise FileNotFoundError(f"clef image variable ${name} is not set")
        path = image_path_from_value(value)
        if not path:
            raise FileNotFoundError(f"clef image variable ${name} is not a file path")
        return path
    expanded = expand_command(text, {str(key): "" if val is None else str(val) for key, val in env.items()}, variables)
    return expanded.strip()


def same_answer(got: str, expected: str) -> bool:
    return (got or "").strip().casefold() == (expected or "").strip().casefold()


def clef_model(env: dict[str, Any] | None = None) -> str:
    """Model id. `tool-details` `clef.model` and CLEF_MODEL override mlx-community/clef-flash-4bit."""
    merged = dict(os.environ)
    if env:
        merged.update({str(key): "" if value is None else str(value) for key, value in env.items()})
    for key in ("CLEF_MODEL", "CG_LOOP_CLEF_MODEL"):
        value = merged.get(key, "").strip()
        if value:
            return value
    return DEFAULT_CLEF_MODEL


def question_body(question: str, options: list[str]) -> dict[str, Any]:
    """One System One question. No options means yes/no."""
    payload: dict[str, Any] = {
        "type": "choice" if options else "noul",
        "instructions": question,
    }
    if options:
        payload["criteria"] = {option: option for option in options}
    return payload


def workflow_needs_clef(workflow: Any) -> bool:
    """True when a step in this run asks Clef."""
    return any(step.kind == "clef" or step.tool == "clef" for step in workflow.all_steps())


def load_clef_if_needed(workflow: Any) -> None:
    """Install mlx-vlm if it is missing, then load Clef once before the first step.

    An `openrouter/` model id skips the local weights and calls OpenRouter later.
    """
    if not workflow_needs_clef(workflow):
        return
    from .gemma import openrouter_checkpoint
    from .model import ChatError

    name = clef_model(getattr(workflow, "env", None))
    try:
        if openrouter_checkpoint(name):
            return
        from .resident import call, use_resident

        if use_resident():
            call("load", {"id": name}, timeout=900)
            return
        ensure_clef_model(name)
    except ChatError:
        raise
    except Exception as exc:
        raise ChatError(f"clef failed: {exc}") from exc


def _ensure_clef_runtime() -> None:
    """`huggingface_hub` downloads the repo. `mlx-vlm` runs the backbone and vision tower."""
    from .model import _install_package

    try:
        import huggingface_hub  # noqa: F401
    except ImportError:
        _install_package("huggingface_hub")
    try:
        import mlx_vlm  # noqa: F401
    except ImportError:
        _install_package(_MLX_VLM)


def _clef_module(path: str) -> Any:
    """The `clef_mlx.py` that ships beside the weights. That file runs the decision head."""
    file = Path(path) / "clef_mlx.py"
    if not file.is_file():
        raise FileNotFoundError(f"{file} is missing")
    spec = importlib.util.spec_from_file_location("cg_loop_clef_mlx", file)
    if spec is None or spec.loader is None:
        raise FileNotFoundError(f"{file} is missing")
    module = importlib.util.module_from_spec(spec)
    sys.modules["cg_loop_clef_mlx"] = module
    spec.loader.exec_module(module)
    return module


def _open_clef(name: str) -> Any:
    _ensure_clef_runtime()
    os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
    from huggingface_hub import snapshot_download
    from huggingface_hub.utils import disable_progress_bars

    disable_progress_bars()
    path = snapshot_download(name)
    return _clef_module(path).load(path)


def ensure_clef_model(model_id: str = "") -> Any:
    """The shared Clef model. The packages are installed here when they are missing."""
    global _MODEL, _MODEL_ID
    name = (model_id or DEFAULT_CLEF_MODEL).strip() or DEFAULT_CLEF_MODEL
    if _MODEL is not None and _MODEL_ID == name:
        return _MODEL
    _MODEL = _open_clef(name)
    _MODEL_ID = name
    return _MODEL


def read_answer(payload: Any, options: list[str]) -> tuple[str, float]:
    """The decision and its probability. Yes/no is `yes` when true is at least 0.5."""
    body = _unwrap(payload)
    answers = body.get("answers") if isinstance(body, dict) else None
    item: Any = {}
    if isinstance(answers, dict) and answers:
        item = answers.get("answer")
        if item is None:
            item = next(iter(answers.values()))
    if not isinstance(item, dict):
        item = {}
    if options:
        choice = str(item.get("choice") or "").strip()
        for option in options:
            if option.casefold() == choice.casefold():
                choice = option
                break
        if choice not in options:
            shown = ", ".join(options)
            raise RuntimeError(f"clef returned {choice!r}, not one of {shown}")
        probs = item.get("probabilities") if isinstance(item.get("probabilities"), dict) else {}
        return choice, _number(probs.get(choice, item.get("confidence")), default=0.0)
    probability = item.get("noul")
    if probability is None and isinstance(item.get("probabilities"), dict):
        probs = item["probabilities"]
        probability = probs.get("true", probs.get("yes"))
    if probability is None:
        raise RuntimeError("clef returned no yes/no probability")
    score = _number(probability, default=None)
    if score is None:
        raise RuntimeError("clef returned no yes/no probability")
    return ("yes" if score >= 0.5 else "no"), score


def ask_clef(
    question: str,
    options: list[str],
    image: bytes,
    *,
    state: str,
    env: dict[str, Any] | None = None,
) -> tuple[str, float]:
    """Ask Clef and return the answer and its probability.

    A local model id loads the MLX weights. `openrouter/cloudflare/clef` sends
    the same question to OpenRouter System One.
    """
    from . import model
    from .gemma import openrouter_checkpoint

    name = clef_model(env)
    remote = openrouter_checkpoint(name)
    if remote:
        try:
            result = _ask_openrouter(remote, question, options, image, state, env)
        except Exception as exc:
            raise RuntimeError(f"clef failed: {exc}") from exc
        return read_answer(result, options)

    from io import BytesIO

    from PIL import Image

    from .resident import announce, call, spill_image, use_resident

    if use_resident():
        started = time.perf_counter()
        spilled = spill_image(prepare_image(image))
        try:
            payload = call(
                "clef",
                {
                    "model": name,
                    "question": question,
                    "options": options,
                    "image": str(spilled),
                    "state": state,
                },
            )
            announce(payload, name)
            return str(payload.get("answer") or ""), float(payload.get("score") or 0)
        except Exception as exc:
            raise RuntimeError(f"clef failed: {exc}") from exc
        finally:
            spilled.unlink(missing_ok=True)
            model._charge_llm(started)

    started = time.perf_counter()
    try:
        loaded = ensure_clef_model(name)
        picture = Image.open(BytesIO(prepare_image(image)))
        picture.load()
        result = loaded.systemone(
            {
                "model": "clef-flash",
                "state": state,
                "images": [picture],
                "questions": {"answer": question_body(question, options)},
            }
        )
    except Exception as exc:
        raise RuntimeError(f"clef failed: {exc}") from exc
    finally:
        model._charge_llm(started)
    return read_answer(result, options)


def _ask_openrouter(
    checkpoint: str,
    question: str,
    options: list[str],
    image: bytes,
    state: str,
    env: dict[str, Any] | None,
) -> dict[str, Any]:
    """One System One request. The image is a JPEG data URL."""
    import base64
    from io import BytesIO

    from PIL import Image

    from .model import openrouter_systemone

    picture = Image.open(BytesIO(prepare_image(image)))
    picture.load()
    out = BytesIO()
    picture.convert("RGB").save(out, format="JPEG", quality=80)
    encoded = base64.b64encode(out.getvalue()).decode("ascii")
    print(f"clef: openrouter {checkpoint}", flush=True)
    result = openrouter_systemone(
        {
            "model": checkpoint,
            "state": state,
            "images": [f"data:image/jpeg;base64,{encoded}"],
            "questions": {"answer": question_body(question, options)},
        },
        env,
    )
    return result if isinstance(result, dict) else {}


def prepare_image(data: bytes) -> bytes:
    """Shrink a large page shot so the request stays within Clef's image limit."""
    if len(data) <= 1_500_000:
        return data
    try:
        from io import BytesIO

        from PIL import Image
    except ImportError:
        return data
    try:
        picture = Image.open(BytesIO(data))
        picture.thumbnail((1600, 1600))
        out = BytesIO()
        picture.convert("RGB").save(out, format="JPEG", quality=75)
    except Exception:
        return data
    shrunk = out.getvalue()
    return shrunk or data


def _unwrap(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    result = payload.get("result")
    if isinstance(result, dict) and "answers" not in payload and "answers" in result:
        return result
    return payload


def _number(value: Any, *, default: float | None) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number
