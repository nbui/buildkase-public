# CG command catalog

Skill roots relative to the repo. Prefer these paths; do not invent
alternate wrappers unless a `SKILL.md` says otherwise.

## Workflow YAML

`cg-loop` can run a YAML plan instead of picking a single command:

```bash
workflows/skills/cg-loop/scripts/cg_loop.sh \
  /Users/nghia/Downloads/workspace/social_content_gen/workflows/wf-research-content.yaml
```

Step kinds: `goto`, `get … to $var`, `llm-call`, `generate story`, `term`.

## Skill roots

| Skill | Root | Primary runner |
|-------|------|----------------|
| cg-post-from-folder | `workflows/skills/cg-post-from-folder` | `scripts/run_cucumber.sh` |
| cg-meal-vid | `/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-meal-vid` | `scripts/run_cucumber.sh` |
| cg-metric-video | `/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-metric-video` | `scripts/run_cucumber.sh` |
| cg-research | `/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-research` | `scripts/research_run.sh` |
| cg-biz-research | `/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-biz-research` | `scripts/run_cucumber.sh` |
| cg-remix | `workflows/skills/cg-remix` | see `SKILL.md` |
| cg-remix-article | `workflows/skills/cg-remix-article` | `scripts/remix_article_run.sh` |
| cg-stable-audio | `/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-stable-audio` | `scripts/run_cucumber.sh` / `music_run.sh` |
| cg-reddit-content | `/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-reddit-content` | see `SKILL.md` |
| cg-slides | `/Users/nghia/Downloads/workspace/messi_libs/flutter_mocks/skills/cg-slides` | `scripts/run_cucumber.sh` |
| cg-chat-vid | `/Users/nghia/Downloads/workspace/messi_libs/flutter_mocks/skills/cg-chat-vid` | `scripts/run_cucumber.sh` |
| cg-metric-signals-vid | `/Users/nghia/Downloads/workspace/messi_libs/flutter_mocks/skills/cg-metric-signals-vid` | `scripts/run_cucumber.sh` |
| cg-loop (this) | `workflows/skills/cg-loop` | `scripts/cg_loop.sh` (workflow YAML or jev-style loop) |

## Cron / batch

```bash
# Daily generation (skips when unposted package exists)
workflows/skills/cg-post-from-folder/scripts/daily_content_cron.sh

# Force regenerate
CG_FORCE_REGENERATE=1 workflows/skills/cg-post-from-folder/scripts/daily_content_cron.sh
```

Post workflow examples live in:

`workflows/skills/cg-post-from-folder/references/post_workflow.md`

Generation notes:

`workflows/skills/cg-post-from-folder/references/content_generation.md`

## Posting (cg-post-from-folder)

Pattern:

```bash
POST=workflows/skills/cg-post-from-folder/scripts/run_cucumber.sh
"$POST" features --tags "@<package> and (@youtube or @tiktok or @instagram)" --stop
"$POST" features --tags "@archive"
```

Common package tags: `chat_can`, `chat_can_short`, `chat_can_heart`,
`chat_can_heart_short`, `chat_v2_can`, `chat_vitamins`, `chat_vitamins_heart`,
`meme_yuba`, `meme_heartkase`, `note_analyze`, `note_analyze_heart`,
`before_after_food_gen`, `guess_music`, `guess_chatterbox`, `heart_guess_music`,
`heart_guess_chatterbox`, `male_34`, `female_30`, `female_25`.

## Generation shortcuts

```bash
SLIDES=/Users/nghia/Downloads/workspace/messi_libs/flutter_mocks/skills/cg-slides/scripts/run_cucumber.sh
CHAT=/Users/nghia/Downloads/workspace/messi_libs/flutter_mocks/skills/cg-chat-vid/scripts/run_cucumber.sh
MEAL=/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-meal-vid/scripts/run_cucumber.sh
METRIC=/Users/nghia/Downloads/workspace/messi_libs/flutter_mocks/skills/cg-metric-signals-vid/scripts/run_cucumber.sh

"$SLIDES" features/slides.feature --tags @meme_yuba
"$SLIDES" features/chat_v2.feature --tags @chat_can_short
"$CHAT" features/chat_vid.feature --tags @vitamins
"$MEAL" features/meal_vid_guess_nutrient.feature --tags @cg_meal_vid_guess_nutrient
"$METRIC" features/personas.feature --tags @male_34
```

When unsure of tags/flags: `head` / `rg` the skill's `SKILL.md` and
`features/*.feature` under that skill root.

## Generate from a free-text idea

When the user says **generate content for idea '…'** (not merely "add idea"),
do **not** stop at research/SKILL.md. Propose a generate command.

**Preferred one-shot** (TOPIC overrides the ideas queue):

```bash
SLIDES=/Users/nghia/Downloads/workspace/messi_libs/flutter_mocks/skills/cg-slides/scripts/run_cucumber.sh
CHAT=/Users/nghia/Downloads/workspace/messi_libs/flutter_mocks/skills/cg-chat-vid/scripts/run_cucumber.sh
MEAL=/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-meal-vid/scripts/run_cucumber.sh
ADD=workflows/skills/cg-loop/scripts/add_idea.sh

# Food / GLP-1 / nutrition explainers → often story_food or chat_vitamins
TOPIC='Why does pizza make you feel terrible on a GLP-1?' \
  "$SLIDES" features/food.feature --tags @story_food

TOPIC='Why does pizza make you feel terrible on a GLP-1?' \
  "$CHAT" features/chat_vid.feature --tags @vitamins

# Capability / app CTA → chat_can or meme_yuba
TOPIC='Track leftover chicken protein after dinner' \
  "$SLIDES" features/chat_v2.feature --tags @chat_can

# Meal plate video
TOPIC='salmon greens walnut dinner' \
  "$MEAL" features/meal_vid_food_image.feature
```

**Queue then generate** (when you want it in the bank first):

```bash
"$ADD" --write --target story_food "Why does pizza make you feel terrible on a GLP-1?"
"$SLIDES" features/food.feature --tags @story_food
```

Rough routing for idea text:
- food / vitamins / GLP-1 / macros → `story_food`, `meme_food`, `chat_vitamins`, `meal`
- heart / HRV / BP / wearable Q&A → `chat`, `chat_explain`, `meme_heartkase`, `metric_signals`
- Do/Want/Track + Get Yuba → `meme_yuba` / `chat_can`
- notes → graphs → AI adjust → `note_analyze` / `note_analyze_heart`

## Add idea only (cg-loop)

LM Studio picks the correct pending `ideas.yaml` bank (cg-research target map),
shapes the entry, and optionally appends it.

```bash
ADD=workflows/skills/cg-loop/scripts/add_idea.sh

# Dry-run — print target + shaped entry (no write)
"$ADD" "track leftover chicken protein after dinner"

# Write into the chosen bank
"$ADD" --write "track leftover chicken protein after dinner"

# Force a bank
"$ADD" --write --target meme_yuba "Do: log dinner macros without a lecture"

# List banks
"$ADD" --list-targets
```

Routing details: `cg-research/references/idea_targets.md` and
`cg-research/lib/cg_research/targets.py`.
