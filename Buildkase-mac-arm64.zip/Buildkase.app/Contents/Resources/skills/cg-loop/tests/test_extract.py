#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.extract import (  # noqa: E402
    article_from_page,
    load_previous_titles,
    load_previous_urls,
    parse_rss_items,
    skip_url_set,
    unwrap_news_url,
)

RSS = """<?xml version="1.0"?>
<rss version="2.0">
  <channel>
    <title>Health</title>
    <item>
      <title>Keto trial cuts liver fat</title>
      <link>https://www.sciencedaily.com/releases/2026/09/liver.htm</link>
      <description>Three diets, same weight loss.</description>
      <pubDate>Wed, 16 Sep 2026 08:00:00 EDT</pubDate>
    </item>
    <item>
      <title>Second story</title>
      <link>https://www.sciencedaily.com/releases/2026/09/second.htm</link>
      <description>Later item.</description>
    </item>
  </channel>
</rss>
"""


class ExtractTests(unittest.TestCase):
    def test_parse_rss_first_item(self) -> None:
        items = parse_rss_items(RSS)
        self.assertGreaterEqual(len(items), 2)
        self.assertEqual(items[0]["title"], "Keto trial cuts liver fat")
        self.assertTrue(items[0]["url"].endswith("liver.htm"))
        self.assertIn("same weight loss", items[0]["text"])

    def test_article_from_page_rss(self) -> None:
        article = article_from_page(
            {
                "url": "https://www.sciencedaily.com/rss/top/health.xml",
                "html": RSS,
                "text": "",
                "actions": [],
            },
            phrase="latest article",
        )
        self.assertIsNotNone(article)
        assert article is not None
        self.assertEqual(article["title"], "Keto trial cuts liver fat")

    def test_article_from_page_link(self) -> None:
        article = article_from_page(
            {
                "url": "https://www.sciencedaily.com/",
                "html": "<html></html>",
                "text": "",
                "actions": [
                    {
                        "kind": "click",
                        "label": "Health release: new article",
                        "href": "https://www.sciencedaily.com/releases/2026/09/x.htm",
                    }
                ],
            },
            phrase="latest article",
        )
        self.assertIsNotNone(article)
        assert article is not None
        self.assertIn("releases", article["url"])

    def test_skip_first_used_url(self) -> None:
        used = "https://www.sciencedaily.com/releases/2026/09/liver.htm"
        article = article_from_page(
            {
                "url": "https://www.sciencedaily.com/rss/top/health.xml",
                "html": RSS,
                "text": "",
                "actions": [],
            },
            phrase="first url not in $seen",
            skip_urls=skip_url_set({"seen": [used]}, "first url not in $seen"),
        )
        self.assertIsNotNone(article)
        assert article is not None
        self.assertTrue(article["url"].endswith("second.htm"))

    def test_load_previous_urls_from_source_url_txt(self) -> None:
        import tempfile

        used = "https://www.sciencedaily.com/releases/2026/09/liver.htm"
        other = "https://example.com/not-this"
        with tempfile.TemporaryDirectory() as tmp:
            draft = Path(tmp) / "draft"
            nested = Path(tmp) / "approved" / "pack"
            draft.mkdir()
            nested.mkdir(parents=True)
            (draft / "one").mkdir()
            (draft / "one" / "source_url.txt").write_text(used + "\n", encoding="utf-8")
            (nested / "source_url.txt").write_text(other + "\n", encoding="utf-8")
            urls = load_previous_urls(
                [str(draft), str(Path(tmp) / "approved")],
                filter_text="previous sciencedaily articles",
            )
        self.assertEqual(urls, [used])

    def test_load_previous_titles_from_posting_data(self) -> None:
        import os
        import tempfile
        import time

        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp) / "archive"
            approved = Path(tmp) / "approved"
            older = archive / "20260101_salt_and_blood_pressure"
            newer = archive / "20260201_walk_after_dinner"
            kept = approved / "a-gut-molecule"
            older.mkdir(parents=True)
            newer.mkdir(parents=True)
            kept.mkdir(parents=True)
            (older / "posting_data.txt").write_text("title\nSalt and blood pressure\n", encoding="utf-8")
            (newer / "posting_data.txt").write_text("title\nWalk after dinner\n", encoding="utf-8")
            (kept / "posting_data.txt").write_text(
                "title\nA gut molecule linked to faster memory loss\n",
                encoding="utf-8",
            )
            now = time.time()
            os.utime(older, (now - 20, now - 20))
            os.utime(newer, (now, now))
            titles = load_previous_titles([str(archive), str(approved)])
        self.assertEqual(
            titles,
            [
                "Walk after dinner",
                "Salt and blood pressure",
                "A gut molecule linked to faster memory loss",
            ],
        )

    def test_yahoo_search_picks_a_heart_story_and_unwraps_it(self) -> None:
        wrapped = (
            "https://r.search.yahoo.com/_ylt=abc/RU=https%3a%2f%2fwww.health.com%2fmagnesium-blood-pressure"
            "/RK=2/RS=zzz"
        )
        self.assertEqual(
            unwrap_news_url(wrapped),
            "https://www.health.com/magnesium-blood-pressure",
        )
        article = article_from_page(
            {
                "url": "https://news.search.yahoo.com/search?p=heart",
                "html": "<html></html>",
                "text": "",
                "actions": [
                    {
                        "kind": "click",
                        "label": "Shopping",
                        "href": "https://r.search.yahoo.com/RU=https%3a%2f%2fshopping.yahoo.com%2f/RK=2",
                    },
                    {
                        "kind": "click",
                        "label": "What Happens to Your Blood Pressure When You Take Magnesium",
                        "href": wrapped,
                    },
                ],
            },
            phrase="first heart or blood pressure article not in $seen",
        )
        self.assertIsNotNone(article)
        assert article is not None
        self.assertEqual(article["url"], "https://www.health.com/magnesium-blood-pressure")
        self.assertIn("Blood Pressure", article["title"])


if __name__ == "__main__":
    unittest.main()
