#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.compiled import execute_compiled  # noqa: E402
from cg_loop.data_numbers import data_numbers_enabled, numbered_data, step_requests_no_numbers  # noqa: E402
from cg_loop.workflow import apply_overrides, load_workflow  # noqa: E402

_WRITE = '''
def run(ctx):
    import os
    from pathlib import Path
    data = ctx["data"]
    os.makedirs(data, exist_ok=True)
    first = os.path.join(data, "recommendation-metamuse.md")
    second = os.path.join(data, "recommendation-deepseek.md")
    with open(first, "w", encoding="utf-8") as handle:
        handle.write("one")
    Path(second).write_text("two", encoding="utf-8")
    report = os.path.join(data, "2024-report.md")
    with open(report, "w", encoding="utf-8") as handle:
        handle.write("year")
    kept = os.path.join(data, "01-notes.md")
    with open(kept, "w", encoding="utf-8") as handle:
        handle.write("kept")
    outside = os.path.join(ctx["outside"], "plain.txt")
    with open(outside, "w", encoding="utf-8") as handle:
        handle.write("out")
    with open(first, "w", encoding="utf-8") as handle:
        handle.write("one-again")
    renamed = os.path.join(data, "moved.txt")
    os.replace(os.path.join(data, "01-notes.md"), renamed)
    return {
        "outputs": {
            "size": os.path.getsize(first),
            "text": Path(first).read_text(encoding="utf-8"),
            "second": Path(second).read_text(encoding="utf-8"),
            "exists": os.path.isfile(first),
            "moved": os.path.isfile(renamed),
        }
    }
'''


class DataNumberTests(unittest.TestCase):
    def test_step_and_config_can_turn_numbers_off(self) -> None:
        self.assertTrue(step_requests_no_numbers("write the guide with no numbers"))
        self.assertTrue(step_requests_no_numbers("do not number the files"))
        self.assertFalse(step_requests_no_numbers("write recommendation-metamuse.md"))
        self.assertFalse(data_numbers_enabled(True, "save the plan with no numbers", {}))
        self.assertFalse(data_numbers_enabled(True, "", {"DATA_NUMBERS": "false"}))
        self.assertTrue(data_numbers_enabled(False, "", {"DATA_NUMBERS": "true"}))
        self.assertFalse(data_numbers_enabled(True, "no numbers", {"DATA_NUMBERS": "true"}))
        self.assertTrue(data_numbers_enabled(True, "", {}))
        self.assertFalse(data_numbers_enabled(False, "", {}))

    def test_yaml_config_and_param(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  data-numbers: false",
                        "wf_off:",
                        "  - /python print hi",
                        "wf_on:",
                        "  config:",
                        "    data-numbers: true",
                        "  steps:",
                        "    - /python print hi",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(path)
            self.assertFalse(workflow.data_numbers)
            groups = workflow.named_groups()
            self.assertFalse(groups["wf_off"].data_numbers)
            self.assertTrue(groups["wf_on"].data_numbers)
            apply_overrides(workflow, {"data-numbers": "0"})
            self.assertFalse(groups["wf_on"].data_numbers)
            apply_overrides(workflow, {"data-numbers": "yes"})
            self.assertTrue(workflow.data_numbers)
            self.assertTrue(groups["wf_off"].data_numbers)

    def test_writes_use_creation_order(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data = root / "z-data"
            outside = root / "outside"
            outside.mkdir()
            script = root / "b-compile.py"
            script.write_text(_WRITE, encoding="utf-8")
            result = execute_compiled(
                script,
                {"data": str(data), "outside": str(outside), "env": {}, "variables": {}},
            )
            self.assertEqual(result["outputs"]["text"], "one-again")
            self.assertEqual(result["outputs"]["second"], "two")
            self.assertEqual(result["outputs"]["size"], len("one-again"))
            self.assertTrue(result["outputs"]["exists"])
            self.assertTrue(result["outputs"]["moved"])
            self.assertEqual(
                sorted(path.name for path in data.iterdir()),
                [
                    "01-recommendation-metamuse.md",
                    "02-recommendation-deepseek.md",
                    "03-2024-report.md",
                    "04-moved.txt",
                ],
            )
            self.assertEqual((data / "01-recommendation-metamuse.md").read_text(encoding="utf-8"), "one-again")
            self.assertEqual((outside / "plain.txt").read_text(encoding="utf-8"), "out")
            self.assertFalse((data / "recommendation-metamuse.md").exists())

            again = root / "next.py"
            again.write_text(
                "def run(ctx):\n"
                "    import os\n"
                "    path = os.path.join(ctx['data'], 'care_plan.md')\n"
                "    with open(path, 'w', encoding='utf-8') as handle:\n"
                "        handle.write('plan')\n"
                "    return {'outputs': {'ok': os.path.isfile(path)}}\n",
                encoding="utf-8",
            )
            follow = execute_compiled(again, {"data": str(data), "env": {}, "variables": {}})
            self.assertTrue(follow["outputs"]["ok"])
            self.assertEqual((data / "05-care_plan.md").read_text(encoding="utf-8"), "plan")
            self.assertEqual((outside / "plain.txt").name, "plain.txt")

    def test_flag_keeps_plain_names(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data = root / "z-data"
            script = root / "b-compile.py"
            script.write_text(
                "def run(ctx):\n"
                "    import os\n"
                "    os.makedirs(ctx['data'], exist_ok=True)\n"
                "    path = os.path.join(ctx['data'], 'recommendation-metamuse.md')\n"
                "    with open(path, 'w', encoding='utf-8') as handle:\n"
                "        handle.write('plain')\n"
                "    return {'outputs': {'path': path}}\n",
                encoding="utf-8",
            )
            execute_compiled(
                script,
                {"data": str(data), "data_numbers": False, "env": {}, "variables": {}},
            )
            self.assertEqual((data / "recommendation-metamuse.md").read_text(encoding="utf-8"), "plain")
            self.assertEqual(list(data.iterdir()), [data / "recommendation-metamuse.md"])

    def test_patches_are_removed_after_the_step(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "z-data"
            data.mkdir()
            with numbered_data({"data": str(data)}):
                target = data / "note.txt"
                with open(target, "w", encoding="utf-8") as handle:
                    handle.write("n")
            self.assertTrue((data / "01-note.txt").is_file())
            leftover = data / "after.txt"
            with open(leftover, "w", encoding="utf-8") as handle:
                handle.write("after")
            self.assertTrue(leftover.is_file())
            self.assertFalse((data / "02-after.txt").exists())


if __name__ == "__main__":
    unittest.main()
