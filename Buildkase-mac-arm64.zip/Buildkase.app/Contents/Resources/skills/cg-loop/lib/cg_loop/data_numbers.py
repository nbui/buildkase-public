"""Prefix files written into this run's data folder so the folder lists in creation order.

`01-name`, `02-name`, and so on. A step that asks for no numbers, config
`data-numbers: false`, or env `DATA_NUMBERS=false` keeps the plain filename.
Later reads of the plain name still find the numbered file.
"""

from __future__ import annotations

import builtins
import glob
import io
import os
import re
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

_ORDERED = re.compile(r"^(\d{2})-(.+)$")
_NO_NUMBERS = re.compile(
    r"(?i)(?:"
    r"\bno numbers\b"
    r"|\bwithout numbers\b"
    r"|\bdo not number\b"
    r"|don't number"
    r"|\bdont number\b"
    r"|\bunnumbered\b"
    r"|\bno number prefixes?\b"
    r"|\bwithout (?:a |any )?number prefixes?\b"
    r"|\bskip numbers\b"
    r"|\bnumbers off\b"
    r")"
)
_ENV_KEYS = ("DATA_NUMBERS", "data_numbers", "data-numbers")


def step_requests_no_numbers(text: str) -> bool:
    """True when this step asks to keep plain filenames."""
    return _NO_NUMBERS.search(text or "") is not None


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def data_numbers_enabled(enabled: bool, step_text: str = "", env: dict[str, Any] | None = None) -> bool:
    """Config turns numbering on. A step that asks for no numbers turns it off.

    `DATA_NUMBERS` in the environment, including a `set_config` step, replaces
    the config flag. The step text still wins when it asks for no numbers.
    """
    if step_requests_no_numbers(step_text):
        return False
    if env:
        for key in _ENV_KEYS:
            if key in env and str(env.get(key) or "").strip() != "":
                return _truthy(env.get(key))
    return bool(enabled)


class _Writes:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.depth = 0
        self._orig_open = builtins.open
        self._orig_io_open = io.open
        self._orig_stat = os.stat
        self._orig_rename = os.rename
        self._orig_replace = os.replace
        self._orig_glob = glob.glob
        self._orig_iglob = glob.iglob

    def install(self) -> None:
        builtins.open = self._open  # type: ignore[assignment]
        io.open = self._open  # type: ignore[assignment]
        os.stat = self._stat  # type: ignore[assignment]
        os.rename = self._rename  # type: ignore[assignment]
        os.replace = self._replace  # type: ignore[assignment]
        glob.glob = self._glob  # type: ignore[assignment]
        glob.iglob = self._iglob  # type: ignore[assignment]

    def restore(self) -> None:
        builtins.open = self._orig_open
        io.open = self._orig_io_open  # type: ignore[assignment]
        os.stat = self._orig_stat  # type: ignore[assignment]
        os.rename = self._orig_rename  # type: ignore[assignment]
        os.replace = self._orig_replace  # type: ignore[assignment]
        glob.glob = self._orig_glob  # type: ignore[assignment]
        glob.iglob = self._orig_iglob  # type: ignore[assignment]

    def _open(self, file: Any, mode: str = "r", *args: Any, **kwargs: Any) -> Any:
        if self.depth:
            return self._orig_open(file, mode, *args, **kwargs)
        path = _as_path(file)
        if path is None:
            return self._orig_open(file, mode, *args, **kwargs)
        self.depth += 1
        try:
            target: Any = file
            if self._inside(path):
                writing = any(flag in str(mode) for flag in ("w", "a", "x", "+"))
                target = self._allocate(path) if writing else self._read_target(path)
        finally:
            self.depth -= 1
        return self._orig_open(target, mode, *args, **kwargs)

    def _stat(self, path: Any, *args: Any, **kwargs: Any) -> os.stat_result:
        if self.depth or args or set(kwargs) - {"follow_symlinks"}:
            return self._orig_stat(path, *args, **kwargs)
        file = _as_path(path)
        if file is None:
            return self._orig_stat(path, *args, **kwargs)
        self.depth += 1
        try:
            target = self._read_target(file) if self._inside(file) else file
        finally:
            self.depth -= 1
        return self._orig_stat(target, *args, **kwargs)

    def _rename(self, src: Any, dst: Any, *args: Any, **kwargs: Any) -> None:
        src, dst = self._move_paths(src, dst, args, kwargs)
        self._orig_rename(src, dst, *args, **kwargs)

    def _replace(self, src: Any, dst: Any, *args: Any, **kwargs: Any) -> None:
        src, dst = self._move_paths(src, dst, args, kwargs)
        self._orig_replace(src, dst, *args, **kwargs)

    def _move_paths(self, src: Any, dst: Any, args: tuple[Any, ...], kwargs: dict[str, Any]) -> tuple[Any, Any]:
        if self.depth or args or kwargs:
            return src, dst
        src_path = _as_path(src)
        dst_path = _as_path(dst)
        if src_path is None and dst_path is None:
            return src, dst
        self.depth += 1
        try:
            if src_path is not None and self._inside(src_path):
                src = self._read_target(src_path)
            if dst_path is not None and self._inside(dst_path):
                dst = self._allocate(dst_path)
        finally:
            self.depth -= 1
        return src, dst

    def _glob(self, pathname: Any, *args: Any, **kwargs: Any) -> list[str]:
        found = self._orig_glob(pathname, *args, **kwargs)
        extra = self._glob_one(pathname, found)
        return extra if extra is not None else found

    def _iglob(self, pathname: Any, *args: Any, **kwargs: Any) -> Any:
        found = list(self._orig_iglob(pathname, *args, **kwargs))
        extra = self._glob_one(pathname, found)
        return iter(extra if extra is not None else found)

    def _glob_one(self, pathname: Any, found: list[str]) -> list[str] | None:
        if self.depth or found or glob.has_magic(str(pathname)):
            return None
        path = _as_path(pathname)
        if path is None:
            return None
        self.depth += 1
        try:
            if not self._inside(path):
                return None
            target = self._read_target(path)
            if target == path or not _exists(self._orig_stat, target):
                return None
            return [os.fspath(target)]
        finally:
            self.depth -= 1

    def _inside(self, path: Path) -> bool:
        try:
            resolved = path.expanduser().resolve()
        except (OSError, RuntimeError):
            return False
        if resolved == self.root:
            return False
        try:
            resolved.relative_to(self.root)
        except ValueError:
            return False
        return True

    def _read_target(self, path: Path) -> Path:
        if _ORDERED.match(path.name):
            return path
        found = self._find(path)
        return found if found is not None else path

    def _allocate(self, path: Path) -> Path:
        if not path.name or _ORDERED.match(path.name):
            return path
        found = self._find(path)
        if found is not None:
            return found
        if _exists(self._orig_stat, path):
            return path
        number = self._next(path.parent)
        return path.parent / f"{number:02d}-{path.name}"

    def _find(self, path: Path) -> Path | None:
        best: tuple[int, str] | None = None
        try:
            with os.scandir(path.parent) as entries:
                for entry in entries:
                    match = _ORDERED.match(entry.name)
                    if match and match.group(2) == path.name:
                        number = int(match.group(1))
                        if best is None or number < best[0]:
                            best = (number, entry.name)
        except OSError:
            return None
        if best is None:
            return None
        return path.parent / best[1]

    def _next(self, parent: Path) -> int:
        highest = 0
        try:
            with os.scandir(parent) as entries:
                for entry in entries:
                    match = _ORDERED.match(entry.name)
                    if match:
                        highest = max(highest, int(match.group(1)))
        except OSError:
            pass
        return highest + 1


def _as_path(value: Any) -> Path | None:
    if isinstance(value, int) or isinstance(value, bytes):
        return None
    if isinstance(value, Path):
        return value
    if isinstance(value, (str, os.PathLike)):
        return Path(os.fspath(value))
    return None


def _exists(stat: Any, path: Path) -> bool:
    try:
        stat(path)
    except OSError:
        return False
    return True


_ACTIVE = 0


@contextmanager
def numbered_data(ctx: dict[str, Any] | None) -> Iterator[None]:
    """Number new files under `ctx["data"]` while this block runs."""
    global _ACTIVE
    data = ""
    enabled = True
    if isinstance(ctx, dict):
        data = str(ctx.get("data") or "")
        if "data_numbers" in ctx:
            enabled = bool(ctx.get("data_numbers"))
    if not enabled or not data or _ACTIVE:
        yield
        return
    root = Path(data).expanduser().resolve()
    state = _Writes(root)
    state.install()
    _ACTIVE += 1
    try:
        yield
    finally:
        _ACTIVE -= 1
        state.restore()
