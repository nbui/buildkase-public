"""One folder per step under <project>/cache/<workflow file>/<workflow name>/.

A step folder is a packet you can hand to any model:

    <step slug, truncated>_<hash>/
      a_01-context.json     what the step is, and how to compile and test it
      a-prompt.json         messages the request loads
      a-prompt.md           readable copy of that prompt
      a-config.json         step params, when the step has any
      a-request.py          HTTP call; message text is loaded from a-prompt.json
      b_01-context.json     compile state the script reuses
      b-compile.py          compiled script
      b-crop.png            remembered control image, when a click has one
      c-01-context.json     this run's record
      c-run.log             this run's log
      c-compile.log         this run's compile log
      z-data_<file>         files this run wrote

The next run copies that tree to <workflow name>/archived/<stamp>/, then deletes
c- files, c_ files, and z-data. Prompts, config, and the compiled script stay.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
from pathlib import Path
from typing import Any

from .workflow import CODE_STEP_TYPES, PYTHON_TYPES, Step, Workflow, step_body, workflow_search_paths

_SLUG_RE = re.compile(r"[^A-Za-z0-9._-]+")
_FENCE_RE = re.compile(r"^```(?:\w+)?\s*([\s\S]*?)\s*```$", re.MULTILINE)
_STEP_DIR_RE = re.compile(r"^.+_[0-9a-f]{10}$")
_STEP_SLUG_LIMIT = 40
PACKET_SCRIPTS = frozenset({"b-compile.py", "b-compile.sh", "b-compile.bash"})


def is_code_step(step: Step) -> bool:
    return step.kind == "code" or str(step.extra or "").lower() in CODE_STEP_TYPES


def code_language(step: Step, step_type: str = "") -> str:
    hint = (step_type or step.extra or step.kind or "").strip().lower()
    if hint in PYTHON_TYPES:
        return "python"
    return "shell"


def workflow_slug(workflow: Workflow) -> str:
    if workflow.path and workflow.path.stem:
        return _fs_slug(workflow.path.stem)
    return _fs_slug(workflow.name or "workflow")


def step_slug(step: Step) -> str:
    text = step.workflow_name or step_body(step) or step.raw or "step"
    return _fs_slug(text)[:80] or "step"


def step_source_text(step: Step) -> str:
    return (step.raw or "").replace('"""', "'").strip()


def step_folder_name(step: Step) -> str:
    """Short readable name plus a hash of the full step text, so truncation stays unique."""
    slug = step_slug(step)[:_STEP_SLUG_LIMIT].strip("._-") or "step"
    digest = hashlib.sha256(step_source_text(step).encode("utf-8")).hexdigest()[:10]
    return f"{slug}_{digest}"


def packet_script_name(language: str = "python") -> str:
    if language == "python":
        return "b-compile.py"
    if language == "bash":
        return "b-compile.bash"
    return "b-compile.sh"


def is_packet_script(path: Path) -> bool:
    """A compiled script that already lives in its step folder."""
    return path.name in PACKET_SCRIPTS and bool(_STEP_DIR_RE.match(path.parent.name))


def is_step_folder(path: Path) -> bool:
    """A truncated step directory, or a folder that already holds `b-compile`."""
    if _STEP_DIR_RE.match(path.name):
        return True
    if not path.is_dir():
        return False
    return any(item.name in PACKET_SCRIPTS for item in path.iterdir())


def data_filename(name: str) -> str:
    """`shot.jpg` becomes `z-data_shot.jpg`. Output files use this prefix."""
    base = Path(name).name
    if base.startswith("z-data_"):
        return base
    return f"z-data_{base}"


def ephemeral_name(name: str) -> bool:
    """Run logs and output files. The next run removes these and keeps the rest."""
    if name in {"run.log", "compile.log"}:
        return True
    if name.startswith("z-data"):
        return True
    return name.startswith("c-") or name.startswith("c_")


def _project_cache_base(workflow: Workflow) -> Path | None:
    """Folder that holds workflows-app.yaml, when this file is in its catalog."""
    path = workflow.path
    if path is None:
        return None
    from .app_config import app_config_path, workflows_root

    catalog = workflows_root()
    if catalog is None:
        return None
    try:
        path.resolve().relative_to(catalog.resolve())
    except (OSError, ValueError):
        return None
    app = app_config_path()
    if app.is_file():
        return app.resolve().parent
    return catalog.parent


def workflow_cache_dir(workflow: Workflow, *, env: dict[str, str] | None = None) -> Path:
    """`<project>/cache/<workflow_name>/` beside workflows-app.yaml.

    A file in the workflows catalog uses that project cache, so Agent Studio
    and cg-loop share one tree. WORKFLOW_CACHE still overrides. A file outside
    the catalog keeps its cache next to WORKFLOW_PATH.
    """
    merged = dict(os.environ)
    if workflow.env:
        merged.update(workflow.env)
    if env:
        merged.update(env)
    explicit = merged.get("WORKFLOW_CACHE") or merged.get("CG_LOOP_WORKFLOW_CACHE") or ""
    slug = workflow_slug(workflow)
    if explicit:
        return Path(explicit).expanduser().resolve() / slug
    project = _project_cache_base(workflow)
    if project is not None:
        return (project / "cache" / slug).resolve()
    roots = workflow_search_paths(merged, workflow.path)
    base = roots[0] if roots else None
    if base and base.is_file():
        base = base.parent
    if base is None:
        base = (workflow.path.parent if workflow.path else Path.cwd())
    return (base / "cache" / slug).resolve()


def workflow_group_dir(workflow: Workflow, *, env: dict[str, str] | None = None) -> Path:
    """`<project>/cache/<workflow file>/<workflow name>/`.

    The workflow name is the group (`wf_open_chrome`). A file with no group uses `main`.
    Each group has its own step folders and `archived/`, so one group leaves the others.
    """
    root = workflow_cache_dir(workflow, env=env)
    group = (workflow.group or "").strip()
    name = _fs_slug(group) if group else "main"
    return (root / name).resolve()


def workflow_log_dir(workflow: Workflow, *, env: dict[str, str] | None = None) -> Path:
    """Same folder as the step packets. The group log is `c-run.log`."""
    return workflow_group_dir(workflow, env=env)


def workflow_data_dir(workflow: Workflow, *, env: dict[str, str] | None = None) -> Path:
    """`.../<workflow name>/z-data/` — this run's working files. The next run removes it."""
    return workflow_group_dir(workflow, env=env) / "z-data"


def workflow_compiled_dir(workflow: Workflow, *, env: dict[str, str] | None = None) -> Path:
    """Step folders live directly under the workflow name, next to `archived/`."""
    return workflow_group_dir(workflow, env=env)


def step_packet_dir(workflow: Workflow, step: Step, *, env: dict[str, str] | None = None) -> Path:
    return workflow_group_dir(workflow, env=env) / step_folder_name(step)


def step_cache_path(workflow: Workflow, step: Step, *, env: dict[str, str] | None = None) -> Path:
    language = code_language(step)
    return step_packet_dir(workflow, step, env=env) / packet_script_name(language)


def find_step_script(workflow: Workflow, step: Step, *, env: dict[str, str] | None = None) -> Path | None:
    preferred = step_cache_path(workflow, step, env=env)
    if preferred.is_file():
        return preferred
    directory = preferred.parent
    if not directory.is_dir():
        return None
    for name in PACKET_SCRIPTS:
        candidate = directory / name
        if candidate.is_file():
            return candidate
    return None


def write_stage_context(folder: Path, step: Step) -> Path:
    """`a_01-context.json` tells another model how to compile and test this folder."""
    folder.mkdir(parents=True, exist_ok=True)
    payload = {
        "stage": "a",
        "seq": 1,
        "step": step.raw,
        "kind": step.kind,
        "tool": step.tool,
        "script": "b-compile.py",
        "compile_context": "b_01-context.json",
        "run_log": "c-run.log",
        "run_context": "c-01-context.json",
        "outputs": "z-data_<file>",
        "instruction": (
            "This folder is one workflow step. "
            "Read a_01-context.json and every a- file, especially a-prompt.md and a-config.json. "
            "Write the compiled script to b-compile.py. It must define run(ctx). "
            "Put compile state the script reuses in b_01-context.json. "
            "A test writes c-run.log, c-01-context.json, and any files as z-data_<name>. "
            "The next run copies this folder to archived/ and deletes c- files and z-data files. "
            "a- files and b- files stay so the script can be reused."
        ),
    }
    path = folder / "a_01-context.json"
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if step.params:
        config = folder / "a-config.json"
        config.write_text(json.dumps(step.params, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
    return path


def write_step_script(path: Path, body: str, *, language: str = "shell") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = _strip_fence(body).strip() + "\n"
    if language == "python":
        if not text.startswith("#!"):
            text = "#!/usr/bin/env python3\n" + text
    else:
        if not text.startswith("#!"):
            text = "#!/usr/bin/env bash\nset -euo pipefail\n" + text
    path.write_text(text, encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return path


def invoke_command(path: Path) -> str:
    resolved = str(path.resolve())
    if path.suffix.lower() == ".py":
        return f"python3 {shlex_quote(resolved)}"
    return f"bash {shlex_quote(resolved)}"


def script_from_command(command: str) -> str:
    return command.strip() + "\n"


def should_cache_command(command: str, cached: Path | None) -> bool:
    text = (command or "").strip()
    if not text:
        return False
    if cached and cached.is_file() and str(cached) in text:
        return False
    return True


def _fs_slug(value: str) -> str:
    text = _SLUG_RE.sub("_", (value or "").strip()).strip("._-")
    return text.lower() or "workflow"


def _strip_fence(body: str) -> str:
    text = (body or "").strip()
    match = _FENCE_RE.match(text)
    if match:
        return match.group(1).strip()
    return text


def shlex_quote(value: str) -> str:
    import shlex

    return shlex.quote(value)


def cache_env(step: Step, variables: dict[str, Any], base: dict[str, str] | None = None) -> dict[str, str]:
    """Env for a cached script: workflow env, step params, then $variables."""
    merged = dict(base or {})
    for key, value in step.params.items():
        merged[str(key)] = "" if value is None else str(value)
    for key, value in variables.items():
        if isinstance(value, dict):
            merged[str(key)] = str(value.get("url") or value.get("text") or value.get("title") or "")
        elif value is None:
            continue
        else:
            merged[str(key)] = str(value)
    return merged
