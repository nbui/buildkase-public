"""Quoted tool params.

`"..."` or `'...'` is one value. `+params` and `into $var` inside the quotes
stay in that value. A backslash escapes the next character, as in `\\"`,
`\\'`, `\\+`, and `\\\\`. An apostrophe inside a word, such as `it's`, is not
a quote.
"""

from __future__ import annotations

from re import Match, Pattern


def mask_quoted(text: str) -> str:
    """Copy `text` with quoted interiors hidden, so a search skips them.

    The quote marks stay. The characters they wrap, and any escaped character,
    become spaces. Indexes still line up with `text`.
    """
    raw = text or ""
    chars = list(raw)
    index = 0
    quote = ""
    while index < len(raw):
        char = raw[index]
        if quote:
            if char == "\\" and index + 1 < len(raw):
                chars[index] = " "
                chars[index + 1] = " "
                index += 2
                continue
            if char == quote:
                quote = ""
                index += 1
                continue
            chars[index] = " "
            index += 1
            continue
        if char == "\\" and index + 1 < len(raw):
            chars[index] = " "
            chars[index + 1] = " "
            index += 2
            continue
        if char in {'"', "'"} and _opens_quote(raw, index):
            quote = char
            index += 1
            continue
        index += 1
    if quote:
        raise ValueError("unclosed quote")
    return "".join(chars)


def finditer_outside(pattern: Pattern[str], text: str) -> list[Match[str]]:
    """Matches of `pattern` whose text is outside quotes."""
    return list(pattern.finditer(mask_quoted(text)))


def search_outside(pattern: Pattern[str], text: str) -> Match[str] | None:
    """The first match of `pattern` outside quotes."""
    return pattern.search(mask_quoted(text))


def unquote_param(raw: str, *, only: bool = False) -> str:
    """The param value. One pair of quotes is removed and escapes are applied.

    A value that is not one quoted string is returned with `\\+`, `\\"`,
    `\\'`, and `\\\\` decoded. `only` rejects text after a quoted value.
    """
    text = (raw or "").strip()
    if not text or not _opens_quote(text, 0):
        return _unescape_plain(text)
    value, index = _read_quoted(text, 0)
    rest = text[index:].strip()
    if rest:
        if only:
            raise ValueError(f"extra text after quote: {rest}")
        return text
    return value.strip()


def _opens_quote(text: str, index: int) -> bool:
    if text[index] not in {'"', "'"}:
        return False
    return index == 0 or text[index - 1].isspace()


def _read_quoted(text: str, start: int) -> tuple[str, int]:
    quote = text[start]
    index = start + 1
    buf: list[str] = []
    while index < len(text):
        char = text[index]
        if char == "\\" and index + 1 < len(text):
            buf.append(text[index + 1])
            index += 2
            continue
        if char == quote:
            return "".join(buf), index + 1
        buf.append(char)
        index += 1
    raise ValueError("unclosed quote")


def _unescape_plain(text: str) -> str:
    out: list[str] = []
    index = 0
    while index < len(text):
        if text[index] == "\\" and index + 1 < len(text) and text[index + 1] in {'\\', '"', "'", "+"}:
            out.append(text[index + 1])
            index += 2
            continue
        out.append(text[index])
        index += 1
    return "".join(out)


def replace_outside(pattern: Pattern[str], text: str, repl) -> str:
    """Replace matches that sit outside quotes. Later matches keep their indexes."""
    raw = text or ""
    matches = finditer_outside(pattern, raw)
    for match in reversed(matches):
        raw = raw[: match.start()] + repl(match) + raw[match.end() :]
    return raw
