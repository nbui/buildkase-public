#!/usr/bin/env python3
"""A system file dialog must not leave the page unread."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import patch

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.browser import (  # noqa: E402
    ACT_JS,
    SNAPSHOT_JS,
    _DISMISS_HASHTAG_POPUP_JS,
    _click_file_button,
    choose_open_page,
    dismiss_hashtag_popup,
    evaluate_guarded,
    opens_file_dialog,
    perform,
    release_stuck_file_dialog,
    set_local_input_files,
)


class _Chooser:
    def __init__(self) -> None:
        self.files = None

    def set_files(self, files, timeout=None) -> None:
        del timeout
        self.files = list(files)


class _Pending:
    def __init__(self, chooser: _Chooser) -> None:
        self.value = chooser

    def __enter__(self) -> "_Pending":
        return self

    def __exit__(self, *_args: object) -> bool:
        return False


class _Page:
    def __init__(self) -> None:
        self.clicks: list[tuple[float, float]] = []
        self.chooser = _Chooser()
        self.mouse = self

    def click(self, x: float, y: float) -> None:
        self.clicks.append((x, y))

    def expect_file_chooser(self, timeout: int | None = None) -> _Pending:
        del timeout
        return _Pending(self.chooser)


class BrowserFileDialogTests(unittest.TestCase):
    def test_select_files_is_a_system_dialog(self) -> None:
        self.assertTrue(opens_file_dialog("Select files"))
        self.assertTrue(opens_file_dialog("Select video"))
        self.assertTrue(opens_file_dialog("Select from computer"))
        self.assertFalse(opens_file_dialog("Upload videos"))
        self.assertFalse(opens_file_dialog("Create"))

    def test_file_button_click_clears_the_chooser(self) -> None:
        page = _Page()
        result = _click_file_button(page, 12.0, 40.0)
        self.assertEqual(result["file_dialog"], "closed")
        self.assertEqual(page.clicks, [(12.0, 40.0)])
        self.assertEqual(page.chooser.files, [])

    def test_local_input_uses_the_chrome_path(self) -> None:
        import tempfile

        class Session:
            def __init__(self) -> None:
                self.sent: list[tuple[str, dict]] = []
                self.detached = False

            def send(self, method: str, params: dict | None = None) -> dict:
                self.sent.append((method, params or {}))
                if method == "Runtime.evaluate":
                    return {"result": {"objectId": "input-1", "type": "object"}}
                return {}

            def detach(self) -> None:
                self.detached = True

        class Page:
            def __init__(self, session: Session) -> None:
                self.session = session
                self.context = self

            def new_cdp_session(self, page: object) -> Session:
                self.page = page
                return self.session

        with tempfile.TemporaryDirectory() as folder:
            video = Path(folder) / "youtube_captions_music.mp4"
            video.write_bytes(b"video")
            session = Session()
            set_local_input_files(Page(session), str(video))
        self.assertTrue(session.detached)
        self.assertEqual(session.sent[0][0], "Runtime.evaluate")
        self.assertEqual(session.sent[1][0], "DOM.setFileInputFiles")
        self.assertEqual(session.sent[1][1]["objectId"], "input-1")
        self.assertEqual(session.sent[1][1]["files"], [str(video.resolve())])

    def test_file_button_click_sends_the_named_video(self) -> None:
        page = _Page()
        video = "/tmp/youtube_captions_music.mp4"
        result = _click_file_button(page, 12.0, 40.0, [video])
        self.assertEqual(result["file_dialog"], "chosen")
        self.assertEqual(result["file"], video)
        self.assertEqual(page.chooser.files, [video])

    def test_missing_chooser_closes_the_native_panel(self) -> None:
        class Slow:
            mouse = None

            def expect_file_chooser(self, timeout: int | None = None):
                del timeout
                raise TimeoutError("no chooser")

        with patch("cg_loop.browser.release_stuck_file_dialog", return_value=True) as close:
            result = _click_file_button(Slow(), 1.0, 2.0)
        self.assertEqual(result["file_dialog"], "closed")
        close.assert_called_once()

    def test_snapshot_wait_closes_a_blocking_dialog(self) -> None:
        class Page:
            def evaluate(self, expression: str, arg: object = None) -> dict:
                del expression, arg
                time.sleep(0.2)
                return {"ok": True}

        with patch("cg_loop.browser.release_stuck_file_dialog", return_value=True) as close:
            result = evaluate_guarded(Page(), "snapshot", timeout_s=0.05)
        self.assertEqual(result, {"ok": True})
        close.assert_called_once()

    def test_release_reports_a_cancelled_panel(self) -> None:
        class Result:
            returncode = 0
            stdout = "cancelled\n"
            stderr = ""

        with patch("cg_loop.browser.sys.platform", "darwin"), patch(
            "cg_loop.browser.subprocess.run", return_value=Result()
        ) as run:
            self.assertTrue(release_stuck_file_dialog())
        self.assertEqual(run.call_args.args[0][0], "osascript")


class _Keys:
    def __init__(self) -> None:
        self.pressed: list[str] = []
        self.inserted: list[str] = []

    def press(self, key: str) -> None:
        self.pressed.append(key)

    def insert_text(self, text: str) -> None:
        self.inserted.append(text)


class _FillPage:
    def __init__(self, popup: bool) -> None:
        self.keyboard = _Keys()
        self.mouse = self
        self.clicks: list[tuple[float, float]] = []
        self.popup = popup
        self.scripts: list[str] = []
        self.waits: list[int] = []

    def click(self, x: float, y: float) -> None:
        self.clicks.append((x, y))

    def evaluate(self, expression: str, arg: object = None) -> object:
        if arg is not None:
            return {"x": 10.0, "y": 20.0, "href": ""}
        self.scripts.append(expression)
        if expression == _DISMISS_HASHTAG_POPUP_JS:
            open_popup = self.popup
            self.popup = False
            return open_popup
        return None

    def wait_for_timeout(self, ms: int) -> None:
        self.waits.append(ms)


class CoveredSpinbuttonTests(unittest.TestCase):
    def test_hour_is_typed_through_the_locator_when_the_node_is_covered(self) -> None:
        class Keys:
            def __init__(self) -> None:
                self.pressed: list[str] = []
                self.typed: list[str] = []

            def press(self, key: str) -> None:
                self.pressed.append(key)

            def type(self, text: str, delay: int = 0) -> None:
                del delay
                self.typed.append(text)

        class Field:
            def __init__(self) -> None:
                self.keyboard = Keys()
                self.clicks = 0

            def locator(self, selector: str) -> "Field":
                self.selector = selector
                return self

            @property
            def first(self) -> "Field":
                return self

            def click(self, timeout: int = 0) -> None:
                del timeout
                self.clicks += 1

            def evaluate(self, expression: str, arg: object = None) -> None:
                del expression, arg
                raise AssertionError("the hour field should be typed, not hit-tested")

        page = Field()
        result = perform(
            page,
            {
                "id": "hours",
                "kind": "fill",
                "role": "spinbutton",
                "node": 4,
                "selector": 'role=spinbutton[name="Hours"s]',
                "label": "Hours",
            },
            "11",
        )
        self.assertEqual(result["executed"], "hours")
        self.assertEqual(page.clicks, 1)
        self.assertEqual(page.keyboard.typed, ["11"])
        self.assertEqual(page.keyboard.pressed, [])


class ContentEditableFillTests(unittest.TestCase):
    def test_caption_is_typed_into_a_contenteditable(self) -> None:
        class Keys:
            def __init__(self) -> None:
                self.pressed: list[str] = []
                self.typed: list[str] = []
                self.inserted: list[str] = []

            def press(self, key: str) -> None:
                self.pressed.append(key)

            def type(self, text: str, delay: int = 0) -> None:
                del delay
                self.typed.append(text)

            def insert_text(self, text: str) -> None:
                self.inserted.append(text)

        class Field:
            def __init__(self, page: "Page", editable: bool, shown: str) -> None:
                self.page = page
                self.editable = editable
                self.shown = shown

            @property
            def first(self) -> "Field":
                return self

            def click(self, timeout: int = 0) -> None:
                del timeout
                self.page.clicks += 1

            def evaluate(self, expression: str) -> object:
                if "isContentEditable" in expression:
                    return self.editable
                return self.shown if not self.editable else (self.page.keyboard.typed[-1] if self.page.keyboard.typed else "")

        class Page:
            def __init__(self, editable: bool, shown: str = "") -> None:
                self.keyboard = Keys()
                self.clicks = 0
                self.waits: list[int] = []
                self.field = Field(self, editable, shown)

            def locator(self, selector: str) -> Field:
                self.selector = selector
                return self.field

            def wait_for_timeout(self, ms: int) -> None:
                self.waits.append(ms)

            def evaluate(self, expression: str, arg: object = None) -> None:
                del expression, arg
                raise AssertionError("a contenteditable caption is typed through the locator")

        caption = "The streets are quieting, and a steaming cup of pennyroyal is waiting."
        page = Page(editable=True)
        result = perform(
            page,
            {
                "id": "caption",
                "kind": "fill",
                "role": "textbox",
                "node": 9,
                "selector": 'role=textbox[name="Add a caption..."s]',
                "label": "Add a caption...",
            },
            caption,
        )
        self.assertEqual(result["executed"], "caption")
        self.assertEqual(page.keyboard.typed, [caption])
        self.assertEqual(page.keyboard.inserted, [])
        self.assertEqual(page.keyboard.pressed, ["Meta+A", "Backspace"])

        plain = Page(editable=False, shown="already there")
        perform(
            plain,
            {
                "id": "title",
                "kind": "fill",
                "role": "textbox",
                "node": 3,
                "selector": 'role=textbox[name="Title"s]',
                "label": "Title",
            },
            "Homeward Brew",
        )
        self.assertEqual(plain.keyboard.inserted, ["Homeward Brew"])
        self.assertEqual(plain.keyboard.typed, [])
        self.assertEqual(plain.keyboard.pressed, ["Meta+A", "Backspace"])

        missed = Page(editable=True)
        missed.field.shown = ""

        def empty_after_type(expression: str) -> object:
            if "isContentEditable" in expression:
                return True
            return ""

        missed.field.evaluate = empty_after_type  # type: ignore[method-assign]
        with self.assertRaises(RuntimeError):
            perform(
                missed,
                {
                    "id": "caption",
                    "kind": "fill",
                    "role": "textbox",
                    "selector": 'role=textbox[name="Add a caption..."s]',
                    "label": "Add a caption...",
                },
                caption,
            )

class HashtagPopupTests(unittest.TestCase):
    def test_description_with_hashtags_closes_the_suggestion_menu(self) -> None:
        page = _FillPage(popup=True)
        result = perform(
            page,
            {"id": "desc", "kind": "fill", "node": 4, "label": "Description"},
            "a quiet story #sleepstory #relax",
        )
        self.assertEqual(result["executed"], "desc")
        self.assertIn(_DISMISS_HASHTAG_POPUP_JS, page.scripts)
        self.assertEqual(page.keyboard.inserted, ["a quiet story #sleepstory #relax"])

    def test_title_without_a_hashtag_leaves_the_page_alone(self) -> None:
        page = _FillPage(popup=True)
        perform(
            page,
            {"id": "title", "kind": "fill", "node": 3, "label": "Title"},
            "marcus wakes before the sun",
        )
        self.assertEqual(page.scripts, [])
        self.assertTrue(page.popup)

    def test_dismiss_reports_when_a_menu_was_hidden(self) -> None:
        page = _FillPage(popup=True)
        self.assertTrue(dismiss_hashtag_popup(page))
        self.assertFalse(dismiss_hashtag_popup(page))


class SelectorClickTests(unittest.TestCase):
    def test_click_uses_the_role_selector(self) -> None:
        class Locator:
            def __init__(self, page: "Page") -> None:
                self.page = page

            def click(self, timeout: int | None = None) -> None:
                del timeout
                self.page.clicked = True

        class Page:
            def __init__(self) -> None:
                self.selector = ""
                self.clicked = False

            def locator(self, selector: str) -> Locator:
                self.selector = selector
                return Locator(self)

            def evaluate(self, *_args: object) -> dict:
                raise AssertionError("selector click must not fall back to the node index")

        page = Page()
        selector = 'role=button[name="Next"s]'
        result = perform(page, {"id": "next", "kind": "click", "role": "button", "selector": selector, "node": 99, "label": "Next"})
        self.assertEqual(page.selector, selector)
        self.assertTrue(page.clicked)
        self.assertEqual(result["selector"], selector)

    def test_duplicate_role_name_uses_the_first_match(self) -> None:
        from cg_loop.browser import wait_for_locator

        class First:
            def __init__(self, page: "Page") -> None:
                self.page = page

            def click(self, timeout: int | None = None) -> None:
                del timeout
                self.page.clicked = "first"

            def wait_for(self, *, state: str, timeout: int) -> None:
                self.page.waited = (state, timeout)

        class Locator:
            def __init__(self, page: "Page") -> None:
                self.page = page
                self.first = First(page)

            def click(self, timeout: int | None = None) -> None:
                del timeout
                self.page.clicked = "all"

            def wait_for(self, *, state: str, timeout: int) -> None:
                del state, timeout
                raise AssertionError("strict wait must not run when several buttons match")

        class Page:
            def __init__(self) -> None:
                self.clicked = ""
                self.waited: tuple[str, int] | None = None

            def locator(self, _selector: str) -> Locator:
                return Locator(self)

            def evaluate(self, *_args: object) -> dict:
                raise AssertionError("selector click must not fall back to the node index")

        page = Page()
        selector = 'role=button[name="Close"s]'
        perform(page, {"id": "close", "kind": "click", "role": "button", "selector": selector, "node": 3, "label": "Close"})
        wait_for_locator(page, selector, 10)
        self.assertEqual(page.clicked, "first")
        self.assertEqual(page.waited, ("attached", 10000))

    def test_radio_keeps_the_node_click(self) -> None:
        class Page:
            def __init__(self) -> None:
                self.used_selector = False

            def locator(self, _selector: str) -> None:
                self.used_selector = True
                raise AssertionError("radio click must use the node")

            def evaluate(self, _expression: str, arg: object = None) -> dict:
                return {"x": 4.0, "y": 8.0, "href": "", "direct": True}

        page = Page()
        result = perform(
            page,
            {
                "id": "kids",
                "kind": "click",
                "role": "radio",
                "selector": 'role=radio[name="No, it\'s not made for kids"s]',
                "node": 70,
                "label": "No, it's not made for kids",
            },
        )
        self.assertFalse(page.used_selector)
        self.assertEqual(result["executed"], "kids")


class ClickPointTests(unittest.TestCase):
    def test_wide_radio_clicks_its_visible_edge_not_the_covered_center(self) -> None:
        node = shutil.which("node")
        if node is None:
            self.skipTest("node is not installed")
        script = r"""
const act = __ACT__;
const radio = {
  nodeType: 1, isConnected: true, tagName: 'TP-YT-PAPER-RADIO-BUTTON', role: 'radio',
  clicked: false, parentElement: null,
  rect: {x: 100, y: 200, width: 700, height: 36, top: 200, bottom: 236, left: 100, right: 800},
  matches() { return false; }, closest() { return null; },
  checkVisibility() { return true; },
  getAttribute(name) { return name === 'role' ? 'radio' : null; },
  getBoundingClientRect() { return this.rect; },
  scrollIntoView() {},
  click() { this.clicked = true; },
  contains(other) { return other === this; },
  getRootNode() { return {host: null}; },
};
const inner = {
  nodeType: 1, isConnected: true, tagName: 'DIV', parentElement: null,
  contains() { return false; },
  getRootNode() { return {host: radio}; },
};
const video = {nodeType: 1, tagName: 'VIDEO', parentElement: null, contains() { return false; }, getRootNode() { return {host: null}; }};
globalThis.innerWidth = 1200;
globalThis.innerHeight = 800;
globalThis.document = {
  elementFromPoint(x, y) {
    if (Math.abs(x - 128) < 2 && Math.abs(y - 218) < 2) return inner;
    return video;
  },
};
globalThis.window = {__cgLoopFast: {nodes: new Map([[7, radio]])}};
const hit = act({node: 7, kind: 'click'});
process.stdout.write(JSON.stringify({x: hit && hit.x, y: hit && hit.y, direct: !!(hit && hit.direct), clicked: radio.clicked}));
"""
        script = script.replace("__ACT__", ACT_JS)
        result = subprocess.run([node, "-e", script], capture_output=True, text=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        hit = json.loads(result.stdout)
        self.assertEqual(hit["x"], 128)
        self.assertEqual(hit["y"], 218)
        self.assertFalse(hit["direct"])
        self.assertFalse(hit["clicked"])

    def test_covered_radio_still_receives_a_click(self) -> None:
        node = shutil.which("node")
        if node is None:
            self.skipTest("node is not installed")
        script = r"""
const act = __ACT__;
const radio = {
  nodeType: 1, isConnected: true, tagName: 'TP-YT-PAPER-RADIO-BUTTON',
  clicked: false, parentElement: null,
  rect: {x: 100, y: 200, width: 240, height: 36, top: 200, bottom: 236, left: 100, right: 340},
  matches() { return false; }, closest() { return null; },
  checkVisibility() { return true; },
  getAttribute(name) { return name === 'role' ? 'radio' : null; },
  getBoundingClientRect() { return this.rect; },
  scrollIntoView() {},
  click() { this.clicked = true; },
  contains() { return false; },
  getRootNode() { return {host: null}; },
};
const cover = {nodeType: 1, tagName: 'DIV', parentElement: null, contains() { return false; }, getRootNode() { return {host: null}; }};
globalThis.innerWidth = 1200;
globalThis.innerHeight = 800;
globalThis.document = {elementFromPoint() { return cover; }};
globalThis.window = {__cgLoopFast: {nodes: new Map([[7, radio]])}};
const hit = act({node: 7, kind: 'click'});
process.stdout.write(JSON.stringify({direct: !!(hit && hit.direct), clicked: radio.clicked}));
"""
        script = script.replace("__ACT__", ACT_JS)
        result = subprocess.run([node, "-e", script], capture_output=True, text=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        hit = json.loads(result.stdout)
        self.assertTrue(hit["direct"])
        self.assertTrue(hit["clicked"])

    def test_native_radio_under_its_circle_is_clicked(self) -> None:
        node = shutil.which("node")
        if node is None:
            self.skipTest("node is not installed")
        script = r"""
const act = __ACT__;
const wrap = {nodeType: 1, tagName: 'SPAN', parentElement: null, contains() { return false; }, getRootNode() { return {host: null}; }};
const circle = {nodeType: 1, tagName: 'SPAN', parentElement: wrap, contains() { return false; }, getRootNode() { return {host: null}; }};
const radio = {
  nodeType: 1, isConnected: true, tagName: 'INPUT', type: 'radio',
  clicked: false, checkedWrites: [], parentElement: wrap,
  rect: {x: 210, y: 952, width: 16, height: 16, top: 952, bottom: 968, left: 210, right: 226},
  matches() { return false; }, closest() { return null; },
  checkVisibility() { return true; },
  getAttribute(name) { return name === 'name' ? 'postSchedule' : null; },
  setAttribute() {},
  set checked(value) { this.checkedWrites.push(value); },
  get checked() { return false; },
  getBoundingClientRect() { return this.rect; },
  scrollIntoView() {},
  click() { this.clicked = true; },
  contains() { return false; },
  getRootNode() { return {host: null}; },
};
globalThis.innerWidth = 1326;
globalThis.innerHeight = 1206;
globalThis.document = {elementFromPoint() { return circle; }};
globalThis.window = {__cgLoopFast: {nodes: new Map([[7, radio]])}};
const hit = act({node: 7, kind: 'click'});
process.stdout.write(JSON.stringify({
  direct: !!(hit && hit.direct), clicked: radio.clicked, checkedWrites: radio.checkedWrites,
}));
"""
        script = script.replace("__ACT__", ACT_JS)
        result = subprocess.run([node, "-e", script], capture_output=True, text=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        hit = json.loads(result.stdout)
        self.assertTrue(hit["direct"])
        self.assertTrue(hit["clicked"])
        self.assertEqual(hit["checkedWrites"], [])

    def test_radio_click_aims_at_the_circle_and_selects_the_group(self) -> None:
        node = shutil.which("node")
        if node is None:
            self.skipTest("node is not installed")
        script = r"""
const act = __ACT__;
const group = {selected: ''};
const radio = {
  nodeType: 1, isConnected: true, tagName: 'TP-YT-PAPER-RADIO-BUTTON',
  clicked: false, checked: false, parentElement: null,
  rect: {x: 100, y: 200, width: 206, height: 24, top: 200, bottom: 224, left: 100, right: 306},
  matches() { return false; },
  closest(selector) { return String(selector).includes('radiogroup') ? group : null; },
  checkVisibility() { return true; },
  getAttribute(name) { return name === 'role' ? 'radio' : name === 'name' ? 'VIDEO_MADE_FOR_KIDS_NOT_MFK' : null; },
  setAttribute() {},
  getBoundingClientRect() { return this.rect; },
  scrollIntoView() {},
  click() { this.clicked = true; },
  contains(other) { return other === this; },
  getRootNode() { return {host: null}; },
};
const circle = {
  nodeType: 1, id: 'offRadio', tagName: 'DIV', parentElement: null,
  rect: {x: 100, y: 204, width: 16, height: 16, top: 204, bottom: 220, left: 100, right: 116},
  contains() { return false; },
  getBoundingClientRect() { return this.rect; },
  getRootNode() { return {host: radio}; },
};
globalThis.innerWidth = 1200;
globalThis.innerHeight = 800;
globalThis.document = {
  elementFromPoint(x) {
    if (x >= 100 && x <= 116) return circle;
    return radio;
  },
};
globalThis.window = {__cgLoopFast: {nodes: new Map([[7, radio]])}};
const hit = act({node: 7, kind: 'click'});
process.stdout.write(JSON.stringify({
  x: hit && hit.x, y: hit && hit.y, direct: !!(hit && hit.direct),
  clicked: radio.clicked, selected: group.selected,
}));
"""
        script = script.replace("__ACT__", ACT_JS)
        result = subprocess.run([node, "-e", script], capture_output=True, text=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        hit = json.loads(result.stdout)
        self.assertEqual(hit["x"], 108)
        self.assertEqual(hit["y"], 212)
        self.assertFalse(hit["direct"])
        self.assertFalse(hit["clicked"])
        self.assertEqual(hit["selected"], "VIDEO_MADE_FOR_KIDS_NOT_MFK")


class ShadowButtonSnapshotTests(unittest.TestCase):
    def test_dialog_close_inside_a_shadow_root_is_offered(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        html = """
        <ytcp-button id="close"></ytcp-button>
        <script>
          const host = document.getElementById("close");
          host.attachShadow({mode: "open"}).innerHTML = "<button><slot></slot></button>";
          host.textContent = "Close";
        </script>
        """
        with sync_playwright() as pw:
            browser = None
            errors: list[str] = []
            for kwargs in ({"channel": "chrome", "headless": True}, {"headless": True}):
                try:
                    browser = pw.chromium.launch(**kwargs)
                    break
                except Exception as exc:
                    errors.append(str(exc))
            if browser is None:
                self.skipTest("chromium is not available: " + errors[-1])
            page = browser.new_page()
            page.set_content(html)
            snap = page.evaluate(SNAPSHOT_JS)
            browser.close()
        labels = [str(action.get("label") or "") for action in (snap or {}).get("actions") or []]
        self.assertIn("Close", labels)
        close = next(action for action in snap["actions"] if action.get("label") == "Close")
        self.assertEqual(close["role"], "button")

    def test_disabled_close_with_a_box_is_offered(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        html = """
        <button id="close" disabled aria-disabled="true" style="width:36px;height:36px">Close</button>
        """
        with sync_playwright() as pw:
            browser = None
            errors: list[str] = []
            for kwargs in ({"channel": "chrome", "headless": True}, {"headless": True}):
                try:
                    browser = pw.chromium.launch(**kwargs)
                    break
                except Exception as exc:
                    errors.append(str(exc))
            if browser is None:
                self.skipTest("chromium is not available: " + errors[-1])
            page = browser.new_page()
            page.set_content(html)
            snap = page.evaluate(SNAPSHOT_JS)
            browser.close()
        labels = [str(action.get("label") or "") for action in (snap or {}).get("actions") or []]
        self.assertIn("Close", labels)


class UnlabeledSwitchSnapshotTests(unittest.TestCase):
    def test_switch_takes_the_text_beside_it(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        html = """
        <div style="display:flex">
          <div>
            <div>Add AI label</div>
            <div>This label is required for realistic photos. <a href="/learn">Learn more</a></div>
          </div>
          <div role="switch" aria-checked="false" style="width:44px;height:24px"></div>
        </div>
        <div style="display:flex">
          <div>Schedule content</div>
          <div role="switch" aria-label="switch" aria-checked="false" style="width:44px;height:24px"></div>
        </div>
        """
        with sync_playwright() as pw:
            browser = None
            errors: list[str] = []
            for kwargs in ({"channel": "chrome", "headless": True}, {"headless": True}):
                try:
                    browser = pw.chromium.launch(**kwargs)
                    break
                except Exception as exc:
                    errors.append(str(exc))
            if browser is None:
                self.skipTest("chromium is not available: " + errors[-1])
            page = browser.new_page()
            page.set_content(html)
            snap = page.evaluate(SNAPSHOT_JS)
            browser.close()
        labels = [
            str(item.get("label") or "")
            for item in (snap or {}).get("actions") or []
            if item.get("role") == "switch"
        ]
        self.assertEqual(labels, ["Add AI label", "Schedule content"])


class OffscreenControlSnapshotTests(unittest.TestCase):
    def test_offscreen_radio_is_kept_and_marked(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        html = """
        <button id="create">Create</button>
        <div style="height: 3000px"></div>
        <div role="radio" aria-checked="false">No, it's not made for kids</div>
        """
        with sync_playwright() as pw:
            browser = None
            errors: list[str] = []
            for kwargs in ({"channel": "chrome", "headless": True}, {"headless": True}):
                try:
                    browser = pw.chromium.launch(**kwargs)
                    break
                except Exception as exc:
                    errors.append(str(exc))
            if browser is None:
                self.skipTest("chromium is not available: " + errors[-1])
            page = browser.new_page()
            page.set_viewport_size({"width": 800, "height": 400})
            page.set_content(html)
            snap = page.evaluate(SNAPSHOT_JS)
            browser.close()
        actions = [item for item in (snap or {}).get("actions") or [] if item.get("kind") == "click"]
        by_label = {str(item.get("label") or ""): item for item in actions}
        self.assertEqual(by_label["Create"]["view"], "shown")
        self.assertEqual(by_label["No, it's not made for kids"]["view"], "offscreen")
        self.assertEqual(by_label["No, it's not made for kids"]["role"], "radio")
        self.assertLess(
            actions.index(by_label["Create"]),
            actions.index(by_label["No, it's not made for kids"]),
        )


class EnabledClickPageTests(unittest.TestCase):
    def test_already_enabled_close_is_clicked_without_waiting(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        from cg_loop.browser_helper import wait_until_enabled_then_click

        html = """
        <button id="ready">Close</button>
        <button id="saving" disabled aria-disabled="true">Close</button>
        <script>
          window.clicked = "";
          document.getElementById("ready").addEventListener("click", () => { window.clicked = "ready"; });
          document.getElementById("saving").addEventListener("click", () => { window.clicked = "saving"; });
        </script>
        """
        with sync_playwright() as pw:
            browser = None
            errors: list[str] = []
            for kwargs in ({"channel": "chrome", "headless": True}, {"headless": True}):
                try:
                    browser = pw.chromium.launch(**kwargs)
                    break
                except Exception as exc:
                    errors.append(str(exc))
            if browser is None:
                self.skipTest("chromium is not available: " + errors[-1])
            page = browser.new_page()
            page.set_content(html)

            class Tab:
                def __init__(self, live) -> None:
                    self.page = live

            result = wait_until_enabled_then_click(
                "/browser wait max 3s Close enabled and then Click Close",
                Tab(page),
            )
            clicked = page.evaluate("() => window.clicked")
            browser.close()
        self.assertEqual(result["status"], "done")
        self.assertEqual(clicked, "ready")

    def test_wait_clicks_close_after_it_is_enabled(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        from cg_loop.browser_helper import wait_until_enabled_then_click

        html = """
        <button id="close" disabled aria-disabled="true">Close</button>
        <script>
          window.clicked = "";
          document.getElementById("close").addEventListener("click", () => { window.clicked = "close"; });
          setTimeout(() => {
            const close = document.getElementById("close");
            close.disabled = false;
            close.setAttribute("aria-disabled", "false");
          }, 400);
        </script>
        """
        with sync_playwright() as pw:
            browser = None
            errors: list[str] = []
            for kwargs in ({"channel": "chrome", "headless": True}, {"headless": True}):
                try:
                    browser = pw.chromium.launch(**kwargs)
                    break
                except Exception as exc:
                    errors.append(str(exc))
            if browser is None:
                self.skipTest("chromium is not available: " + errors[-1])
            page = browser.new_page()
            page.set_content(html)

            class Tab:
                def __init__(self, live) -> None:
                    self.page = live

            result = wait_until_enabled_then_click(
                "/browser wait max 3s Close enabled and then Click Close",
                Tab(page),
            )
            clicked = page.evaluate("() => window.clicked")
            browser.close()
        self.assertEqual(result["status"], "done")
        self.assertFalse(result["blocked"])
        self.assertEqual(clicked, "close")


class ClickIfExistsPageTests(unittest.TestCase):
    def test_clicks_a_nested_label_and_skips_when_it_is_missing(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        from cg_loop.browser_helper import click_if_exists

        present = """
        <button id="hidden" style="display:none"><span>Post Now</span></button>
        <button><span>Post Now</span></button>
        <script>
          window.clicked = "";
          document.querySelectorAll("button")[1].addEventListener("click", () => { window.clicked = "post"; });
        </script>
        """
        absent = "<button>Schedule</button>"
        with sync_playwright() as pw:
            browser = None
            errors: list[str] = []
            for kwargs in ({"channel": "chrome", "headless": True}, {"headless": True}):
                try:
                    browser = pw.chromium.launch(**kwargs)
                    break
                except Exception as exc:
                    errors.append(str(exc))
            if browser is None:
                self.skipTest("chromium is not available: " + errors[-1])
            page = browser.new_page()

            class Tab:
                def __init__(self, live) -> None:
                    self.page = live

            page.set_content(present)
            clicked_result = click_if_exists("/browser click Post Now if it exists", Tab(page))
            clicked = page.evaluate("() => window.clicked")
            page.set_content(absent)
            skipped = click_if_exists("/browser click Post Now if it exists", Tab(page))
            browser.close()
        self.assertEqual(clicked_result["status"], "done")
        self.assertTrue(clicked_result["outputs"]["clicked"])
        self.assertEqual(clicked, "post")
        self.assertEqual(skipped["status"], "done")
        self.assertFalse(skipped["blocked"])
        self.assertFalse(skipped["outputs"]["clicked"])


class _FocusPage:
    def __init__(self, url: str, *, focus: bool = False, visible: bool = False, error: bool = False) -> None:
        self.url = url
        self._focus = focus
        self._visible = visible
        self._error = error

    def evaluate(self, _js: str) -> dict[str, bool]:
        if self._error:
            raise RuntimeError("tab is not readable")
        return {"focus": self._focus, "visible": self._visible}


class ChooseOpenPageTests(unittest.TestCase):
    def test_uses_the_focused_tab(self) -> None:
        first = _FocusPage("https://example.com/", visible=True)
        active = _FocusPage("https://studio.youtube.com/", focus=True, visible=True)
        hidden = _FocusPage("https://www.tiktok.com/")
        self.assertIs(choose_open_page([first, hidden, active]), active)

    def test_uses_the_visible_tab_when_the_window_is_in_the_background(self) -> None:
        hidden = _FocusPage("https://example.com/")
        active = _FocusPage("https://studio.youtube.com/", visible=True)
        self.assertIs(choose_open_page([hidden, active]), active)

    def test_uses_the_newest_visible_tab_when_several_windows_are_open(self) -> None:
        older = _FocusPage("https://example.com/", visible=True)
        newer = _FocusPage("https://www.youtube.com/", visible=True)
        self.assertIs(choose_open_page([older, newer]), newer)

    def test_uses_the_first_page_when_no_tab_reports_focus(self) -> None:
        first = _FocusPage("chrome://new-tab-page/", error=True)
        second = _FocusPage("https://example.com/", error=True)
        self.assertIs(choose_open_page([first, second]), first)


if __name__ == "__main__":
    unittest.main()
