#!/usr/bin/env python3
"""A /python step writes the post marker in the story folder."""

from __future__ import annotations

import io
import json
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.compiled import ensure_compiled, execute_compiled, validate_compiled  # noqa: E402
from cg_loop.decision import skips_script  # noqa: E402
from cg_loop.python_helper import python_helper, python_helper_handles  # noqa: E402
from cg_loop.questions import COMPILE_PYTHON  # noqa: E402
from cg_loop.workflow import load_workflow, parse_step, project_root  # noqa: E402

SLEEP = project_root() / "workflows" / "wf-sleep-story.yaml"
COMMAND = (
    "/python write post_youtube.yaml in the story folder with platform, status, "
    "posted_at, url, title, video file, browser profile, and CDP url."
)


class Tab:
    def __init__(self, page: dict) -> None:
        self.page_info = page
        self.profile = "from-browser"

    def observe(self) -> dict:
        return self.page_info


def _page(video_id: str = "abc123xyz") -> dict:
    return {
        "url": "https://studio.youtube.com/channel/UC/videos/upload",
        "title": "Channel content - YouTube Studio",
        "text": (
            "Imagine You Woke Up in Ancient Rome\n"
            "The city stirs.\n"
            "Scheduled\n"
            "Oct 5, 2026\n"
            "Another Story\n"
            "Public\n"
        ),
        "actions": [
            {
                "href": f"/video/{video_id}/edit",
                "label": "Imagine You Woke Up in Ancient Rome",
            },
            {"href": "/video/other999/edit", "label": "Another Story"},
        ],
    }


class PythonHelperTest(unittest.TestCase):
    def test_sleep_story_step_is_python(self) -> None:
        step = parse_step(COMMAND)
        self.assertEqual(step.tool, "python")
        self.assertEqual(step.kind, "goal")
        with self.assertRaises(ValueError):
            parse_step("/python term echo hi")
        group = load_workflow(SLEEP).named_groups()["post_full_sleep_story_routine"]
        python_steps = [item for item in group.all_steps() if item.tool == "python"]
        self.assertEqual([item.raw for item in python_steps], [COMMAND])

    def test_compile_generates_python(self) -> None:
        from unittest.mock import patch

        from cg_loop.model import CompileReply

        def compile_python_step(context: dict) -> CompileReply:
            self.assertEqual(context["step"], COMMAND)
            return CompileReply(
                text=(
                    "def run(ctx):\n"
                    "    print('generated', flush=True)\n"
                    "    return {'outputs': {'status': 'ok', 'printed': 'generated'}, 'variables': {}}\n"
                ),
                model="test",
            )

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_post:\n  - " + COMMAND + "\n",
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_post"]
            with patch("cg_loop.model.compile_python_step", side_effect=compile_python_step):
                created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("generated", text)
            self.assertNotIn("python_helper", text)

    def test_bare_wait_sleeps_without_the_model(self) -> None:
        from unittest.mock import patch

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text("config:\n  name: demo\nwf_wait:\n  - /python wait 10s\n", encoding="utf-8")
            group = load_workflow(path).named_groups()["wf_wait"]
            with patch("cg_loop.model.compile_python_step", side_effect=AssertionError("model")):
                created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("time.sleep(seconds)", text)
            self.assertFalse((created.path.parent / "a-request.py").exists())
            slept: list[float] = []
            with patch("time.sleep", lambda seconds: slept.append(seconds)):
                from cg_loop.compiled import execute_compiled

                result = execute_compiled(created.path, {"dry_run": False, "env": {}, "variables": {}})
        self.assertEqual(slept, [10])
        self.assertEqual(result["outputs"]["status"], "ok")

    def test_compile_writes_the_api_request(self) -> None:
        import ast
        from unittest.mock import patch

        script = (
            "def run(ctx):\n"
            "    print('ok', flush=True)\n"
            "    return {'outputs': {'status': 'ok'}}\n"
        )

        class _Message:
            content = script

            def model_dump(self) -> dict[str, str]:
                return {"role": "assistant", "content": self.content}

        class _Choice:
            message = _Message()

        class _Response:
            model = "test-model"
            choices = [_Choice()]

        sent: list[dict[str, object]] = []

        class _Completions:
            def create(self, **kwargs: object) -> _Response:
                sent.append(kwargs)
                return _Response()

        class _Chat:
            completions = _Completions()

        class _Client:
            chat = _Chat()

            def close(self) -> None:
                return None

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text("config:\n  name: demo\nwf_post:\n  - /python reverse the words in $title\n", encoding="utf-8")
            group = load_workflow(path).named_groups()["wf_post"]
            with patch("cg_loop.model.client", return_value=_Client()):
                created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            request = created.path.parent / "a-request.py"
            text = request.read_text(encoding="utf-8")
            ast.parse(text)
            self.assertNotIn("Write the run(ctx)", text)
            self.assertIn("a-prompt.json", text)
            prompt_path = created.path.parent / "a-prompt.json"
            saved = json.loads(prompt_path.read_text(encoding="utf-8"))
            namespace: dict[str, object] = {"__file__": str(request)}
            exec(text, namespace)  # noqa: S102
            self.assertIn("/chat/completions", str(namespace["URL"]))
            body = namespace["BODY"]
            assert isinstance(body, dict)
            self.assertEqual(body["temperature"], 0.1)
            self.assertEqual(body["messages"], saved["messages"])
            self.assertEqual(sent[0]["messages"], saved["messages"])
            self.assertIn("Write the run(ctx) function for one /python step", saved["messages"][0]["content"])
            self.assertIn("reverse the words in $title", saved["messages"][1]["content"])
            self.assertIn("## system", (created.path.parent / "a-prompt.md").read_text(encoding="utf-8"))
            self.assertNotIn("sk-or-v1-", text)
            log = (created.path.parent / "c-compile.log").read_text(encoding="utf-8")
            self.assertIn("request: a-request.py", log)
            with patch("cg_loop.model.client", return_value=_Client()):
                again = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(again.status, "reused")
            self.assertTrue(request.is_file())

    def test_request_file_hides_a_secret_and_numbers_later_calls(self) -> None:
        import ast

        from cg_loop.model import _note_api_call, api_request_source, logging_api_calls

        secret = "sk-or-v1-secretkeyvalue"
        text = api_request_source(
            "https://openrouter.ai/api/v1/chat/completions",
            {"Authorization": f"Bearer {secret}", "Content-Type": "application/json"},
            {
                "model": "deepseek/deepseek-v3.2",
                "messages": [{"role": "user", "content": f"token {secret}"}],
                "temperature": 0.1,
                "reasoning": {"enabled": True},
            },
        )
        self.assertNotIn(secret, text)
        self.assertIn("OPENROUTER_API_KEY", text)
        self.assertIn("'reasoning': {'enabled': True}", text)
        ast.parse(text)
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "a-request.py").write_text("old\n", encoding="utf-8")
            (folder / "a-request-3.py").write_text("old\n", encoding="utf-8")
            with logging_api_calls(folder):
                _note_api_call("http://127.0.0.1:1234/v1/chat/completions", {"Authorization": "Bearer lm-studio"}, {"model": "a"})
                _note_api_call("http://127.0.0.1:1234/v1/chat/completions", {"Authorization": "Bearer lm-studio"}, {"model": "b"})
            self.assertIn("lm-studio", (folder / "a-request.py").read_text(encoding="utf-8"))
            self.assertIn("'model': 'b'", (folder / "a-request-2.py").read_text(encoding="utf-8"))
            self.assertFalse((folder / "a-request-3.py").exists())

    def test_writes_marker_from_story_and_page(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / "rome"
            folder.mkdir()
            video = folder / "youtube_captions_music.mp4"
            video.write_bytes(b"video")
            result = python_helper(
                COMMAND,
                env={"PROFILE": "yuba-social"},
                variables={
                    "story_folder": str(folder),
                    "post_title": "Imagine You Woke Up in Ancient Rome",
                    "youtube_video": str(video),
                    "story_video": str(folder / "story_captions_music.mp4"),
                },
                browser=Tab(_page()),
                cdp_url="http://127.0.0.1:18801",
            )
            path = folder / "post_youtube.yaml"
            self.assertEqual(result["outputs"]["status"], "ok")
            self.assertTrue(path.is_file())
            import yaml

            marker = yaml.safe_load(path.read_text(encoding="utf-8"))
            self.assertEqual(marker["platform"], "youtube")
            self.assertEqual(marker["status"], "scheduled")
            self.assertTrue(marker["posted_at"])
            self.assertEqual(marker["url"], "https://www.youtube.com/watch?v=abc123xyz")
            self.assertEqual(marker["title"], "Imagine You Woke Up in Ancient Rome")
            self.assertEqual(marker["video_file"], "youtube_captions_music.mp4")
            self.assertEqual(marker["browser_profile"], "yuba-social")
            self.assertEqual(marker["browser_cdp_url"], "http://127.0.0.1:18801")

            again = python_helper(
                COMMAND,
                env={"PROFILE": "yuba-social"},
                variables={"story_folder": str(folder), "post_title": "Imagine You Woke Up in Ancient Rome"},
                browser=Tab(_page("changed")),
                cdp_url="http://127.0.0.1:18801",
            )
            self.assertIn("already", again["outputs"]["message"])
            self.assertEqual(
                yaml.safe_load(path.read_text(encoding="utf-8"))["url"],
                "https://www.youtube.com/watch?v=abc123xyz",
            )

    def test_dry_run_and_missing_folder(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / "rome"
            folder.mkdir()
            (folder / "youtube_captions_music.mp4").write_bytes(b"video")
            result = python_helper(
                COMMAND,
                dry_run=True,
                env={"PROFILE": "yuba-social", "CDP_URL": "http://127.0.0.1:18801"},
                variables={"story_folder": str(folder), "title": "Imagine You Woke Up in Ancient Rome"},
                browser=Tab(_page()),
            )
            self.assertEqual(result["outputs"]["status"], "proposed")
            self.assertFalse((folder / "post_youtube.yaml").exists())
            self.assertEqual(result["outputs"]["marker"]["browser_cdp_url"], "http://127.0.0.1:18801")
            self.assertEqual(result["outputs"]["marker"]["browser_profile"], "yuba-social")

        blocked = python_helper(COMMAND, variables={"story_folder": "none"})
        self.assertTrue(blocked["blocked"])
        self.assertIn("story folder", blocked["outputs"]["message"])

    def test_unmatched_python_compiles_instead_of_the_helper(self) -> None:
        from unittest.mock import patch

        from cg_loop.compiled import compiled_step_path
        from cg_loop.model import CompileReply
        from cg_loop.python_helper import python_helper_handles

        command = "/python reverse the words in $title"
        self.assertFalse(python_helper_handles(command))
        select = (
            "/python select short from APPROVED_STORIES/**/shorts/ "
            "where it does not have post_tiktok.yaml into $folder"
        )
        self.assertFalse(python_helper_handles(select))
        self.assertTrue(
            python_helper_handles("/python write post_tiktok.yaml in the $folder with platform")
        )
        seen: dict[str, object] = {}

        def compile_python_step(context: dict) -> CompileReply:
            seen["context"] = context
            return CompileReply(
                text=(
                    "def run(ctx):\n"
                    "    names = ctx.get('variables') or {}\n"
                    "    value = ' '.join(reversed(str(names.get('title') or '').split()))\n"
                    "    print(value, flush=True)\n"
                    "    return {'outputs': {'printed': value}, 'variables': {'title': value}}\n"
                ),
                model="test",
            )

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_post:\n  - /python reverse the words in $title\n",
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_post"]
            script = compiled_step_path(group, group.steps[0], index=0, env=group.env)
            script.parent.mkdir(parents=True)
            script.write_text(
                "\n".join(
                    [
                        '"""Compiled cg-loop step.',
                        "",
                        f"Source: {command}",
                        '"""',
                        "def run(ctx):",
                        "    from cg_loop.python_helper import python_helper",
                        f"    return python_helper({command!r}, variables=ctx.get('variables') or {{}})",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            self.assertEqual(
                validate_compiled(script, group.steps[0]),
                "python script must be generated code",
            )
            with patch("cg_loop.model.compile_python_step", side_effect=compile_python_step):
                created = ensure_compiled(
                    group,
                    group.steps[0],
                    index=0,
                    env=group.env,
                    variables={"title": "one two"},
                )
            self.assertEqual(created.status, "recompiled")
            body = created.path.read_text(encoding="utf-8")
            self.assertNotIn("python_helper", body)
            self.assertIn("reversed", body)
            self.assertEqual(seen["context"]["variables"]["title"], "one two")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")

    def test_set_and_add_compile_instead_of_the_helper(self) -> None:
        from unittest.mock import patch

        from cg_loop.decision import skips_script
        from cg_loop.model import CompileReply
        from cg_loop.python_helper import python_helper_handles

        commands = (
            "/python set $post_date= today + 48 hours",
            "/python add 1 day to $post_date and print in format YYYY-MM-DD HH:MM:SS",
        )
        for command in commands:
            self.assertFalse(python_helper_handles(command))
            self.assertFalse(skips_script(parse_step(command)))

        def compile_python_step(context: dict) -> CompileReply:
            self.assertEqual(context["step"], commands[0])
            return CompileReply(
                text=(
                    "def run(ctx):\n"
                    "    from datetime import datetime, timedelta\n"
                    "    value = (datetime.now() + timedelta(hours=48)).strftime('%Y-%m-%d %H:%M:%S')\n"
                    "    print(value, flush=True)\n"
                    "    return {'outputs': {'status': 'ok', 'printed': value}, 'variables': {'post_date': value}}\n"
                ),
                model="test",
            )

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_post:\n  - /python set $post_date= today + 48 hours\n",
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_post"]
            with patch("cg_loop.model.compile_python_step", side_effect=compile_python_step):
                created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            body = created.path.read_text(encoding="utf-8")
            self.assertNotIn("python_helper", body)
            self.assertIn("timedelta", body)
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")

    def test_write_uses_the_named_folder_variable(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / "short_01"
            folder.mkdir()
            result = python_helper(
                "/python write post_tiktok.yaml in the $folder with platform",
                variables={"folder": str(folder)},
                dry_run=True,
            )
        self.assertEqual(result["outputs"]["status"], "proposed")
        self.assertTrue(str(result["outputs"]["path"]).endswith("post_tiktok.yaml"))

    def test_print_reads_the_variable_date(self) -> None:
        value = {
            "url": "https://www.tiktok.com/tiktokstudio/content",
            "date": "2026-10-11 16:20:00",
            "published": "",
            "text": "",
        }
        buf = io.StringIO()
        with redirect_stdout(buf):
            result = python_helper("/python print $post_date", variables={"post_date": value})
        self.assertEqual(buf.getvalue(), "")
        self.assertEqual(result["outputs"]["status"], "ok")
        self.assertEqual(result["outputs"]["printed"], "2026-10-11 16:20:00")
        self.assertEqual(result["outputs"]["post_date"], value)

    def test_print_shows_the_mapping_when_it_has_no_date(self) -> None:
        value = {"url": "https://www.tiktok.com/tiktokstudio/content", "date": "", "text": ""}
        buf = io.StringIO()
        with redirect_stdout(buf):
            result = python_helper("print $post_date", variables={"post_date": value})
        self.assertEqual(buf.getvalue(), "")
        self.assertIn("tiktokstudio/content", result["outputs"]["printed"])
        self.assertIn('"date": ""', result["outputs"]["printed"])

    def test_print_requires_the_variable(self) -> None:
        with self.assertRaises(RuntimeError):
            python_helper("/python print $post_date", variables={})

    def test_compiled_print_script_prints_the_date(self) -> None:
        from unittest.mock import patch

        from cg_loop.model import CompileReply

        def compile_python_step(_context: dict) -> CompileReply:
            return CompileReply(
                text=(
                    "def run(ctx):\n"
                    "    value = (ctx.get('variables') or {}).get('post_date') or {}\n"
                    "    shown = value.get('date') if isinstance(value, dict) else str(value)\n"
                    "    print(shown, flush=True)\n"
                    "    return {'outputs': {'status': 'ok', 'printed': shown}, 'variables': {}}\n"
                ),
                model="test",
            )

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_post:\n  - /python print $post_date\n",
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_post"]
            with patch("cg_loop.model.compile_python_step", side_effect=compile_python_step):
                created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            self.assertNotIn("python_helper", created.path.read_text(encoding="utf-8"))
            buf = io.StringIO()
            with redirect_stdout(buf):
                result = execute_compiled(
                    created.path,
                    {
                        "env": {},
                        "variables": {"post_date": {"date": "2026-10-11 16:20:00", "url": "https://example.com"}},
                        "dry_run": False,
                    },
                )
            self.assertEqual(result["outputs"]["printed"], "2026-10-11 16:20:00")
            self.assertIn("2026-10-11 16:20:00", buf.getvalue())


def _spoken(count: int) -> str:
    return "## Scene\n\nStill: a quiet room\n\n" + " ".join(["word"] * count) + "\n"


class StoryPromptTest(unittest.TestCase):
    def test_compile_reads_markdown_and_json_templates(self) -> None:
        self.assertIn("read_template(path, ctx)", COMPILE_PYTHON)
        self.assertIn(".md or .json", COMPILE_PYTHON)
        self.assertNotIn("2026-10-12", COMPILE_PYTHON)
        self.assertIn("Do not print a date", COMPILE_PYTHON)

    def test_story_prompt_step_runs_locally(self) -> None:
        group = load_workflow(SLEEP).named_groups()["generate_story_routine"]
        prompt_step = next(item for item in group.steps if "$story_prompt" in item.raw and "STORY_CONTINUE" in item.raw)
        write_step = next(item for item in group.steps if "leave story.md" in item.raw)
        self.assertTrue(python_helper_handles(prompt_step.raw))
        self.assertTrue(skips_script(prompt_step))
        self.assertFalse(python_helper_handles(write_step.raw))

    def test_new_story_fills_markdown_and_appends_the_arc(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            prompt = folder / "story-prompt.md"
            prompt.write_text("Title: $STORY_TITLE\nLength: $STORY_WORDS\n", encoding="utf-8")
            arc = folder / "arc.md"
            arc.write_text("The arc begins.\n", encoding="utf-8")
            (folder / "continue.md").write_text("unused\n", encoding="utf-8")
            result = python_helper(
                _story_step(),
                env=_env(folder, prompt=prompt, continue_file=folder / "continue.md", arc=arc),
                variables={"story_title": "Night Market"},
            )
        text = result["variables"]["story_prompt"]
        self.assertEqual(result["outputs"]["printed"], text)
        self.assertIn("Title: Night Market", text)
        self.assertIn("Length: 2000", text)
        self.assertIn("The arc begins.", text)
        self.assertNotIn("$STORY_TITLE", text)
        self.assertNotIn("$STORY_WORDS", text)
        self.assertFalse((folder / "night-market" / "story.md").exists())

    def test_short_story_fills_the_continue_file_and_appends_story_md(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            prompt = folder / "story-prompt.json"
            prompt.write_text(
                json.dumps({"task": "Title: $STORY_TITLE", "words": "$STORY_WORDS"}),
                encoding="utf-8",
            )
            continued = folder / "story-continue.md"
            continued.write_text("Continue $STORY_TITLE to $STORY_WORDS words.\n\nStory so far:\n", encoding="utf-8")
            arc = folder / "arc.md"
            arc.write_text("do not use\n", encoding="utf-8")
            story = folder / "night-market" / "story.md"
            story.parent.mkdir()
            story.write_text(_spoken(4), encoding="utf-8")
            result = python_helper(
                _story_step(),
                env=_env(folder, prompt=prompt, continue_file=continued, arc=arc),
                variables={"STORY_TITLE": "Night Market"},
            )
        text = result["variables"]["story_prompt"]
        self.assertIn("Continue Night Market to 2000 words.", text)
        self.assertIn("Story so far:", text)
        self.assertIn("word word word word", text)
        self.assertNotIn("do not use", text)
        self.assertNotIn("$STORY_TITLE", text)

    def test_finished_story_is_done(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            prompt = folder / "story-prompt.md"
            prompt.write_text("Title: $STORY_TITLE\n", encoding="utf-8")
            story = folder / "night-market" / "story.md"
            story.parent.mkdir()
            story.write_text(_spoken(1600), encoding="utf-8")
            result = python_helper(
                _story_step(),
                env=_env(folder, prompt=prompt, continue_file=prompt, arc=prompt),
                variables={"STORY_TITLE": "Night Market"},
            )
        self.assertEqual(result["variables"]["story_prompt"], "DONE")
        self.assertEqual(result["outputs"]["printed"], "DONE")

    def test_long_title_reads_the_full_folder_name(self) -> None:
        title = (
            "Drifting to sleep on a calm winter evening while watching "
            "the first television broadcast flicker to life"
        )
        folder_name = (
            "drifting-to-sleep-on-a-calm-winter-evening-while-watching-"
            "the-first-television-broadcast-flicker-to-life"
        )
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            prompt = folder / "story-prompt.md"
            prompt.write_text("Title: $STORY_TITLE\n", encoding="utf-8")
            story = folder / folder_name / "story.md"
            story.parent.mkdir()
            story.write_text(_spoken(1600), encoding="utf-8")
            result = python_helper(
                _story_step(),
                env=_env(folder, prompt=prompt, continue_file=prompt, arc=prompt),
                variables={"STORY_TITLE": title},
            )
        self.assertEqual(result["variables"]["story_prompt"], "DONE")

    def test_long_story_starts_again_from_the_prompt_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            prompt = folder / "story-prompt.json"
            prompt.write_text(json.dumps("Title: $STORY_TITLE\nLength: $STORY_WORDS"), encoding="utf-8")
            continued = folder / "story-continue.md"
            continued.write_text("continue instead\n", encoding="utf-8")
            arc = folder / "arc.md"
            arc.write_text("fresh arc\n", encoding="utf-8")
            story = folder / "night-market" / "story.md"
            story.parent.mkdir()
            story.write_text(_spoken(2401), encoding="utf-8")
            result = python_helper(
                _story_step(),
                env=_env(folder, prompt=prompt, continue_file=continued, arc=arc),
                variables={"STORY_TITLE": 'Say "hello"'},
            )
        text = result["variables"]["story_prompt"]
        self.assertIn('Title: Say "hello"', text)
        self.assertIn("Length: 2000", text)
        self.assertIn("fresh arc", text)
        self.assertNotIn("continue instead", text)

    def test_json_object_keeps_a_quote_in_the_title(self) -> None:
        from cg_loop.compiled import read_template

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "ask.json"
            path.write_text('{"prompt": "Title: $STORY_TITLE"}', encoding="utf-8")
            text = read_template(path, {"variables": {"STORY_TITLE": 'Say "hello"'}})
        self.assertIn('Say \\"hello\\"', text)
        self.assertNotIn("$STORY_TITLE", text)


class StoryTitleTest(unittest.TestCase):
    def test_missing_story_asks_openrouter_for_a_title(self) -> None:
        group = load_workflow(SLEEP).named_groups()["generate_story_routine"]
        title_step = next(step for step in group.before if "$title_prompt" in step.raw and "creative" in step.raw)
        apply_step = next(step for step in group.before if "keep $STORY_TITLE" in step.raw)
        ask = next(step for step in group.before if step.kind == "openrouter" and step.var == "story_idea")
        self.assertTrue(python_helper_handles(title_step.raw))
        self.assertTrue(skips_script(title_step))
        self.assertTrue(python_helper_handles(apply_step.raw))
        self.assertEqual(ask.extra, "$title_prompt")
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "night-market").mkdir()
            brief = python_helper(title_step.raw, env={"STORY_ROOT": str(folder)})
            kept = python_helper(
                title_step.raw,
                env={"STORY_ROOT": str(folder), "STORY_TITLE": "Night Market"},
            )
        self.assertIn("Write one creative sleep story title.", brief["variables"]["title_prompt"])
        self.assertIn("night market", brief["variables"]["title_prompt"])
        self.assertEqual(kept["variables"]["title_prompt"], "DONE")

    def test_done_keeps_the_title_and_a_reply_replaces_it(self) -> None:
        group = load_workflow(SLEEP).named_groups()["generate_story_routine"]
        apply_step = next(step for step in group.before if "keep $STORY_TITLE" in step.raw)
        kept = python_helper(
            apply_step.raw,
            env={"STORY_TITLE": "Night Market"},
            variables={"title_prompt": "DONE", "story_idea": {"text": "A different title"}},
        )
        chosen = python_helper(
            apply_step.raw,
            variables={"title_prompt": "Write one title.", "story_idea": {"text": "The Quiet War", "value": "The Quiet War"}},
        )
        self.assertEqual(kept["variables"]["STORY_TITLE"], "Night Market")
        self.assertEqual(chosen["variables"]["STORY_TITLE"], "The Quiet War")


def _story_step() -> str:
    group = load_workflow(SLEEP).named_groups()["generate_story_routine"]
    return next(item.raw for item in group.steps if item.raw.startswith("/python") and "STORY_CONTINUE" in item.raw)


def _env(folder: Path, *, prompt: Path, continue_file: Path, arc: Path) -> dict[str, str]:
    return {
        "STORY_ROOT": str(folder),
        "STORY_WORDS": "2000",
        "STORY_PROMPT": str(prompt),
        "STORY_CONTINUE": str(continue_file),
        "ARC": str(arc),
    }


if __name__ == "__main__":
    unittest.main()
