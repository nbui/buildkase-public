---
name: cg-loop
description: >-
  Jev-style agent loop with a dynamic indexed action space. Observes the page,
  picks one operation and one target per tick, and can also run terminal
  commands. Pass a workflow YAML (goto / extract / llm-call / generate / term
  / locate) or a natural-language goal. Use for cg-loop,
  wf-research-content, browser agent, or running a content workflow yaml.
metadata: {"openclaw": {"requires": {"bins": ["python3", "bash"]}}}
---

# CG Loop

A [Jev Ultrafast](https://github.com/browser-use/jev-ultrafast)-style loop for
Yuba CG workflows. Each observation builds an indexed action table. One model
request picks an **operation** and a **target**. A small LLM writes text only
when the operation is `TYPE_TEXT`, and writes a shell command only when the
operation is `TERM` and the command is not already in the step.

Difference from Jev: **TERM** is a first-class operation, and a workflow YAML
is a runnable plan.

| Resource | Path |
| -------- | ---- |
| Command index | [references/command_catalog.md](references/command_catalog.md) |
| Agent notes | [references/overview.md](references/overview.md) |
| Story template | [references/story.md](references/story.md) |

## Setup

```bash
cd {baseDir}
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
chmod +x scripts/*.sh tests/run_tests.sh
```

Needs **LM Studio** (`LM_STUDIO_BASE_URL=http://127.0.0.1:1234/v1`, default
model `qwen3.8-27b-mlx`) for `TYPE_TEXT`, free-form `TERM`, `llm-call`, and
ambiguous browser steps. Workflow YAML steps that already name a URL or command
run without a model call.

Browser steps attach to an existing profile over CDP (`cdp-url` in the YAML).
`workflows/workflows-app.yaml` is the app config. `workflows` is the root
folder, so a command can name `--only wf_<group>` and leave the YAML file off.
`decision` defaults to local `von`. It reads a step message and picks one tool
from `tools`. `tool-details` lists each tool's actions with top-level `in` and
`out` names. `model` on `locate` and `clef` is that tool's Hugging Face id.
`openrouter/<vendor>/<name>` uses OpenRouter instead: `openrouter/cloudflare/clef`
for Clef System One, or a vision model for Locate. Both need `OPENROUTER_API_KEY`. `config` there is the default workflow config, and a file's
`config` overrides those keys. `venv` is the one Python environment for the
loop and for workflow commands. A file's `config.venv` replaces it. `env-file`
and `env` are the process environment for the loop, workflow commands, and
models such as Hugging Face. `env-file` loads first, `env` replaces those
keys, and a value already set in the shell wins. A file's `config.env`
replaces both for that file. Von is
installed in that environment (`von-sdk`). Compile runs a known tool in process and does not write a `.py`
wrapper. A `/browser` or `/cua` goal is the exception: Von or Layla writes the
actions once, later runs replay that file, and the model runs again only on
recompile. `python` is the tool that generates code, and `python.llm` /
`python.model` are the provider for that code.

`llm: local` uses LM Studio. `llm: openrouter` uses the workflow chat model
and reads `OPENROUTER_API_KEY` from `config.env` or the process environment.
`browser-tool-model` sends browser actions to a System One model. The default
is local `von` (`pip install von-sdk`). cg-loop asks the shared background process to load those weights before the
first step when the decision model is `von` and a step will call it. A model that is already loaded is reused. A
different decision model skips the load. The step itself opens the page and asks
for the action. `layla` (also `laya`) is local Laya. cg-loop installs it into
the workflow venv when it is missing, then asks the shared background process to load it before the first step that
calls it. A model that is already loaded is reused. `jev-latest` still calls Jev on OpenRouter and needs
`OPENROUTER_API_KEY`. Typed field text still uses the chat model. A step with
no `/browser`, `/python`, `/term`, `/locate`, `/clef`, `/cua`, or `/lmstudio-` prefix is
picked by Von, not by Jev. `goto` is a browser action. `load` and `generate`
are python actions.

## Workflow YAML

```bash
bash {baseDir}/scripts/cg_loop.sh --only wf_research
```

```yaml
config:
  name: research content
  profile: yuba-heart
  cdp-url: http://127.0.0.1:18802
  loop-count: 1
  log-keep: 5
  llm: local
  env:
    SLIDES_SCRIPT: "/path/to/cg-slides/scripts/run_cucumber.sh"
    REMIX_SCRIPT: "/path/to/cg-remix-article/scripts/remix_article_run.sh"
    WORKFLOW_PATH: "/path/to/workflows"
    DRAFT_ROOT: "/path/to/mocks_out/draft_posts"
    APPROVED_ROOT: "/path/to/mocks_out/approved_posts"

wf_research:
  - load previous sciencedaily articles to $seen from $DRAFT_ROOT $APPROVED_ROOT
  - goto https://www.sciencedaily.com/rss/top/health.xml
  - get first url not in $seen to $url
  - term $REMIX_SCRIPT "$url" --story-only
  - msg: wf-contet-post wf_all
    type: workflow
    params:
      profile: yuba-heart
  - msg: "wf-contet-post wf_post"
    type: workflow
  - msg: wf_research|wf_slides
    type: workflow
    workflow: wf-research-content

wf_slides:
  - term $SLIDES_SCRIPT features/slides.feature --tags @meme_yuba

wf_post: wf-contet-post
```

Every `wf_<name>` key is a peer group. They run in file order, sharing
`$variables` and `config.env`. The value is either more steps, a YAML path, or
a workflow name resolved from `WORKFLOW_PATH`. No group is special.

A group may also be a mapping. `steps` is compiled like a step list. `auto`
is a step list the agent loop runs live (those steps are not compiled).
`auto: true` with `steps` marks that list the same way. `config` overrides
the file `config` for that group only (`profile`, `cdp-url`, `llm`, `model`,
`env`, and the other config keys). `steps` run first when both lists are set.

A step with `type: workflow` looks up `msg` as the workflow name in
`WORKFLOW_PATH`. One group runs as itself. Several groups stay idle until
`msg` includes `wf_all` or a group list (`msg: "wf-contet-post wf_post"`, or
`workflow:` with `msg: wf_research|wf_slides`). `params` overlay the child
config the same way `--param` does, on every selected group. Lookup matches
filename, stem, `config.name`, or a path relative to a search directory.
Subfolders are included. Cache folders are not. If
`WORKFLOW_PATH` is unset, the current YAML's directory and the workflows
folder from `workflows-app.yaml` are searched.

The loop reads each step message, picks a known tool, then compiles or executes.
Compile does not write a `.py` file for a known tool. Those tools run in process.
A `/python` step the local helper does not already handle is compiled to Python
by the provider in `workflows-app.yaml`. Page extracts are compiled the same way.
Do not add workflow-specific helpers to cg-loop.

The current run lives in `<project>/cache/<workflow_file>/<group>/`, beside `workflows-app.yaml`. Each step has its own folder, named from a shortened step plus a hash so the name stays unique:

```
<step>_<hash>/
  a_01-context.json    step text and how to compile or test this folder
  a-prompt.md          prompts
  a-config.json        step params, when there are any
  b_01-context.json    compile state the script reuses
  b-compile.py         compiled script
  c-01-context.json    this run's record
  c-run.log            this run's log for the step
  c-compile.log        this run's compile log for the step
  z-data_<file>        files this run wrote
```

The group folder also has `c-run.log`, `c-compile.log`, and `z-data/` (`ctx["data"]`, `$DATA`). Files written there are stored as `01-name`, `02-name`, in the order they are created, so the folder lists that way. Config `data-numbers: false` turns the prefixes off. A step that says `no numbers` keeps plain filenames for that step. `set_config DATA_NUMBERS=false` turns them off for the group. The next run copies that tree to `<group>/archived/<stamp>/`, then deletes `c-` files, `c_` files, and `z-data`. Prompts, config, and `b-compile.py` stay so the step can be reused or sent to another model. Each `wf_*` group has its own folder. `log-keep` (default 5) is how many archived runs to keep. A compiled script is reused only when it parses, defines `run`, and calls that step's tool; otherwise it is rewritten once. When a group starts, step folders that are not steps of that group are deleted. Archived runs stay. `c-run.log` ends with a summary: total, compile, LLM, and step time, plus compiled, reused, recompiled, and failed recompile counts.

```bash
# one group runs as itself; several groups need --only wf_all
bash {baseDir}/scripts/cg_loop.sh workflows/wf-research-content.yaml

# every wf_* group, in file order
bash {baseDir}/scripts/cg_loop.sh --only wf_all workflows/wf-stats.yaml

# --param overlays config, then the merged values are used
bash {baseDir}/scripts/cg_loop.sh workflows/wf-research-content.yaml \
  --param cdp-url=http://127.0.0.1:18802 \
  --param loop-count=1

# one group only
bash {baseDir}/scripts/cg_loop.sh --only wf_research workflows/wf-research-content.yaml

# another group only
bash {baseDir}/scripts/cg_loop.sh --only wf_slides workflows/wf-research-content.yaml

# the step on that line. A nested step runs alone. The condition line runs the condition.
bash {baseDir}/scripts/cg_loop.sh --line 23 workflows/wf-cua.yaml

# the steps a highlight covers, from the first line through the last
bash {baseDir}/scripts/cg_loop.sh --line 23 --end 31 workflows/wf-cua.yaml
```

A param value in `"` or `'` is literal for every tool. `+params` and `into $var` inside the quotes stay in the value. A backslash escapes the next character (`\"`, `\'`, `\+`, `\\`). An apostrophe in a word, such as `it's`, is not a quote.

| Step | Operation |
| ---- | --------- |
| `goto URL` / `open …` | Navigate when the target is already a URL. Otherwise the model compiles the step and may correct the URL or mark it as a goal |
| `load … to $seen from $ROOTS` | Collect previous `source_url`s from package folders |
| `get first url not in $seen to $var` | EXTRACT first RSS/article URL not already in `$seen` |
| `llm-call story.md $article` | Write `story.md` from the template + `$article` |
| `generate story $article` | `cg-remix-article` `--story-only` |
| `/term …` | Shell command (`$ENV` and `$vars` expand). The term starts with `/` |
| `/locate <what>, '<image>' into $var` | [LocateAnything-3B-MLX](https://huggingface.co/andai-labs/LocateAnything-3B-MLX) finds `<what>` in the image, stores the pixel center and box in `$var`, and writes `<image>.locate.jpg` with that box drawn. `$var` prints as `x,y box=x1,y1,x2,y2` plus the marked image path. Jobs load the weights once in a shared background process. A later run uses them when they are already loaded. The Models tab can kill or restart that process. `tool-details` `locate.model` is the model id. `openrouter/<vendor>/<name>` asks that OpenRouter vision model instead |
| `/cua +launch Chrome [url]` | Launch an app with the Cua driver. The term starts with `/` and the action param starts with `+`. `Chrome` uses the Google Chrome bundle id. A URL opens in a new Chrome window, and the next click uses the window whose title matches that site. Config `cua: local` drives this machine. `cua: space` with `cua-space` (or `cua-url` and `cua-token`) drives a Cua Space |
| `/cua +click "<label>"` | Compile remembers the point and a crop of the control. Later runs click that saved point first. When the crop still matches, perception and LocateAnything are not called. When it does not, the step finds the control again, text regions first and then LocateAnything, and saves the new point. The boxed image is written beside the step log as `<step>.locate.jpg`. Add `in Chrome` to pick that app |
| `/cua +type "<text>" into "<label>"` | Type `<text>` into the accessibility field whose label contains `<label>`. When that field is missing, locate it the same way a click does, focus it, then type. The keystrokes name that window |
| `/cua +sendkeys clear then "<text>"` | Send keys to the field the last click focused. It does not click. `clear` selects all and deletes, then `<text>` is typed. `^Enter` in the text presses that key, so `Hello World^Enter` types the words and presses Enter. `^Shift+Enter` holds the modifier. The window is brought forward for the keys, because a background key cannot be aimed at one Chrome window. `+sendkeys "<text>"` only types. `+sendkeys clear` only deletes |
| `/cua <command>` | A sentence with more than one action. [Laya](https://github.com/FluidInference/FluidUse) picks the launch, click, type, and press actions once, when the step compiles. Later runs replay those actions and do not call Laya again |
| `set-config browser-reusetab=youtube` | Attach later `/browser` steps to an open tab whose URL matches that site (`youtube`, `tiktok`, `instagram`, or a host). Opens a new tab when none match. Other tabs stay open. Config `browser-reusetab` does this when the session opens. A workflow file's config replaces the app value. This step replaces it again from there. An empty value uses the active tab. `--param browser-reusetab=` keeps its value for the run |
| `/browser +click $loc` | Click the center stored by `/locate`. Screenshot pixels are scaled onto the page. `+click 1883,1506 box=... /path.jpg` is the same click. `/browser +click subscribe box` names the control the same way |
| `/browser +verify <phrase> [max Ns]` | Check that `<phrase>` is showing. `max Ns` is how long to wait. It can follow another param, as in `+click Next +verify Checks max 2s` |
| `/browser /locate "arrow down icon"` | Screenshot the open page and run LocateAnything locally. The marked box is written beside that screenshot. This does not call Jev. Add `and click` to click the center |
| `/clef <question>` | [Clef Flash 4-bit](https://huggingface.co/mlx-community/clef-flash-4bit) answers `<question>` about an image. It loads in the shared background process, the way Layla does. The default is yes or no, as in `/clef Subscript text exists?`, and the image is the open page. `/browser /clef` is the same. `/cua /clef` asks about the window from the last `/cua` step. `+image /browser` takes that page explicitly. `+image /cua` takes that window. `+image $shot` uses a path stored by an earlier step. `+image /path/shot.jpg` reads that file. `+options a,b,c` or `+options "a", "b,", "c"` lists the allowed answers; quotes keep a comma inside an option. `+verify yes` fails the step when the answer is different. `into $var` stores the answer. `tool-details` `clef.model` is the model id, default `mlx-community/clef-flash-4bit`. `openrouter/cloudflare/clef` asks OpenRouter System One instead. `mlx-vlm` is installed into the workflow venv when the local model is missing |
| `/hug +model <id> +m <prompt> +files <path> +out <path>` | Ask one Hugging Face model and keep the text reply. `+m` is the prompt, or a path to a longer instruction. Markdown is the usual file (`+m instructions.md`). `.txt` works too. A `.yaml` file is read as text and is not parsed. YAML is not required. `{{name}}` and `$name` in the prompt are replaced from a workflow variable or config before the model runs. `+files` is one or more image paths. Each model accepts its own params: a text model such as [Bonsai 4B 1-bit](https://huggingface.co/prism-ml/Bonsai-4B-mlx-1bit) or [Ternary Bonsai 8B](https://huggingface.co/prism-ml/Ternary-Bonsai-8B-mlx-2bit) takes `+m`. A `+param` the model list does not name is still kept. [Bonsai 2 9B](https://huggingface.co/prism-ml/Ternary-Bonsai-2-9B-mlx-2bit) takes `+m` and `+files`. An image model takes `+files` and does not run on `+m` alone. [Bonsai Image 4B](https://huggingface.co/prism-ml/bonsai-image-ternary-4B-mlx-2bit) draws an image from `+m`. `+out` is the file. `into $var` stores that path. `+out` can be left off, and the path still goes into `$var`. Those params are `tool-details` `hug.models`. `+model` can be omitted when config `hug-model` or `set-config hug-model=` already names the model. `+m "find +model and into $place"` keeps those words in the prompt. `+print` writes that reply to the log. `into $var` stores the text reply, or the image path for a generate model. Text models load with `mlx-lm`. Ternary Bonsai 8B uses stock MLX. 1-bit Bonsai also needs the PrismML MLX fork, which compiles Metal kernels. A missing Metal compiler is downloaded with `xcodebuild -downloadComponent MetalToolchain`, then selected with `TOOLCHAINS`, before that build. Image models load with `mlx-vlm`. Bonsai Image loads with `mlx-gen`. Jobs keep those weights in the shared background process and reuse them when they are already loaded. Config `hug-download` defaults to true and installs a missing backend, then downloads the weights. `hug-download: false` leaves that step blocked |
| `/browser /lmstudio-<model> <instruction> into $var` | Screenshot the open page and ask that LM Studio model for one JSON object. `<model>` is the loaded model id, for example `qwen3.8-27b-mlx` or `gemma-4`. `$var` prints as the `value` field. A `YYYY-MM-DD HH:MM:SS` instruction must come back in that form. Config `lmstudio` is the server, default `http://127.0.0.1:1234/v1`. `CG_LOOP_GEMMA_MODEL` replaces the name only for `/lmstudio-gemma-4` |
| `/browser /openrouter-<model> <instruction> into $var` | Screenshot the open page and send it to that OpenRouter model. `<model>` is `vendor/name`, for example `google/gemma-3-27b-it`. Needs `OPENROUTER_API_KEY` |
| `/openrouter-<model> <instruction> into $var` | Ask that OpenRouter model for text and store the reply in `$var`. No screenshot and no browser |
| `/browser …` | Browser only. `open` navigates the tab from `set-config browser-reusetab=` or config `browser-reusetab`. The active tab is used when that site is empty: the focused one, or the visible tab when the window is in the background. Any other line is compiled when that step runs, using the text of the page already open, into a script that reads it with `browser_page`. That script is reused. It is not sent back through the tick loop, and shell is not offered |
| `msg` / `type: workflow` / `params` | `msg` is the workflow name. One group runs; `wf_all` or `wf_slides` / `wf_research\|wf_slides` picks groups |
| `msg` / `type: python` or `shell` / `params` | Compiled once into the step folder as `b-compile.py`, then reused |
| any other line | The browser tool model picks `/browser`, `/python`, or `/term`. Python and term compile still use the chat model. Browser actions use `browser-tool-model` |

`goto`, `load`, `extract`, `term`, `llm-call`, `generate`, `workflow`, `locate`, and `cua` are
compiled on first run too. The compiled file is the step that runs after that.

## Arg examples

| Agent / user arg | Shell form | Example |
|------------------|------------|---------|
| workflow YAML | positional or `--workflow` | `wf-research-content.yaml` |
| every group | `--only wf_all` | run every `wf_*` group |
| one group | `--only wf_slides` | run `wf_slides` only |
| one group | `--only research` | run `wf_research` only |
| one step | `--line N` | `--line 23` with the workflow file. N is the step's line, such as the editor cursor |
| highlighted steps | `--line N --end M` | steps from line N through M. Two highlighted steps run together |
| free-form goal | positional string | `"open the latest ScienceDaily health article"` |
| start URL | `--url` | `--url https://en.wikipedia.org/` |
| config override | `--param KEY=VALUE` | `--param cdp-url=http://127.0.0.1:18802` |
| CDP override | `--cdp-url` | `--cdp-url http://127.0.0.1:18802` |
| print only | `--dry-run` | skip browser/terminal/LLM writes |
| pause each act | `--pause` | Jev "Choose next" |

```bash
bash {baseDir}/scripts/cg_loop.sh \
  /Users/nghia/Downloads/workspace/social_content_gen/workflows/wf-research-content.yaml

bash {baseDir}/scripts/cg_loop.sh --dry-run \
  /Users/nghia/Downloads/workspace/social_content_gen/workflows/wf-research-content.yaml

bash {baseDir}/scripts/cg_loop.sh --only wf_research \
  /Users/nghia/Downloads/workspace/social_content_gen/workflows/wf-research-content.yaml

bash {baseDir}/scripts/cg_loop.sh --only wf_slides \
  /Users/nghia/Downloads/workspace/social_content_gen/workflows/wf-research-content.yaml

bash {baseDir}/scripts/add_idea.sh --write "track leftover chicken protein after dinner"
```

## Commands

```bash
bash {baseDir}/scripts/cg_loop.sh workflows/wf-research-content.yaml
bash {baseDir}/scripts/cg_loop.sh --workflow workflows/wf-research-content.yaml
bash {baseDir}/scripts/cg_loop.sh --only wf_slides --dry-run --workflow workflows/wf-research-content.yaml
bash {baseDir}/scripts/cg_loop.sh --param cdp-url=http://127.0.0.1:18802 --param loop-count=1 workflows/wf-research-content.yaml
bash {baseDir}/tests/run_tests.sh
```

Env overrides:

| Variable | Default | Meaning |
|----------|---------|---------|
| `LM_STUDIO_BASE_URL` | `http://127.0.0.1:1234/v1` | OpenAI-compatible base |
| `LM_STUDIO_MODEL` | `qwen3.8-27b-mlx` | Loaded model id |
| `LM_STUDIO_API_KEY` | `lm-studio` | Dummy key for LM Studio |
| `llm` | `local` | `openrouter` sends chat calls to OpenRouter instead |
| `model` | `deepseek/deepseek-v3.2` when `llm` is openrouter | Chat model for python and term compile, typed text, and term commands |
| `browser-tool-model` | `von` | Local Von for browser actions and unprefixed tool choice. `layla` is local Laya. `jev-latest` is Jev on OpenRouter and uses `OPENROUTER_API_KEY` |
| `OPENROUTER_API_KEY` | unset | Key for `llm: openrouter`, from `config.env` or the process environment |
| `CG_LOOP_MAX_STEPS` | `60` | Max executed actions |
| `command-timeout` | none | Seconds per TERM command, from workflow config. Omitted means no limit |
| `WORKFLOW_PATH` | parent YAML dir + repo `workflows/` | Directories of known workflow YAML files |
| `WORKFLOW_CACHE` | `<project>/cache/<workflow_name>/` | Cache root beside `workflows-app.yaml`. Each group is a folder of step packets |
| run log | `<project>/cache/<workflow_name>/<group>/c-run.log` | Current run for that wf group. Each step also has `c-run.log` |
| `log-keep` | `5` | How many previous runs to keep in `<group>/archived/` |

## Layout

```
{baseDir}/
├── SKILL.md
├── requirements.txt
├── references/
│   ├── overview.md
│   ├── command_catalog.md
│   └── story.md
├── lib/cg_loop/
│   ├── agent.py
│   ├── browser.py
│   ├── model.py
│   ├── snapshot.js
│   ├── workflow.py
│   ├── step_cache.py
│   └── terminal.py
├── tests/
└── scripts/
    ├── cg_loop.py
    ├── cg_loop.sh
    ├── add_idea.py
    └── add_idea.sh
```

## Agent behavior (summary)

1. Observe the page into an indexed table (`[1] link …`, `[2] textbox …`).
2. Offer only supported operations: `CLICK`, `TYPE_TEXT`, `SELECT`, `SCROLL_*`,
   `WAIT`, `TERM`, `GOTO`, `EXTRACT`, `LLM_CALL`, `GENERATE`, `DONE`, `BLOCKED`.
3. One request picks the operation; only the matching target head can execute.
4. `TYPE_TEXT` / unspecified `TERM` call a small helper LLM for the value.
5. Workflow YAML `wf_<name>` groups run in file order, sharing variables and env.
