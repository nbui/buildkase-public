"""App config for cg-loop: workflows root, Von decision model, known tools."""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .workflow import SKILL_ROOT, project_root

_CACHE: AppConfig | None = None


@dataclass(frozen=True)
class ToolAction:
    """One action a tool already knows. `inputs` and `outputs` are top-level names."""

    name: str
    inputs: tuple[str, ...] = ()
    outputs: tuple[str, ...] = ()


@dataclass(frozen=True)
class ModelSpec:
    """Params one Hugging Face model accepts.

    `kind` is `text`, `image`, or `generate`. `params` are the step params it
    accepts (`m`, `files`, `out`). `requires` are the ones that must be
    present. An image model reads files. A generate model writes `+out`.
    `file`, `steps`, `guidance`, and `scheduler` are the run settings for a
    diffusers model. They come from the tool config.
    """

    name: str
    kind: str = "text"
    params: tuple[str, ...] = ()
    requires: tuple[str, ...] = ()
    declared: bool = True
    # mlx-lm, mlx-vlm, mlx-gen, or diffusers. Empty follows `kind`.
    backend: str = ""
    # Run settings from tool-details. A step `+file`, `+steps`, or `+guidance` replaces them.
    file: str = ""
    steps: int | None = None
    guidance: float | None = None
    scheduler: str = ""


@dataclass(frozen=True)
class ToolSpec:
    """A tool the decision model may pick, and the actions it already knows."""

    description: str = ""
    actions: tuple[ToolAction, ...] = ()
    model: str = ""
    models: tuple[ModelSpec, ...] = ()

    def criteria(self) -> str:
        """One line Von can score. Nested fields stay under their top-level name."""
        parts = [self.description] if self.description else []
        for action in self.actions:
            incoming = ", ".join(action.inputs) if action.inputs else "none"
            outgoing = ", ".join(action.outputs) if action.outputs else "none"
            parts.append(f"{action.name}: in {incoming}; out {outgoing}")
        return " ".join(parts).strip()


@dataclass(frozen=True)
class AppConfig:
    path: Path | None
    workflows: Path | None
    decision_llm: str = "von"
    decision_url: str = ""
    decision_model: str = "von"
    tools: dict[str, ToolSpec] = field(default_factory=dict)
    defaults: dict[str, Any] = field(default_factory=dict)
    cg_loop: Path | None = None
    venv: Path | None = None
    env_file: Path | None = None
    env: dict[str, str] = field(default_factory=dict)
    python_llm: str = ""
    python_model: str = ""
    python_timeout: float = 30.0
    python_fallbacks: list[tuple[str, str, float | None]] | None = None
    browser_llm: str = ""
    browser_model: str = ""
    browser_timeout: float = 30.0
    browser_fallbacks: list[tuple[str, str, float | None]] | None = None

    def tool_names(self) -> list[str]:
        return list(self.tools)


def reset_app_config() -> None:
    global _CACHE
    _CACHE = None


def app_config_path() -> Path:
    explicit = os.environ.get("CG_LOOP_APP", "").strip()
    if explicit:
        return Path(explicit).expanduser()
    return project_root() / "workflows-app.yaml"


def load_app_config(path: Path | str | None = None, *, force: bool = False) -> AppConfig:
    """Load workflows-app.yaml. An explicit path is not cached."""
    global _CACHE
    if path is None and _CACHE is not None and not force:
        return _CACHE
    file = Path(path).expanduser() if path else app_config_path()
    config = _read(file)
    if path is None:
        _CACHE = config
    return config


def workflows_root() -> Path | None:
    """The configured workflows folder. The repo workflows/ folder is the fallback."""
    config = load_app_config()
    if config.workflows is not None:
        return config.workflows
    default = project_root()
    if default.is_dir():
        return default.resolve()
    return None


def tool_model(name: str) -> str:
    """The Hugging Face id under `tool-details.<tool>.model`. Empty when unset."""
    spec = load_app_config().tools.get((name or "").strip().lower())
    if spec is None:
        return ""
    return spec.model


def tool_models(name: str) -> dict[str, ModelSpec]:
    """Per-model params under `tool-details.<tool>.models`, keyed by model id."""
    spec = load_app_config().tools.get((name or "").strip().lower())
    if spec is None:
        return {}
    return {item.name: item for item in spec.models}


def python_llm() -> tuple[str, str, float]:
    """Provider, model, and timeout that write Python. An empty provider keeps the active chat model."""
    llm_name, model_name, timeout, _fallbacks = compile_llm("python")
    return llm_name, model_name, timeout


def compile_llm(tool: str) -> tuple[str, str, float, list[tuple[str, str, float | None]] | None]:
    """Provider, model, timeout, and fallbacks for one compile tool.

    An empty provider keeps the active chat model. Fallbacks are None when
    the section omits them, which leaves the workflow fallback list in place.
    A present list, including an empty one, replaces that list for the call.
    """
    config = load_app_config()
    if (tool or "").strip().lower() == "browser":
        return config.browser_llm, config.browser_model, config.browser_timeout, config.browser_fallbacks
    return config.python_llm, config.python_model, config.python_timeout, config.python_fallbacks


def workflow_defaults() -> dict[str, Any]:
    """Config keys every workflow starts with. A file's config replaces these."""
    config = load_app_config()
    defaults = dict(config.defaults)
    if config.venv is not None and "venv" not in defaults:
        defaults["venv"] = str(config.venv)
    return defaults


def app_env() -> dict[str, str]:
    """Environment from workflows-app.yaml.

    `env-file` loads first. The `env` mapping replaces those keys, then
    `config.env`. A workflow file's `config.env` replaces this later.
    """
    config = load_app_config()
    found = _dotenv(config.env_file)
    found.update(config.env)
    raw = config.defaults.get("env") if isinstance(config.defaults, dict) else None
    if isinstance(raw, dict):
        found.update(_coerce_env(raw))
    return found


def apply_app_env() -> None:
    """Fill unset process variables from workflows-app.yaml. The shell wins.

    `bkase` is placed on PATH so every bash script this process starts can call it.
    A local-model folder from Settings replaces `HF_HOME` after that.
    """
    current = dict(os.environ)
    for key, value in app_env().items():
        if key not in current:
            os.environ[key] = value
    from .terminal import with_bkase

    os.environ["PATH"] = with_bkase(dict(os.environ)).get("PATH", os.environ.get("PATH", ""))
    apply_model_storage()


_HF_KEYS = ("HF_HOME", "HF_HUB_CACHE", "HUGGINGFACE_HUB_CACHE")
_APPLIED_MODEL_DIR = ""
_MODEL_DIR_PREVIOUS: dict[str, str | None] | None = None


def models_runtime_dir() -> Path:
    """Folder for the models process state. `CG_LOOP_MODELS_DIR` replaces the default."""
    override = (os.environ.get("CG_LOOP_MODELS_DIR") or "").strip()
    if override:
        return Path(override).expanduser()
    return Path.home() / ".cache" / "cg-loop"


def model_storage_dir() -> Path | None:
    """Folder from Settings where downloaded weights are stored.

    None means the Hugging Face default, `~/.cache/huggingface`.
    """
    path = models_runtime_dir() / "memory.json"
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(raw, dict):
        return None
    text = raw.get("dir")
    if not isinstance(text, str) or not text.strip():
        return None
    folder = Path(text.strip()).expanduser()
    if not folder.is_absolute():
        return None
    return folder


def apply_model_storage() -> None:
    """Point Hugging Face at the Settings folder. An empty setting restores the prior cache."""
    global _APPLIED_MODEL_DIR, _MODEL_DIR_PREVIOUS
    folder = model_storage_dir()
    target = str(folder) if folder is not None else ""
    if target:
        if _MODEL_DIR_PREVIOUS is None:
            _MODEL_DIR_PREVIOUS = {key: os.environ.get(key) for key in _HF_KEYS}
        _point_hf(folder)
        _APPLIED_MODEL_DIR = target
        return
    if not _APPLIED_MODEL_DIR or _MODEL_DIR_PREVIOUS is None:
        return
    for key, value in _MODEL_DIR_PREVIOUS.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value
    _APPLIED_MODEL_DIR = ""
    _MODEL_DIR_PREVIOUS = None
    _refresh_hf_constants()


def reset_model_storage() -> None:
    """Drop the bookkeeping from `apply_model_storage`. Tests use this."""
    global _APPLIED_MODEL_DIR, _MODEL_DIR_PREVIOUS
    _APPLIED_MODEL_DIR = ""
    _MODEL_DIR_PREVIOUS = None


def _point_hf(folder: Path) -> None:
    home = str(folder)
    hub = str(folder / "hub")
    os.environ["HF_HOME"] = home
    os.environ["HF_HUB_CACHE"] = hub
    os.environ["HUGGINGFACE_HUB_CACHE"] = hub
    try:
        folder.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    _refresh_hf_constants()


def _refresh_hf_constants() -> None:
    try:
        import huggingface_hub.constants as constants
    except ImportError:
        return
    home = os.path.expanduser(
        os.environ.get("HF_HOME")
        or os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.join(os.path.expanduser("~"), ".cache")), "huggingface")
    )
    hub = os.path.expanduser(
        os.environ.get("HF_HUB_CACHE")
        or os.environ.get("HUGGINGFACE_HUB_CACHE")
        or os.path.join(home, "hub")
    )
    constants.HF_HOME = home
    constants.HF_HUB_CACHE = hub
    constants.HUGGINGFACE_HUB_CACHE = hub


def _read(path: Path) -> AppConfig:
    if not path.is_file():
        return AppConfig(
            path=None,
            workflows=None,
            tools=_default_tools(),
            cg_loop=_bundled_script(),
            venv=_bundled_venv(),
        )
    payload = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(payload, dict):
        raise ValueError(f"workflows-app.yaml must be a mapping: {path}")
    decision = payload.get("decision") if isinstance(payload.get("decision"), dict) else {}
    python = payload.get("python") if isinstance(payload.get("python"), dict) else {}
    browser = payload.get("browser") if isinstance(payload.get("browser"), dict) else {}
    tools = _tools(payload.get("tools"), payload.get("tool-details") or payload.get("tool_details"))
    model = str(decision.get("model") or "von").strip() or "von"
    defaults = payload.get("config") if isinstance(payload.get("config"), dict) else {}
    return AppConfig(
        path=path.resolve(),
        workflows=_workflows_dir(payload.get("workflows"), path),
        decision_llm=str(decision.get("llm") or decision.get("provider") or model).strip() or model,
        decision_url=str(decision.get("url") or "").strip(),
        decision_model=model,
        tools=tools,
        defaults=dict(defaults),
        cg_loop=_abs_dir(payload.get("cg-loop") or payload.get("cg_loop"), path) or _bundled_script(),
        venv=_abs_dir(payload.get("venv"), path) or _bundled_venv(),
        env_file=_abs_dir(payload.get("env-file") or payload.get("env_file"), path),
        env=_env_mapping(payload.get("env")),
        python_llm=str(python.get("llm") or python.get("provider") or "").strip(),
        python_model=str(python.get("model") or "").strip(),
        python_timeout=_section_timeout(python),
        python_fallbacks=_section_fallbacks(python),
        browser_llm=str(browser.get("llm") or browser.get("provider") or "").strip(),
        browser_model=str(browser.get("model") or "").strip(),
        browser_timeout=_section_timeout(browser),
        browser_fallbacks=_section_fallbacks(browser),
    )


def _section_timeout(section: dict[str, Any]) -> float:
    """Seconds for one compile call. Missing or invalid means 30."""
    if "llm-timeout" in section:
        raw = section.get("llm-timeout")
    elif "llm_timeout" in section:
        raw = section.get("llm_timeout")
    else:
        return 30.0
    try:
        seconds = float(raw)
    except (TypeError, ValueError):
        return 30.0
    if seconds <= 0:
        return 30.0
    return seconds


def _section_fallbacks(section: dict[str, Any]) -> list[tuple[str, str, float | None]] | None:
    """Fallbacks written on a compile section. None means the section does not override."""
    if "fallbacks" not in section and "llm-fallbacks" not in section:
        return None
    from .workflow import _fallbacks

    return _fallbacks(section)


def _bundled_script() -> Path | None:
    """The cg-loop script that ships with this install. A `cg-loop` key replaces it."""
    bkase = SKILL_ROOT / "scripts" / "bkase"
    if bkase.is_file():
        return bkase.resolve()
    script = SKILL_ROOT / "scripts" / "cg_loop.sh"
    if script.is_file():
        return script.resolve()
    return None


def _bundled_venv() -> Path | None:
    """The Python environment next to this skill. A `venv` key replaces it."""
    folder = SKILL_ROOT / "venv"
    if folder.is_dir():
        return folder.resolve()
    return None


def _workflows_dir(value: Any, config_path: Path) -> Path | None:
    return _abs_dir(value, config_path)


def _abs_dir(value: Any, config_path: Path) -> Path | None:
    text = str(value or "").strip()
    if not text:
        return None
    folder = Path(text).expanduser()
    if not folder.is_absolute():
        folder = config_path.parent / folder
    return folder.resolve()


def _env_mapping(raw: Any) -> dict[str, str]:
    """Top-level `env`. Comments-only blocks load as empty."""
    if raw is None:
        return {}
    if isinstance(raw, str):
        raise ValueError("env must be a mapping; point env-file at a dotenv file")
    if not isinstance(raw, dict):
        raise ValueError("env must be a mapping")
    return _coerce_env(raw)


def _coerce_env(raw: dict[str, Any]) -> dict[str, str]:
    found: dict[str, str] = {}
    for key, value in raw.items():
        name = str(key).strip()
        if not name:
            continue
        text = _env_value(value)
        if text:
            found[name] = text
    return found


def _env_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        parts = [_env_value(item) for item in value]
        return os.pathsep.join(part for part in parts if part)
    text = str(value).strip()
    if text.startswith("~"):
        text = str(Path(text).expanduser())
    return text


def _dotenv(path: Path | None) -> dict[str, str]:
    """KEY=VALUE lines. Missing files contribute nothing."""
    if path is None or not path.is_file():
        return {}
    found: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#") or "=" not in text:
            continue
        if text.startswith("export "):
            text = text[len("export ") :].strip()
        key, value = text.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'\"")
        if key and value:
            found[key] = value
    return found


def _tools(raw: Any, details: Any) -> dict[str, ToolSpec]:
    specs = _tool_names(raw)
    for name, (actions, model, models) in _tool_details(details).items():
        current = specs.get(name, ToolSpec())
        specs[name] = ToolSpec(
            description=current.description,
            actions=actions,
            model=model or current.model,
            models=models or current.models,
        )
    return specs


def _tool_names(raw: Any) -> dict[str, ToolSpec]:
    if raw is None:
        return _default_tools()
    if isinstance(raw, dict):
        found = {str(key).strip().lower(): _tool_spec(value) for key, value in raw.items()}
        found = {key: value for key, value in found.items() if key}
        if not found:
            raise ValueError("tools must name at least one tool")
        return found
    if isinstance(raw, list):
        found = {str(item).strip().lower(): ToolSpec() for item in raw if str(item).strip()}
        if not found:
            raise ValueError("tools must name at least one tool")
        return found
    raise ValueError("tools must be a mapping or a list")


def _tool_spec(raw: Any) -> ToolSpec:
    if raw is None or isinstance(raw, str):
        return ToolSpec(description=str(raw or "").strip())
    if not isinstance(raw, dict):
        raise ValueError("a tool must be a description")
    description = str(raw.get("description") or raw.get("text") or "").strip()
    return ToolSpec(description=description)


def _tool_details(raw: Any) -> dict[str, tuple[tuple[ToolAction, ...], str, tuple[ModelSpec, ...]]]:
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise ValueError("tool-details must be a mapping of tool name to actions")
    found: dict[str, tuple[tuple[ToolAction, ...], str, tuple[ModelSpec, ...]]] = {}
    for key, value in raw.items():
        name = str(key).strip().lower()
        if name:
            found[name] = (_actions(value), _detail_model(value), _detail_models(value))
    return found


def _detail_model(raw: Any) -> str:
    """`model` on a tool. It is the Hugging Face id, not an action."""
    if not isinstance(raw, dict):
        return ""
    for key, value in raw.items():
        if str(key).strip().lower() == "model":
            return str(value or "").strip()
    return ""


def _detail_models(raw: Any) -> tuple[ModelSpec, ...]:
    """`models` on a tool. Each id lists the params that model accepts."""
    if not isinstance(raw, dict):
        return ()
    block = None
    for key, value in raw.items():
        if str(key).strip().lower() == "models":
            block = value
            break
    if block is None:
        return ()
    if not isinstance(block, dict):
        raise ValueError("models must be a mapping of Hugging Face id to params")
    found: list[ModelSpec] = []
    for key, value in block.items():
        name = str(key).strip()
        if name:
            found.append(_model_spec(name, value))
    return tuple(found)


def _model_spec(model_id: str, raw: Any) -> ModelSpec:
    if isinstance(raw, str):
        kind = raw.strip().lower()
        body: dict[str, Any] = {}
    elif isinstance(raw, dict):
        kind = str(raw.get("kind") or raw.get("type") or "text").strip().lower()
        body = raw
    else:
        raise ValueError(f"model {model_id} must list kind and params")
    if kind not in {"text", "image", "generate"}:
        raise ValueError(f"model {model_id} kind must be text, image, or generate")
    if "params" in body:
        params = _hug_param_names(body.get("params"), model_id)
    elif kind == "image":
        params = ("files",)
    elif kind == "generate":
        params = ("m", "out")
    else:
        params = ("m",)
    if not params:
        raise ValueError(f"model {model_id} needs at least one param")
    if "requires" in body:
        requires = _hug_param_names(body.get("requires"), model_id)
    elif kind == "image":
        requires = ("files",) if "files" in params else ()
    else:
        requires = ("m",) if "m" in params else ()
    missing = [name for name in requires if name not in params]
    if missing:
        shown = ", ".join(missing)
        raise ValueError(f"model {model_id} requires {shown}, which is not in params")
    if kind == "image" and "files" not in params:
        raise ValueError(f"model {model_id} is an image model and needs files in params")
    if kind == "generate" and "m" not in params:
        raise ValueError(f"model {model_id} generates an image and needs m in params")
    backend = str(body.get("backend") or "").strip().lower()
    if backend and backend not in {"mlx-lm", "mlx-vlm", "mlx-gen", "diffusers"}:
        raise ValueError(f"model {model_id} backend must be mlx-lm, mlx-vlm, mlx-gen, or diffusers")
    file_name = str(body.get("file") or "").strip()
    if any(ch.isspace() for ch in file_name):
        raise ValueError(f"model {model_id} file must be one filename")
    scheduler = str(body.get("scheduler") or "").strip().lower()
    if scheduler and scheduler not in {"euler-trailing", "euler-trailing-sample"}:
        raise ValueError(
            f"model {model_id} scheduler must be euler-trailing or euler-trailing-sample"
        )
    return ModelSpec(
        name=model_id,
        kind=kind,
        params=params,
        requires=requires,
        backend=backend,
        file=file_name,
        steps=_model_number(body.get("steps"), model_id, "steps", whole=True),
        guidance=_model_number(body.get("guidance"), model_id, "guidance", whole=False),
        scheduler=scheduler,
    )


def _model_number(raw: Any, model_id: str, label: str, *, whole: bool) -> int | float | None:
    """A tool-config number. Missing stays unset. `whole` keeps an integer step count."""
    if raw is None or raw == "":
        return None
    if isinstance(raw, bool) or not isinstance(raw, (int, float)):
        raise ValueError(f"model {model_id} {label} must be a number")
    if whole:
        if isinstance(raw, float) and not raw.is_integer():
            raise ValueError(f"model {model_id} {label} must be an integer")
        return int(raw)
    return float(raw)


def _hug_param_names(raw: Any, model_id: str) -> tuple[str, ...]:
    names = _param_names(raw)
    found: list[str] = []
    for name in names:
        key = name.strip().lower().replace("-", "_")
        if not key or not re.fullmatch(r"[a-z][a-z0-9_]*", key):
            raise ValueError(f"model {model_id} param must be a name, got {name!r}")
        canonical = {
            "m": "m",
            "message": "m",
            "prompt": "m",
            "file": "files",
            "files": "files",
            "out": "out",
            "output": "out",
        }.get(key, key)
        if canonical not in found:
            found.append(canonical)
    return tuple(found)


def _actions(raw: Any) -> tuple[ToolAction, ...]:
    if raw is None:
        return ()
    if not isinstance(raw, dict):
        raise ValueError("actions must be a mapping of action name to in and out")
    found: list[ToolAction] = []
    for key, value in raw.items():
        name = str(key).strip().lower()
        if not name or name in {"model", "models"}:
            continue
        if value is None or isinstance(value, str):
            found.append(ToolAction(name=name))
            continue
        if not isinstance(value, dict):
            raise ValueError(f"action {name} must list in and out")
        found.append(
            ToolAction(
                name=name,
                inputs=_param_names(value.get("in", value.get("inputs"))),
                outputs=_param_names(value.get("out", value.get("outputs"))),
            )
        )
    return tuple(found)


def _param_names(raw: Any) -> tuple[str, ...]:
    """Top-level names only. A nested mapping contributes its keys, not the children."""
    if raw is None:
        return ()
    if isinstance(raw, str):
        text = raw.strip()
        return (text,) if text else ()
    if isinstance(raw, list):
        names: list[str] = []
        for item in raw:
            names.extend(_param_names(item))
        return tuple(dict.fromkeys(names))
    if isinstance(raw, dict):
        return tuple(str(key).strip() for key in raw if str(key).strip())
    text = str(raw).strip()
    return (text,) if text else ()


def _default_tools() -> dict[str, ToolSpec]:
    return {
        "browser": ToolSpec("Act on the open page.", (ToolAction("goto", ("url",), ("page",)),)),
        "term": ToolSpec("Run a shell command.", (ToolAction("run", ("command",), ("stdout", "code")),)),
        "locate": ToolSpec("Find something in an image.", (ToolAction("find", ("query", "image"), ("box",)),)),
        "clef": ToolSpec(
            "Answer a yes/no question about the open page.",
            (ToolAction("ask", ("question", "options"), ("value",)),),
        ),
        "cua": ToolSpec("Drive a desktop app.", (ToolAction("launch", ("app", "url"), ("window",)),)),
        "lmstudio": ToolSpec(
            "Ask one local LM Studio model.",
            (ToolAction("ask", ("model", "instruction"), ("value",)),),
        ),
        "python": ToolSpec(
            "Write Python when no listed action can do the step.",
            (
                ToolAction("load", ("roots",), ("items",)),
                ToolAction("generate", ("source",), ("text",)),
            ),
        ),
        "hug": ToolSpec(
            "Ask one Hugging Face model. Text models take +m. Image models take +files. Generate models take +m and write +out.",
            (ToolAction("ask", ("model", "m", "files", "out"), ("value",)),),
            model="prism-ml/Bonsai-4B-mlx-1bit",
            models=(
                ModelSpec(
                    name="prism-ml/Bonsai-4B-mlx-1bit",
                    kind="text",
                    params=("m",),
                    requires=("m",),
                ),
                ModelSpec(
                    name="prism-ml/Ternary-Bonsai-8B-mlx-2bit",
                    kind="text",
                    params=("m",),
                    requires=("m",),
                ),
                ModelSpec(
                    name="prism-ml/Ternary-Bonsai-2-9B-mlx-2bit",
                    kind="image",
                    params=("m", "files"),
                    requires=("files",),
                ),
                ModelSpec(
                    name="prism-ml/bonsai-image-ternary-4B-mlx-2bit",
                    kind="generate",
                    params=("m", "out"),
                    requires=("m",),
                ),
            ),
        ),
    }
