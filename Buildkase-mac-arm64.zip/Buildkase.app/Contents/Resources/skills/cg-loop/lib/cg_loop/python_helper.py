"""Write a post marker from a `/python` step.

The step names the file, the folder, and the fields. Values come from the
story already picked, the open page, and this run's browser profile and CDP URL.
A story-prompt step reads markdown or JSON, fills `$name` from context, and
stores the prompt.
"""

from __future__ import annotations

import json
import re
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_MARKER_RE = re.compile(r"\b(post_[a-z0-9_]+\.yaml)\b", re.IGNORECASE)
_WRITE_MARKER_RE = re.compile(r"\bwrite\s+(post_[a-z0-9_]+\.yaml)\b", re.IGNORECASE)
_PRINT_RE = re.compile(r"^(?:/python\s+)?print\s+\$(\w+)\s*$", re.IGNORECASE)
_DATE_KEYS = ("date", "published", "post_date", "iso", "value", "text", "raw")
_FIELD_ORDER = (
    "platform",
    "status",
    "posted_at",
    "url",
    "title",
    "video_file",
    "browser_profile",
    "browser_cdp_url",
)
# Longer names first so "cdp url" is not also read as "url".
_FIELD_ALIASES = (
    ("browser profile", "browser_profile"),
    ("browser_profile", "browser_profile"),
    ("cdp url", "browser_cdp_url"),
    ("browser cdp url", "browser_cdp_url"),
    ("cdp_url", "browser_cdp_url"),
    ("posted at", "posted_at"),
    ("posted_at", "posted_at"),
    ("video file", "video_file"),
    ("video_file", "video_file"),
    ("platform", "platform"),
    ("status", "status"),
    ("title", "title"),
    ("url", "url"),
)
_VIDEO_KEYS = {
    "youtube": ("youtube_video", "video"),
    "tiktok": ("story_video", "video"),
    "instagram": ("story_video", "video"),
}
_VIDEO_NAMES = {
    "youtube": ("youtube_captions_music.mp4", "short.mp4", "output_music.mp4"),
    "tiktok": ("story_captions_music.mp4", "short.mp4", "output_music.mp4"),
    "instagram": ("story_captions_music.mp4", "short.mp4", "output_square_music.mp4"),
}
_SHORTS_URL = re.compile(r"youtube\.com/shorts/([\w-]{6,})")
_WATCH_URL = re.compile(r"(?:youtube\.com/watch\?v=|youtu\.be/)([\w-]{6,})")
_STUDIO_URL = re.compile(r"studio\.youtube\.com/video/([\w-]{6,})")
_OTHER_URL = re.compile(r"https?://(?:www\.)?(?:tiktok\.com|instagram\.com)/\S+")


_FOLDER_CONDITION = re.compile(
    r"folders\s+in\s+\$([A-Za-z_]\w*)"
    r"(?:\s+of\s+type\s+(\$[\w]+|[\w.-]+))?"
    r"\s*(<=|>=|==|!=|<|>)\s*(\d+)",
    re.IGNORECASE,
)
_COMPARE = {
    "<": lambda count, limit: count < limit,
    ">": lambda count, limit: count > limit,
    "<=": lambda count, limit: count <= limit,
    ">=": lambda count, limit: count >= limit,
    "==": lambda count, limit: count == limit,
    "!=": lambda count, limit: count != limit,
}


def folder_condition(text: str, env: dict[str, Any]) -> bool | None:
    """True or false for a folder-count sentence. None when this is not that sentence.

    The python tool counts the named root. A type limits DRAFT_ROOT to folders
    whose type.txt matches. The loop does not ask a chat model to compare.
    """
    match = _FOLDER_CONDITION.search(text or "")
    if not match:
        return None
    root, type_token, op, raw_limit = match.groups()
    from .agent import folder_state

    items = list(folder_state(env).get(root) or [])
    if type_token:
        kind = str(env.get(type_token[1:]) or "").strip() if type_token.startswith("$") else type_token
        items = [item for item in items if item.get("type") == kind]
    count = len(items)
    matched = _COMPARE[op](count, int(raw_limit))
    print(f"PYTHON condition {text}: {str(matched).lower()} count={count}", flush=True)
    return matched


def python_helper_handles(command: str) -> bool:
    """True when this sentence is a print, a story prompt, or a post marker write.

    A set, an add, or other date math is generated. Mentioning `post_tiktok.yaml`
    is not enough. A select that skips folders which already have that file
    still needs generated Python.
    """
    text = (command or "").strip()
    if not text:
        return False
    if _PRINT_RE.match(text):
        return True
    if _story_prompt_command(text):
        return True
    if _title_prompt_command(text) or _apply_title_command(text):
        return True
    return _WRITE_MARKER_RE.search(text) is not None


def python_helper(
    command: str,
    *,
    dry_run: bool = False,
    env: dict[str, str] | None = None,
    variables: dict[str, Any] | None = None,
    browser: Any = None,
    cdp_url: str = "",
) -> dict[str, Any]:
    """Write the yaml named in `command`, or print one `$variable`.

    A dry-run prints the marker and does not write it. `print $name` reads that
    variable. A mapping print uses its date when one is present. The run log
    writes that text after the step line. A set or a date calculation is
    generated Python, not this helper.
    """
    text = (command or "").strip()
    if not text:
        raise ValueError("python helper needs a command")
    merged_env = dict(env or {})
    names = dict(variables or {})
    printed = _print_variable(text, names)
    if printed is not None:
        return printed
    if _story_prompt_command(text):
        return _story_prompt(merged_env, names)
    if _title_prompt_command(text):
        return _title_prompt(merged_env, names)
    if _apply_title_command(text):
        return _apply_title(merged_env, names)
    filename = _marker_name(text)
    folder_key = _folder_key(text)
    folder = _folder(names, folder_key)
    inputs = {"command": text, "file": filename, "folder": folder_key}
    if folder is None:
        message = f"{folder_key.replace('_', ' ')} was not found"
        print(f"BLOCKED {message}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {"status": "blocked", "message": message},
            "blocked": True,
        }
    page = _read_page(browser)
    fields = _requested_fields(text)
    marker = _marker(
        fields,
        filename=filename,
        folder=folder,
        env=merged_env,
        variables=names,
        page=page,
        cdp_url=cdp_url,
        browser=browser,
    )
    path = folder / filename
    if path.is_file():
        print(f"KEEP {path}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {
                "status": "ok",
                "path": str(path),
                "message": f"{filename} is already in the {folder_key.replace('_', ' ')}",
            },
        }
    if dry_run:
        print(f"DRY-RUN WRITE {path}", flush=True)
        return {"inputs": inputs, "outputs": {"status": "proposed", "path": str(path), "marker": marker}}
    import yaml

    path.write_text(yaml.safe_dump(marker, sort_keys=False, allow_unicode=True), encoding="utf-8")
    print(f"WROTE {path}", flush=True)
    return {"inputs": inputs, "outputs": {"status": "ok", "path": str(path), "marker": marker}}


def _print_variable(command: str, variables: dict[str, Any]) -> dict[str, Any] | None:
    """Read `$name` from the workflow variables. Other commands return None.

    The text is returned as `printed`. The run log writes it after the step line.
    """
    match = _PRINT_RE.match(command.strip())
    if not match:
        return None
    name = match.group(1)
    if name not in variables:
        raise RuntimeError(f"${name} is not set")
    value = variables[name]
    shown = _print_text(value)
    return {
        "inputs": {"command": command, "var": name},
        "outputs": {"status": "ok", "printed": shown, name: value},
    }


def _print_text(value: Any) -> str:
    if isinstance(value, dict):
        for key in _DATE_KEYS:
            text = str(value.get(key) or "").strip()
            if text:
                return text
        return json.dumps(value, ensure_ascii=False, default=str)
    if isinstance(value, (list, tuple)):
        return json.dumps(list(value), ensure_ascii=False, default=str)
    if value is None:
        return ""
    return str(value)


def _title_prompt_command(command: str) -> bool:
    """The step that asks for a new title only when this story does not exist."""
    text = (command or "").lower()
    return (
        "$title_prompt" in text
        and "$story_title" in text
        and "story.md" in text
        and "creative sleep story title" in text
    )


def _apply_title_command(command: str) -> bool:
    """The step that stores the OpenRouter title on `$STORY_TITLE`."""
    text = (command or "").lower()
    return (
        "$title_prompt" in text
        and "$story_title" in text
        and "$story_idea" in text
        and "done" in text
        and "keep" in text
    )


def _title_prompt(env: dict[str, str], variables: dict[str, Any]) -> dict[str, Any]:
    """DONE when a title is already chosen. Otherwise the OpenRouter title brief."""
    title = str(_context_get(variables, env, "STORY_TITLE", "story_title") or "").strip()
    if title:
        prompt = "DONE"
    else:
        prompt = _new_title_brief(variables, env)
    return {
        "inputs": {"story_title": title},
        "outputs": {"status": "ok", "printed": prompt, "title_prompt": prompt},
        "variables": {"title_prompt": prompt},
    }


def _new_title_brief(variables: dict[str, Any], env: dict[str, str]) -> str:
    lines = [
        "Write one creative sleep story title.",
        "Use a month, a season, a historical event, an invention, a war, or the news.",
        "One line. No quotes.",
    ]
    root = _context_get(variables, env, "STORY_ROOT", "story_root")
    names: list[str] = []
    if root and Path(str(root)).expanduser().is_dir():
        for child in sorted(Path(str(root)).expanduser().iterdir()):
            if child.is_dir() and not child.name.startswith("."):
                names.append(child.name.replace("-", " "))
    if names:
        lines.append("Do not repeat: " + "; ".join(names[:200]))
    return "\n".join(lines)


def _apply_title(env: dict[str, str], variables: dict[str, Any]) -> dict[str, Any]:
    """Keep `$STORY_TITLE` when the prompt was DONE. Otherwise use `$story_idea`."""
    prompt = str(_context_get(variables, env, "title_prompt") or "").strip()
    current = str(_context_get(variables, env, "STORY_TITLE", "story_title") or "").strip()
    if prompt == "DONE":
        title = current
    else:
        title = _idea_title(_context_get(variables, env, "story_idea"))
        if not title:
            raise RuntimeError("$story_idea has no title")
    return {
        "inputs": {"title_prompt": prompt, "story_title": current},
        "outputs": {"status": "ok", "printed": title, "STORY_TITLE": title},
        "variables": {"STORY_TITLE": title},
    }


def _idea_title(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("text", "value", "title"):
            text = str(value.get(key) or "").strip()
            if text:
                value = text
                break
        else:
            return ""
    text = str(value or "").strip().strip('"').strip("'")
    return text.splitlines()[0].strip() if text else ""


def _story_prompt_command(command: str) -> bool:
    """The step that builds `$story_prompt` from the story file and the prompt files."""
    text = (command or "").lower()
    return (
        "$story_prompt" in text
        and "story.md" in text
        and "$story_words" in text
        and ("$story_continue" in text or "read $story_prompt" in text)
    )


def spoken_word_count(text: str) -> int:
    """Words that will be read aloud. Headings and Still lines do not count."""
    body = re.sub(r"(?s)```.*?```", " ", text or "")
    body = re.sub(r"(?m)^#+\s+.*$", " ", body)
    body = re.sub(r"(?im)^still:.*$", " ", body)
    return len(body.split())


def _story_prompt(env: dict[str, str], variables: dict[str, Any]) -> dict[str, Any]:
    """Build `$story_prompt` from markdown or JSON, with context variables filled in.

    A `story.md` already inside 80 to 120 percent of `$STORY_WORDS` is DONE.
    A shorter file continues from `$STORY_CONTINUE`. Anything else starts from
    `$STORY_PROMPT` and the text of `$ARC`.
    """
    from .hug import read_template

    words = _required_int(variables, env, "STORY_WORDS")
    floor = max(1, int(round(words * 0.8)))
    ceiling = max(floor, int(round(words * 1.2)))
    story_md = _story_markdown(variables, env)
    existing = story_md.read_text(encoding="utf-8") if story_md.is_file() else ""
    count = spoken_word_count(existing) if story_md.is_file() else 0
    if story_md.is_file() and floor <= count <= ceiling:
        prompt = "DONE"
    elif story_md.is_file() and count < floor:
        prompt = _join(
            read_template(_required_file(variables, env, "STORY_CONTINUE"), env=env, variables=variables),
            existing,
        )
    else:
        prompt = _join(
            read_template(_required_file(variables, env, "STORY_PROMPT"), env=env, variables=variables),
            _arc_text(variables, env),
        )
    return {
        "inputs": {"story": str(story_md), "spoken_words": count, "floor": floor, "ceiling": ceiling},
        "outputs": {"status": "ok", "printed": prompt, "story_prompt": prompt, "spoken_words": count},
        "variables": {"story_prompt": prompt},
    }


def _join(head: str, tail: str) -> str:
    body = (head or "").rstrip()
    extra = (tail or "").strip()
    if not extra:
        return body + "\n"
    return f"{body}\n\n{extra}\n"


def _arc_text(variables: dict[str, Any], env: dict[str, str]) -> str:
    from .hug import read_template

    path = _required_file(variables, env, "ARC")
    if path.suffix.lower() in {".md", ".markdown", ".json", ".txt", ".text", ".yaml", ".yml"}:
        return read_template(path, env=env, variables=variables)
    return path.read_text(encoding="utf-8")


def _story_markdown(variables: dict[str, Any], env: dict[str, str]) -> Path:
    root = _context_get(variables, env, "STORY_ROOT", "story_root")
    if root is None or not str(root).strip():
        folder = _context_get(variables, env, "story_folder", "STORY_DIR", "story_dir")
        if folder is None or not str(folder).strip() or str(folder).strip().lower() == "none":
            raise RuntimeError("$STORY_ROOT is not set")
        return Path(str(folder)).expanduser() / "story.md"
    title = _context_get(variables, env, "STORY_TITLE", "story_title") or "story"
    return Path(str(root)).expanduser() / _kebab(str(title)) / "story.md"


def _kebab(title: str) -> str:
    """Full kebab-case folder name. The story writer uses the same rule."""
    text = re.sub(r"[^a-z0-9]+", "-", (title or "").strip().lower())
    text = re.sub(r"-+", "-", text).strip("-")
    return text or "story"


def _required_file(variables: dict[str, Any], env: dict[str, str], name: str) -> Path:
    raw = _context_get(variables, env, name)
    if raw is None or not str(raw).strip():
        raise RuntimeError(f"${name} is not set")
    path = Path(str(raw)).expanduser()
    if not path.is_file():
        raise RuntimeError(f"${name} is not a file: {path}")
    return path


def _required_int(variables: dict[str, Any], env: dict[str, str], name: str) -> int:
    raw = _context_get(variables, env, name)
    if raw is None or not str(raw).strip():
        raise RuntimeError(f"${name} is not set")
    try:
        return int(str(raw).strip())
    except ValueError as exc:
        raise RuntimeError(f"${name} is not a number: {raw}") from exc


def _context_get(variables: dict[str, Any], env: dict[str, str], *names: str) -> Any:
    for name in names:
        keys = [name]
        if name.upper() not in keys:
            keys.append(name.upper())
        if name.lower() not in keys:
            keys.append(name.lower())
        for source in (variables, env):
            for key in keys:
                if key in source and source[key] is not None:
                    return source[key]
    return None


def _marker_name(command: str) -> str:
    match = _MARKER_RE.search(command)
    if not match:
        raise ValueError(f"python step needs a post_*.yaml file name: {command}")
    return match.group(1)


def _folder_key(command: str) -> str:
    text = command.lower()
    if "short folder" in text:
        return "short_folder"
    named = re.search(r"\bin\s+(?:the\s+)?\$([a-z_][a-z0-9_]*)", text)
    if named:
        return named.group(1)
    return "story_folder"


def _folder(variables: dict[str, Any], key: str) -> Path | None:
    raw = str(variables.get(key) or "").strip()
    if not raw or raw.lower() == "none":
        return None
    path = Path(raw).expanduser()
    if not path.is_dir():
        return None
    return path


def _requested_fields(command: str) -> list[str]:
    text = command.lower()
    with_at = text.rfind(" with ")
    body = text[with_at + 6 :] if with_at >= 0 else ""
    if not body.strip():
        return list(_FIELD_ORDER)
    found: list[str] = []
    scratch = body
    for alias, key in _FIELD_ALIASES:
        if alias in scratch:
            if key not in found:
                found.append(key)
            scratch = scratch.replace(alias, " ")
    ordered = [key for key in _FIELD_ORDER if key in found]
    return ordered or list(_FIELD_ORDER)


def _marker(
    fields: list[str],
    *,
    filename: str,
    folder: Path,
    env: dict[str, str],
    variables: dict[str, Any],
    page: dict[str, Any],
    cdp_url: str,
    browser: Any,
) -> dict[str, Any]:
    platform = _platform(filename)
    title = _title(folder, variables)
    values = {
        "platform": platform,
        "status": _status(page, title),
        "posted_at": datetime.now(timezone.utc).isoformat(),
        "url": _url(page, title, platform),
        "title": title,
        "video_file": _video_file(folder, variables, platform),
        "browser_profile": _profile(env, browser),
        "browser_cdp_url": (cdp_url or env.get("CDP_URL") or "").strip(),
    }
    return {key: values[key] for key in fields if key in values}


def _platform(filename: str) -> str:
    stem = Path(filename).stem
    if stem.startswith("post_"):
        return stem.removeprefix("post_")
    return stem


def _title(folder: Path, variables: dict[str, Any]) -> str:
    for key in ("post_title", "title"):
        text = str(variables.get(key) or "").strip()
        if text and text.lower() != "none":
            return text
    path = folder / "post_title.txt"
    if path.is_file():
        return path.read_text(encoding="utf-8").strip()
    return ""


def _profile(env: dict[str, str], browser: Any) -> str:
    name = str(env.get("PROFILE") or "").strip()
    if name:
        return name
    return str(getattr(browser, "profile", "") or "").strip()


def _video_file(folder: Path, variables: dict[str, Any], platform: str) -> str:
    for key in _VIDEO_KEYS.get(platform, ("video",)):
        found = _video_in_folder(folder, variables.get(key))
        if found:
            return found
    for name in _VIDEO_NAMES.get(platform, ()):
        if (folder / name).is_file():
            return name
    for key in ("youtube_video", "story_video", "video"):
        found = _video_in_folder(folder, variables.get(key))
        if found:
            return found
    return ""


def _video_in_folder(folder: Path, value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        return ""
    path = Path(value).expanduser()
    if path.is_file() and path.parent == folder:
        return path.name
    return ""


def _status(page: dict[str, Any], title: str) -> str:
    folded = re.sub(r"\s+", " ", str(page.get("text") or "")).casefold()
    if "video scheduled" in folded:
        return "scheduled"
    needle = re.sub(r"\s+", " ", title).casefold()
    start = folded.find(needle) if needle else -1
    window = folded[start : start + 600] if start >= 0 else ""
    if "scheduled" in window:
        return "scheduled"
    if "published" in window or re.search(r"\bpublic\b", window):
        return "posted"
    return "posted"


def _url(page: dict[str, Any], title: str, platform: str) -> str:
    page_url = str(page.get("url") or "")
    needle = re.sub(r"\s+", " ", title).casefold()
    ranked: list[tuple[int, str]] = []
    for href, label in _links(page, page_url):
        public = _public_url(href, platform)
        if not public:
            continue
        score = 2 if needle and needle in re.sub(r"\s+", " ", label).casefold() else 0
        ranked.append((score, public))
    titled = [item for item in ranked if item[0] >= 2]
    if titled:
        titled.sort(key=lambda item: item[0], reverse=True)
        return titled[0][1]
    own = _public_url(page_url, platform)
    if own:
        return own
    if len(ranked) == 1:
        return ranked[0][1]
    return ""


def _links(page: dict[str, Any], page_url: str) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    for action in page.get("actions") or []:
        if not isinstance(action, dict):
            continue
        href = str(action.get("href") or "").strip()
        if not href:
            continue
        label = str(action.get("label") or action.get("name") or "")
        found.append((_absolute(href, page_url), label))
    html = str(page.get("html") or "")
    for match in re.finditer(r"""href=["']([^"']+)["']""", html):
        found.append((_absolute(match.group(1), page_url), ""))
    return found


def _absolute(href: str, page_url: str) -> str:
    if href.startswith(("http://", "https://")):
        return href
    if href.startswith("//"):
        return "https:" + href
    if href.startswith("/") and page_url:
        parsed = urllib.parse.urlparse(page_url)
        if parsed.scheme and parsed.netloc:
            return f"{parsed.scheme}://{parsed.netloc}{href}"
    return href


def _public_url(href: str, platform: str) -> str:
    if platform == "youtube":
        shorts = _SHORTS_URL.search(href)
        if shorts:
            return f"https://www.youtube.com/shorts/{shorts.group(1)}"
        watch = _WATCH_URL.search(href)
        if watch:
            return f"https://www.youtube.com/watch?v={watch.group(1)}"
        studio = _STUDIO_URL.search(href)
        if studio:
            return f"https://www.youtube.com/watch?v={studio.group(1)}"
        return ""
    match = _OTHER_URL.search(href)
    return match.group(0) if match else ""


def _read_page(browser: Any) -> dict[str, Any]:
    observe = getattr(browser, "observe", None)
    if not callable(observe):
        return {}
    try:
        page = observe()
    except Exception as exc:
        print(f"PAGE {exc}", flush=True)
        return {}
    return page if isinstance(page, dict) else {}
