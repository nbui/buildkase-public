#!/usr/bin/env bash
# Older name for the cg-loop launcher. `bkase` is the script on PATH.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
exec "$DIR/bkase" "$@"
