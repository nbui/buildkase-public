"""/hug asks one Hugging Face model. Each model accepts its own params."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.app_config import load_app_config, reset_app_config  # noqa: E402
from cg_loop.compiled import ensure_compiled, run_hug, validate_compiled  # noqa: E402
from cg_loop.decision import skips_script  # noqa: E402
from cg_loop import hug  # noqa: E402
from cg_loop.hug import (  # noqa: E402
    BONSAI2_9B,
    BONSAI_IMAGE,
    TERNARY_BONSAI_8B,
    load_prompt,
    model_params,
    parse_hug_command,
)
from cg_loop.workflow import load_workflow, parse_step, project_root  # noqa: E402

ROOT = project_root()
BONSAI = "prism-ml/Bonsai-4B-mlx-1bit"
IMAGE = "org/image-only"
VISION = "org/vision"


def _app(body: str) -> Path:
    folder = Path(tempfile.mkdtemp())
    path = folder / "workflows-app.yaml"
    path.write_text(body, encoding="utf-8")
    return path


class HugParseTests(unittest.TestCase):
    def tearDown(self) -> None:
        reset_app_config()

    def test_text_model_takes_a_message(self) -> None:
        step = parse_step(f"/hug +model {BONSAI} +m Find location of X into $place")
        self.assertEqual(step.tool, "hug")
        self.assertEqual(step.kind, "hug")
        self.assertEqual(step.command, BONSAI)
        self.assertEqual(step.extra, "Find location of X")
        self.assertEqual(step.var, "place")
        self.assertEqual(step.params["files"], [])
        self.assertFalse(step.params["print"])
        self.assertTrue(skips_script(step))

    def test_message_can_be_quoted_and_files_can_come_first(self) -> None:
        call = parse_hug_command('+files "shot one.jpg", other.png +m "Find location of X" into $seen')
        self.assertEqual(call.model, "")
        self.assertEqual(call.message, "Find location of X")
        self.assertEqual(call.files, ("shot one.jpg", "other.png"))
        self.assertEqual(call.var, "seen")

    def test_quotes_keep_params_and_into_inside_the_value(self) -> None:
        quoted = (
            '+m "find params in /hug +model prism-ml/Bonsai-4B-mlx-1bit '
            '+m Find location of X into $place" +print'
        )
        step = parse_step("/hug " + quoted)
        self.assertEqual(
            step.extra,
            "find params in /hug +model prism-ml/Bonsai-4B-mlx-1bit "
            "+m Find location of X into $place",
        )
        self.assertEqual(step.var, "")
        self.assertTrue(step.params["print"])
        escaped = parse_step(r'/hug +m "say \"into $place\" and \+model x" +print')
        self.assertEqual(escaped.extra, 'say "into $place" and +model x')
        self.assertEqual(escaped.var, "")
        with self.assertRaises(ValueError):
            parse_step('/hug +m "forgot the end')

    def test_bonsai_keeps_a_file_param_the_definition_omits(self) -> None:
        step = parse_step(f"/hug +model {BONSAI} +m Find location of X +files shot.jpg +temperature 0.2")
        self.assertEqual(step.extra, "Find location of X")
        self.assertEqual(step.params["files"], ["shot.jpg"])
        self.assertEqual(step.params["temperature"], "0.2")

    def test_ternary_bonsai_takes_text_and_rejects_files(self) -> None:
        step = parse_step(f"/hug +model {TERNARY_BONSAI_8B} +m Find location of X into $place")
        self.assertEqual(step.command, TERNARY_BONSAI_8B)
        self.assertEqual(step.extra, "Find location of X")
        spec = model_params(TERNARY_BONSAI_8B)
        self.assertEqual(spec.kind, "text")
        self.assertEqual(spec.params, ("m",))
        self.assertEqual(spec.requires, ("m",))
        kept = parse_step(f"/hug +model {TERNARY_BONSAI_8B} +m Find location of X +file shot.png")
        self.assertEqual(kept.params["files"], ["shot.png"])

    def test_bonsai2_takes_a_prompt_and_a_file(self) -> None:
        step = parse_step(
            f"/hug +model {BONSAI2_9B} +m find pixel location of Sat +file shot.png into $place"
        )
        self.assertEqual(step.command, BONSAI2_9B)
        self.assertEqual(step.extra, "find pixel location of Sat")
        self.assertEqual(step.params["files"], ["shot.png"])
        spec = model_params(BONSAI2_9B)
        self.assertEqual(spec.kind, "image")
        self.assertEqual(spec.params, ("m", "files"))
        self.assertEqual(spec.requires, ("files",))
        with self.assertRaises(ValueError) as raised:
            parse_step(f"/hug +model {BONSAI2_9B} +m find pixel location of Sat")
        self.assertIn("+files", str(raised.exception))

    def test_bonsai_image_takes_out_and_a_variable(self) -> None:
        step = parse_step(
            f"/hug +model {BONSAI_IMAGE} +m a bonsai tree in morning light "
            "+out ../data/wf-test/bonsai.png +print into $image"
        )
        self.assertEqual(step.command, BONSAI_IMAGE)
        self.assertEqual(step.extra, "a bonsai tree in morning light")
        self.assertEqual(step.params["out"], "../data/wf-test/bonsai.png")
        self.assertEqual(step.params["files"], [])
        self.assertTrue(step.params["print"])
        self.assertEqual(step.var, "image")
        spec = model_params(BONSAI_IMAGE)
        self.assertEqual(spec.kind, "generate")
        self.assertEqual(spec.params, ("m", "out"))
        self.assertEqual(spec.requires, ("m",))
        stored = parse_step(f"/hug +model {BONSAI_IMAGE} +m a bonsai tree into $image")
        self.assertEqual(stored.params["out"], "")
        self.assertEqual(stored.var, "image")
        extra_file = parse_step(f"/hug +model {BONSAI_IMAGE} +m a bonsai tree +files shot.png")
        self.assertEqual(extra_file.params["files"], ["shot.png"])
        with self.assertRaises(ValueError) as missing:
            parse_step(f"/hug +model {BONSAI_IMAGE} +out shot.png")
        self.assertIn("+m", str(missing.exception))
        text_out = parse_step(f"/hug +model {BONSAI} +m Find location of X +out shot.png")
        self.assertEqual(text_out.params["out"], "shot.png")

    def test_empty_params_fail(self) -> None:
        with self.assertRaises(ValueError):
            parse_step("/hug +model " + BONSAI)
        with self.assertRaises(ValueError):
            parse_step("/hug Find location of X")

    def test_image_model_needs_a_file_and_rejects_a_text_prompt_alone(self) -> None:
        path = _app(
            "tool-details:\n"
            "  hug:\n"
            "    models:\n"
            f"      {IMAGE}:\n"
            "        kind: image\n"
            "        params: [files]\n"
            "        requires: [files]\n"
            f"      {VISION}:\n"
            "        kind: image\n"
            "        params: [m, files]\n"
            "        requires: [files]\n"
        )
        reset_app_config()
        with patch.dict(os.environ, {"CG_LOOP_APP": str(path)}):
            reset_app_config()
            with self.assertRaises(ValueError) as text_only:
                parse_step(f"/hug +model {IMAGE} +m Find location of X")
            self.assertIn("+files", str(text_only.exception))
            kept = parse_step(f"/hug +model {IMAGE} +m Find location of X +files shot.jpg")
            self.assertEqual(kept.extra, "Find location of X")
            self.assertEqual(kept.params["files"], ["shot.jpg"])
            with self.assertRaises(ValueError) as missing:
                parse_step(f"/hug +model {VISION} +m Find location of X")
            self.assertIn("+files", str(missing.exception))
            step = parse_step(f"/hug +model {IMAGE} +file shot.jpg into $seen")
            self.assertEqual(step.params["files"], ["shot.jpg"])
            self.assertEqual(step.extra, "")
            both = parse_step(f"/hug +model {VISION} +m Find location of X +files shot.jpg")
            self.assertEqual(both.extra, "Find location of X")
            self.assertEqual(both.params["files"], ["shot.jpg"])
            spec = model_params(IMAGE)
            self.assertEqual(spec.kind, "image")
            self.assertEqual(spec.params, ("files",))
            self.assertNotIn("models", {action.name for action in load_app_config().tools["hug"].actions})

    def test_undeclared_model_keeps_params_and_still_needs_m(self) -> None:
        # The repo is read when the step runs, so parse keeps the params.
        step = parse_step("/hug +model org/unknown-text +files shot.jpg +seed 3")
        self.assertEqual(step.params["files"], ["shot.jpg"])
        self.assertEqual(step.params["seed"], "3")
        kept = parse_step("/hug +model org/unknown-text +m look +files shot.jpg +seed 3")
        self.assertEqual(kept.extra, "look")
        hug._DETECTED.pop("org/unknown-text", None)
        with patch.object(hug, "_repo_files", return_value=["config.json", "model.safetensors"]), patch.object(
            hug, "_repo_config", return_value={"model_type": "llama", "architectures": ["LlamaForCausalLM"]}
        ):
            spec = hug.runtime_spec("org/unknown-text")
        self.assertEqual(spec.kind, "text")
        self.assertEqual(spec.backend, "mlx-lm")
        with self.assertRaises(ValueError) as raised:
            hug.check_params(spec, message="", files=("shot.jpg",))
        self.assertIn("+m", str(raised.exception))


class HugConfigTests(unittest.TestCase):
    def tearDown(self) -> None:
        reset_app_config()

    def test_app_config_lists_bonsai_as_text(self) -> None:
        reset_app_config()
        config = load_app_config(force=True)
        hug = config.tools["hug"]
        self.assertEqual(hug.model, BONSAI)
        self.assertEqual([action.name for action in hug.actions], ["ask"])
        self.assertNotIn("models", {action.name for action in hug.actions})
        spec = next(item for item in hug.models if item.name == BONSAI)
        self.assertEqual(spec.kind, "text")
        self.assertEqual(spec.params, ("m",))
        self.assertEqual(spec.requires, ("m",))
        ternary = next(item for item in hug.models if item.name == TERNARY_BONSAI_8B)
        self.assertEqual(ternary.kind, "text")
        self.assertEqual(ternary.params, ("m",))
        self.assertEqual(ternary.requires, ("m",))
        vision = next(item for item in hug.models if item.name == BONSAI2_9B)
        self.assertEqual(vision.kind, "image")
        self.assertEqual(vision.params, ("m", "files"))
        self.assertEqual(vision.requires, ("files",))
        drawn = next(item for item in hug.models if item.name == BONSAI_IMAGE)
        self.assertEqual(drawn.kind, "generate")
        self.assertEqual(drawn.params, ("m", "out"))
        self.assertEqual(drawn.requires, ("m",))
        lightning = next(item for item in hug.models if item.name == "ByteDance/SDXL-Lightning")
        self.assertEqual(lightning.kind, "generate")
        self.assertEqual(lightning.backend, "diffusers")
        self.assertEqual(lightning.file, "sdxl_lightning_4step.safetensors")
        self.assertEqual(lightning.steps, 4)
        self.assertEqual(lightning.guidance, 0.0)
        self.assertEqual(lightning.scheduler, "euler-trailing")

    def test_config_and_set_config_supply_the_model(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-hug.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: hug",
                        f"  hug-model: {BONSAI}",
                        "from_config_routine:",
                        "  - /hug +m Find location of X into $place",
                        "from_step_routine:",
                        f"  - set-config hug-model={BONSAI}",
                        "  - /hug +m Find location of X into $place",
                        "  - /hug +m Where is X into $place",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(path)
        groups = workflow.named_groups()
        configured = groups["from_config_routine"]
        stepped = groups["from_step_routine"]
        self.assertEqual(configured.env["HUG_MODEL"], BONSAI)
        self.assertEqual(stepped.env["HUG_MODEL"], BONSAI)
        self.assertEqual(configured.steps[0].command, "")
        self.assertEqual(configured.steps[0].extra, "Find location of X")
        self.assertEqual(stepped.steps[1].command, "")
        self.assertEqual(stepped.steps[2].extra, "Where is X")

    def test_example_workflow_parses(self) -> None:
        group = load_workflow(ROOT / "workflows" / "wf-tests.yaml").named_groups()["hug_model_routine"]
        self.assertEqual(group.env["HUG_MODEL"], BONSAI)
        prompts = [step.extra for step in group.steps if step.kind == "hug"]
        self.assertEqual(
            prompts,
            [
                "Find location of X",
                "Where is X",
                "Find location of X",
                "../data/wf-test/hug-find.md",
                "whats 2+1 equal to",
                "who is washignton",
                "find params in /hug +model prism-ml/Bonsai-4B-mlx-1bit "
                "+m Find location of X into $place",
                "../data/wf-test/hug-json.md",
                "../data/wf-test/hug-json.yaml",
                "find pixel location of Sat",
                "whats 2+1 equal to",
                "a bonsai tree in morning light",
                "A calm square photoreal photograph of a secret pre-World War II underground bunker, "
                "Robert standing beside a prototype radar device with vacuum tubes, cathode ray "
                "oscilloscopes, and brass dials on a metal console, concrete walls lined with mounted "
                "technical charts and maps, soft warm overhead lighting casting gentle shadows across "
                "the stone floor, old radio equipment and wire coils scattered on a wooden table, "
                "no text, no letters, no watermark., How Radar Was Invented Before World War II, "
                "Scene 1: Secret Bunker Demonstration",
            ],
        )
        sat = next(step for step in group.steps if step.extra == "find pixel location of Sat")
        self.assertEqual(sat.command, BONSAI2_9B)
        self.assertEqual(sat.params["files"], ["../data/wf-test/iphone-yuba.png"])
        self.assertTrue(sat.params["print"])
        self.assertEqual(sat.var, "place")
        drawn = next(step for step in group.steps if step.command == BONSAI_IMAGE)
        self.assertEqual(drawn.extra, "a bonsai tree in morning light")
        self.assertEqual(drawn.params["out"], "../data/wf-test/bonsai.png")
        self.assertTrue(drawn.params["print"])
        self.assertEqual(drawn.var, "image")
        printed = next(step for step in group.steps if step.extra.startswith("find params"))
        self.assertTrue(printed.params["print"])
        self.assertEqual(printed.var, "")
        as_json = next(step for step in group.steps if step.extra == "../data/wf-test/hug-json.md")
        self.assertEqual(as_json.var, "place")
        self.assertTrue(as_json.params["print"])
        as_yaml = next(step for step in group.steps if step.extra == "../data/wf-test/hug-json.yaml")
        self.assertEqual(as_yaml.var, "place")
        self.assertTrue(as_yaml.params["print"])
        named = next(step for step in group.steps if step.kind == "hug" and step.command == BONSAI)
        self.assertEqual(named.extra, "Find location of X")
        text, source = load_prompt("data/wf-test/hug-find.md", base=ROOT)
        self.assertIn("Find the location of X.", text)
        self.assertTrue(source.endswith("data/wf-test/hug-find.md"))
        body, json_source = load_prompt("data/wf-test/hug-json.md", base=ROOT, env={"SUBJECT": "X"})
        self.assertIn("location of X.", body)
        self.assertIn('"place"', body)
        self.assertNotIn("{{subject}}", body)
        self.assertTrue(json_source.endswith("data/wf-test/hug-json.md"))
        yaml_body, yaml_source = load_prompt("data/wf-test/hug-json.yaml", base=ROOT, env={"subject": "X"})
        self.assertIn("task: Find the location of X.", yaml_body)
        self.assertIn("format: json", yaml_body)
        self.assertNotIn("{{subject}}", yaml_body)
        self.assertTrue(yaml_source.endswith("data/wf-test/hug-json.yaml"))

    def test_hug_download_defaults_on_and_can_be_turned_off(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-hug.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: hug",
                        "ask_routine:",
                        "  - /hug +m Find location of X into $place",
                        "off_routine:",
                        "  - set-config hug-download=false",
                        "  - /hug +m Find location of X into $place",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            groups = load_workflow(path).named_groups()
            off = Path(tmp) / "wf-off.yaml"
            off.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: hug",
                        "  hug-download: false",
                        "quiet_routine:",
                        "  - /hug +m Find location of X into $place",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            quiet = load_workflow(off).named_groups()["quiet_routine"]
        self.assertEqual(groups["ask_routine"].env["HUG_DOWNLOAD"], "true")
        self.assertEqual(groups["off_routine"].env["HUG_DOWNLOAD"], "false")
        self.assertEqual(quiet.env["HUG_DOWNLOAD"], "false")


class HugRunTests(unittest.TestCase):
    def test_dry_run_uses_the_configured_model_and_does_not_load_it(self) -> None:
        result = run_hug(
            {"dry_run": True, "env": {"HUG_MODEL": BONSAI}, "variables": {}},
            model="",
            message="Find location of X",
            files=[],
            var="place",
        )
        self.assertEqual(result["outputs"]["status"], "proposed")
        self.assertEqual(result["inputs"]["model"], BONSAI)
        self.assertEqual(result["variables"]["place"], "")

    def test_explicit_model_wins_and_the_reply_is_stored(self) -> None:
        with patch("cg_loop.hug.ask_hug", return_value="beside the door") as ask:
            result = run_hug(
                {"env": {"HUG_MODEL": "other/model"}, "variables": {}},
                model=BONSAI,
                message="Find location of X",
                files=[],
                var="place",
            )
        ask.assert_called_once_with(BONSAI, "Find location of X", [], out="", download=True)
        self.assertEqual(result["outputs"]["status"], "ok")
        self.assertEqual(result["outputs"]["text"], "beside the door")
        self.assertEqual(result["variables"]["place"], "beside the door")
        self.assertFalse(result["inputs"]["print"])

    def test_print_writes_the_reply_to_the_log(self) -> None:
        step = parse_step("/hug +m whats 2+1 +print")
        self.assertEqual(step.extra, "whats 2+1")
        self.assertTrue(step.params["print"])
        with self.assertRaises(ValueError):
            parse_step("/hug +m whats 2+1 +print extra")
        with patch("cg_loop.hug.ask_hug", return_value="3"):
            result = run_hug(
                {"env": {"HUG_MODEL": BONSAI}, "variables": {}},
                model="",
                message=step.extra,
                files=[],
                var="",
                printed=True,
            )
        self.assertEqual(result["outputs"]["text"], "3")
        self.assertTrue(result["inputs"]["print"])

    def test_prompt_file_is_read_as_text(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            markdown = folder / "hug-find.md"
            markdown.write_text("Find the location of X.\n\nReply in one sentence.\n", encoding="utf-8")
            yaml_prompt = folder / "hug-find.yaml"
            yaml_prompt.write_text("task: find X\nreply: one sentence\n", encoding="utf-8")
            workflow = folder / "wf-hug.yaml"
            workflow.write_text("config:\n  name: hug\n", encoding="utf-8")
            with patch("cg_loop.hug.ask_hug", return_value="beside the door") as ask:
                from_md = run_hug(
                    {"env": {"HUG_MODEL": BONSAI}, "variables": {}, "workflow_path": str(workflow)},
                    model="",
                    message="hug-find.md",
                    files=[],
                    var="place",
                )
                from_yaml = run_hug(
                    {"env": {"HUG_MODEL": BONSAI}, "variables": {}, "workflow_path": str(workflow)},
                    model="",
                    message="hug-find.yaml",
                    files=[],
                    var="place",
                )
        self.assertEqual(from_md["outputs"]["text"], "beside the door")
        self.assertEqual(ask.call_args_list[0].args[1], "Find the location of X.\n\nReply in one sentence.")
        self.assertEqual(ask.call_args_list[1].args[1], "task: find X\nreply: one sentence")
        self.assertTrue(from_yaml["inputs"]["prompt_file"].endswith("hug-find.yaml"))

    def test_prompt_template_fields_are_filled_before_the_model(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "ask.md").write_text(
                "Find {{subject}} near $item.\n",
                encoding="utf-8",
            )
            (folder / "ask.yaml").write_text(
                "task: Find {{subject}}\nnear: ${item}\n",
                encoding="utf-8",
            )
            workflow = folder / "wf-hug.yaml"
            workflow.write_text("config:\n  name: hug\n", encoding="utf-8")
            ctx = {
                "env": {"HUG_MODEL": BONSAI, "SUBJECT": "X"},
                "variables": {"item": {"text": "the door"}},
                "workflow_path": str(workflow),
            }
            with patch("cg_loop.hug.ask_hug", return_value="beside the door") as ask:
                from_md = run_hug(ctx, model="", message="ask.md", files=[], var="place")
                from_yaml = run_hug(ctx, model="", message="ask.yaml", files=[], var="place")
        self.assertEqual(ask.call_args_list[0].args[1], "Find X near the door.")
        self.assertEqual(ask.call_args_list[1].args[1], "task: Find X\nnear: the door")
        self.assertEqual(from_md["inputs"]["message"], "Find X near the door.")
        self.assertIn("task: Find X", from_yaml["inputs"]["message"])
        self.assertNotIn("{{subject}}", from_yaml["inputs"]["message"])

    def test_json_prompt_file_fills_context_variables(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "ask.json").write_text(
                json.dumps("Find {{subject}} near $item."),
                encoding="utf-8",
            )
            workflow = folder / "wf-hug.yaml"
            workflow.write_text("config:\n  name: hug\n", encoding="utf-8")
            ctx = {
                "env": {"HUG_MODEL": BONSAI, "subject": "X"},
                "variables": {"item": "the door"},
                "workflow_path": str(workflow),
            }
            with patch("cg_loop.hug.ask_hug", return_value="beside the door") as ask:
                result = run_hug(ctx, model="", message="ask.json", files=[], var="place")
        self.assertEqual(ask.call_args.args[1], "Find X near the door.")
        self.assertEqual(result["inputs"]["message"], "Find X near the door.")
        self.assertTrue(result["inputs"]["prompt_file"].endswith("ask.json"))

    def test_missing_prompt_file_is_blocked(self) -> None:
        result = run_hug(
            {"env": {"HUG_MODEL": BONSAI}, "variables": {}},
            model="",
            message="missing-instructions.md",
            files=[],
            var="place",
        )
        self.assertTrue(result["blocked"])
        self.assertIn("prompt not found", result["outputs"]["message"])

    def test_missing_mlx_installs_when_download_is_on(self) -> None:
        calls = {"n": 0}

        def importer():
            calls["n"] += 1
            if calls["n"] == 1:
                raise ImportError("No module named 'mlx_lm'")

            def generate(model, tokenizer, prompt, max_tokens):
                return "beside the door"

            def load(model_id):
                return ("weights", "tokenizer")

            return generate, load

        hug._LOADED.pop(("text", BONSAI), None)
        with patch("cg_loop.hug._import_mlx_lm", side_effect=importer), patch(
            "cg_loop.hug._pip_install"
        ) as install, patch("cg_loop.hug._ensure_metal_toolchain"):
            text = hug._generate_text(BONSAI, "Find location of X", download=True)
        hug._LOADED.pop(("text", BONSAI), None)
        self.assertEqual(text, "beside the door")
        specs = [call.args[0] for call in install.call_args_list]
        self.assertEqual(specs[0], "mlx-lm")
        self.assertIn("PrismML-Eng/mlx", specs[1])
        self.assertTrue(install.call_args_list[1].kwargs["upgrade"])

    def test_text_prompt_is_sent_as_a_user_turn(self) -> None:
        seen: dict[str, object] = {}

        class Tokenizer:
            has_chat_template = True

            def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=False):
                seen["messages"] = messages
                seen["add"] = add_generation_prompt
                return "<user>Find the location of X.</user><assistant>\n\n"

        def generate(model, tokenizer, prompt, max_tokens):
            seen["prompt"] = prompt
            return '{"place": "beside the door"}'

        def load(model_id):
            return ("weights", Tokenizer())

        hug._LOADED.pop(("text", BONSAI), None)
        with patch("cg_loop.hug._import_mlx_lm", return_value=(generate, load)):
            text = hug._generate_text(BONSAI, "Find the location of X.", download=False)
        hug._LOADED.pop(("text", BONSAI), None)
        self.assertEqual(text, '{"place": "beside the door"}')
        self.assertEqual(seen["prompt"], "<user>Find the location of X.</user><assistant>\n\n")
        self.assertEqual(seen["messages"], [{"role": "user", "content": "Find the location of X."}])
        self.assertTrue(seen["add"])

    def test_text_prompt_keeps_the_thread(self) -> None:
        seen: dict[str, object] = {}
        thread = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
            {"role": "user", "content": "and now"},
        ]

        class Tokenizer:
            has_chat_template = True

            def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=False):
                seen["messages"] = messages
                return "<thread><assistant>\n"

        def generate(model, tokenizer, prompt, max_tokens):
            seen["prompt"] = prompt
            return "still here"

        def load(model_id):
            return ("weights", Tokenizer())

        hug._LOADED.pop(("text", BONSAI), None)
        with patch("cg_loop.hug._import_mlx_lm", return_value=(generate, load)):
            text = hug._generate_text(BONSAI, "and now", download=False, messages=thread)
        hug._LOADED.pop(("text", BONSAI), None)
        self.assertEqual(text, "still here")
        self.assertEqual(seen["messages"], thread)
        self.assertEqual(seen["prompt"], "<thread><assistant>\n")

    def test_text_reply_uses_the_requested_token_budget(self) -> None:
        seen: dict[str, object] = {}

        class Tokenizer:
            has_chat_template = True

            def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=False):
                seen["messages"] = messages
                return "<system>Write Python.</system><user>print today</user><assistant>\n"

        def generate(model, tokenizer, prompt, max_tokens):
            seen["max_tokens"] = max_tokens
            return "def run(ctx):\n    pass\n"

        def load(model_id):
            return ("weights", Tokenizer())

        thread = [
            {"role": "system", "content": "Write Python."},
            {"role": "user", "content": "print today"},
        ]
        hug._LOADED.pop(("text", TERNARY_BONSAI_8B), None)
        with patch("cg_loop.hug._import_mlx_lm", return_value=(generate, load)):
            text = hug._generate_text(
                TERNARY_BONSAI_8B,
                "Write Python.\n\nprint today",
                download=False,
                messages=thread,
                max_tokens=4096,
            )
        hug._LOADED.pop(("text", TERNARY_BONSAI_8B), None)
        self.assertIn("def run", text)
        self.assertEqual(seen["max_tokens"], 4096)
        self.assertEqual(seen["messages"], thread)

    def test_image_prompt_keeps_the_thread(self) -> None:
        import types

        seen: dict[str, object] = {}
        thread = [
            {"role": "user", "content": "what is this"},
            {"role": "assistant", "content": "a cat"},
            {"role": "user", "content": "what color"},
        ]

        def apply_chat_template(processor, config, prompt, num_images=0, **kwargs):
            seen["prompt"] = prompt
            seen["images"] = num_images
            return "<image>thread"

        prompt_utils = types.ModuleType("mlx_vlm.prompt_utils")
        prompt_utils.apply_chat_template = apply_chat_template  # type: ignore[attr-defined]
        utils = types.ModuleType("mlx_vlm.utils")
        utils.load_config = lambda model_id: {"model_type": "qwen2_vl"}  # type: ignore[attr-defined]
        saved = {name: sys.modules.get(name) for name in ("mlx_vlm", "mlx_vlm.prompt_utils", "mlx_vlm.utils")}
        sys.modules["mlx_vlm"] = types.ModuleType("mlx_vlm")
        sys.modules["mlx_vlm.prompt_utils"] = prompt_utils
        sys.modules["mlx_vlm.utils"] = utils
        try:
            text = hug._image_prompt("processor", "org/see", "what color", 1, thread)
        finally:
            for name, module in saved.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module
        self.assertEqual(text, "<image>thread")
        self.assertEqual(seen["prompt"], thread)
        self.assertEqual(seen["images"], 1)

    def test_missing_mlx_stays_blocked_when_download_is_off(self) -> None:
        with patch("cg_loop.hug._import_mlx_lm", side_effect=ImportError("No module named 'mlx_lm'")), patch(
            "cg_loop.hug._pip_install"
        ) as install:
            with self.assertRaises(RuntimeError) as raised:
                hug._generate_text(BONSAI, "Find location of X", download=False)
        install.assert_not_called()
        self.assertIn("No module named 'mlx_lm'", str(raised.exception))

    def test_prism_install_downloads_metal_when_the_compiler_is_missing(self) -> None:
        hug._LOADED.pop(("text", BONSAI), None)
        calls = {"n": 0}

        def importing():
            calls["n"] += 1
            if calls["n"] == 1:
                raise ImportError("No module named 'mlx_lm'")

            def generate(model, tokenizer, prompt, max_tokens):
                return "beside the door"

            def load(model_id):
                return ("weights", "tokenizer")

            return generate, load

        with patch("cg_loop.hug._import_mlx_lm", side_effect=importing), patch(
            "cg_loop.hug._pip_install"
        ), patch("cg_loop.hug._metal_ready", side_effect=[False, True]), patch(
            "cg_loop.hug.subprocess.run",
            return_value=subprocess.CompletedProcess(args=[], returncode=0),
        ) as run:
            hug._generate_text(BONSAI, "Find location of X", download=True)
        hug._LOADED.pop(("text", BONSAI), None)
        cmds = [call.args[0] for call in run.call_args_list]
        self.assertIn(["xcodebuild", "-downloadComponent", "MetalToolchain"], cmds)

    def test_ternary_installs_mlx_lm_without_the_prism_fork(self) -> None:
        hug._LOADED.pop(("text", TERNARY_BONSAI_8B), None)
        calls = {"n": 0}

        def importer():
            calls["n"] += 1
            if calls["n"] == 1:
                raise ImportError("No module named 'mlx_lm'")

            def generate(model, tokenizer, prompt, max_tokens):
                return "beside the door"

            def load(model_id):
                return ("weights", "tokenizer")

            return generate, load

        with patch("cg_loop.hug._import_mlx_lm", side_effect=importer), patch(
            "cg_loop.hug._pip_install"
        ) as install, patch("cg_loop.hug._ensure_metal_toolchain") as metal:
            text = hug._generate_text(TERNARY_BONSAI_8B, "Find location of X", download=True)
        hug._LOADED.pop(("text", TERNARY_BONSAI_8B), None)
        self.assertEqual(text, "beside the door")
        self.assertEqual([call.args[0] for call in install.call_args_list], ["mlx-lm"])
        metal.assert_not_called()

    def test_bonsai2_sends_the_image_with_thinking_off(self) -> None:
        import types

        seen: dict[str, object] = {}

        def generate(model, processor, prompt, image, **kwargs):
            seen["prompt"] = prompt
            seen["image"] = image
            seen["kwargs"] = kwargs
            return "120,340"

        def load(model_id):
            return ("weights", "processor")

        def apply_chat_template(processor, config, prompt, num_images=0, **kwargs):
            seen["template"] = kwargs
            seen["images"] = num_images
            return "<image>find Sat"

        prompt_utils = types.ModuleType("mlx_vlm.prompt_utils")
        prompt_utils.apply_chat_template = apply_chat_template  # type: ignore[attr-defined]
        utils = types.ModuleType("mlx_vlm.utils")
        utils.load_config = lambda model_id: {"model_type": "prism_hadamard_qwen35"}  # type: ignore[attr-defined]
        saved = {name: sys.modules.get(name) for name in ("mlx_vlm", "mlx_vlm.prompt_utils", "mlx_vlm.utils")}
        sys.modules["mlx_vlm"] = types.ModuleType("mlx_vlm")
        sys.modules["mlx_vlm.prompt_utils"] = prompt_utils
        sys.modules["mlx_vlm.utils"] = utils
        hug._LOADED.pop(("image", BONSAI2_9B), None)
        try:
            with patch("cg_loop.hug._import_mlx_vlm", return_value=(generate, load)):
                text = hug._generate_image(BONSAI2_9B, "find Sat", ["shot.png"], download=False)
        finally:
            hug._LOADED.pop(("image", BONSAI2_9B), None)
            for name, module in saved.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module
        self.assertEqual(text, "120,340")
        self.assertEqual(seen["image"], ["shot.png"])
        self.assertEqual(seen["prompt"], "<image>find Sat")
        self.assertEqual(seen["images"], 1)
        kwargs = seen["kwargs"]
        template = seen["template"]
        assert isinstance(kwargs, dict)
        assert isinstance(template, dict)
        self.assertEqual(kwargs["temperature"], 0.7)
        self.assertFalse(template["enable_thinking"])

    def test_prism_build_selects_the_installed_metal_toolchain(self) -> None:
        shown = (
            "Status: installed\n"
            "Toolchain Identifier: com.apple.dt.toolchain.Metal.32023.921.5\n"
        )
        with patch.dict(os.environ, {"TOOLCHAINS": "com.apple.dt.toolchain.XcodeDefault"}, clear=False), patch(
            "cg_loop.hug.subprocess.run",
            return_value=subprocess.CompletedProcess(args=[], returncode=0, stdout=shown, stderr=""),
        ):
            env = hug._compiler_env()
        self.assertEqual(
            env["TOOLCHAINS"],
            "com.apple.dt.toolchain.Metal.32023.921.5:com.apple.dt.toolchain.XcodeDefault",
        )

    def test_missing_image_is_blocked(self) -> None:
        path = _app(
            "tool-details:\n"
            "  hug:\n"
            "    models:\n"
            f"      {IMAGE}:\n"
            "        kind: image\n"
            "        params: [files]\n"
            "        requires: [files]\n"
        )
        reset_app_config()
        with patch.dict(os.environ, {"CG_LOOP_APP": str(path)}):
            reset_app_config()
            result = run_hug(
                {"env": {}, "variables": {}},
                model=IMAGE,
                message="",
                files=["/tmp/cg-loop-missing-hug.jpg"],
                var="seen",
            )
        reset_app_config()
        self.assertTrue(result["blocked"])
        self.assertIn("not found", result["outputs"]["message"])

    def test_compile_calls_run_hug(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-hug.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: hug",
                        "ask_routine:",
                        f"  - /hug +model {BONSAI} +m Find location of X into $place",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["ask_routine"]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            text = created.path.read_text(encoding="utf-8")
        self.assertIn("run_hug", text)
        self.assertIn("Find location of X", text)

    def test_generate_stores_the_path_from_out_or_a_default(self) -> None:
        def reply(_model, _message, _files, *, out="", download=True):
            return out

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflow = root / "workflows" / "wf.yaml"
            workflow.parent.mkdir()
            workflow.write_text("config:\n  name: hug\n", encoding="utf-8")
            data = root / "out"
            with patch("cg_loop.hug.ask_hug", side_effect=reply) as ask:
                named = run_hug(
                    {
                        "env": {},
                        "variables": {},
                        "data": str(data),
                        "workflow_path": str(workflow),
                    },
                    model=BONSAI_IMAGE,
                    message="a bonsai tree",
                    out="../data/wf-test/bonsai.png",
                    var="image",
                    printed=True,
                )
                defaulted = run_hug(
                    {
                        "env": {},
                        "variables": {},
                        "data": str(data),
                        "workflow_path": str(workflow),
                    },
                    model=BONSAI_IMAGE,
                    message="a bonsai tree",
                    out="",
                    var="image",
                )
        named_path = Path(named["inputs"]["out"])
        self.assertEqual(named_path.name, "bonsai.png")
        self.assertEqual(named["variables"]["image"], str(named_path))
        self.assertEqual(ask.call_args_list[0].kwargs["out"], str(named_path))
        default_path = Path(defaulted["inputs"]["out"])
        self.assertEqual(default_path.parent, data.resolve())
        self.assertTrue(default_path.name.startswith("image-"))
        self.assertTrue(default_path.name.endswith(".png"))
        self.assertEqual(defaulted["variables"]["image"], str(default_path))

    def test_generate_dry_run_keeps_the_path_and_does_not_draw(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            workflow = Path(tmp) / "wf.yaml"
            workflow.write_text("config:\n  name: hug\n", encoding="utf-8")
            with patch("cg_loop.hug.ask_hug") as ask:
                result = run_hug(
                    {"dry_run": True, "env": {}, "variables": {}, "workflow_path": str(workflow)},
                    model=BONSAI_IMAGE,
                    message="a bonsai tree",
                    out="shot.png",
                    var="image",
                )
        ask.assert_not_called()
        self.assertEqual(result["outputs"]["status"], "proposed")
        self.assertTrue(str(result["inputs"]["out"]).endswith("shot.png"))
        self.assertEqual(result["variables"]["image"], "")

    def test_bonsai_model_gets_a_predict_cache(self) -> None:
        inner = type("Model", (), {})()
        loaded = type("Loaded", (), {"model": inner})()
        hug._ensure_predict_cache(loaded)
        cache = inner.compiled_predict_cache
        hug._ensure_predict_cache(loaded)
        self.assertIs(inner.compiled_predict_cache, cache)

    def test_picture_is_written_with_the_bonsai_sampler(self) -> None:
        seen: dict[str, object] = {}

        class Loaded:
            def generate_outputs(self, **kwargs):
                seen.update(kwargs)
                path = Path(kwargs["output"])
                path.write_bytes(b"png")
                return [type("Saved", (), {"saved_path": path})()]

        destination = Path(tempfile.mkdtemp()) / "bonsai.png"
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        with patch("cg_loop.hug._import_mlxgen", return_value=lambda model: Loaded()):
            text = hug._generate_picture(BONSAI_IMAGE, "a bonsai tree", str(destination), download=False)
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        self.assertEqual(text, str(destination))
        self.assertEqual(seen["prompt"], "a bonsai tree")
        self.assertEqual(seen["output"], str(destination))
        self.assertEqual(seen["width"], 1024)
        self.assertEqual(seen["height"], 1024)
        self.assertEqual(seen["num_inference_steps"], 4)
        self.assertEqual(seen["guidance"], 1.0)
        self.assertEqual(seen["seeds"], [42])
        self.assertTrue(destination.is_file())

    def test_random_seed_is_drawn_and_printed(self) -> None:
        seen: dict[str, object] = {}

        class Loaded:
            def generate_outputs(self, **kwargs):
                seen.update(kwargs)
                path = Path(kwargs["output"])
                path.write_bytes(b"png")
                return [type("Saved", (), {"saved_path": path})()]

        destination = Path(tempfile.mkdtemp()) / "bonsai.png"
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        with patch("cg_loop.hug._import_mlxgen", return_value=lambda model: Loaded()), patch(
            "cg_loop.hug._draw_seed", return_value=99
        ) as draw:
            hug._generate_picture(
                BONSAI_IMAGE,
                "a bonsai tree",
                str(destination),
                download=False,
                extra={"seed": "random"},
            )
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        draw.assert_called_once()
        self.assertEqual(seen["seeds"], [99])

    def test_numbered_seed_is_kept(self) -> None:
        self.assertEqual(hug._resolve_seed("7"), 7)
        self.assertEqual(hug._resolve_seed(7), 7)
        with self.assertRaises(ValueError):
            hug._resolve_seed("warm")

    def test_named_size_snaps_to_the_model_grid(self) -> None:
        self.assertEqual(hug.resolve_image_size("instagram story"), (1088, 1920, "instagram-story"))
        self.assertEqual(hug.resolve_image_size("instagram-story"), (1088, 1920, "instagram-story"))
        self.assertEqual(hug.resolve_image_size("meta ad"), (1088, 1088, "meta-ad"))
        self.assertEqual(hug.resolve_image_size("1080x1920"), (1088, 1920, ""))
        self.assertEqual(hug.resolve_image_size("9:16"), (576, 1024, "9:16"))
        self.assertEqual(hug.resolve_image_size("1024x1024"), (1024, 1024, ""))
        with self.assertRaises(ValueError):
            hug.resolve_image_size("billboard")

    def test_size_sets_the_canvas(self) -> None:
        seen: dict[str, object] = {}

        class Loaded:
            def generate_outputs(self, **kwargs):
                seen.update(kwargs)
                path = Path(kwargs["output"])
                path.write_bytes(b"png")
                return [type("Saved", (), {"saved_path": path})()]

        destination = Path(tempfile.mkdtemp()) / "bonsai.png"
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        with patch("cg_loop.hug._import_mlxgen", return_value=lambda model: Loaded()):
            hug._generate_picture(
                BONSAI_IMAGE,
                "a bonsai tree",
                str(destination),
                download=False,
                extra={"size": "instagram-story", "width": "512"},
            )
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        self.assertEqual(seen["width"], 512)
        self.assertEqual(seen["height"], 1920)

    def test_resident_keeps_the_seed_param(self) -> None:
        from cg_loop import resident

        with patch("cg_loop.resident._touch", return_value=False), patch(
            "cg_loop.hug._generate_picture", return_value="bonsai.png"
        ) as draw:
            resident._hug_command(
                {
                    "model": BONSAI_IMAGE,
                    "message": "a bonsai tree",
                    "out": "bonsai.png",
                    "params": {"seed": "random"},
                }
            )
        self.assertEqual(draw.call_args.kwargs["extra"], {"seed": "random"})

    def test_missing_mlxgen_installs_when_download_is_on(self) -> None:
        calls = {"n": 0}

        def importer():
            calls["n"] += 1
            if calls["n"] == 1:
                raise ImportError("No module named 'mlxgen'")
            return lambda model: "weights"

        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        with patch("cg_loop.hug._generate_weights_ready", return_value=True), patch(
            "cg_loop.hug._import_mlxgen", side_effect=importer
        ), patch("cg_loop.hug._pip_install") as install:
            loaded = hug._ensure_generate_loaded(BONSAI_IMAGE, download=True)
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        self.assertEqual(loaded, "weights")
        self.assertEqual(install.call_args.args[0], "mlx-gen")

    def test_missing_weights_download_the_packed_files(self) -> None:
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        with patch("cg_loop.hug._generate_weights_ready", side_effect=[False, True]), patch(
            "cg_loop.hug._download_generate_weights"
        ) as download, patch("cg_loop.hug._import_mlxgen", return_value=lambda model: "weights"):
            loaded = hug._ensure_generate_loaded(BONSAI_IMAGE, download=True)
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        download.assert_called_once_with(BONSAI_IMAGE)
        self.assertEqual(loaded, "weights")

    def test_download_asks_for_the_packed_safetensors(self) -> None:
        with patch("cg_loop.hug._snapshot_download") as snap:
            hug._download_generate_weights(BONSAI_IMAGE)
        repo_id, patterns = snap.call_args.args
        self.assertEqual(repo_id, BONSAI_IMAGE)
        self.assertIn("transformer-packed-mflux/*.safetensors", patterns)
        self.assertIn("text_encoder-mlx-4bit/*.safetensors", patterns)
        self.assertIn("vae/*.safetensors", patterns)
        self.assertIn("README.md", patterns)
        self.assertIn("LICENSE", patterns)
        self.assertIn("NOTICE.md", patterns)
        self.assertIn("added_tokens.json", patterns)
        self.assertIn("chat_template.jinja", patterns)

    def test_packed_weights_alone_are_not_ready(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            snapshot = (
                Path(tmp)
                / "models--prism-ml--bonsai-image-ternary-4B-mlx-2bit"
                / "snapshots"
                / "rev"
            )
            for name in (
                "transformer-packed-mflux/diffusion_pytorch_model.safetensors",
                "text_encoder-mlx-4bit/model.safetensors",
                "vae/diffusion_pytorch_model.safetensors",
                "tokenizer/added_tokens.json",
                "tokenizer/chat_template.jinja",
            ):
                path = snapshot / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"x")
            with patch("huggingface_hub.constants.HF_HUB_CACHE", tmp):
                self.assertFalse(hug._generate_weights_ready(BONSAI_IMAGE))
                hug._link_generate_sidecars(BONSAI_IMAGE)
                self.assertEqual((snapshot / "added_tokens.json").read_bytes(), b"x")
                self.assertEqual((snapshot / "chat_template.jinja").read_bytes(), b"x")
                self.assertFalse(hug._generate_weights_ready(BONSAI_IMAGE))

    def test_incomplete_cache_still_downloads_before_load(self) -> None:
        calls = {"n": 0}

        def loader(model):
            calls["n"] += 1
            if calls["n"] == 1:
                raise FileNotFoundError(
                    "MLX-Gen will not download model files during generation."
                )
            return "weights"

        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        with patch("cg_loop.hug._generate_weights_ready", return_value=True), patch(
            "cg_loop.hug._import_mlxgen", return_value=loader
        ), patch("cg_loop.hug._download_generate_weights") as download, patch(
            "cg_loop.hug._link_generate_sidecars"
        ), patch("cg_loop.hug._invoke_generate_load", side_effect=lambda load, model, download: load(model)):
            loaded = hug._ensure_generate_loaded(BONSAI_IMAGE, download=True)
        hug._LOADED.pop(("generate", BONSAI_IMAGE), None)
        download.assert_called_once_with(BONSAI_IMAGE)
        self.assertEqual(loaded, "weights")

    def test_compile_passes_out(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-hug.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: hug",
                        "draw_routine:",
                        f"  - /hug +model {BONSAI_IMAGE} +m a bonsai tree "
                        "+out ../data/wf-test/bonsai.png into $image",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["draw_routine"]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            text = created.path.read_text(encoding="utf-8")
        self.assertIn("out='../data/wf-test/bonsai.png'", text)
        self.assertIn("var='image'", text)


SDXL = "ByteDance/SDXL-Lightning"
_SDXL_FILES = [
    "sdxl_lightning_1step_x0.safetensors",
    "sdxl_lightning_2step.safetensors",
    "sdxl_lightning_4step.safetensors",
    "sdxl_lightning_4step_lora.safetensors",
    "sdxl_lightning_4step_unet.safetensors",
    "sdxl_lightning_8step.safetensors",
    "README.md",
    "comfyui/sdxl_lightning_workflow_full.json",
]


class DynamicModelTests(unittest.TestCase):
    def tearDown(self) -> None:
        hug._DETECTED.pop(SDXL, None)
        hug._DETECTED.pop("org/pipeline", None)
        hug._DETECTED.pop("org/vision-repo", None)
        hug._DETECTED.pop("org/several-checkpoints", None)
        reset_app_config()
        hug._LOADED.pop(("diffusers", SDXL, "sdxl_lightning_4step.safetensors"), None)

    def test_checkpoint_repo_is_a_diffusers_generate_model(self) -> None:
        kind, backend = hug._classify_repo(_SDXL_FILES)
        self.assertEqual((kind, backend), ("generate", "diffusers"))
        with self.assertRaises(ValueError) as raised:
            hug._only_checkpoint([name for name in _SDXL_FILES if "/" not in name])
        self.assertIn("more than one checkpoint", str(raised.exception))
        self.assertIn("tool-details", str(raised.exception))

    def test_pipeline_and_vision_and_packed_repos(self) -> None:
        self.assertEqual(
            hug._classify_repo(["model_index.json", "unet/diffusion_pytorch_model.safetensors"]),
            ("generate", "diffusers"),
        )
        self.assertEqual(
            hug._classify_repo(
                ["vae/diffusion_pytorch_model.safetensors", "transformer-packed-mflux/model.safetensors"]
            ),
            ("generate", "mlx-gen"),
        )
        self.assertEqual(
            hug._classify_repo(
                ["config.json", "model.safetensors"],
                {"model_type": "qwen2_vl", "architectures": ["Qwen2VLForConditionalGeneration"]},
            ),
            ("image", "mlx-vlm"),
        )
        self.assertEqual(
            hug._classify_repo(
                ["config.json", "model.safetensors"],
                {"model_type": "llama", "architectures": ["LlamaForCausalLM"]},
            ),
            ("text", "mlx-lm"),
        )

    def test_lora_only_repo_names_the_missing_checkpoint(self) -> None:
        with self.assertRaises(ValueError) as raised:
            hug._only_checkpoint(["sdxl_lightning_4step_lora.safetensors"])
        self.assertIn("full checkpoint", str(raised.exception))

    def test_cached_tree_lists_files_that_are_not_downloaded(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            trees = Path(tmp) / "models--ByteDance--SDXL-Lightning" / "trees"
            trees.mkdir(parents=True)
            (trees / "rev.json").write_text(
                json.dumps({"files": {"sdxl_lightning_4step.safetensors": {}, "README.md": {}}}),
                encoding="utf-8",
            )
            with patch("huggingface_hub.constants.HF_HUB_CACHE", tmp):
                found = hug._cached_tree_files(SDXL)
        self.assertEqual(found, ["sdxl_lightning_4step.safetensors", "README.md"])

    def test_listed_model_uses_the_tool_config(self) -> None:
        reset_app_config()
        with patch.object(hug, "_repo_files", side_effect=AssertionError("repo should not be read")):
            spec = hug.runtime_spec(SDXL)
            plan = hug._diffusers_plan(SDXL, {})
            overridden = hug._diffusers_plan(SDXL, {"steps": "8", "guidance": "1.5"})
        self.assertTrue(spec.declared)
        self.assertEqual(spec.backend, "diffusers")
        self.assertEqual(plan.filename, "sdxl_lightning_4step.safetensors")
        self.assertEqual(plan.steps, 4)
        self.assertEqual(plan.guidance, 0.0)
        self.assertEqual(plan.scheduler, "euler-trailing")
        self.assertEqual(overridden.filename, plan.filename)
        self.assertEqual(overridden.steps, 8)
        self.assertEqual(overridden.guidance, 1.5)

    def test_unlisted_repo_does_not_guess_steps_or_a_checkpoint(self) -> None:
        with patch.object(hug, "_repo_files", return_value=_SDXL_FILES):
            hug._DETECTED.pop("org/several-checkpoints", None)
            spec = hug.runtime_spec("org/several-checkpoints")
            with self.assertRaises(ValueError) as raised:
                hug._diffusers_plan("org/several-checkpoints", {})
        self.assertEqual(spec.kind, "generate")
        self.assertEqual(spec.backend, "diffusers")
        self.assertFalse(spec.declared)
        self.assertIn("file", str(raised.exception))

    def test_diffusers_draw_uses_the_checkpoint_steps_and_writes_the_file(self) -> None:
        seen: dict[str, object] = {}

        class Image:
            def save(self, path: Path) -> None:
                Path(path).write_bytes(b"png")

        class Pipe:
            def __call__(self) -> object:
                return type("Result", (), {"images": [Image()]})()

        def call(pipe, prompt, plan, extra):
            seen["prompt"] = prompt
            seen["steps"] = plan.steps
            seen["guidance"] = plan.guidance
            seen["seed"] = extra.get("seed")
            seen["filename"] = plan.filename
            seen["scheduler"] = plan.scheduler
            return pipe()

        destination = Path(tempfile.mkdtemp()) / "lightning.png"
        with patch.object(hug, "_repo_files", return_value=_SDXL_FILES), patch.object(
            hug, "_load_diffusers_pipeline", return_value=Pipe()
        ), patch.object(hug, "_call_diffusers", call):
            written = hug._generate_picture(
                SDXL,
                "a bunker",
                str(destination),
                download=False,
                extra={"seed": "3"},
            )
        self.assertEqual(written, str(destination))
        self.assertEqual(destination.read_bytes(), b"png")
        self.assertEqual(seen["filename"], "sdxl_lightning_4step.safetensors")
        self.assertEqual(seen["steps"], 4)
        self.assertEqual(seen["guidance"], 0.0)
        self.assertEqual(seen["scheduler"], "euler-trailing")
        self.assertEqual(seen["prompt"], "a bunker")
        self.assertEqual(seen["seed"], "3")

    def test_run_hug_passes_out_for_an_unlisted_image_repo(self) -> None:
        seen: dict[str, str] = {}

        def reply(_model, _message, _files, *, out="", download=True, extra=None):
            seen["out"] = out
            return out

        with patch.object(hug, "_repo_files", return_value=_SDXL_FILES), patch.object(hug, "ask_hug", reply):
            result = run_hug(
                {"env": {}, "variables": {}},
                model=SDXL,
                message="a bunker",
                out="/tmp/compare-lightning.png",
                var="image",
            )
        self.assertFalse(result.get("blocked"))
        self.assertEqual(seen["out"], str(Path("/tmp/compare-lightning.png").resolve()))
        self.assertEqual(result["variables"]["image"], seen["out"])


if __name__ == "__main__":
    unittest.main()
