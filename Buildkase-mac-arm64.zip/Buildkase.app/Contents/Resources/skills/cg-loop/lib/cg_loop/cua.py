"""Drive a native app with Cua and click a label the perception engine reads.

`/cua +launch Chrome https://example.com` opens the app.
`/cua +click "Learn more"` captures that window, parses visual regions, and
clicks the region whose text contains the label. When no region contains it,
LocateAnything reads the same screenshot and the click uses that box.
The boxed screenshot is written beside the step log, the same way `/locate` does.
Capture and click stay on one driver session so the capture id is still valid.

Chrome is launched by bundle id. Any other name is passed to launch_app.
"""

from __future__ import annotations

import atexit
import json
import os
import queue
import re
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

_BUNDLES = {
    "chrome": "com.google.Chrome",
    "google chrome": "com.google.Chrome",
    "safari": "com.apple.Safari",
    "finder": "com.apple.finder",
}
_DRIVER: "McpCuaDriver | None" = None


def _program_name(command: list[str]) -> str:
    if not command:
        return ""
    return Path(command[0]).name


def _configured_program(env_key: str, default: str) -> str:
    raw = (os.environ.get(env_key) or "").strip()
    return raw or default


def local_driver_command() -> list[str]:
    """Local desktop driver. CG_LOOP_CUA_DRIVER replaces the program on PATH."""
    return [_configured_program("CG_LOOP_CUA_DRIVER", "cua-driver"), "mcp"]


def space_driver_command() -> list[str]:
    """Cua Space CLI. CG_LOOP_CUA replaces the program on PATH."""
    return [_configured_program("CG_LOOP_CUA", "cua"), "mcp"]


@dataclass
class WindowState:
    capture_id: str
    pid: int
    window_id: int
    image: str = ""


class LocateMiss(LookupError):
    """The label was not found. `screenshots` are the shots already written."""

    def __init__(self, message: str, screenshots: list[str] | None = None) -> None:
        super().__init__(message)
        self.screenshots = [item for item in (screenshots or []) if item]


class ClickVerifyMiss(RuntimeError):
    """The saved click point no longer matches the screen. Compile locates it again."""

    def __init__(self, message: str, screenshots: list[str] | None = None) -> None:
        super().__init__(message)
        self.screenshots = [item for item in (screenshots or []) if item]


@dataclass
class Region:
    id: str
    type: str
    text: str
    bounds: dict[str, float]

    def center(self) -> tuple[float, float]:
        """Center of a half-open screenshot rectangle."""
        if "x2" in self.bounds:
            return (
                (float(self.bounds["x1"]) + float(self.bounds["x2"])) / 2,
                (float(self.bounds["y1"]) + float(self.bounds["y2"])) / 2,
            )
        return (
            float(self.bounds["x"]) + float(self.bounds["width"]) / 2,
            float(self.bounds["y"]) + float(self.bounds["height"]) / 2,
        )


class McpCuaDriver:
    """One line-delimited MCP session. Later calls share its capture registry.

    `local` starts `cua-driver mcp` and drives this machine.
    `space` starts `cua mcp` and sends each driver call into that Space.
    """

    def __init__(self, command: list[str] | None = None, session: str = "") -> None:
        self.command = command or local_driver_command()
        self.session = session or session_label()
        self._session_ready = False
        self.space = ""
        self.space_url = ""
        self.space_token = ""
        self.space_name = ""
        self.last_pid = 0
        self.last_window_id = 0
        self.last_app = ""
        self.last_x: float | None = None
        self.last_y: float | None = None
        self._proc: subprocess.Popen[str] | None = None
        self._lines: queue.Queue[str] = queue.Queue()
        self._stderr: list[str] = []
        self._id = 0
        self._ready = False
        self._space_ready = False
        self._announced = False
        self._lock = threading.Lock()
        self._regions: dict[str, dict[str, Region]] = {}
        self._targets: dict[str, dict[str, int]] = {}

    @classmethod
    def from_target(cls, target: dict[str, str]) -> "McpCuaDriver":
        session = target.get("session") or ""
        if target.get("mode") == "space":
            driver = cls(command=space_driver_command(), session=session)
            driver.space = target.get("space") or ""
            driver.space_url = target.get("url") or ""
            driver.space_token = target.get("token") or ""
            driver.space_name = target.get("space") or ""
            return driver
        return cls(command=local_driver_command(), session=session)

    def same_target(self, target: dict[str, str]) -> bool:
        if self.session != (target.get("session") or ""):
            return False
        if target.get("mode") == "space":
            return (
                _program_name(self.command) == "cua"
                and self.space == (target.get("space") or "")
                and self.space_url == (target.get("url") or "")
                and self.space_token == (target.get("token") or "")
            )
        return _program_name(self.command) == "cua-driver" and not self.space and not self.space_url

    def close(self) -> None:
        """End this run's session, then stop the MCP process."""
        if self._session_ready:
            self._session_ready = False
            try:
                self._end_session()
            except Exception:
                pass
        proc = self._proc
        self._proc = None
        self._ready = False
        if proc is None or proc.poll() is not None:
            return
        if proc.stdin is not None:
            proc.stdin.close()
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()

    def launch(self, app: str, url: str = "") -> dict[str, Any]:
        """Launch `app`. A following click uses this window when no app is named."""
        name = (app or "").strip()
        if not name:
            raise ValueError("cua launch needs an app name")
        args: dict[str, Any] = {}
        bundle = _BUNDLES.get(name.lower())
        if bundle:
            args["bundle_id"] = bundle
        else:
            args["name"] = name
        if url:
            args["urls"] = [url]
            if bundle == "com.google.Chrome":
                args["additional_arguments"] = ["--new-window"]
        payload = self._driver_tool("launch_app", args)
        chosen = _best_window(_windows(payload))
        pid = int((chosen or {}).get("pid") or payload.get("pid") or 0)
        if not chosen and pid:
            chosen = self._wait_window(pid, name)
        if url and pid:
            chosen = self._window_showing_url(pid, chosen or {}, url) or chosen
            pid = int((chosen or {}).get("pid") or pid)
        window_id = int((chosen or {}).get("window_id") or 0)
        if not window_id:
            raise RuntimeError(f"{name} launched but no window appeared")
        self.last_app = name
        self.last_pid = pid
        self.last_window_id = window_id
        text = f"launch {name} pid={pid} window={window_id}"
        return {
            "status": "ok",
            "app": name,
            "pid": pid,
            "window_id": window_id,
            "url": url,
            "text": text,
        }

    def target_window(self, app: str = "") -> dict[str, int]:
        """The launched window, or the best window whose app name matches."""
        name = (app or "").strip()
        if not name and self.last_pid and self.last_window_id:
            return {"pid": self.last_pid, "window_id": self.last_window_id}
        payload = self._driver_tool("list_windows", {})
        windows = _windows(payload)
        matched = [item for item in windows if _app_match(item, name)] if name else windows
        chosen = _best_window(matched)
        if not chosen:
            label = name or "the screen"
            raise RuntimeError(f"no window for {label}")
        return {"pid": int(chosen["pid"]), "window_id": int(chosen["window_id"])}

    def get_window_state(self, pid: int | None = None, window_id: int | None = None) -> WindowState:
        """Capture one window. The returned capture id is required for a later click."""
        target_pid = int(pid or self.last_pid)
        target_window = int(window_id or self.last_window_id)
        if not target_pid or not target_window:
            raise RuntimeError("get_window_state needs a pid and window_id")
        shot = Path(os.environ.get("TMPDIR") or "/tmp") / "cg-loop-cua" / f"{target_pid}-{target_window}.png"
        shot.parent.mkdir(parents=True, exist_ok=True)
        payload = self._driver_tool(
            "get_window_state",
            {
                "pid": target_pid,
                "window_id": target_window,
                "include_accessibility_tree": False,
                "max_image_dimension": 0,
                "timeout_ms": 5000,
                "screenshot_out_file": str(shot),
            },
            timeout=30,
        )
        capture_id = _capture_id(payload)
        if not capture_id:
            raise RuntimeError("get_window_state returned no capture_id")
        self._targets[capture_id] = {"pid": target_pid, "window_id": target_window}
        return WindowState(
            capture_id=capture_id,
            pid=target_pid,
            window_id=target_window,
            image=str(shot),
        )

    def parse_visual_regions(self, capture_id: str, options: dict[str, Any] | None = None) -> list[Region]:
        """Read text and icon regions from one capture."""
        payload = self._driver_tool(
            "parse_visual_regions",
            {
                "capture_id": capture_id,
                "options": options
                or {"kinds": ["text", "icon"], "min_confidence": 0.4, "max_regions": 100},
            },
            timeout=120,
        )
        regions = regions_from(payload)
        self._regions[capture_id] = {region.id: region for region in regions}
        return regions

    def find_elements(self, pid: int, window_id: int, query: str) -> list[dict[str, Any]]:
        """Accessibility rows whose label matches `query`."""
        payload = self._driver_tool(
            "get_window_state",
            {
                "pid": pid,
                "window_id": window_id,
                "include_screenshot": False,
                "query": query,
                "timeout_ms": 5000,
            },
            timeout=30,
        )
        elements = payload.get("elements")
        if isinstance(elements, list):
            return [item for item in elements if isinstance(item, dict)]
        return []

    def click_element(self, pid: int, window_id: int, element_token: str) -> dict[str, Any]:
        """Click one accessibility element. This does not need a screenshot capture."""
        self._driver_tool(
            "click",
            {
                "pid": pid,
                "window_id": window_id,
                "element_token": element_token,
                "delivery_mode": "background",
            },
        )
        return {"status": "ok", "element_token": element_token, "pid": pid, "window_id": window_id}

    def click_region(self, capture_id: str, region_id: str, strategy: str = "background_first") -> dict[str, Any]:
        """Click the center of a region from this capture. Background delivery first."""
        region = self._regions.get(capture_id, {}).get(region_id)
        if region is None:
            raise RuntimeError(f"unknown region {region_id}")
        target = self._targets.get(capture_id)
        if not target:
            raise RuntimeError(f"unknown capture {capture_id}")
        x, y = region.center()
        self.last_x = float(x)
        self.last_y = float(y)
        delivery = "background" if strategy in {"background_first", "background"} else "foreground"
        self._driver_tool(
            "click",
            {
                "pid": target["pid"],
                "window_id": target["window_id"],
                "x": x,
                "y": y,
                "capture_id": capture_id,
                "delivery_mode": delivery,
                "target": {
                    "kind": "window",
                    "pid": target["pid"],
                    "window_id": target["window_id"],
                },
            },
        )
        return {
            "status": "ok",
            "region_id": region_id,
            "capture_id": capture_id,
            "x": x,
            "y": y,
            "text": region.text,
        }

    def click_point(self, capture_id: str, x: float, y: float) -> dict[str, Any]:
        """Click one point on the capture LocateAnything or a region resolved."""
        target = self._targets.get(capture_id)
        if not target:
            raise RuntimeError(f"unknown capture {capture_id}")
        self.last_x = float(x)
        self.last_y = float(y)
        point = {
            "pid": target["pid"],
            "window_id": target["window_id"],
            "x": float(x),
            "y": float(y),
            "capture_id": capture_id,
            "delivery_mode": "background",
            "target": {
                "kind": "window",
                "pid": target["pid"],
                "window_id": target["window_id"],
            },
        }
        try:
            self._driver_tool("click", point)
        except RuntimeError as exc:
            if "invalid_action_target" not in str(exc):
                raise
            print("CUA capture refused; clicking the point on the window", flush=True)
            self._driver_tool(
                "click",
                {
                    "pid": target["pid"],
                    "window_id": target["window_id"],
                    "x": float(x),
                    "y": float(y),
                    "delivery_mode": "background",
                },
            )
        return {"status": "ok", "capture_id": capture_id, "x": float(x), "y": float(y)}

    def click_window_point(self, pid: int, window_id: int, x: float, y: float) -> dict[str, Any]:
        """Click a saved point on this window. No capture id and no nested target."""
        self.last_x = float(x)
        self.last_y = float(y)
        self._driver_tool(
            "click",
            {
                "pid": int(pid),
                "window_id": int(window_id),
                "x": float(x),
                "y": float(y),
                "delivery_mode": "background",
            },
        )
        return {"status": "ok", "x": float(x), "y": float(y)}

    def _window_showing_url(self, pid: int, fallback: dict[str, Any], url: str) -> dict[str, Any]:
        """The window whose title is the launched page, not whichever window was already in front."""
        marks = _url_marks(url)
        if not marks:
            return fallback
        window_id = int(fallback.get("window_id") or 0)
        activated = False
        for attempt in range(6):
            windows = _windows(self._driver_tool("list_windows", {"pid": pid}))
            matched = [item for item in windows if _title_has(item, marks)]
            if matched:
                chosen = _best_window(matched)
                title = str(chosen.get("title") or "").strip()
                from .trace import detail

                detail(f"CUA url window {chosen.get('window_id')} {title}".rstrip())
                return chosen
            if attempt == 0 and window_id and not activated:
                activated = self._activate_url_tab(pid, window_id, marks)
                if activated:
                    time.sleep(0.4)
                    continue
            if not any(_loading_title(item.get("title")) for item in windows):
                break
            time.sleep(0.3)
        return fallback

    def _activate_url_tab(self, pid: int, window_id: int, marks: tuple[str, ...]) -> bool:
        """Select the tab whose label names the launched site. Menu rows are left alone."""
        try:
            elements = self.find_elements(pid, window_id, marks[0])
        except Exception:
            return False
        tab = _match_tab(elements, marks)
        if tab is None:
            return False
        label = str(tab.get("label") or tab.get("title") or marks[0])
        print(f"CUA show tab {label}", flush=True)
        self.click_element(pid, window_id, str(tab["element_token"]))
        return True

    def _wait_window(self, pid: int, app: str) -> dict[str, Any]:
        for _ in range(10):
            time.sleep(0.4)
            payload = self._driver_tool("list_windows", {"pid": pid} if pid else {})
            windows = _windows(payload)
            matched = [item for item in windows if _app_match(item, app)] or windows
            chosen = _best_window(matched)
            if chosen:
                return chosen
        return {}

    def _driver_tool(self, name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
        """Call a driver tool here, or forward it into the configured Space."""
        self._announce()
        self._begin_session()
        if not self.space and not self.space_url:
            return self._tool(name, arguments, timeout=timeout)
        self._ensure_space()
        inner = dict(arguments)
        inner.setdefault("session", self.session)
        return self._tool(
            "call_tool",
            {
                "space": self.space,
                "service": "driver",
                "tool": name,
                "arguments": inner,
            },
            timeout=timeout,
        )

    def _announce(self) -> None:
        if self._announced:
            return
        self._announced = True
        from .trace import detail

        if self.space or self.space_url:
            where = self.space or self.space_url
            detail(f"CUA target space {where} session {self.session}")
            return
        detail(f"CUA target local session {self.session}")

    def _begin_session(self) -> None:
        """Open the workflow session. An existing one is closed first."""
        if self._session_ready:
            return
        if self.space or self.space_url:
            self._ensure_space()
        if self._session_exists():
            from .trace import detail

            detail(f"CUA close session {self.session}")
            try:
                self._end_session()
            except Exception as exc:
                print(f"CUA close session {self.session}: {exc}", flush=True)
        try:
            self._session_tool("start_session")
        except RuntimeError as exc:
            if not _session_unavailable(exc):
                raise
            from .trace import detail

            detail(f"CUA close session {self.session}")
            try:
                self._end_session()
            except Exception:
                pass
            self._session_tool("start_session")
        self._session_ready = True

    def _session_exists(self) -> bool:
        try:
            payload = self._session_tool("get_session")
        except Exception as exc:
            text = str(exc).lower()
            return _session_unavailable(exc) or "has ended" in text
        return _session_present(payload, self.session)

    def _session_tool(self, name: str) -> dict[str, Any]:
        arguments: dict[str, Any] = {}
        if self.session:
            arguments["session"] = self.session
        if self.space or self.space_url:
            return self._tool(
                "call_tool",
                {
                    "space": self.space,
                    "service": "driver",
                    "tool": name,
                    "arguments": arguments,
                },
            )
        return self._tool(name, arguments)

    def _end_session(self) -> None:
        self._session_tool("end_session")

    def _ensure_space(self) -> None:
        if self._space_ready:
            return
        if not self.space and not self.space_url:
            raise RuntimeError("cua: space needs cua-space or cua-url")
        if self.space_url:
            args: dict[str, Any] = {"url": self.space_url}
            if self.space_token:
                args["token"] = self.space_token
            if self.space_name:
                args["name"] = self.space_name
            payload = self._tool("add_space", args)
            found = _space_id(payload)
            if found:
                self.space = found
            elif not self.space:
                self.space = self.space_name or self.space_url
        self._space_ready = True

    def _uses_cli(self) -> bool:
        """Local runs share one named session. A private MCP connection cannot reopen it."""
        return _program_name(self.command) == "cua-driver" and not self.space and not self.space_url

    def _tool(self, name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
        payload = dict(arguments)
        if self.session and name not in {"call_tool", "add_space"}:
            payload.setdefault("session", self.session)
        if self._uses_cli():
            return self._cli_tool(name, payload, timeout)
        result = self._request("tools/call", {"name": name, "arguments": payload}, timeout=timeout)
        if result.get("isError"):
            raise RuntimeError(_error_text(result) or f"{name} failed")
        structured = result.get("structuredContent")
        if isinstance(structured, dict):
            return structured
        parsed = _json_text(result)
        if isinstance(parsed, dict):
            return parsed
        return result if isinstance(result, dict) else {}

    def _cli_tool(self, name: str, payload: dict[str, Any], timeout: float) -> dict[str, Any]:
        """One daemon call in the shared CLI session named for this workflow."""
        proc = subprocess.run(
            [self.command[0], name, json.dumps(payload)],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        text = (proc.stdout or "").strip()
        data: Any = None
        if text[:1] in {"{", "["}:
            try:
                data = json.loads(text)
            except json.JSONDecodeError:
                data = None
        if proc.returncode != 0 or (isinstance(data, dict) and data.get("code")):
            message = ""
            if isinstance(data, dict):
                message = str(data.get("message") or data.get("detail") or data.get("code") or "")
            raise RuntimeError(message or text or (proc.stderr or "").strip() or f"{name} failed")
        if isinstance(data, dict):
            return data
        if text:
            raise RuntimeError(text)
        return {}

    def _request(self, method: str, params: dict[str, Any], timeout: float) -> dict[str, Any]:
        with self._lock:
            self._ensure()
            self._id += 1
            rpc_id = self._id
            self._send({"jsonrpc": "2.0", "id": rpc_id, "method": method, "params": params})
            message = self._read_id(rpc_id, timeout)
        if "error" in message:
            raise RuntimeError(_error_text(message["error"]) or f"{method} failed")
        result = message.get("result")
        return result if isinstance(result, dict) else {}

    def _ensure(self) -> None:
        if self._ready and self._proc is not None and self._proc.poll() is None:
            return
        try:
            self._proc = subprocess.Popen(
                self.command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
            )
        except FileNotFoundError as exc:
            binary = self.command[0] if self.command else "cua-driver"
            raise RuntimeError(f"{binary} is not installed") from exc
        threading.Thread(target=self._read_stdout, daemon=True).start()
        threading.Thread(target=self._read_stderr, daemon=True).start()
        self._id += 1
        rpc_id = self._id
        self._send(
            {
                "jsonrpc": "2.0",
                "id": rpc_id,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "cg-loop", "version": "0.1"},
                },
            }
        )
        self._read_id(rpc_id, 20)
        self._send({"jsonrpc": "2.0", "method": "notifications/initialized"})
        self._ready = True

    def _send(self, message: dict[str, Any]) -> None:
        proc = self._proc
        if proc is None or proc.stdin is None:
            raise RuntimeError("cua-driver mcp is not running")
        proc.stdin.write(json.dumps(message) + "\n")
        proc.stdin.flush()

    def _read_id(self, rpc_id: int, timeout: float) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            remaining = max(0.1, deadline - time.monotonic())
            try:
                line = self._lines.get(timeout=min(0.5, remaining))
            except queue.Empty:
                if self._proc is not None and self._proc.poll() is not None:
                    detail = " ".join(self._stderr[-3:]).strip()
                    raise RuntimeError(detail or "cua-driver mcp exited")
                continue
            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(message, dict) and message.get("id") == rpc_id:
                return message
        detail = " ".join(self._stderr[-3:]).strip()
        raise RuntimeError(detail or "cua-driver mcp timed out")

    def _read_stdout(self) -> None:
        proc = self._proc
        if proc is None or proc.stdout is None:
            return
        for line in proc.stdout:
            self._lines.put(line)

    def _read_stderr(self) -> None:
        proc = self._proc
        if proc is None or proc.stderr is None:
            return
        for line in proc.stderr:
            self._stderr.append(line.strip())
            del self._stderr[:-8]


def cua_target(env: dict[str, Any] | None = None) -> dict[str, str]:
    """`local` is this machine. `space` is a Cua Space named by CUA_SPACE or CUA_URL."""
    merged = {**os.environ, **(env or {})}
    mode = str(merged.get("CUA") or merged.get("cua") or "local").strip().lower()
    if mode in {"local", "host", "this"}:
        mode = "local"
    elif mode in {"space", "sandbox"}:
        mode = "space"
    else:
        raise ValueError(f"cua must be local or space, got {mode}")
    return {
        "mode": mode,
        "space": str(merged.get("CUA_SPACE") or merged.get("cua-space") or "").strip(),
        "url": str(merged.get("CUA_URL") or merged.get("cua-url") or "").strip(),
        "token": str(merged.get("CUA_TOKEN") or merged.get("cua-token") or "").strip(),
    }


def close_driver() -> None:
    """End the session this process opened."""
    global _DRIVER
    driver = _DRIVER
    _DRIVER = None
    if driver is not None:
        driver.close()


def open_driver(env: dict[str, Any] | None = None) -> McpCuaDriver:
    """The driver for this process. One run keeps the same local or Space session."""
    global _DRIVER
    atexit.register(close_driver)
    target = cua_target(env)
    target["session"] = session_label(env)
    if target["mode"] == "space" and not target["space"] and not target["url"]:
        raise RuntimeError("cua: space needs cua-space or cua-url")
    if _DRIVER is not None and _DRIVER.same_target(target):
        return _DRIVER
    if _DRIVER is not None:
        _DRIVER.close()
    _DRIVER = McpCuaDriver.from_target(target)
    return _DRIVER


def resolve_click_point(
    driver: Any,
    target_text_label: str,
    app: str = "",
    env: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Find `target_text_label` and return its point. Does not click.

    Text regions are first. When none contain the label, LocateAnything reads
    the same screenshot. The compiled click saves this point and tries it first.
    """
    window = driver.target_window(app)
    window_state = driver.get_window_state(pid=window["pid"], window_id=window["window_id"])
    capture_id = window_state.capture_id
    image = str(getattr(window_state, "image", "") or "")
    try:
        regions = driver.parse_visual_regions(capture_id=capture_id)
    except Exception as exc:
        if not _perception_missing(exc):
            raise
        print("CUA perception is not installed; LocateAnything", flush=True)
        if not image or not Path(image).is_file():
            raise
        point = _locate_point(target_text_label, image, env)
    else:
        target_region_id = _match_region(regions, target_text_label)
        if not target_region_id:
            print(f"CUA no text region for {target_text_label!r}; LocateAnything", flush=True)
            point = _locate_point(target_text_label, image, env)
        else:
            matched = next(region for region in regions if region.id == target_region_id)
            box = _region_box(matched)
            x, y = matched.center()
            shots = _boxed_shot(image, box, env)
            point = {
                "x": float(x),
                "y": float(y),
                "box": box,
                "image": image,
                "screenshots": shots,
                "method": "region",
                "label": target_text_label,
                "text": f"click {target_text_label} region={target_region_id} x={int(x)} y={int(y)}",
            }
    width, height = _image_size(str(point.get("image") or image))
    point["width"] = width
    point["height"] = height
    point["label"] = target_text_label
    return point


def compile_click_location(
    label: str,
    app: str = "",
    env: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Locate the click once, while the step is compiling."""
    driver = open_driver(env)
    point = resolve_click_point(driver, label, app, env)
    print(
        f"CUA compile click {label} {point.get('method') or 'locate'} "
        f"x={int(float(point['x']))} y={int(float(point['y']))}",
        flush=True,
    )
    return point


def replay_cua_click(ctx: dict[str, Any], script: Path) -> dict[str, Any]:
    """Run the saved click before perception or LocateAnything.

    A matching crop keeps that click. When the crop does not match, the saved
    click has already run, and the step then finds the control again and
    remembers the new point.
    """
    from .browser_helper import compile_crop_path, compiled_json_path

    saved = json.loads(compiled_json_path(script).read_text(encoding="utf-8"))
    label = str(saved.get("label") or "")
    app = str(saved.get("app") or "")
    inputs = {"action": "click", "label": label, "x": saved.get("x"), "y": saved.get("y")}
    if ctx.get("dry_run"):
        print(f"DRY-RUN CUA click {label} at {saved.get('x')},{saved.get('y')}")
        found = {"status": "proposed", "text": f"click {label}", **inputs}
        return {"inputs": inputs, "outputs": {"status": "proposed", "cua": found}}
    env = {**os.environ, **(ctx.get("env") or {})}
    driver = open_driver(env)
    window = driver.target_window(app)
    if saved.get("x") is not None and saved.get("y") is not None:
        state = driver.get_window_state(pid=window["pid"], window_id=window["window_id"])
        image = str(getattr(state, "image", "") or "")
        width, height = _image_size(image)
        scaled = _scaled_point(saved, width, height)
        x = float(scaled["x"])
        y = float(scaled["y"])
        from .trace import detail

        detail(f"CUA cached click {label} x={int(x)} y={int(y)}")
        try:
            clicked = driver.click_window_point(window["pid"], window["window_id"], x, y)
        except Exception as exc:
            print(f"CUA cached click failed: {exc}", flush=True)
        else:
            crop = compile_crop_path(script)
            ok, reason = saved_location_matches({**saved, **scaled}, image, crop)
            if ok:
                detail(f"CUA verify saved location {label}")
                if scaled["x"] != saved.get("x") or scaled["y"] != saved.get("y") or scaled["width"] != saved.get("width"):
                    _remember_click(script, saved, {**scaled, "method": saved.get("method") or "saved"}, image)
                return _click_result(
                    inputs,
                    clicked,
                    image,
                    scaled.get("box"),
                    env,
                    label,
                    f"click {label} saved x={int(x)} y={int(y)}",
                    echo=False,
                )
            print(f"CUA cached click did not verify: {reason}", flush=True)
    print(f"CUA cached click missed; perception {label}", flush=True)
    try:
        point = resolve_click_point(driver, label, app, env)
    except Exception as exc:
        shots = [str(item) for item in (getattr(exc, "screenshots", None) or []) if item]
        raise ClickVerifyMiss(f"verify failed for saved click {label}: {exc}", shots) from exc
    x = float(point["x"])
    y = float(point["y"])
    clicked = driver.click_window_point(window["pid"], window["window_id"], x, y)
    _remember_click(script, saved, point, str(point.get("image") or ""))
    text = f"click {label} {point.get('method') or 'locate'} x={int(x)} y={int(y)}"
    return _click_result(inputs, clicked, str(point.get("image") or ""), point.get("box"), env, label, text, list(point.get("screenshots") or []))


def _scaled_point(saved: dict[str, Any], width: int, height: int) -> dict[str, Any]:
    """Map a saved point onto the current screenshot when the window size changed."""
    x = float(saved["x"])
    y = float(saved["y"])
    box = dict(saved["box"]) if isinstance(saved.get("box"), dict) else {}
    saved_width = int(saved.get("width") or 0)
    saved_height = int(saved.get("height") or 0)
    if saved_width and saved_height and width and height and (saved_width != width or saved_height != height):
        scale_x = width / saved_width
        scale_y = height / saved_height
        x *= scale_x
        y *= scale_y
        if box:
            box = {
                "x1": int(float(box["x1"]) * scale_x),
                "y1": int(float(box["y1"]) * scale_y),
                "x2": int(float(box["x2"]) * scale_x),
                "y2": int(float(box["y2"]) * scale_y),
            }
    return {"x": x, "y": y, "box": box, "width": width or saved_width, "height": height or saved_height}


def _remember_click(script: Path, saved: dict[str, Any], point: dict[str, Any], image: str) -> None:
    """Store the point that worked so the next run clicks it first."""
    from .browser_helper import compile_crop_path, compiled_json_path

    updated = dict(saved)
    updated["x"] = point.get("x")
    updated["y"] = point.get("y")
    updated["width"] = point.get("width") or 0
    updated["height"] = point.get("height") or 0
    updated["box"] = point.get("box") or {}
    if point.get("method"):
        updated["method"] = point["method"]
    path = compiled_json_path(script)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(updated, indent=2) + "\n", encoding="utf-8")
    box = updated["box"] if isinstance(updated["box"], dict) else {}
    if image and box:
        save_click_crop(image, box, compile_crop_path(script))


def _click_result(
    inputs: dict[str, Any],
    clicked: dict[str, Any],
    image: str,
    box: Any,
    env: dict[str, Any],
    label: str,
    text: str,
    screenshots: list[str] | None = None,
    *,
    echo: bool = True,
) -> dict[str, Any]:
    shots = [str(item) for item in (screenshots or []) if item]
    if not shots and isinstance(box, dict) and box and image:
        shots = _boxed_shot(image, {key: int(box[key]) for key in ("x1", "y1", "x2", "y2")}, env)
    clicked["screenshots"] = shots
    clicked["label"] = label
    clicked["grounding"] = "saved" if "saved" in text else str(clicked.get("grounding") or "")
    clicked["text"] = text
    if echo:
        print(f"CUA {text}", flush=True)
    else:
        from .trace import detail

        detail(f"CUA {text}")
    outputs: dict[str, Any] = {"status": "ok", "cua": clicked}
    if shots:
        outputs["screenshots"] = shots
    return {"inputs": inputs, "outputs": outputs}


def saved_location_matches(saved: dict[str, Any], image: str, crop: Path) -> tuple[bool, str]:
    """The saved box still shows the control that was located."""
    if not image or not Path(image).is_file():
        return False, "no screenshot"
    if not crop.is_file():
        return False, "saved crop is missing"
    box = saved.get("box") if isinstance(saved.get("box"), dict) else None
    if not box:
        return False, "saved box is missing"
    from PIL import Image, ImageChops, ImageStat

    with Image.open(image) as current:
        current = current.convert("RGB")
        width = int(saved.get("width") or 0)
        height = int(saved.get("height") or 0)
        if width and abs(current.width - width) > max(12, int(width * 0.03)):
            return False, f"window width {current.width} != {width}"
        if height and abs(current.height - height) > max(12, int(height * 0.03)):
            return False, f"window height {current.height} != {height}"
        piece = current.crop(_clamp_box(box, current.width, current.height))
    with Image.open(crop) as remembered:
        remembered = remembered.convert("RGB")
    if piece.size != remembered.size:
        piece = piece.resize(remembered.size)
    diff = ImageChops.difference(piece, remembered)
    mean = sum(ImageStat.Stat(diff).mean) / 3
    if mean > 36:
        return False, f"saved location changed ({mean:.0f})"
    return True, ""


def save_click_crop(image: str, box: dict[str, Any], dest: Path) -> None:
    """Keep the located control so a later run can verify the same spot."""
    from PIL import Image

    dest.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(image) as picture:
        picture.convert("RGB").crop(_clamp_box(box, picture.width, picture.height)).save(dest)


def _clamp_box(box: dict[str, Any], width: int, height: int) -> tuple[int, int, int, int]:
    x1 = max(0, min(width - 1, int(float(box["x1"]))))
    y1 = max(0, min(height - 1, int(float(box["y1"]))))
    x2 = max(x1 + 1, min(width, int(float(box["x2"]))))
    y2 = max(y1 + 1, min(height, int(float(box["y2"]))))
    return x1, y1, x2, y2


def _image_size(path: str) -> tuple[int, int]:
    if not path or not Path(path).is_file():
        return 0, 0
    from PIL import Image

    with Image.open(path) as picture:
        return picture.size


def perception_fallback_click(
    driver: Any,
    target_text_label: str,
    app: str = "",
    env: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Find `target_text_label` in the current window and click it.

    Visual regions are the first match. When none contain the label, LocateAnything
    reads that screenshot and the click uses its box. Accessibility is used only
    when the perception extension is not installed.
    """
    window = driver.target_window(app)
    window_state = driver.get_window_state(pid=window["pid"], window_id=window["window_id"])
    capture_id = window_state.capture_id
    image = str(getattr(window_state, "image", "") or "")
    try:
        regions = driver.parse_visual_regions(capture_id=capture_id)
    except Exception as exc:
        if not _perception_missing(exc):
            raise
        print("CUA perception is not installed; clicking the accessibility label", flush=True)
        try:
            return accessibility_click(driver, target_text_label, window)
        except LookupError:
            if not image or not Path(image).is_file():
                raise
            return _click_locateanything(driver, target_text_label, capture_id, image, env)
    target_region_id = _match_region(regions, target_text_label)
    if not target_region_id:
        print(f"CUA no text region for {target_text_label!r}; LocateAnything", flush=True)
        return _click_locateanything(driver, target_text_label, capture_id, image, env)
    print(f"Found visual region match: {target_region_id}. Injecting click...", flush=True)
    clicked = driver.click_region(
        capture_id=capture_id,
        region_id=target_region_id,
        strategy="background_first",
    )
    matched = next(region for region in regions if region.id == target_region_id)
    shots = _boxed_shot(image, _region_box(matched), env)
    if shots:
        clicked["screenshots"] = shots
    clicked["label"] = target_text_label
    clicked["text"] = f"click {target_text_label} region={target_region_id}"
    return clicked


def accessibility_click(driver: Any, label: str, window: dict[str, int]) -> dict[str, Any]:
    """Click the accessibility row whose label contains `label`."""
    elements = driver.find_elements(pid=window["pid"], window_id=window["window_id"], query=label)
    match = _match_element(elements, label)
    if match is None:
        message = f"Could not locate '{label}' in the accessibility tree."
        print(message, flush=True)
        raise LookupError(message)
    shown = str(match.get("label") or match.get("value") or label)
    print(f"Found accessibility match: {shown}. Injecting click...", flush=True)
    clicked = driver.click_element(
        pid=window["pid"],
        window_id=window["window_id"],
        element_token=str(match["element_token"]),
    )
    clicked["label"] = label
    clicked["text"] = f"click {label} element={match.get('element_token')}"
    return clicked


def perform(
    action: str,
    *,
    app: str = "",
    url: str = "",
    label: str = "",
    text: str = "",
    env: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run one `/cua` action on the shared driver."""
    if action == "wait":
        return wait_action(text or label)
    driver = open_driver(env)
    if action == "launch":
        return driver.launch(app, url)
    if action == "click":
        if not label:
            raise ValueError("cua click needs a label")
        return perception_fallback_click(driver, label, app, env)
    if action == "type":
        if not text:
            raise ValueError("cua type needs text")
        return type_into(driver, text, label, app, env)
    if action == "sendkeys":
        return send_keys(driver, text, clear=label == "clear", app=app)
    if action == "press":
        return press_key(driver, text or label, app)
    raise ValueError(f"unknown cua action {action}")


_WAIT_AMOUNT = re.compile(
    r"^(?P<num>\d+(?:\.\d+)?)\s*(?:s|sec|secs|second|seconds)$",
    re.IGNORECASE,
)


def wait_action(text: str) -> dict[str, Any]:
    """Sleep for `/cua +wait 10s`. This does not open a window or a driver."""
    match = _WAIT_AMOUNT.match((text or "").strip())
    if not match:
        raise ValueError('cua wait needs a duration: /cua +wait 10s')
    seconds = float(match.group("num"))
    print(f"Waiting {seconds:g}s.", flush=True)
    time.sleep(seconds)
    return {"status": "ok", "text": f"wait {seconds:g}s", "seconds": seconds}


def type_into(
    driver: Any,
    text: str,
    label: str,
    app: str = "",
    env: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Type `text` into the field named `label`.

    An accessibility label is used when one matches. Otherwise the field is
    located the same way a click is, then the keystrokes go to that focus.
    """
    window = driver.target_window(app)
    elements = driver.find_elements(pid=window["pid"], window_id=window["window_id"], query=label)
    match = _match_element(elements, label) if label else None
    focused: dict[str, Any] = {}
    if label and match is None:
        focused = perception_fallback_click(driver, label, app, env)
        window = driver.target_window(app)
    args = _window_key_args(window, text=text)
    point = _point_from(focused)
    if match is not None:
        args["element_token"] = str(match["element_token"])
    elif point is not None:
        args["x"], args["y"] = point
    driver._driver_tool("type_text", args)
    shown = f"type {text}" + (f" into {label}" if label else "")
    result = {"status": "ok", "text": shown, "label": label, "typed": text}
    shots = [str(item) for item in (focused.get("screenshots") or []) if item]
    if shots:
        result["screenshots"] = shots
    return result


def send_keys(driver: Any, text: str, *, clear: bool, app: str = "") -> dict[str, Any]:
    """Send keystrokes to the field the last click focused. `clear` selects all, then deletes.

    This does not click. Chrome keeps several windows in one process, so a
    background key cannot be proven to reach this window. The keys are sent
    with the window briefly in front.
    """
    window = driver.target_window(app)
    if clear:
        driver._driver_tool("hotkey", _send_args(window, keys=["cmd", "a"]))
        driver._driver_tool("press_key", _send_args(window, key="delete"))
    for kind, value in _send_pieces(text):
        if kind == "type":
            driver._driver_tool("type_text", _send_args(window, text=value))
            continue
        key, modifiers = value
        if modifiers:
            driver._driver_tool("hotkey", _send_args(window, keys=[*modifiers, key]))
        else:
            driver._driver_tool("press_key", _send_args(window, key=key))
    if clear and text:
        shown = f"sendkeys clear then {text}"
    elif clear:
        shown = "sendkeys clear"
    else:
        shown = f"sendkeys {text}"
    return {"status": "ok", "text": shown, "label": "clear" if clear else "", "typed": text, "clear": clear}


_CARET_KEY_RE = re.compile(r"\^([A-Za-z][A-Za-z0-9+]*)")
_DRIVER_KEYS = {
    "enter": "return",
    "return": "return",
    "tab": "tab",
    "escape": "escape",
    "esc": "escape",
    "backspace": "delete",
    "delete": "delete",
    "space": "space",
    "up": "up",
    "down": "down",
    "left": "left",
    "right": "right",
    "home": "home",
    "end": "end",
    "pageup": "pageup",
    "pagedown": "pagedown",
}
_KEY_MODIFIERS = {
    "cmd": "cmd",
    "command": "cmd",
    "shift": "shift",
    "option": "option",
    "alt": "alt",
    "ctrl": "ctrl",
    "control": "ctrl",
    "fn": "fn",
}


def _send_pieces(text: str) -> list[tuple[str, Any]]:
    """`Hello World^Enter` types the words, then presses Enter. `^` marks a key."""
    parts = _CARET_KEY_RE.split(text or "")
    pieces: list[tuple[str, Any]] = []
    for index, part in enumerate(parts):
        if index % 2 == 0:
            chunk = part
            if index:
                chunk = chunk.lstrip()
            if index + 1 < len(parts):
                chunk = chunk.rstrip()
            if chunk:
                pieces.append(("type", chunk))
            continue
        pieces.append(("press", _caret_key(part)))
    return pieces


def _caret_key(token: str) -> tuple[str, list[str]]:
    parts = [part for part in token.split("+") if part]
    if not parts:
        raise ValueError(f"unknown key ^{token}")
    modifiers: list[str] = []
    key = ""
    for part in parts:
        folded = part.casefold()
        modifier = _KEY_MODIFIERS.get(folded)
        if modifier:
            modifiers.append(modifier)
            continue
        if key:
            raise ValueError(f"unknown key ^{token}")
        mapped = _DRIVER_KEYS.get(folded)
        if mapped is None and re.fullmatch(r"f(?:[1-9]|1[0-2])", folded):
            mapped = folded
        if mapped is None and len(part) == 1:
            mapped = part.lower()
        if mapped is None:
            raise ValueError(f"unknown key ^{token}")
        key = mapped
    if not key:
        raise ValueError(f"unknown key ^{token}")
    return key, modifiers


def _send_args(window: dict[str, int], **extra: Any) -> dict[str, Any]:
    """Keys for one window. Foreground delivery avoids a process-wide key refusal."""
    args: dict[str, Any] = {
        "pid": int(window["pid"]),
        "window_id": int(window["window_id"]),
        "delivery_mode": "foreground",
    }
    args.update(extra)
    return args


def _window_key_args(window: dict[str, int], **extra: Any) -> dict[str, Any]:
    """Key and type calls name one window. A bare pid is ambiguous when the app has several."""
    pid = int(window["pid"])
    window_id = int(window["window_id"])
    args: dict[str, Any] = {
        "pid": pid,
        "window_id": window_id,
        "delivery_mode": "background",
        "target": {"kind": "window", "pid": pid, "window_id": window_id},
    }
    args.update(extra)
    return args


def _point_from(found: dict[str, Any]) -> tuple[float, float] | None:
    if found.get("x") is None or found.get("y") is None:
        return None
    return float(found["x"]), float(found["y"])


def press_key(driver: Any, key: str, app: str = "") -> dict[str, Any]:
    """Press one key in the current window."""
    window = driver.target_window(app)
    name = (key or "").strip()
    if not name:
        raise ValueError("cua press needs a key")
    driver._driver_tool(
        "press_key",
        {"pid": window["pid"], "window_id": window["window_id"], "key": name, "delivery_mode": "background"},
    )
    return {"status": "ok", "text": f"press {name}", "key": name}


def regions_from(payload: Any) -> list[Region]:
    """Regions from a parse_visual_regions result."""
    raw_regions = _region_list(payload)
    found: list[Region] = []
    for index, item in enumerate(raw_regions):
        if not isinstance(item, dict):
            continue
        bounds = _bounds(item)
        if not bounds:
            continue
        kind = str(item.get("type") or item.get("kind") or "text").strip().lower()
        if kind in {"ocr", "line", "word"}:
            kind = "text"
        text = str(item.get("text") or item.get("label") or item.get("content") or "")
        region_id = str(item.get("id") or item.get("region_id") or f"r{index}")
        found.append(Region(id=region_id, type=kind, text=text, bounds=bounds))
    return found


def _perception_missing(exc: BaseException) -> bool:
    text = str(exc).lower()
    return "not_installed" in text or "not installed" in text or "cua-perception" in text


def _match_element(elements: list[dict[str, Any]], label: str) -> dict[str, Any] | None:
    wanted = (label or "").strip().lower()
    if not wanted:
        return None
    ranked: list[tuple[int, dict[str, Any]]] = []
    for item in elements:
        token = str(item.get("element_token") or "")
        if not token:
            continue
        text = " ".join(str(item.get(key) or "") for key in ("label", "value", "title", "description"))
        if wanted not in text.lower():
            continue
        role = str(item.get("role") or "").lower()
        rank = 0 if role in {"link", "button", "axlink", "axbutton"} else 1
        ranked.append((rank, item))
    if not ranked:
        return None
    ranked.sort(key=lambda pair: pair[0])
    return ranked[0][1]


def _locate_point(label: str, image: str, env: dict[str, Any] | None) -> dict[str, Any]:
    """The LocateAnything box for `label`. Does not click."""
    from .locate import locate_image

    if not image or not Path(image).is_file():
        message = f"Could not visually locate '{label}' on the screen."
        print(message, flush=True)
        raise LookupError(message)
    log_image = _log_image(image, env)
    print(f"CUA LocateAnything {label}", flush=True)
    try:
        found = locate_image(label, str(log_image), env)
    except Exception as exc:
        raise LocateMiss(
            f"Could not visually locate '{label}' on the screen.",
            [str(log_image)],
        ) from exc
    marked = str(found.get("marked") or "")
    shots = [item for item in (marked, str(log_image)) if item]
    if not found.get("box") or found.get("x") is None or found.get("y") is None:
        message = f"Could not visually locate '{label}' on the screen."
        raw = str(found.get("raw") or "").strip()
        if raw:
            message = f"{message}: {raw}"
        print(message, flush=True)
        raise LocateMiss(message, shots)
    x = float(found["x"])
    y = float(found["y"])
    box = {key: int(found["box"][key]) for key in ("x1", "y1", "x2", "y2")}
    return {
        "x": x,
        "y": y,
        "box": box,
        "image": str(log_image),
        "screenshots": shots,
        "method": "locateanything",
        "label": label,
        "text": f"click {label} locateanything x={int(x)} y={int(y)}",
    }


def _click_locateanything(
    driver: Any,
    label: str,
    capture_id: str,
    image: str,
    env: dict[str, Any] | None,
) -> dict[str, Any]:
    """Click the box LocateAnything returns for `label` on `image`."""
    found = _locate_point(label, image, env)
    x = float(found["x"])
    y = float(found["y"])
    clicked = driver.click_point(capture_id, x, y)
    shots = [str(item) for item in (found.get("screenshots") or []) if item]
    if shots:
        clicked["screenshots"] = shots
    clicked["label"] = label
    clicked["grounding"] = "locateanything"
    clicked["text"] = found["text"]
    return clicked


def _log_image(image: str, env: dict[str, Any] | None) -> Path:
    """Copy the capture beside the step JSON so the log keeps the screenshot."""
    source = Path(image)
    raw = str((env or {}).get("CG_LOOP_STEP_JSON") or "").strip()
    if not raw:
        return source
    dest = Path(raw).expanduser().with_suffix(".jpg")
    if dest.resolve() == source.resolve():
        return source
    dest.parent.mkdir(parents=True, exist_ok=True)
    if source.suffix.lower() in {".jpg", ".jpeg"}:
        dest.write_bytes(source.read_bytes())
        return dest
    from PIL import Image

    with Image.open(source) as picture:
        picture.convert("RGB").save(dest, quality=90)
    return dest


def _region_box(region: Region) -> dict[str, int]:
    bounds = region.bounds
    if "x2" in bounds:
        return {
            "x1": int(float(bounds["x1"])),
            "y1": int(float(bounds["y1"])),
            "x2": int(float(bounds["x2"])),
            "y2": int(float(bounds["y2"])),
        }
    x = int(float(bounds["x"]))
    y = int(float(bounds["y"]))
    return {
        "x1": x,
        "y1": y,
        "x2": x + int(float(bounds["width"])),
        "y2": y + int(float(bounds["height"])),
    }


def _boxed_shot(image: str, box: dict[str, int], env: dict[str, Any] | None) -> list[str]:
    """Draw `box` on a copy of the capture and return the marked log path first."""
    if not image or not Path(image).is_file():
        return []
    from .locate import mark_image

    log_image = _log_image(image, env)
    marked = mark_image(log_image, [box])
    return [marked, str(log_image)]


def _match_region(regions: list[Region], label: str) -> str:
    wanted = (label or "").strip().lower()
    if not wanted:
        return ""
    for region in regions:
        if region.type == "text" and wanted in region.text.lower():
            return region.id
    for region in regions:
        if wanted in region.text.lower():
            return region.id
    return ""


def _region_list(payload: Any) -> list[Any]:
    if isinstance(payload, list):
        return payload
    if not isinstance(payload, dict):
        return []
    for key in ("regions", "items", "visual_regions"):
        value = payload.get(key)
        if isinstance(value, list):
            return value
    structured = payload.get("structuredContent")
    if isinstance(structured, dict) and structured is not payload:
        return _region_list(structured)
    return []


def _bounds(item: dict[str, Any]) -> dict[str, float]:
    raw = item.get("bounds") or item.get("rect") or item.get("box") or item.get("bbox") or item.get("frame")
    if isinstance(raw, (list, tuple)) and len(raw) >= 4:
        return {
            "x": float(raw[0]),
            "y": float(raw[1]),
            "width": float(raw[2]),
            "height": float(raw[3]),
        }
    if not isinstance(raw, dict):
        return {}
    if {"x1", "y1", "x2", "y2"} <= set(raw):
        return {key: float(raw[key]) for key in ("x1", "y1", "x2", "y2")}
    if {"left", "top", "right", "bottom"} <= set(raw):
        return {
            "x1": float(raw["left"]),
            "y1": float(raw["top"]),
            "x2": float(raw["right"]),
            "y2": float(raw["bottom"]),
        }
    width = raw.get("width", raw.get("w"))
    height = raw.get("height", raw.get("h"))
    if "x" in raw and "y" in raw and width is not None and height is not None:
        return {"x": float(raw["x"]), "y": float(raw["y"]), "width": float(width), "height": float(height)}
    return {}


def _windows(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("windows", "items"):
        value = payload.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
    return []


def _url_marks(url: str) -> tuple[str, ...]:
    """Host tokens that can appear in a window or tab title, such as `yahoo.com` and `yahoo`."""
    text = (url or "").strip()
    if "://" in text:
        text = text.split("://", 1)[1]
    host = text.split("/")[0].split("?")[0].split("#")[0].split(":")[0].lower()
    if host.startswith("www."):
        host = host[4:]
    if not host:
        return ()
    label = host.split(".")[0]
    if label and label != host and len(label) >= 4:
        return (host, label)
    return (host,)


def _title_has(window: dict[str, Any], marks: tuple[str, ...]) -> bool:
    title = str(window.get("title") or "").lower()
    return any(mark in title for mark in marks)


def _loading_title(title: Any) -> bool:
    text = str(title or "").strip().lower()
    return text.startswith("new tab") or text.startswith("untitled")


def _match_tab(elements: list[dict[str, Any]], marks: tuple[str, ...]) -> dict[str, Any] | None:
    """A tab control whose label contains the site. History menu rows are not tabs."""
    ranked: list[tuple[int, dict[str, Any]]] = []
    for item in elements:
        if not str(item.get("element_token") or ""):
            continue
        role = str(item.get("role") or "").lower()
        if "menu" in role or "textfield" in role or role in {"axstatictext", "statictext"}:
            continue
        text = " ".join(str(item.get(key) or "") for key in ("label", "value", "title", "description")).lower()
        if not any(mark in text for mark in marks):
            continue
        rank = 0 if any(part in role for part in ("tab", "radio")) else 1
        ranked.append((rank, item))
    if not ranked:
        return None
    ranked.sort(key=lambda pair: pair[0])
    return ranked[0][1]


def _best_window(windows: list[dict[str, Any]]) -> dict[str, Any]:
    usable = [item for item in windows if item.get("window_id")]
    if not usable:
        return {}

    def rank(item: dict[str, Any]) -> tuple[int, int, int]:
        on_space = 1 if item.get("on_current_space") else 0
        on_screen = 1 if item.get("is_on_screen", True) else 0
        z_index = item.get("z_index")
        height = int(z_index) if isinstance(z_index, int) else -1
        return (on_space, on_screen, height)

    return max(usable, key=rank)


def _app_match(window: dict[str, Any], app: str) -> bool:
    wanted = (app or "").strip().lower()
    if not wanted:
        return True
    name = str(window.get("app_name") or window.get("name") or window.get("title") or "").lower()
    if wanted in {"chrome", "google chrome"}:
        return "chrome" in name
    return wanted in name


_CUA_APPS = ("Chrome", "Safari", "Firefox", "Notes", "Finder", "Terminal", "Mail", "TextEdit")
_CUA_KEYS = ("Return", "Escape", "Tab", "Space")
_CUA_OPS = {
    "launch": "Open an application. A URL in the command opens with it.",
    "click": "Click a control the command names.",
    "type": "Type text into a field the command names.",
    "press": "Press a key such as Return.",
    "done": "This slot is past the last action in the command.",
}
_CUA_SLOTS = 4
_QUOTE_RE = re.compile(r'"([^"]+)"|\'([^\']+)\'')
_URL_RE = re.compile(r"https?://\S+")


def compile_cua_actions(
    command: str,
    *,
    elements: list[str] | None = None,
    ask: Any = None,
) -> dict[str, Any]:
    """Ask Laya which cua actions are in `command`. Nothing is clicked."""
    text = (command or "").strip()
    if text.lower().startswith("/cua"):
        text = text.split(None, 1)[1].strip() if " " in text else ""
    if not text:
        raise ValueError("cua command needs a sentence")
    state, questions = cua_questions(text, elements or [])
    answer = (ask or ask_laya)(state, questions)
    answers = answer.get("answers") if isinstance(answer, dict) else None
    if not isinstance(answers, dict):
        raise RuntimeError("laya returned no answers")
    actions = actions_from_laya(answers)
    error = "" if actions else "Laya returned no cua actions."
    return {
        "error": error,
        "actions": actions,
        "model": "laya",
        "state": state,
        "questions": questions,
        "answers": answers,
    }


def cua_questions(command: str, elements: list[str] | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
    """The typed questions for one command. Laya picks one label per question."""
    apps = _named_apps(command)
    urls = [item.rstrip(".,)") for item in _URL_RE.findall(command)]
    quotes = [next(part for part in match.groups() if part is not None) for match in _QUOTE_RE.finditer(command)]
    labels = _unique([*quotes, *_phrase_labels(command), *(elements or [])])
    texts = _unique(quotes + _typed_phrases(command))
    state = {"command": command, "elements": labels[:16]}
    questions: dict[str, Any] = {}
    for slot in range(1, _CUA_SLOTS + 1):
        place = {1: "first", 2: "second", 3: "third", 4: "fourth"}[slot]
        questions[f"action_{slot}"] = {
            "type": "choice",
            "instructions": f"What is the {place} action in this command? Choose done when the command has no {place} action.",
            "criteria": dict(_CUA_OPS),
        }
        _add_choice(questions, f"action_{slot}_app", "Which app does this action open?", _described(apps or list(_CUA_APPS), "application"))
        _add_choice(questions, f"action_{slot}_url", "Which URL does this action open?", _described(urls, "address"))
        _add_choice(questions, f"action_{slot}_label", "Which control does this action use?", _described(labels, "control"))
        _add_choice(questions, f"action_{slot}_text", "Which text does this action type?", _described(texts, "text"))
        _add_choice(questions, f"action_{slot}_key", "Which key does this action press?", _described(list(_CUA_KEYS), "key"))
    return state, questions


def actions_from_laya(answers: dict[str, Any]) -> list[dict[str, Any]]:
    """Turn Laya's slot choices into launch, click, type, and press actions."""
    found: list[dict[str, Any]] = []
    for slot in range(1, _CUA_SLOTS + 1):
        operation = _laya_choice(answers, f"action_{slot}").lower()
        if operation in {"", "done", "none"}:
            break
        app = _kept(_laya_choice(answers, f"action_{slot}_app"))
        url = _kept(_laya_choice(answers, f"action_{slot}_url"))
        label = _kept(_laya_choice(answers, f"action_{slot}_label"))
        typed = _kept(_laya_choice(answers, f"action_{slot}_text"))
        key = _kept(_laya_choice(answers, f"action_{slot}_key"))
        if operation == "launch" and app:
            found.append({"action": "launch", "app": app, "url": url, "label": "", "text": ""})
        elif operation == "click" and label:
            found.append({"action": "click", "app": "", "url": "", "label": label, "text": ""})
        elif operation == "type" and typed:
            found.append({"action": "type", "app": "", "url": "", "label": label, "text": typed})
        elif operation == "press" and key:
            found.append({"action": "press", "app": "", "url": "", "label": "", "text": key})
    return found


def ask_laya(state: dict[str, Any], questions: dict[str, Any]) -> dict[str, Any]:
    """One local Laya pass. The package and checkpoint are loaded on the first call."""
    from .model import ensure_laya_router

    result = ensure_laya_router().predict(state, questions)
    if not isinstance(result, dict):
        raise RuntimeError("laya returned no answers")
    return result


def replay_cua_actions(
    command: str,
    actions: list[dict[str, Any]],
    *,
    dry_run: bool = False,
    env: dict[str, Any] | None = None,
    variables: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run actions Laya saved for a `/cua` command. This does not call Laya."""
    from .terminal import expand_command

    merged = {**os.environ, **(env or {})}
    stored = variables if isinstance(variables, dict) else {}
    ran: list[dict[str, Any]] = []
    if not actions:
        return {
            "inputs": {"command": command},
            "outputs": {"status": "blocked", "message": "Compiled cua actions are missing.", "actions": []},
            "blocked": True,
        }
    for item in actions:
        action = str(item.get("action") or "")
        app = expand_command(str(item.get("app") or ""), merged, stored)
        url = expand_command(str(item.get("url") or ""), merged, stored)
        label = expand_command(str(item.get("label") or ""), merged, stored)
        text = expand_command(str(item.get("text") or ""), merged, stored)
        shown = _action_text(action, app, url, label, text)
        if dry_run:
            print(f"DRY-RUN CUA {shown}", flush=True)
            ran.append({"status": "proposed", "action": action, "app": app, "url": url, "label": label, "text": text})
            continue
        found = perform(action, app=app, url=url, label=label, text=text, env=env)
        ran.append(found)
        print(f"CUA {found.get('text') or shown}", flush=True)
    status = "proposed" if dry_run else "ok"
    return {"inputs": {"command": command}, "outputs": {"status": status, "actions": ran, "cua": ran[-1] if ran else {}}}


def _action_text(action: str, app: str, url: str, label: str, text: str) -> str:
    if action == "launch":
        return f"launch {app} {url}".strip()
    if action == "type":
        return f"type {text} into {label}".strip()
    if action == "sendkeys":
        if label == "clear" and text:
            return f"sendkeys clear then {text}"
        if label == "clear":
            return "sendkeys clear"
        return f"sendkeys {text}".strip()
    if action == "press":
        return f"press {text or label}".strip()
    if action == "wait":
        return f"wait {text or label}".strip()
    return f"click {label}".strip()


def _add_choice(questions: dict[str, Any], key: str, instructions: str, criteria: dict[str, str]) -> None:
    if len(criteria) < 2:
        return
    questions[key] = {"type": "choice", "instructions": instructions, "criteria": criteria}


def _described(options: list[str], kind: str) -> dict[str, str]:
    criteria = {option: kind for option in options if option and option.lower() != "none"}
    criteria["none"] = "Not part of this action"
    return criteria


def _named_apps(command: str) -> list[str]:
    lower = command.lower()
    return [name for name in _CUA_APPS if re.search(rf"\b{re.escape(name.lower())}\b", lower)]


def _phrase_labels(command: str) -> list[str]:
    found: list[str] = []
    for match in re.finditer(r"\b(?:click|press)\s+(?:on\s+)?(?:the\s+)?(.+?)(?=,|\band\b|$)", command, re.IGNORECASE):
        found.append(match.group(1).strip(" .\"'"))
    for match in re.finditer(r"\binto\s+(?:the\s+)?(.+?)(?=,|\band\b|$)", command, re.IGNORECASE):
        found.append(match.group(1).strip(" .\"'"))
    return [item for item in found if item]


def _typed_phrases(command: str) -> list[str]:
    found: list[str] = []
    for match in re.finditer(r"\btype\s+(?:the\s+)?(.+?)\s+into\b", command, re.IGNORECASE):
        found.append(match.group(1).strip(" .\"'"))
    return [item for item in found if item]


def _unique(values: list[str]) -> list[str]:
    found: list[str] = []
    for value in values:
        text = value.strip().rstrip(".,")
        if text and text not in found:
            found.append(text)
    return found[:16]


def _laya_choice(answers: dict[str, Any], key: str) -> str:
    item = answers.get(key)
    if not isinstance(item, dict):
        return ""
    return str(item.get("choice") or "").strip()


def _kept(value: str) -> str:
    if value.lower() in {"", "none"}:
        return ""
    return value


def session_label(env: dict[str, Any] | None = None) -> str:
    """The driver session is the workflow name, unless a run sets one explicitly."""
    merged = {**os.environ, **(env or {})}
    chosen = str(merged.get("CG_LOOP_CUA_SESSION") or merged.get("CUA_SESSION") or "").strip()
    if chosen:
        return _slug_session(chosen)
    workflow = str(merged.get("CUA_WORKFLOW") or "").strip()
    if workflow:
        return _slug_session(workflow)
    return "cg-loop"


def _slug_session(value: str) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "-" for ch in value.strip())
    collapsed = "-".join(part for part in text.split("-") if part)
    return collapsed[:64] or "cg-loop"


def _session_unavailable(exc: BaseException) -> bool:
    text = str(exc).lower()
    return "not available to this transport" in text or "session_unavailable" in text


def _session_present(payload: Any, name: str) -> bool:
    if not isinstance(payload, dict):
        return False
    status = str(payload.get("status") or payload.get("state") or "").strip().lower()
    if status in {"not_found", "missing", "absent", "unknown", "none", "does_not_exist"}:
        return False
    if status in {"active", "running", "live", "open", "ready", "idle", "ended", "closed", "expired"}:
        return True
    label = str(payload.get("session") or payload.get("label") or payload.get("name") or "")
    return label == name


def _new_session() -> str:
    """One label for this process. Reusing an ended name is rejected by the driver."""
    return session_label()


def _space_id(payload: Any) -> str:
    if isinstance(payload, dict):
        for key in ("id", "space", "space_id"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
            if isinstance(value, dict):
                found = _space_id(value)
                if found:
                    return found
        for value in payload.values():
            found = _space_id(value)
            if found:
                return found
    return ""


def _capture_id(payload: Any) -> str:
    if isinstance(payload, dict):
        value = payload.get("capture_id")
        if value:
            return str(value)
        for child in payload.values():
            found = _capture_id(child)
            if found:
                return found
    elif isinstance(payload, list):
        for child in payload:
            found = _capture_id(child)
            if found:
                return found
    return ""


def _json_text(result: dict[str, Any]) -> Any:
    content = result.get("content")
    if not isinstance(content, list):
        return None
    for item in content:
        if not isinstance(item, dict) or item.get("type") != "text":
            continue
        try:
            return json.loads(str(item.get("text") or ""))
        except json.JSONDecodeError:
            continue
    return None


def _error_text(result: Any) -> str:
    if isinstance(result, str):
        return result
    if not isinstance(result, dict):
        return str(result or "")
    message = result.get("message") or result.get("error")
    if message:
        return str(message)
    content = result.get("content")
    if isinstance(content, list):
        parts = [str(item.get("text") or "") for item in content if isinstance(item, dict)]
        return " ".join(part for part in parts if part).strip()
    return ""
