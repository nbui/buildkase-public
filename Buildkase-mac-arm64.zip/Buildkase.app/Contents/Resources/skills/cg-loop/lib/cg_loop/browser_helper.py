"""Execute the browser actions Jev returns.

The helper does not decide a destination, an upload, a schedule, or a wait.
Jev returns those actions. A workflow Python script computes values such as a
time or a file path. This module reads the page, asks Jev, and runs the reply.
"""

from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Any, Callable

from .questions import BROWSER_ACTION, TEXT_VALUE
from .quoting import mask_quoted
from .terminal import expand_command
from .workflow import Step, parse_step, strip_action_plus

_VAR_RE = re.compile(r"\$([A-Za-z_][A-Za-z0-9_]*)")
_PLAN = (
    "Return each action in this command once, in order. "
    "A go to is always GOTO, then WAIT when the command waits or verifies. "
    "A click then a verify is CLICK, then WAIT. A verify then a click is WAIT, then CLICK. "
    "verify <phrase> max Ns is WAIT for page text or WAIT_FOR_LOCATOR for a control. "
    "Do not skip GOTO or the click because the phrase is already visible. "
    "Copy an offered selector. A wait or verify sentence is not a click."
)
_BROWSER_RULES = [
    "The actions array is the whole command. A go to is GOTO, then WAIT when the command waits or verifies.",
    "A click followed by a wait or verify is CLICK, then WAIT. A verify or wait followed by a click is WAIT, then CLICK.",
    "verify <phrase> max Ns is WAIT for page text or WAIT_FOR_LOCATOR for a control.",
    "Always GOTO the address in the command. Do not skip it because that host is already open.",
    "GOTO sets url. RELOAD, BACK, FORWARD, PRESS, and SCROLL need no selector. PRESS sets key.",
    "When the command says Wait max Ns until and names a click, return WAIT_FOR_LOCATOR, then CLICK.",
    "When it says Wait max Ns until Close button, return only WAIT_FOR_LOCATOR for that button. Do not click and do not search page text.",
    "DONE is only the last item. BLOCKED when the named control is not offered.",
]
_PAGE_ACTIONS = {"GOTO", "RELOAD", "BACK", "FORWARD", "PRESS"}
_WAIT_EXIST = re.compile(
    r"\bwait(?:\s+max)?\s+(?:(\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?\s+)?"
    r"until\s+(.+?)\s+is showing\b",
    re.IGNORECASE,
)
_ACTION_WORD = re.compile(r"\b(click|type|select|tick|search)\b", re.IGNORECASE)
_SCROLL_TO = re.compile(r"\bscroll\s+to\s+(.+)", re.IGNORECASE)
_HOST = re.compile(r"^(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}(?:/[^\s]*)?$")
_COMMAND_URL = re.compile(r"https?://\S+", re.IGNORECASE)
_GO_TARGET = re.compile(r"\bgo(?:\s+to)?\s+(\S+)", re.IGNORECASE)
_CHOOSE_FILE = re.compile(
    r"\bchoose\s+(\S+\.(?:mp4|mov|m4v|webm|mkv|png|jpe?g|gif|webp))\b",
    re.IGNORECASE,
)
_CHOOSE_SELECTED_VIDEO = re.compile(r"\bchoose\s+the\s+selected\s+video\b", re.IGNORECASE)
_CONTROL_BOX = re.compile(r"^(?:the\s+)?(.+?)\s+(?:box|field|input)$", re.IGNORECASE)
_DATE_PHRASE = re.compile(r"^(?:the\s+)?date$", re.IGNORECASE)
_DATE_VALUE = re.compile(r"\d{4}-\d{2}-\d{2}")
_CLICK_QUOTED = re.compile(r'\bclick\s+(?:the\s+)?"([^"]+)"', re.IGNORECASE)
_WAIT_FOR_SHOW = re.compile(r'\bwait\s+for\s+"([^"]+)"\s+to\s+show\b', re.IGNORECASE)
_DURATION_WAIT = re.compile(r"\bwait\s+(\d+(?:\.\d+)?)\s*s\b", re.IGNORECASE)


def browser_helper(
    command: str,
    tab: Any,
    *,
    dry_run: bool = False,
    env: dict[str, str] | None = None,
    variables: dict[str, Any] | None = None,
    reference: str = "",
    workflow_path: str = "",
    max_steps: int = 1,
    ask: Callable[[list[dict[str, str]]], dict[str, Any]] | None = None,
    compile_step: Callable[[dict[str, Any]], Any] | None = None,
) -> dict[str, Any]:
    """Ask Jev for the actions in `command` and run them on `tab`.

    `dry_run` uses the same call and does not act. A missing control, a failed
    wait, or a step that never finishes comes back blocked.
    """
    from . import model
    from .browser import StalePage

    del reference, workflow_path, compile_step
    text = (command or "").strip()
    if not text:
        raise ValueError("browser helper needs a command")
    if locate_click_command(text):
        return click_located(
            text,
            tab,
            dry_run=dry_run,
            env=env,
            variables=variables if isinstance(variables, dict) else {},
        )
    if enabled_click_command(text):
        return wait_until_enabled_then_click(text, tab, dry_run=dry_run)
    if click_if_exists_command(text):
        return click_if_exists(text, tab, dry_run=dry_run)
    merged_env = {**os.environ, **(env or {})}
    stored: dict[str, Any] = variables if isinstance(variables, dict) else {}
    expanded = expand_command(text, merged_env, stored)
    pause = _only_duration_wait(expanded)
    if pause is not None:
        return _pause_only(expanded, tab, pause, dry_run=dry_run)
    if tab is None:
        raise RuntimeError("browser helper needs a tab")
    names = _searched(text, merged_env, stored)
    step = _browser_step(expanded)
    # Jev returns one action per call unless the reply lists several.
    # The agent asks for one step; a command still needs room for each action.
    limit = max(1, max_steps)
    if ask is None or limit == 1:
        limit = max(limit, 8)

    history: list[dict[str, Any]] = []
    actions: list[dict[str, Any]] = []
    llm_calls: list[dict[str, Any]] = []
    status = "ready"
    message = ""
    executed = False
    page: dict[str, Any] = {}
    public: dict[str, Any] = {}
    retried_done = False
    clicked: set[str] = set()
    steps = _command_steps(expanded)

    for _tick in range(limit):
        page = _read_tab(tab)
        if not dry_run:
            page = _dismiss_feature_notice(tab, page)
        request = model.choose_request(
            page,
            step,
            history,
            stored,
            plan=_PLAN,
            system=BROWSER_ACTION,
            rules=_BROWSER_RULES,
            selectors=True,
        )
        try:
            answer = _action_answer(ask, request, goal=expanded)
        except Exception as exc:
            llm_calls.append(
                {"purpose": "action", "messages": request["messages"], "reply": {}, "sent": True, "error": str(exc)}
            )
            status = "blocked"
            message = str(exc)
            break
        llm_calls.append(
            {"purpose": "action", "messages": request["messages"], "reply": answer, "sent": True, "error": ""}
        )
        batch = _answer_actions(answer)
        if not batch:
            status = "blocked"
            message = "Model returned no browser actions."
            break
        if not retried_done and not history and _only_done(batch) and _command_needs_action(expanded):
            retried_done = True
            request = model.choose_request(
                page,
                step,
                history,
                stored,
                plan=f"{_PLAN} The previous reply was only DONE. Return each action in the command.",
                system=BROWSER_ACTION,
                rules=_BROWSER_RULES,
                selectors=True,
            )
            try:
                answer = _action_answer(ask, request, goal=expanded)
            except Exception as exc:
                llm_calls.append(
                    {"purpose": "action", "messages": request["messages"], "reply": {}, "sent": True, "error": str(exc)}
                )
                status = "blocked"
                message = str(exc)
                break
            llm_calls.append(
                {"purpose": "action", "messages": request["messages"], "reply": answer, "sent": True, "error": ""}
            )
            batch = _answer_actions(answer)
            if not batch:
                status = "blocked"
                message = "Model returned no browser actions."
                break
        stop = False
        for item in batch:
            try:
                decision = model.decision_from_answer(item, request, started=time.perf_counter())
            except model.ChatError as exc:
                status = "blocked"
                message = str(exc)
                stop = True
                break
            resolved = _resolve(decision, page)
            operation = str(decision.get("operation") or "")
            if operation == "CLICK":
                resolved = _prefer_menu_item(expanded, resolved, decision.get("targets") or {})
            if operation in _PAGE_ACTIONS:
                if operation == "GOTO" and not str(item.get("url") or decision.get("url") or "").strip():
                    found = _command_url(expanded)
                    if found:
                        item = dict(item)
                        item["url"] = found
                prepared = _prepare_page_action(operation, resolved, item, decision)
                if prepared.get("error"):
                    status = "blocked"
                    message = str(prepared["error"])
                    stop = True
                    break
                resolved = prepared["action"]
                public = _public_action(decision, resolved, None)
                public["label"] = resolved.get("label") or ""
                actions.append(public)
                if dry_run:
                    print(f"DRY-RUN {operation} {public['label']}".rstrip())
                    continue
                try:
                    page = _run_page_action(tab, resolved, page)
                except Exception as exc:
                    status = "blocked"
                    message = str(exc)
                    stop = True
                    break
                executed = True
                history.append(
                    {
                        "action": public.get("label") or operation,
                        "selector": "",
                        "kind": resolved.get("kind") or "",
                        "text": None,
                        "page_changed": True,
                    }
                )
                continue
            if operation == "WAIT_FOR_LOCATOR":
                selector = str(resolved.get("selector") or item.get("selector") or decision.get("target") or "")
                try:
                    seconds = max(0.0, float(resolved.get("seconds") or item.get("seconds") or 5))
                except (TypeError, ValueError):
                    seconds = 5.0
                waited = _recorded(
                    "WAIT_FOR_LOCATOR",
                    selector,
                    kind="wait_for_locator",
                    message=f"Wait for locator {selector}, up to {seconds:g}s",
                )
                waited["selector"] = selector
                waited["seconds"] = seconds
                actions.append(waited)
                public = waited
                if dry_run:
                    continue
                if not selector:
                    status = "blocked"
                    message = "Wait for locator needs a selector."
                    stop = True
                    break
                print(f"Waiting up to {seconds:g}s until {selector} exists.", flush=True)
                try:
                    from .browser import wait_for_locator

                    live = getattr(tab, "page", None)
                    if live is None or not hasattr(live, "locator"):
                        raise RuntimeError("wait for locator needs a Playwright page")
                    wait_for_locator(live, selector, seconds)
                except Exception as exc:
                    status = "blocked"
                    timed_out = "timeout" in type(exc).__name__.lower() or "timeout" in str(exc).lower()
                    message = (
                        f"{selector} did not exist within {seconds:g}s."
                        if timed_out
                        else f"Could not wait for {selector}: {exc}"
                    )
                    waited["message"] = message
                    stop = True
                    break
                executed = True
                page = _read_tab(tab)
                if _wait_completes_command(expanded):
                    status = "done"
                    message = f"{selector} exists."
                    stop = True
                    break
                continue
            if operation == "WAIT":
                phrase, seconds = _wait_target(expanded, resolved, item)
                selector = str(
                    item.get("selector")
                    or item.get("locator")
                    or decision.get("locator")
                    or resolved.get("selector")
                    or ""
                )
                if selector and phrase and _names_a_control(phrase):
                    phrase = ""
                if not phrase:
                    # A bare wait sleeps for its time. A locator makes that wait for the locator.
                    if selector and _duration_wait(expanded) is None:
                        waited = _recorded(
                            "WAIT",
                            selector,
                            kind="wait",
                            message=f"Wait for {selector}, up to {seconds:g}s",
                        )
                        waited["selector"] = selector
                        waited["locator"] = selector
                        waited["seconds"] = seconds
                        actions.append(waited)
                        public = waited
                        if dry_run:
                            continue
                        print(f"Waiting up to {seconds:g}s until {selector} exists.", flush=True)
                        try:
                            from .browser import wait_for_locator

                            live = getattr(tab, "page", None)
                            if live is None or not hasattr(live, "locator"):
                                raise RuntimeError("wait for locator needs a Playwright page")
                            wait_for_locator(live, selector, seconds)
                        except Exception as exc:
                            status = "blocked"
                            timed_out = "timeout" in type(exc).__name__.lower() or "timeout" in str(exc).lower()
                            message = (
                                f"{selector} did not exist within {seconds:g}s."
                                if timed_out
                                else f"Could not wait for {selector}: {exc}"
                            )
                            waited["message"] = message
                            stop = True
                            break
                        executed = True
                        page = _read_tab(tab)
                        if _wait_completes_command(expanded):
                            status = "done"
                            message = f"{selector} exists."
                            stop = True
                            break
                        continue
                    waited = _recorded(
                        "WAIT",
                        f"{seconds:g}s",
                        kind="wait",
                        message=f"Wait {seconds:g}s",
                    )
                    waited["selector"] = selector
                    waited["seconds"] = seconds
                    if selector:
                        waited["locator"] = selector
                    actions.append(waited)
                    public = waited
                    if dry_run:
                        continue
                    print(f"Waiting {seconds:g}s.", flush=True)
                    time.sleep(seconds)
                    executed = True
                    status = "done"
                    message = f"Waited {seconds:g}s."
                    stop = True
                    break
                waited = _recorded(
                    "WAIT",
                    phrase,
                    kind="wait",
                    message=f"Wait for {phrase} to exist, poll up to {seconds:g}s",
                )
                waited["selector"] = ""
                actions.append(waited)
                public = waited
                if dry_run:
                    continue
                if not _phrase_visible(page, phrase):
                    print(f"Waiting up to {seconds:g}s until {phrase} exists.", flush=True)
                waited_status, waited_message, page = _settle_showing(
                    tab, phrase, page, dry_run=False, seconds=seconds
                )
                if waited_message == "already there":
                    waited["message"] = "already there"
                message = waited_message
                if waited_status != "done":
                    status = waited_status
                    stop = True
                    break
                executed = True
                status = "done"
                message = waited_message
                later = batch[batch.index(item) + 1 :]
                if any(str(step.get("operation") or "").upper() not in {"", "DONE", "WAIT"} for step in later):
                    continue
                stop = True
                break
            if operation == "BLOCKED":
                replaced = _type_instead_of_blocked(expanded, decision)
                if replaced is None:
                    status = "blocked"
                    message = _with_searched(str(decision.get("message") or item.get("message") or ""), names)
                    stop = True
                    break
                decision = replaced
                resolved = _resolve(decision, page)
                operation = "TYPE_TEXT"
            if operation == "DONE":
                status = "done"
                message = str(decision.get("message") or message or "")
                stop = True
                break
            typed = None
            if operation == "TYPE_TEXT":
                box = _box_name(expanded)
                label = str(resolved.get("label") or "")
                if box and not _name_in_label(box, label):
                    status = "blocked"
                    message = f"{box} input is not on the page."
                    public = _public_action(decision, resolved, None)
                    actions.append(public)
                    stop = True
                    break
                known = _known_text(text, stored)
                if known:
                    typed = known
                    text_error = ""
                else:
                    typed, text_call, text_error = _field_text(
                        ask or model.ask_json, expanded, resolved, page, stored
                    )
                    llm_calls.append(text_call)
                if text_error:
                    status = "blocked"
                    message = text_error
                    public = _public_action(decision, resolved, typed)
                    actions.append(public)
                    stop = True
                    break
            public = _public_action(decision, resolved, typed)
            selector = str(public.get("selector") or "")
            if operation == "CLICK" and selector and selector in clicked:
                continue
            if not dry_run and operation in {"CLICK", "TYPE_TEXT", "SELECT"} and selector:
                page = _read_tab(tab)
                fresh = _current_action(page, step, stored, operation, selector)
                if fresh is None:
                    break
                resolved = fresh
                public = _public_action(decision, resolved, typed)
                selector = str(public.get("selector") or selector)
            if operation == "CLICK":
                video_error = _video_selection_error(expanded, stored, str(resolved.get("label") or ""))
                if video_error:
                    status = "blocked"
                    message = video_error
                    actions.append(public)
                    stop = True
                    break
                _attach_chosen_file(expanded, stored, resolved, public)
            actions.append(public)
            if dry_run:
                if operation == "CLICK" and selector:
                    clicked.add(selector)
                continue
            try:
                acted = _perform(tab, resolved, page, typed)
            except StalePage as exc:
                print(f"(stale page: {exc} — observing again)")
                history.append(
                    {
                        "action": public.get("label") or "",
                        "selector": public.get("selector") or "",
                        "kind": public.get("kind") or "",
                        "text": typed,
                        "error": str(exc),
                        "page_changed": False,
                    }
                )
                break
            if _video_was_not_chosen(resolved, acted):
                status = "blocked"
                message = "Could not select the video."
                stop = True
                break
            executed = True
            if operation == "CLICK" and selector:
                clicked.add(selector)
            history.append(
                {
                    "action": public.get("label") or "",
                    "selector": public.get("selector") or "",
                    "kind": public.get("kind") or "",
                    "text": typed,
                    "page_changed": True,
                }
            )
            if typed:
                message = typed
        else:
            if dry_run:
                status = "dry-run"
                break
            ran_ops = {str(item.get("operation") or "").upper() for item in actions}
            verified = bool(ran_ops & {"WAIT", "WAIT_FOR_LOCATOR"})
            if _verify_clause(expanded) and _wait_before_page_action(expanded) and verified and "CLICK" in ran_ops:
                status = "done"
                break
            continue
        if dry_run and status != "blocked":
            status = "dry-run"
        if stop or dry_run:
            break
    else:
        if status not in {"done", "blocked", "dry-run"}:
            status = "blocked"
            message = message or f"Stopped after {limit} actions before the command finished."

    _print_actions(actions, dry_run=dry_run)
    if dry_run or status == "blocked":
        _print_blocked(message, status)
    action_call = next((item for item in llm_calls if item.get("purpose") == "action"), None)
    result = {
        "command": expanded,
        "dry_run": dry_run,
        "status": status,
        "executed": executed,
        "blocked": status == "blocked",
        "message": message,
        "searched": names,
        "action": public or None,
        "actions": actions,
        "llm_call": action_call,
        "llm_calls": llm_calls,
        "page": {
            "url": str(page.get("url") or ""),
            "title": str(page.get("title") or ""),
            "text": str(page.get("text") or ""),
        },
        "inputs": {"command": text},
        "outputs": {
            "status": status,
            "steps": steps,
            "actions": actions,
            "message": message,
            "searched": names,
            "llm_call": action_call,
        },
    }
    saved = {
        key: stored[key]
        for key in ("story_folder", "short_folder", "video", "post_title", "post_description")
        if key in stored
    }
    if saved:
        result["variables"] = saved
        result["outputs"]["variables"] = saved
    return result


def compile_browser_actions(
    command: str,
    tab: Any,
    *,
    env: dict[str, str] | None = None,
    variables: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """One Jev call for a browser step. The reply is saved. Nothing is clicked."""
    from . import model

    if tab is None:
        raise RuntimeError("browser compile needs a tab")
    text = (command or "").strip()
    if not text:
        raise ValueError("browser compile needs a command")
    merged_env = {**os.environ, **(env or {})}
    stored: dict[str, Any] = variables if isinstance(variables, dict) else {}
    expanded = expand_command(text, merged_env, stored)
    pause = _only_duration_wait(expanded)
    if pause is not None:
        page = _read_tab(tab)
        return {
            "error": "",
            "actions": [_duration_action(pause)],
            "elements": [],
            "page": {
                "url": str(page.get("url") or ""),
                "title": str(page.get("title") or ""),
            },
            "messages": [],
            "model": "",
        }
    step = _browser_step(expanded)
    page = _read_tab(tab)
    request = model.choose_request(
        page,
        step,
        [],
        stored,
        plan=_PLAN,
        system=BROWSER_ACTION,
        rules=_BROWSER_RULES,
        selectors=True,
    )
    answer = model.ask_jev_browser(request, goal=expanded)

    def finish(*, error: str = "", actions: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        return {
            "error": error,
            "actions": actions or [],
            "elements": _review_elements(request.get("elements") or []),
            "page": {
                "url": str(page.get("url") or ""),
                "title": str(page.get("title") or ""),
            },
            "messages": request.get("messages") or [],
            "model": str(answer.get("model") or model.browser_model_name()),
        }

    batch = _answer_actions(answer)
    actions: list[dict[str, Any]] = []
    for item in batch:
        decision = model.decision_from_answer(item, request, started=time.perf_counter())
        operation = str(decision.get("operation") or "")
        if operation == "BLOCKED":
            replaced = _type_instead_of_blocked(expanded, decision)
            if replaced is None:
                message = str(decision.get("message") or item.get("message") or "The named control is not on the page.")
                return finish(error=message)
            decision = replaced
            operation = "TYPE_TEXT"
        if operation == "DONE":
            continue
        resolved = _resolve(decision, page)
        if operation == "CLICK":
            resolved = _prefer_menu_item(expanded, resolved, decision.get("targets") or {})
            resolved = _prefer_named_label(expanded, resolved, decision.get("targets") or {})
            video_error = _video_selection_error(expanded, stored, str(resolved.get("label") or ""))
            if video_error:
                return finish(error=video_error)
        if operation == "GOTO" and not str(item.get("url") or decision.get("url") or "").strip():
            found = _command_url(expanded)
            if found:
                item = dict(item)
                item["url"] = found
        if operation in _PAGE_ACTIONS:
            prepared = _prepare_page_action(operation, resolved, item, decision)
            if prepared.get("error"):
                return finish(error=str(prepared["error"]))
            resolved = prepared["action"]
        public = _public_action(decision, resolved, None)
        if operation in _PAGE_ACTIONS:
            public["url"] = resolved.get("url") or ""
            public["key"] = resolved.get("key") or ""
            public["kind"] = resolved.get("kind") or public.get("kind") or ""
        if operation in {"WAIT", "WAIT_FOR_LOCATOR"} and _followup_wait_after_click(expanded, actions):
            continue
        if operation in {"WAIT", "WAIT_FOR_LOCATOR"}:
            phrase = str(resolved.get("phrase") or "")
            raw_seconds = resolved.get("seconds")
            if raw_seconds in (None, ""):
                raw_seconds = item.get("seconds") or decision.get("seconds") or 5
            try:
                seconds = max(0.0, float(raw_seconds))
            except (TypeError, ValueError):
                seconds = 5.0
            found = _text_phrase(expanded)
            if found and not _names_a_control(found[0]):
                phrase, seconds = found
            public["seconds"] = seconds
            if phrase and not _names_a_control(phrase):
                public["operation"] = "WAIT"
                public["phrase"] = phrase
                public["selector"] = ""
                public["target"] = phrase
                public.pop("locator", None)
            elif phrase:
                public["phrase"] = phrase
                public["selector"] = ""
                public.pop("locator", None)
            else:
                selector = str(public.get("selector") or item.get("selector") or decision.get("locator") or "")
                public["selector"] = selector
        actions.append(public)
    actions = _fill_command_actions(expanded, actions)
    actions, click_error = _fill_click_param(expanded, actions, request.get("targets") or {})
    if click_error:
        return finish(error=click_error)
    actions = _bind_verify_element(expanded, actions, request.get("targets") or {})
    if not actions and not _command_needs_action(expanded):
        shown = _showing_phrase(expanded)
        if shown and not _names_a_control(shown) and _phrase_visible(page, shown):
            actions = [_already_there_action(shown)]
    if not actions and _command_needs_action(expanded):
        return finish(error="Jev returned no browser actions.")
    return finish(actions=actions)


def replay_browser_actions(
    command: str,
    tab: Any,
    actions: list[dict[str, Any]],
    *,
    dry_run: bool = False,
    env: dict[str, str] | None = None,
    variables: dict[str, Any] | None = None,
    screenshot_path: str = "",
) -> dict[str, Any]:
    """Run actions saved at compile time. This does not call Jev."""
    from .browser import StalePage

    text = (command or "").strip()
    merged_env = {**os.environ, **(env or {})}
    stored: dict[str, Any] = variables if isinstance(variables, dict) else {}
    expanded = expand_command(text, merged_env, stored)
    pause = _only_duration_wait(expanded)
    if pause is None and tab is None and not dry_run:
        raise RuntimeError("browser helper needs a tab")
    if pause is not None:
        page = _read_tab(tab) if tab is not None and not dry_run else {}
        waited, page, status, message = _sleep_wait(tab, pause, page, dry_run=dry_run)
        if dry_run:
            status = "dry-run"
        return {
            "command": expanded,
            "dry_run": dry_run,
            "status": status,
            "executed": status == "done",
            "blocked": False,
            "message": message,
            "actions": [waited],
            "page": {
                "url": str(page.get("url") or ""),
                "title": str(page.get("title") or ""),
            },
            "inputs": {"command": text},
            "outputs": {
                "status": status,
                "actions": [waited],
                "message": message,
                "screenshots": [],
                "llm_call": None,
            },
        }
    step = _browser_step(expanded)
    status = "done" if actions else "blocked"
    message = "" if actions else "Compiled browser actions are missing."
    executed = False
    page: dict[str, Any] = {}
    ran: list[dict[str, Any]] = []
    shots: list[str] = []
    shot_names: set[str] = set()
    log_json = Path(str(merged_env.get("CG_LOOP_STEP_JSON") or ""))
    run_shots = log_json.suffix == ".json"
    if tab is not None and not dry_run:
        page = _read_tab(tab)
        page = _dismiss_feature_notice(tab, page)
    for index, item in enumerate(actions, start=1):
        shot = ""
        if not isinstance(item, dict):
            continue
        operation = str(item.get("operation") or "").upper()
        if operation in {"WAIT", "WAIT_FOR_LOCATOR"} and _followup_wait_after_click(expanded, ran):
            continue
        if (screenshot_path or run_shots) and not dry_run:
            label = _action_shot_name(item, shot_names)
            shot = compile_screenshot(
                tab,
                log_json if run_shots else Path(screenshot_path),
                index,
                name=_log_shot_name(log_json, index, label) if run_shots else label,
                directory=log_json.parent if run_shots else None,
                exact=run_shots,
                actions=[item],
            )
            if shot and run_shots:
                shot = str(log_json.parent / shot)
            if shot:
                shots.append(shot)
        if operation in {"DONE", "BLOCKED"}:
            status = "done" if operation == "DONE" else "blocked"
            message = str(item.get("message") or message)
            break
        if operation in {"WAIT", "WAIT_FOR_LOCATOR"}:
            waited, page, wait_status, wait_message = _replay_wait(tab, item, expanded, page, dry_run=dry_run)
            ran.append(_with_shot(waited, shot))
            if wait_status != "done":
                status = wait_status
                message = wait_message
                break
            if wait_message:
                message = wait_message
            executed = not dry_run
            continue
        if operation in _PAGE_ACTIONS:
            action = {
                "kind": item.get("kind") or operation.lower(),
                "url": item.get("url") or "",
                "key": item.get("key") or "",
                "label": item.get("label") or item.get("url") or operation,
                "id": item.get("id"),
            }
            public = _with_shot(dict(item), shot)
            ran.append(public)
            if dry_run:
                print(f"DRY-RUN {operation} {action['label']}".rstrip())
                continue
            try:
                page = _run_page_action(tab, action, page)
            except Exception as exc:
                status = "blocked"
                message = str(exc)
                break
            executed = True
            continue
        selector = str(item.get("selector") or "")
        public = _with_shot(dict(item), shot)
        if dry_run:
            ran.append(public)
            continue
        page = _read_tab(tab)
        fresh = _current_action(page, step, stored, operation, selector) if selector else None
        if selector and fresh is None:
            status = "blocked"
            message = f"{selector} is not on the page."
            ran.append(public)
            break
        resolved = fresh or {
            "kind": item.get("kind") or operation.lower(),
            "selector": selector,
            "label": item.get("label") or "",
            "id": item.get("id"),
        }
        typed = None
        if operation == "TYPE_TEXT":
            typed = _known_text(text, stored) or str(item.get("text") or "").strip()
            if not typed:
                status = "blocked"
                message = "No text to type."
                ran.append(public)
                break
            public["text"] = typed
        if operation == "CLICK":
            video_error = _video_selection_error(expanded, stored, str(resolved.get("label") or ""))
            if video_error:
                status = "blocked"
                message = video_error
                ran.append(public)
                break
            _attach_chosen_file(expanded, stored, resolved, public)
        ran.append(public)
        try:
            acted = _perform(tab, resolved, page, typed)
        except StalePage as exc:
            status = "blocked"
            message = str(exc)
            break
        if _video_was_not_chosen(resolved, acted):
            status = "blocked"
            message = "Could not select the video."
            break
        executed = True
        page = _read_tab(tab)
    if status == "done" and not dry_run:
        day = _chosen_day(expanded, stored)
        if day and not _already_clicked_day(ran, day):
            page, cell = _wait_for_day(tab, page, day)
            public = {
                "operation": "CLICK",
                "selector": str((cell or {}).get("selector") or ""),
                "target": str((cell or {}).get("selector") or ""),
                "label": day,
                "kind": "click",
                "id": (cell or {}).get("id"),
            }
            ran.append(public)
            if cell is None:
                status = "blocked"
                message = f"Day {day} is not on the calendar."
            else:
                try:
                    _perform(tab, cell, page, None)
                except StalePage as exc:
                    status = "blocked"
                    message = str(exc)
                else:
                    executed = True
                    page = _read_tab(tab)
    if dry_run and status != "blocked":
        status = "dry-run"
    _print_actions(ran, dry_run=dry_run)
    if not run_shots:
        _remember_screenshots(screenshot_path, shots)
    if dry_run or status == "blocked":
        _print_blocked(message, status)
    if status == "blocked":
        failed = RuntimeError(message or "Browser step failed.")
        failed.screenshots = list(shots)  # type: ignore[attr-defined]
        raise failed
    result = {
        "command": expanded,
        "dry_run": dry_run,
        "status": status,
        "executed": executed,
        "blocked": status == "blocked",
        "message": message,
        "actions": ran,
        "page": {
            "url": str(page.get("url") or ""),
            "title": str(page.get("title") or ""),
            "text": str(page.get("text") or ""),
        },
        "inputs": {"command": text},
        "outputs": {
            "status": status,
            "actions": ran,
            "message": message,
            "screenshots": shots,
            "llm_call": None,
        },
    }
    saved = {
        key: stored[key]
        for key in ("story_folder", "short_folder", "video", "post_title", "post_description")
        if key in stored
    }
    if saved:
        result["variables"] = saved
        result["outputs"]["variables"] = saved
    return result


def _replay_wait(
    tab: Any,
    item: dict[str, Any],
    command: str,
    page: dict[str, Any],
    *,
    dry_run: bool,
) -> tuple[dict[str, Any], dict[str, Any], str, str]:
    """Replay one saved wait. A locator wait does not ask Jev."""
    pause = _only_duration_wait(command)
    if pause is not None:
        return _sleep_wait(tab, pause, page, dry_run=dry_run)
    try:
        seconds = max(0.0, float(item.get("seconds") or 5))
    except (TypeError, ValueError):
        seconds = 5.0
    selector = str(item.get("selector") or "").strip()
    if selector and str(item.get("operation") or "").upper() in {"WAIT", "WAIT_FOR_LOCATOR"}:
        return _replay_element_wait(tab, item, page, seconds=seconds, dry_run=dry_run)
    phrase, phrase_seconds = _wait_target(command, {}, item)
    if phrase and not _names_a_control(phrase):
        seconds = phrase_seconds
        waited = _recorded(
            "WAIT",
            phrase,
            kind="wait",
            message=f"Wait for {phrase} to exist, poll up to {seconds:g}s",
        )
        waited["seconds"] = seconds
        if dry_run:
            return waited, page, "done", ""
        if not _phrase_visible(page, phrase):
            print(f"Waiting up to {seconds:g}s until {phrase} exists.", flush=True)
        waited_status, waited_message, page = _settle_showing(
            tab, phrase, page, dry_run=False, seconds=seconds
        )
        if waited_message == "already there":
            waited["message"] = "already there"
        return waited, page, waited_status, waited_message
    selector = str(item.get("selector") or "")
    if selector:
        waited = _recorded(
            "WAIT",
            selector,
            kind="wait",
            message=f"Wait for {selector}, up to {seconds:g}s",
        )
        waited["selector"] = selector
        waited["seconds"] = seconds
        if dry_run:
            return waited, page, "done", ""
        print(f"Waiting up to {seconds:g}s until {selector} exists.", flush=True)
        try:
            from .browser import wait_for_locator

            live = getattr(tab, "page", None)
            if live is None or not hasattr(live, "locator"):
                raise RuntimeError("wait for locator needs a Playwright page")
            wait_for_locator(live, selector, seconds)
        except Exception as exc:
            timed_out = "timeout" in type(exc).__name__.lower() or "timeout" in str(exc).lower()
            message = (
                f"{selector} did not exist within {seconds:g}s."
                if timed_out
                else f"Could not wait for {selector}: {exc}"
            )
            return waited, page, "blocked", message
        return waited, _read_tab(tab), "done", f"{selector} exists."
    phrase, seconds = _wait_target(command, {}, item)
    if phrase:
        waited = _recorded(
            "WAIT",
            phrase,
            kind="wait",
            message=f"Wait for {phrase} to exist, poll up to {seconds:g}s",
        )
        waited["seconds"] = seconds
        if dry_run:
            return waited, page, "done", ""
        waited_status, waited_message, page = _settle_showing(
            tab, phrase, page, dry_run=False, seconds=seconds
        )
        if waited_message == "already there":
            waited["message"] = "already there"
        return waited, page, waited_status, waited_message
    waited = _recorded("WAIT", f"{seconds:g}s", kind="wait", message=f"Wait {seconds:g}s")
    waited["seconds"] = seconds
    if dry_run:
        return waited, page, "done", ""
    print(f"Waiting {seconds:g}s.", flush=True)
    time.sleep(seconds)
    return waited, _read_tab(tab) if tab is not None else page, "done", f"Waited {seconds:g}s."


def read_tab(tab: Any) -> dict[str, Any]:
    return _read_tab(tab)


def phrase_visible(page: dict[str, Any], phrase: str) -> bool:
    return _phrase_visible(page, phrase)


def page_down(tab: Any, page: dict[str, Any]) -> bool:
    """Page the open panel down, then report whether the view changed."""
    before = _scroll_mark(page)
    action = _page_down_action(page) or {
        "id": "scroll_down",
        "kind": "scroll",
        "label": "Page down",
        "delta": 720,
        "anchor": {"x": 480, "y": 400},
    }
    _perform(tab, action, page, None)
    return _scroll_mark(_read_tab(tab)) != before


def _scroll_phrase(command: str) -> str:
    text = _command_body(command)
    if not re.match(r"scroll\s+to\s+", text, flags=re.IGNORECASE):
        return ""
    match = _SCROLL_TO.search(text)
    return match.group(1).strip(" .") if match else ""


_ANY_PLUS_RE = re.compile(r"(?<!\S)\+(?P<name>[A-Za-z][A-Za-z0-9_-]*)\b")


def _command_body(command: str) -> str:
    """Text after `/browser`. Every `+param` drops the plus, even when tool-details omits it."""
    body = re.sub(r"^/browser\s+", "", (command or "").strip(), flags=re.IGNORECASE)
    body = strip_action_plus(body)
    masked = mask_quoted(body)
    matches = list(_ANY_PLUS_RE.finditer(masked))
    for match in reversed(matches):
        body = body[: match.start()] + match.group("name").lower() + body[match.end() :]
    return body


_LOCATE_PAGE_RE = re.compile(
    r'^/locate\s+(?:"(?P<q1>[^"]+)"|\'(?P<q2>[^\']+)\'|(?P<q3>.+?))'
    r'(?P<click>\s+and\s+click)?\s*$',
    re.IGNORECASE,
)
_CLICK_LOCATE_RE = re.compile(
    r"^click\s+(?:\$\{(?P<braced>[A-Za-z_][\w]*)\}|\$(?P<name>[A-Za-z_][\w]*)|(?P<point>\d+\s*,\s*\d+.*))\s*$",
    re.IGNORECASE | re.DOTALL,
)
_POINT_RE = re.compile(
    r"^(?P<x>\d+)\s*,\s*(?P<y>\d+)"
    r"(?:\s+box=(?P<x1>\d+)\s*,\s*(?P<y1>\d+)\s*,\s*(?P<x2>\d+)\s*,\s*(?P<y2>\d+))?"
    r"(?:\s+(?P<path>/\S+))?\s*$"
)


_ENABLED_THEN_CLICK = re.compile(
    r"\bwait\s+max\s+(?P<seconds>\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?\s+"
    r"(?P<name>.+?)\s+enabled\s+and\s+then\s+click\s+(?P<click>.+?)\s*\.?\s*$",
    re.IGNORECASE,
)
_CLICK_IF_EXISTS = re.compile(
    r"^(?:wait\s+(?P<seconds>\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?\s+and\s+)?"
    r"click\s+(?P<name>.+?)\s+if\s+(?:it\s+)?exists\s*\.?\s*$",
    re.IGNORECASE,
)
_ENABLED_CONTROLS_JS = r"""
(name) => {
  const wanted = String(name || "").replace(/\s+/g, " ").trim().toLowerCase();
  const seenRoots = new Set();
  const out = [];
  const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
  const labelOf = (e) => clean(e.getAttribute("aria-label"));
  const textOf = (e) =>
    clean([...e.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join(" "));
  const matches = (e) => {
    const label = labelOf(e).toLowerCase();
    const text = textOf(e).toLowerCase();
    if (label === wanted || text === wanted) return true;
    if (wanted !== "close") return false;
    const icon = clean(e.getAttribute("icon")).toLowerCase();
    const id = clean(e.id).toLowerCase();
    return icon === "close" || id === "ytcp-uploads-dialog-close-button" || id.endsWith("close-button");
  };
  const turnedOff = (e) =>
    !!e &&
    (e.getAttribute("aria-disabled") === "true" || e.disabled === true || e.hasAttribute("disabled"));
  const disabledOf = (e) => {
    if (turnedOff(e)) return true;
    try {
      if (e.matches(":disabled")) return true;
    } catch (err) {}
    const inner = typeof e.querySelector === "function" ? e.querySelector("button") : null;
    return turnedOff(inner);
  };
  const visit = (root) => {
    if (!root || seenRoots.has(root) || typeof root.querySelectorAll !== "function") return;
    seenRoots.add(root);
    for (const e of root.querySelectorAll("button,[role='button'],ytcp-button,ytcp-icon-button")) {
      if (!matches(e)) continue;
      const r = e.getBoundingClientRect();
      out.push({
        id: e.id || "",
        tag: e.localName || "",
        label: labelOf(e) || textOf(e),
        disabled: disabledOf(e),
        x: r.x,
        y: r.y,
        w: r.width,
        h: r.height,
      });
    }
    for (const e of root.querySelectorAll("*")) {
      if (e.shadowRoot) visit(e.shadowRoot);
    }
  };
  visit(document);
  return out;
}
"""


def enabled_click_command(command: str) -> tuple[str, float] | None:
    """`wait max 10s Close enabled and then Click Close` is a name and a timeout."""
    match = _ENABLED_THEN_CLICK.search(_command_body(command))
    if not match:
        return None
    name = match.group("name").strip().strip("\"'")
    click = match.group("click").strip().strip("\"'")
    if not name or name.casefold() != click.casefold():
        return None
    try:
        return name, max(0.0, float(match.group("seconds")))
    except ValueError:
        return None


def _control_key(item: dict[str, Any]) -> str:
    ident = str(item.get("id") or "").strip()
    if ident:
        return "id:" + ident
    return "at:{:.0f},{:.0f}".format(float(item.get("x") or 0), float(item.get("y") or 0))


def _visible_control(item: dict[str, Any]) -> bool:
    return float(item.get("w") or 0) >= 8 and float(item.get("h") or 0) >= 8


def _prefer_enabled(items: list[dict[str, Any]]) -> dict[str, Any]:
    for item in items:
        if item.get("id") == "ytcp-uploads-dialog-close-button":
            return item
    labeled = [item for item in items if str(item.get("label") or "").strip()]
    return (labeled or items)[0]


def choose_enabled_click(
    matches: list[Any],
    pending: set[str],
) -> tuple[str, dict[str, Any] | None, set[str]]:
    """Click a visible match that is already enabled. Wait only when every match is disabled."""
    visible = [item for item in matches if isinstance(item, dict) and _visible_control(item)]
    disabled = [item for item in visible if item.get("disabled")]
    enabled = [item for item in visible if not item.get("disabled")]
    if enabled:
        ready = [item for item in enabled if _control_key(item) in pending] if pending else []
        return "click", _prefer_enabled(ready or enabled), set(pending)
    if disabled:
        return "wait", None, {_control_key(item) for item in disabled} | set(pending)
    return "wait", None, set(pending)


def wait_until_enabled_then_click(
    command: str,
    tab: Any,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Wait until the named control is enabled, then click that same control."""
    parsed = enabled_click_command(command)
    if parsed is None:
        raise ValueError(f"not an enabled click: {command}")
    name, seconds = parsed
    actions = [
        {
            "operation": "WAIT",
            "label": name,
            "seconds": seconds,
            "message": f"Wait until {name} is enabled, up to {seconds:g}s",
        },
        {"operation": "CLICK", "label": name, "message": f"Click {name}"},
    ]
    if dry_run:
        print(f"DRY-RUN wait until {name} is enabled, up to {seconds:g}s, then click {name}", flush=True)
        return _enabled_click_result(command, actions, dry_run=True, status="dry-run", message="")
    if tab is None:
        raise RuntimeError("enabled click needs a tab")
    live = _live_page(tab)
    print(f"Waiting up to {seconds:g}s until {name} is enabled.", flush=True)
    pending: set[str] = set()
    deadline = time.time() + seconds
    chosen: dict[str, Any] | None = None
    while True:
        found = live.evaluate(_ENABLED_CONTROLS_JS, name)
        matches = found if isinstance(found, list) else []
        action, picked, pending = choose_enabled_click(matches, pending)
        if action == "click" and picked is not None:
            chosen = picked
            break
        if time.time() >= deadline:
            break
        time.sleep(0.25)
    if chosen is None:
        message = f"{name} is not enabled."
        print(message, flush=True)
        return _enabled_click_result(command, actions, dry_run=False, status="blocked", message=message)
    _click_enabled_control(live, chosen)
    print(f"Click {name}", flush=True)
    page = _read_tab(tab) if hasattr(tab, "observe") or hasattr(tab, "evaluate") else {}
    return _enabled_click_result(command, actions, dry_run=False, status="done", message=f"Clicked {name}.", page=page)


def _click_enabled_control(page: Any, item: dict[str, Any]) -> None:
    ident = str(item.get("id") or "").strip()
    if ident:
        page.locator("#" + ident).click(timeout=3000, force=True)
        return
    page.mouse.click(
        float(item.get("x") or 0) + float(item.get("w") or 0) / 2,
        float(item.get("y") or 0) + float(item.get("h") or 0) / 2,
    )


_SPECIAL_KEYS = {
    "enter": "Enter",
    "return": "Enter",
    "esc": "Escape",
    "escape": "Escape",
    "tab": "Tab",
    "backspace": "Backspace",
    "delete": "Delete",
    "del": "Delete",
    "space": "Space",
    "up": "ArrowUp",
    "down": "ArrowDown",
    "left": "ArrowLeft",
    "right": "ArrowRight",
    "arrowup": "ArrowUp",
    "arrowdown": "ArrowDown",
    "arrowleft": "ArrowLeft",
    "arrowright": "ArrowRight",
    "home": "Home",
    "end": "End",
    "pageup": "PageUp",
    "pagedown": "PageDown",
}
_KEY_MODIFIERS = {
    "shift": "Shift",
    "control": "Control",
    "ctrl": "Control",
    "alt": "Alt",
    "meta": "Meta",
    "command": "Meta",
    "cmd": "Meta",
}


def _press_token(token: str) -> str | None:
    """Playwright key name for `^Enter`, `^esc`, or `^Shift+Enter`. None for ordinary text."""
    parts = [part for part in token.split("+") if part]
    if not parts:
        return None
    names: list[str] = []
    for part in parts:
        folded = part.casefold()
        modifier = _KEY_MODIFIERS.get(folded)
        if modifier:
            names.append(modifier)
            continue
        special = _SPECIAL_KEYS.get(folded)
        if special:
            names.append(special)
            continue
        if len(part) == 1:
            names.append(part.upper() if part.isalpha() else part)
            continue
        return None
    if not names:
        return None
    return "+".join(names)


def _send_pieces(text: str) -> list[tuple[str, str]]:
    """`Oct 15 ^Enter` is typed text, then the Enter key. A caret marks a key name."""
    pieces: list[tuple[str, str]] = []
    words: list[str] = []
    for token in text.split():
        if token.startswith("^") and len(token) > 1:
            if words:
                pieces.append(("type", " ".join(words)))
                words = []
            name = _press_token(token[1:])
            if name is None:
                raise ValueError(f"unknown key {token}")
            pieces.append(("press", name))
            continue
        words.append(token)
    if words:
        pieces.append(("type", " ".join(words)))
    return pieces


def click_locator_command(command: str) -> str | None:
    """`Click locator #time-of-day-container input` is a Playwright selector, not a visible name."""
    body = _command_body(command).strip()
    match = re.match(r"^click\s+locator\s+(?P<selector>.+?)\s*$", body, re.IGNORECASE)
    if not match:
        return None
    selector = match.group("selector").strip()
    if len(selector) >= 2 and selector[0] == selector[-1] and selector[0] in "\"'":
        selector = selector[1:-1].strip()
    if not selector:
        raise ValueError("click locator needs a selector")
    return selector


def run_click_locator(ctx: dict[str, Any], command: str) -> dict[str, Any]:
    """Click the first match of a Playwright locator. The visible label is not used."""
    selector = click_locator_command(command)
    if selector is None:
        raise ValueError(f"not a locator click: {command}")
    print(f"CLICK {selector}", flush=True)
    inputs = {"command": command, "locator": selector}
    if ctx.get("dry_run"):
        return {"inputs": inputs, "outputs": {"status": "dry-run", "locator": selector}}
    browser = ctx.get("browser")
    page = getattr(browser, "page", None) if browser is not None else None
    if page is None or not hasattr(page, "locator"):
        raise RuntimeError("click locator needs an open page")
    try:
        page.locator(selector).first.click(timeout=5000)
    except Exception as exc:
        raise RuntimeError(f"could not click {selector}: {exc}") from exc
    return {"inputs": inputs, "outputs": {"status": "ok", "locator": selector}}


def sendkeys_command(command: str) -> tuple[bool, str] | None:
    """`sendkeys clear then $post_date` clears the focused field, then types.

    `sendkeys clear` only deletes. `sendkeys $post_date` only types.
    `sendkeys ^Enter` presses that key. `sendkeys Enter` types the word.
    """
    body = _command_body(command).strip()
    match = re.match(r"^sendkeys\b\s*(?P<rest>.*?)\s*$", body, re.IGNORECASE)
    if not match:
        return None
    rest = (match.group("rest") or "").strip()
    if not rest:
        raise ValueError("sendkeys needs clear, text, or clear then text")
    cleared = re.match(r"^clear(?:\s+then\s+(?P<text>.*?))?\s*$", rest, re.IGNORECASE)
    if cleared:
        return True, (cleared.group("text") or "").strip().rstrip(".")
    return False, rest.rstrip(".")


def run_sendkeys(ctx: dict[str, Any], command: str) -> dict[str, Any]:
    """Delete the focused field when asked, then send the keys. No textbox lookup."""
    from .terminal import expand_command

    parsed = sendkeys_command(command)
    if parsed is None:
        raise ValueError(f"not a sendkeys step: {command}")
    clear, text = parsed
    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}
    keys = expand_command(text, env, variables).strip() if text else ""
    if text and re.search(r"\$\{?\w+\}?", keys):
        raise RuntimeError(f"sendkeys could not read {text}")
    pieces = _send_pieces(keys) if keys else []
    inputs = {"command": command, "clear": clear, "keys": keys}
    if clear and keys:
        shown = f"clear then {keys}"
    elif clear:
        shown = "clear"
    else:
        shown = keys
    print(f"SENDKEYS {shown}", flush=True)
    if ctx.get("dry_run"):
        return {"inputs": inputs, "outputs": {"status": "dry-run", "clear": clear, "keys": keys}}
    browser = ctx.get("browser")
    page = getattr(browser, "page", None) if browser is not None else None
    if page is None or not hasattr(page, "keyboard"):
        raise RuntimeError("sendkeys needs an open page")
    if clear:
        page.keyboard.press("Meta+A")
        page.keyboard.press("Backspace")
    for kind, value in pieces:
        if kind == "press":
            page.keyboard.press(value)
        else:
            page.keyboard.type(value, delay=20)
    return {"inputs": inputs, "outputs": {"status": "ok", "clear": clear, "keys": keys}}


def click_if_exists_command(command: str) -> tuple[str, float] | None:
    """`wait 2s and click Post Now if it exists` is a pause, then an optional click."""
    match = _CLICK_IF_EXISTS.match(_command_body(command))
    if not match:
        return None
    name = _optional_click_name(match.group("name") or "")
    if not name:
        return None
    raw = match.group("seconds")
    try:
        seconds = 0.0 if raw is None else max(0.0, float(raw))
    except ValueError:
        return None
    return name, seconds


def _optional_click_name(raw: str) -> str:
    name = raw.strip().strip("\"'")
    name = re.sub(r"^the\s+", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\s+button$", "", name, flags=re.IGNORECASE)
    return name.strip().strip("\"'")


def choose_existing_click(matches: list[Any]) -> dict[str, Any] | None:
    """Pick a visible control. An enabled one is used when any match is enabled."""
    visible = [item for item in matches if isinstance(item, dict) and _visible_control(item)]
    if not visible:
        return None
    enabled = [item for item in visible if not item.get("disabled")]
    pool = enabled or visible
    labeled = [item for item in pool if str(item.get("label") or "").strip()]
    return (labeled or pool)[0]


def click_if_exists(
    command: str,
    tab: Any,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Wait, then click the named control when it is on the page.

    A missing control is a finished step. The workflow continues.
    """
    parsed = click_if_exists_command(command)
    if parsed is None:
        raise ValueError(f"not a click if exists: {command}")
    name, seconds = parsed
    actions: list[dict[str, Any]] = []
    if seconds:
        actions.append(
            {
                "operation": "WAIT",
                "seconds": seconds,
                "message": f"Wait {seconds:g}s",
            }
        )
    actions.append(
        {
            "operation": "CLICK",
            "label": name,
            "optional": True,
            "message": f"Click {name} if it exists",
        }
    )
    if dry_run:
        waited = f"wait {seconds:g}s and " if seconds else ""
        print(f"DRY-RUN {waited}click {name} if it exists", flush=True)
        result = _enabled_click_result(command, actions, dry_run=True, status="dry-run", message="")
        result["outputs"]["clicked"] = False
        return result
    if tab is None:
        raise RuntimeError("click if exists needs a tab")
    if seconds:
        print(f"Waiting {seconds:g}s.", flush=True)
        time.sleep(seconds)
    live = _live_page(tab)
    found = live.evaluate(_EXISTING_CONTROLS_JS, name)
    matches = found if isinstance(found, list) else []
    chosen = choose_existing_click(matches)
    page = _read_tab(tab) if hasattr(tab, "observe") or hasattr(tab, "evaluate") else {}
    if chosen is None:
        message = f"{name} is not on the page."
        print(message, flush=True)
        result = _enabled_click_result(command, actions, dry_run=False, status="done", message=message, page=page)
        result["outputs"]["clicked"] = False
        return result
    _click_enabled_control(live, chosen)
    print(f"Click {name}", flush=True)
    page = _read_tab(tab) if hasattr(tab, "observe") or hasattr(tab, "evaluate") else page
    result = _enabled_click_result(
        command,
        actions,
        dry_run=False,
        status="done",
        message=f"Clicked {name}.",
        page=page,
    )
    result["outputs"]["clicked"] = True
    return result


_EXISTING_CONTROLS_JS = r"""
(name) => {
  const wanted = String(name || "").replace(/\s+/g, " ").trim().toLowerCase();
  const seenRoots = new Set();
  const out = [];
  const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
  const labelOf = (e) => clean(e.getAttribute("aria-label"));
  const textOf = (e) => {
    try {
      return clean(e.innerText);
    } catch (err) {
      return clean(e.textContent);
    }
  };
  const matches = (e) => {
    const label = labelOf(e).toLowerCase();
    const text = textOf(e).toLowerCase();
    return label === wanted || text === wanted;
  };
  const turnedOff = (e) =>
    !!e &&
    (e.getAttribute("aria-disabled") === "true" || e.disabled === true || e.hasAttribute("disabled"));
  const disabledOf = (e) => {
    if (turnedOff(e)) return true;
    try {
      if (e.matches(":disabled")) return true;
    } catch (err) {}
    const inner = typeof e.querySelector === "function" ? e.querySelector("button") : null;
    return turnedOff(inner);
  };
  const visit = (root) => {
    if (!root || seenRoots.has(root) || typeof root.querySelectorAll !== "function") return;
    seenRoots.add(root);
    for (const e of root.querySelectorAll("button,[role='button']")) {
      if (!matches(e)) continue;
      const r = e.getBoundingClientRect();
      out.push({
        id: e.id || "",
        tag: e.localName || "",
        label: labelOf(e) || textOf(e),
        disabled: disabledOf(e),
        x: r.x,
        y: r.y,
        w: r.width,
        h: r.height,
      });
    }
    for (const e of root.querySelectorAll("*")) {
      if (e.shadowRoot) visit(e.shadowRoot);
    }
  };
  visit(document);
  return out;
}
"""


def _enabled_click_result(
    command: str,
    actions: list[dict[str, Any]],
    *,
    dry_run: bool,
    status: str,
    message: str,
    page: dict[str, Any] | None = None,
) -> dict[str, Any]:
    seen = page or {}
    return {
        "command": command,
        "dry_run": dry_run,
        "status": status,
        "executed": status == "done",
        "blocked": status == "blocked",
        "message": message,
        "actions": actions,
        "page": {"url": str(seen.get("url") or ""), "title": str(seen.get("title") or "")},
        "outputs": {"status": status, "message": message, "actions": actions},
    }


def locate_click_command(command: str) -> bool:
    """True for a page locate, `click $loc`, or `click 1883,1506 ...`.

    `/browser /locate "arrow"` screenshots the open page and runs LocateAnything.
    `and click` clicks that center. Neither form asks Jev.
    """
    body = _command_body(command)
    return _LOCATE_PAGE_RE.match(body) is not None or _CLICK_LOCATE_RE.match(body) is not None


def css_from_image(
    x: float,
    y: float,
    *,
    image_width: float,
    image_height: float,
    viewport_width: float,
    viewport_height: float,
    dpr: float,
) -> tuple[float, float]:
    """Map screenshot pixels onto the CSS pixels `page.mouse.click` uses."""
    if image_width > 0 and image_height > 0 and viewport_width > 0 and viewport_height > 0:
        return x * viewport_width / image_width, y * viewport_height / image_height
    scale = dpr if dpr > 0 else 1.0
    return x / scale, y / scale


def click_located(
    command: str,
    tab: Any,
    *,
    dry_run: bool = False,
    env: dict[str, str] | None = None,
    variables: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Locate a phrase on the open page, or click a saved locate result.

    `/browser /locate "arrow"` screenshots the page and runs LocateAnything.
    `and click` also clicks the center. `click $loc` clicks a stored position.
    """
    body = _command_body(command)
    names = variables if isinstance(variables, dict) else {}
    merged = {**os.environ, **(env or {})}
    query, click = _locate_page(body)
    if query:
        return _locate_on_page(query, tab, dry_run=dry_run, env=merged, click=click)
    point = _saved_point(body, names)
    if point is None:
        raise ValueError(f"not a locate click: {command}")
    return _click_point(point, tab, dry_run=dry_run, label=body)


def _locate_page(body: str) -> tuple[str, bool]:
    """The phrase in `/browser /locate "phrase"`, and whether to click it."""
    match = _LOCATE_PAGE_RE.match(body)
    if not match:
        return "", False
    query = (match.group("q1") or match.group("q2") or match.group("q3") or "").strip()
    return query, bool(match.group("click"))


def _saved_point(body: str, variables: dict[str, Any]) -> dict[str, Any] | None:
    match = _CLICK_LOCATE_RE.match(body)
    if not match:
        return None
    name = match.group("braced") or match.group("name")
    if name:
        if name not in variables:
            raise ValueError(f"${name} is not set")
        point = _point_from_value(variables[name])
        if point is None:
            raise ValueError(f"${name} is not a locate position")
        return point
    return _point_from_value(match.group("point") or "")


def _point_from_value(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict) and value.get("x") is not None and value.get("y") is not None:
        point = {
            "x": float(value["x"]),
            "y": float(value["y"]),
            "width": float(value.get("width") or 0),
            "height": float(value.get("height") or 0),
            "image": str(value.get("image") or value.get("marked") or ""),
        }
        if point["width"] <= 0 or point["height"] <= 0:
            width, height = _image_size(point["image"])
            point["width"] = point["width"] or width
            point["height"] = point["height"] or height
        return point
    text = str(value or "").strip()
    match = _POINT_RE.match(text)
    if not match:
        return None
    image = match.group("path") or ""
    width, height = _image_size(image)
    return {
        "x": float(match.group("x")),
        "y": float(match.group("y")),
        "width": width,
        "height": height,
        "image": image,
    }


def _image_size(path: str) -> tuple[float, float]:
    if not path or not Path(path).is_file():
        return 0.0, 0.0
    try:
        from PIL import Image

        with Image.open(path) as image:
            return float(image.size[0]), float(image.size[1])
    except Exception:
        return 0.0, 0.0


def _live_page(tab: Any) -> Any:
    live = getattr(tab, "page", None)
    if live is None or not hasattr(live, "mouse"):
        raise RuntimeError("locate click needs a Playwright page")
    return live


def _viewport(page: Any) -> dict[str, float]:
    size = page.evaluate(
        "() => ({w: window.innerWidth, h: window.innerHeight, dpr: window.devicePixelRatio || 1})"
    )
    if not isinstance(size, dict):
        return {"w": 0.0, "h": 0.0, "dpr": 1.0}
    return {
        "w": float(size.get("w") or 0),
        "h": float(size.get("h") or 0),
        "dpr": float(size.get("dpr") or 1) or 1.0,
    }


def _click_point(point: dict[str, Any], tab: Any, *, dry_run: bool, label: str) -> dict[str, Any]:
    page = {} if tab is None or dry_run else _read_tab(tab)
    if dry_run or tab is None:
        print(f"DRY-RUN CLICK {point['x']:.0f},{point['y']:.0f}")
        return _locate_click_result(
            label,
            point,
            None,
            page,
            dry_run=True,
            status="dry-run",
        )
    live = _live_page(tab)
    view = _viewport(live)
    css_x, css_y = css_from_image(
        point["x"],
        point["y"],
        image_width=point["width"],
        image_height=point["height"],
        viewport_width=view["w"],
        viewport_height=view["h"],
        dpr=view["dpr"],
    )
    print(f"CLICK {css_x:.0f},{css_y:.0f} from {point['x']:.0f},{point['y']:.0f}", flush=True)
    live.mouse.click(css_x, css_y)
    return _locate_click_result(label, point, (css_x, css_y), _read_tab(tab), dry_run=False, status="done")


def _locate_shot_path(env: dict[str, str]) -> Path:
    """Page shot for LocateAnything. A run keeps it beside the step JSON."""
    log_json = Path(str(env.get("CG_LOOP_STEP_JSON") or ""))
    if log_json.suffix == ".json":
        log_json.parent.mkdir(parents=True, exist_ok=True)
        return log_json.with_suffix(".jpg")
    folder = Path(env.get("DATA") or env.get("CG_LOOP_DATA") or "")
    if not str(folder):
        import tempfile

        folder = Path(tempfile.mkdtemp(prefix="cg-locate-"))
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "locate-page.jpg"


def _locate_on_page(
    query: str,
    tab: Any,
    *,
    dry_run: bool,
    env: dict[str, str],
    click: bool,
) -> dict[str, Any]:
    """Screenshot the open page and run LocateAnything. Click when the step says so."""
    label = f"locate {query}" + (" and click" if click else "")
    if dry_run or tab is None:
        print(f"DRY-RUN LOCATE {query}" + (" and click" if click else ""))
        return _locate_click_result(
            label,
            {"x": 0, "y": 0, "query": query},
            None,
            {},
            dry_run=True,
            status="dry-run",
            operation="CLICK" if click else "LOCATE",
        )
    live = _live_page(tab)
    shot = _locate_shot_path(env)
    shot.write_bytes(live.screenshot(type="jpeg", quality=90))
    from .locate import locate_image

    try:
        found = locate_image(query, str(shot), env)
    except Exception as exc:
        message = str(exc)
        print(f"BLOCKED {message}", flush=True)
        return _locate_click_result(
            label,
            {"x": 0, "y": 0, "image": str(shot), "query": query},
            None,
            _read_tab(tab),
            dry_run=False,
            status="blocked",
            message=message,
            operation="CLICK" if click else "LOCATE",
        )
    if not found.get("box"):
        message = f"no position for {query!r}"
        raw = str(found.get("raw") or "").strip()
        if raw:
            message = f"{message}: {raw}"
        print(f"BLOCKED {message}", flush=True)
        return _locate_click_result(
            label,
            found,
            None,
            _read_tab(tab),
            dry_run=False,
            status="blocked",
            message=message,
            operation="CLICK" if click else "LOCATE",
        )
    point = {
        "x": float(found["x"]),
        "y": float(found["y"]),
        "width": float(found.get("width") or 0),
        "height": float(found.get("height") or 0),
        "image": str(found.get("marked") or found.get("image") or shot),
        "query": query,
        "text": found.get("text") or "",
    }
    if not click:
        print(f"LOCATE {query} -> {point['text']}", flush=True)
        return _finish_locate(label, point, found, shot, tab, click=False)
    clicked = _click_point(point, tab, dry_run=False, label=label)
    return _with_locate_shots(clicked, found, shot)


def _finish_locate(
    label: str,
    point: dict[str, Any],
    found: dict[str, Any],
    shot: Path,
    tab: Any,
    *,
    click: bool,
) -> dict[str, Any]:
    result = _locate_click_result(
        label,
        point,
        None,
        _read_tab(tab),
        dry_run=False,
        status="done",
        operation="CLICK" if click else "LOCATE",
    )
    return _with_locate_shots(result, found, shot)


def _with_locate_shots(result: dict[str, Any], found: dict[str, Any], shot: Path) -> dict[str, Any]:
    shots = [str(item) for item in (result["outputs"].get("screenshots") or [])]
    marked = str(found.get("marked") or "")
    if marked and marked not in shots:
        shots.append(marked)
    if str(shot) not in shots:
        shots.insert(0, str(shot))
    result["outputs"]["screenshots"] = shots
    result["outputs"]["locate"] = found.get("text") or ""
    return result


def _locate_click_result(
    label: str,
    point: dict[str, Any],
    css: tuple[float, float] | None,
    page: dict[str, Any],
    *,
    dry_run: bool,
    status: str,
    message: str = "",
    operation: str = "CLICK",
) -> dict[str, Any]:
    action = {
        "operation": operation,
        "kind": "click" if operation == "CLICK" else "locate",
        "label": label,
        "x": None if css is None else css[0],
        "y": None if css is None else css[1],
        "image_x": point.get("x"),
        "image_y": point.get("y"),
    }
    shots = [str(point["image"])] if point.get("image") else []
    outputs: dict[str, Any] = {
        "status": status,
        "steps": [label],
        "actions": [action],
        "message": message,
        "screenshots": shots,
    }
    if point.get("text"):
        outputs["locate"] = point["text"]
    return {
        "command": label,
        "dry_run": dry_run,
        "status": status,
        "executed": status == "done",
        "blocked": status == "blocked",
        "message": message,
        "actions": [action],
        "page": {
            "url": str(page.get("url") or ""),
            "title": str(page.get("title") or ""),
            "text": str(page.get("text") or ""),
        },
        "inputs": {"command": label},
        "outputs": outputs,
    }


def _showing_phrase(command: str) -> str:
    match = _WAIT_EXIST.search(_command_body(command))
    if not match:
        return ""
    return re.sub(r"\s+text$", "", match.group(2).strip(), flags=re.IGNORECASE).strip(" .")


def _wait_seconds(command: str, default: float = 2.0) -> float:
    match = _WAIT_EXIST.search(_command_body(command))
    if not match or not match.group(1):
        return default
    try:
        return max(0.0, float(match.group(1)))
    except ValueError:
        return default


def _names_a_control(phrase: str) -> bool:
    """`Close button` is a button named Close, not the words Close button."""
    return bool(
        re.fullmatch(
            r"(?:the\s+)?.+?\s+(?:button|radio|link|checkbox|tab|switch)",
            (phrase or "").strip(),
            flags=re.IGNORECASE,
        )
    )


def _clean_wait_phrase(phrase: str) -> str:
    text = phrase.strip().strip(" .")
    text = re.sub(r"\s+is showing$", "", text, flags=re.IGNORECASE).strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
        text = text[1:-1].strip()
    return text


_VERIFY_WAIT = re.compile(
    r"\bverify\s+(?P<phrase>.+?)\s+max\s+(?P<seconds>\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?\b",
    re.IGNORECASE,
)
_VERIFY_BARE = re.compile(
    r"\bverify\s+(?P<phrase>.+?)\s*$",
    re.IGNORECASE,
)


def _command_mentions_wait(command: str) -> bool:
    """True when the step itself says to wait or verify."""
    return re.search(r"\b(?:wait|verify)\b", _command_body(command), re.IGNORECASE) is not None


def _followup_wait_after_click(command: str, done: list[dict[str, Any]]) -> bool:
    """A plain click does not then wait for that button to remain on the page.

    Clicking Schedule opens a dialog and hides the button. The click already finished the step.
    """
    if _command_mentions_wait(command):
        return False
    return any(str(item.get("operation") or "").upper() == "CLICK" for item in done)


def _verify_clause(command: str) -> tuple[str, float] | None:
    """`verify Content max 10s` is a phrase and a timeout. `verify Date` waits 5s."""
    match = _VERIFY_WAIT.search(_command_body(command))
    if match:
        phrase = _clean_wait_phrase(match.group("phrase"))
        if not phrase:
            return None
        try:
            return phrase, max(0.0, float(match.group("seconds")))
        except ValueError:
            return None
    bare = _VERIFY_BARE.search(_command_body(command))
    if not bare:
        return None
    phrase = _clean_wait_phrase(bare.group("phrase"))
    if not phrase:
        return None
    return phrase, 5.0


def _text_phrase(command: str) -> tuple[str, float] | None:
    """The page-text check in this step, when it does not name a control."""
    found = _verify_clause(command) or _text_wait(command)
    if found is None or _names_a_control(found[0]):
        return None
    return found


def _verify_as_wait(command: str) -> str:
    """`verify Content max 10s` is the same wait as `wait max 10s until Content`."""

    def repl(match: re.Match[str]) -> str:
        phrase = match.group("phrase").strip().strip(".")
        return f"wait max {match.group('seconds')}s until {phrase}"

    rewritten = _VERIFY_WAIT.sub(repl, command or "")

    def bare(match: re.Match[str]) -> str:
        phrase = match.group("phrase").strip().strip(".")
        return f"wait max 5s until {phrase}"

    return _VERIFY_BARE.sub(bare, rewritten)


def _type_instead_of_blocked(command: str, decision: dict[str, Any]) -> dict[str, Any] | None:
    """Type into the field the step names when that field is offered.

    Jev reports BLOCKED as "the named control is not on the page" even when the
    field is in the snapshot. `into AM PM` names that spinbutton.
    """
    from .model import _locator_priority, _priority_names

    named = _priority_names(command)
    group = decision.get("targets") if isinstance(decision.get("targets"), dict) else {}
    typed = group.get("TYPE_TEXT") if isinstance(group.get("TYPE_TEXT"), dict) else {}
    matches = [
        (str(key), action)
        for key, action in typed.items()
        if isinstance(action, dict) and _locator_priority(action, named) == "likely"
    ]
    if len(matches) != 1:
        return None
    key, action = matches[0]
    selector = str(action.get("selector_key") or action.get("selector") or key)
    target = key if key.startswith("role=") else selector
    return {
        **decision,
        "operation": "TYPE_TEXT",
        "target": target,
        "choice": action.get("id") or target,
        "message": "",
    }


def _prefer_named_label(
    command: str,
    resolved: dict[str, Any],
    targets: dict[str, Any],
) -> dict[str, Any]:
    """Use the one control whose label is the click the step names."""
    from .model import _locator_priority, _priority_names

    named = _priority_names(command)
    if _locator_priority(resolved, named) == "likely":
        return resolved
    group = targets.get("CLICK") if isinstance(targets.get("CLICK"), dict) else {}
    matches = [
        action
        for action in (group or {}).values()
        if isinstance(action, dict) and _locator_priority(action, named) == "likely"
    ]
    if len(matches) == 1:
        return dict(matches[0])
    return resolved


def _clause_positions(command: str) -> tuple[int | None, int | None]:
    """Start of the click or go, and start of the verify or wait, after `until click` is ignored."""
    body = _verify_as_wait(_command_body(command))
    masked = re.sub(
        r"\bwait\s+max\s+\d+(?:\.\d+)?\s*s(?:ec(?:ond)?s?)?\s+until\s+click\b",
        "wait",
        body,
        flags=re.IGNORECASE,
    )
    action = re.search(r"\bgo(?:\s+to)?\s+\S+|\bclick\b", masked, re.IGNORECASE)
    waiting = re.search(r"\bwait\s+max\b|\bverify\b", masked, re.IGNORECASE)
    return (
        None if action is None else action.start(),
        None if waiting is None else waiting.start(),
    )


def _page_action_before_wait(command: str) -> bool:
    """The click or go comes before verify or wait, so that action is first."""
    action_at, wait_at = _clause_positions(command)
    return action_at is not None and (wait_at is None or action_at < wait_at)


def _wait_before_page_action(command: str) -> bool:
    """Verify or wait comes before the click or go, so the check is first."""
    action_at, wait_at = _clause_positions(command)
    return wait_at is not None and action_at is not None and wait_at < action_at


def _text_wait(command: str) -> tuple[str, float] | None:
    """`Wait max Ns until Content` or `verify Content max Ns` when the line does not name a role click.

    A role click uses WAIT_FOR_LOCATOR. This phrase is page text after a go-to or a click.
    """
    body = _verify_as_wait(_command_body(command))
    match = re.search(
        r"\bwait\s+max\s+(\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?\s+until\s+"
        r"(.+?)(?=\s+(?:click|go)\b|\s*[.]?\s*$)",
        body,
        re.IGNORECASE,
    )
    if not match:
        return None
    from .model import _wait_until_role

    if _wait_until_role(body):
        return None
    if _page_action_before_wait(body) and re.search(
        r"\bclick\s+(?:the\s+)?.+?\s+(?:button|radio|link|checkbox|tab|switch)\b",
        body,
        re.IGNORECASE,
    ):
        return None
    phrase = _clean_wait_phrase(match.group(2))
    if not phrase or re.match(r"click\b", phrase, re.IGNORECASE):
        return None
    try:
        return phrase, max(0.0, float(match.group(1)))
    except ValueError:
        return None


def _duration_wait(command: str) -> float | None:
    """`wait 1s` is a pause. `wait max 10s until` is a phrase, not this."""
    body = _command_body(command)
    if re.search(r"\bwait\s+max\b", body, re.IGNORECASE):
        return None
    match = _DURATION_WAIT.search(body)
    if not match:
        return None
    try:
        return max(0.0, float(match.group(1)))
    except ValueError:
        return None


def _only_duration_wait(command: str) -> float | None:
    """`Wait 5s` is the whole command. It sleeps and does not check the page."""
    body = _command_body(command).strip()
    if not re.fullmatch(r"wait\s+\d+(?:\.\d+)?\s*s(?:ec(?:ond)?s?)?\.?", body, re.IGNORECASE):
        return None
    return _duration_wait(command)


def _duration_action(seconds: float) -> dict[str, Any]:
    return {
        "operation": "WAIT",
        "selector": "",
        "target": f"{seconds:g}s",
        "choice": "WAIT",
        "id": "WAIT",
        "kind": "wait",
        "label": f"Wait {seconds:g}s",
        "node": None,
        "text": None,
        "message": f"Wait {seconds:g}s",
        "confidence": 1,
        "seconds": seconds,
    }


def _sleep_wait(
    tab: Any,
    seconds: float,
    page: dict[str, Any],
    *,
    dry_run: bool,
) -> tuple[dict[str, Any], dict[str, Any], str, str]:
    waited = _recorded("WAIT", f"{seconds:g}s", kind="wait", message=f"Wait {seconds:g}s")
    waited["seconds"] = seconds
    waited["selector"] = ""
    if dry_run:
        return waited, page, "done", ""
    print(f"Waiting {seconds:g}s.", flush=True)
    time.sleep(seconds)
    return waited, _read_tab(tab) if tab is not None else page, "done", f"Waited {seconds:g}s."


def _pause_only(command: str, tab: Any, seconds: float, *, dry_run: bool) -> dict[str, Any]:
    """Sleep for a bare `Wait 5s`. The page is not read for a phrase or a control."""
    action = _duration_action(seconds)
    if dry_run:
        return _enabled_click_result(command, [action], dry_run=True, status="dry-run", message="")
    print(f"Waiting {seconds:g}s.", flush=True)
    time.sleep(seconds)
    page = _read_tab(tab) if tab is not None else {}
    return _enabled_click_result(
        command,
        [action],
        dry_run=False,
        status="done",
        message=f"Waited {seconds:g}s.",
        page=page,
    )


def _wait_seconds_value(resolved: dict[str, Any], item: dict[str, Any], default: float = 5.0) -> float:
    raw = resolved.get("seconds", item.get("seconds"))
    if raw in (None, ""):
        return default
    try:
        return max(0.0, float(raw))
    except (TypeError, ValueError):
        return default


def _wait_target(command: str, resolved: dict[str, Any], item: dict[str, Any]) -> tuple[str, float]:
    """The phrase and cap on the WAIT action Jev returned."""
    phrase = str(resolved.get("phrase") or item.get("phrase") or "")
    seconds = _wait_seconds_value(resolved, item)
    duration = _duration_wait(command)
    if duration is not None:
        seconds = duration
    if phrase:
        return phrase, seconds
    waiting = _text_wait(command)
    if waiting:
        return waiting
    quoted = _WAIT_FOR_SHOW.search(_command_body(command))
    if quoted and quoted.group(1).strip():
        return quoted.group(1).strip(), seconds
    shown = _showing_phrase(command)
    if shown:
        return shown, _wait_seconds(command)
    return "", seconds


def _settle_showing(
    tab: Any,
    phrase: str,
    page: dict[str, Any],
    *,
    dry_run: bool,
    seconds: float = 2.0,
) -> tuple[str, str, dict[str, Any]]:
    if not phrase:
        return "done", "", page
    if _phrase_visible(page, phrase):
        print("already there", flush=True)
        return "done", "already there", page
    if not dry_run:
        deadline = time.time() + seconds
        while time.time() < deadline:
            time.sleep(0.25)
            page = _read_tab(tab)
            if _phrase_visible(page, phrase):
                break
    if _phrase_visible(page, phrase):
        return "done", f"{phrase} is showing.", page
    return "blocked", f"{phrase} is not showing.", page


def _command_url(command: str) -> str:
    """The address in `go https://...` or `go to studio.youtube.com`."""
    match = _COMMAND_URL.search(command or "")
    if match:
        return _browser_url(match.group(0))
    target = _GO_TARGET.search(_command_body(command))
    if target:
        return _browser_url(target.group(1))
    return ""


def _browser_url(token: str) -> str:
    text = (token or "").strip().strip("\"'").rstrip(".,")
    if not text or any(ch.isspace() for ch in text):
        return ""
    lowered = text.lower()
    if lowered.startswith(("http://", "https://")):
        return text
    if _HOST.fullmatch(text):
        return "https://" + text
    return ""


def _prepare_page_action(
    operation: str,
    resolved: dict[str, Any],
    item: dict[str, Any],
    decision: dict[str, Any],
) -> dict[str, Any]:
    action = dict(resolved)
    if operation == "GOTO":
        url = _browser_url(str(item.get("url") or decision.get("url") or action.get("url") or ""))
        if not url:
            return {"error": "GOTO needs a url."}
        action.update(kind="goto", url=url, label=url)
    elif operation == "PRESS":
        key = str(item.get("key") or decision.get("key") or action.get("key") or "").strip()
        if not key:
            return {"error": "PRESS needs a key."}
        action.update(kind="press", key=key, label=key)
    elif operation == "RELOAD":
        action.update(kind="reload", label="Reload")
    elif operation == "BACK":
        action.update(kind="back", label="Back")
    elif operation == "FORWARD":
        action.update(kind="forward", label="Forward")
    return {"action": action}


def _run_page_action(tab: Any, action: dict[str, Any], page: dict[str, Any]) -> dict[str, Any]:
    kind = str(action.get("kind") or "")
    if kind == "goto":
        if not hasattr(tab, "goto"):
            raise RuntimeError("goto needs a browser session")
        url = str(action.get("url") or "")
        print(f"GOTO {url}")
        landed = tab.goto(url)
        return landed if isinstance(landed, dict) else _read_tab(tab)
    print(f"{str(action.get('id') or kind).upper()} {action.get('label') or ''}".strip())
    _perform(tab, action, page, None)
    return _read_tab(tab)


def set_schedule_datetime(ctx: dict[str, Any], var: str) -> dict[str, Any]:
    """Open the schedule pickers and choose `$var`."""
    names = ctx.get("variables") or {}
    raw = names.get(var)
    text = str(raw or "").strip()
    if not text:
        raise RuntimeError(f"${var} is not set")
    when = _parse_schedule_when(text)
    date_iso = when.strftime("%Y-%m-%d")
    time_text = when.strftime("%H:%M")
    browser = ctx.get("browser")
    page = getattr(browser, "page", None)
    if page is None or not hasattr(page, "locator"):
        raise RuntimeError("schedule date needs an open page")
    written = _fill_schedule_inputs(page, when)
    if written.get("date") != date_iso:
        raise RuntimeError(f"schedule date input was not set to {date_iso}")
    shown_time = str(written.get("time") or time_text)
    print(f"SCHEDULE {date_iso} {shown_time}", flush=True)
    return {
        "inputs": {"var": var, "date": date_iso, "time": time_text},
        "outputs": {"status": "ok", "date": date_iso, "time": shown_time},
    }


def _parse_schedule_when(text: str) -> Any:
    from datetime import datetime

    cleaned = text.replace("\u202f", " ").replace("\xa0", " ")
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%b %d, %Y %I:%M %p", "%b %d, %I:%M %p"):
        try:
            parsed = datetime.strptime(cleaned, fmt)
        except ValueError:
            continue
        if parsed.year == 1900:
            parsed = parsed.replace(year=datetime.now().year)
        return parsed
    raise RuntimeError(f"could not read a date from {text!r}")


_MONTHS = (
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
)


def _click_field_arrow(box: Any) -> None:
    """The down arrow on a schedule field opens its picker."""
    arrow = box.locator("xpath=ancestor::*[contains(@class,'TUXTextInputCore')][1]").locator(
        "[data-testid='ArrowDown']"
    )
    arrow.click(timeout=5000)


def _choose_date(page: Any, box: Any, when: Any) -> None:
    """Click the date field's down arrow, then the day in the calendar."""
    _click_field_arrow(box)
    calendar = page.locator(".calendar-wrapper")
    calendar.wait_for(state="visible", timeout=5000)
    target = when.year * 12 + (when.month - 1)
    for _ in range(24):
        month = str(calendar.locator(".month-title").inner_text()).strip()
        year = str(calendar.locator(".year-title").inner_text()).strip()
        shown = int(year) * 12 + _MONTHS.index(month)
        if shown == target:
            break
        arrows = calendar.locator(".month-header-wrapper .arrow")
        arrows.nth(1 if shown < target else 0).click(timeout=5000)
    else:
        raise RuntimeError(f"schedule calendar did not reach {when.strftime('%B %Y')}")
    day = calendar.locator(".day.valid", has_text=re.compile(rf"^{when.day}$"))
    if day.count() == 0:
        raise RuntimeError(f"schedule day {when.day} is not available")
    day.first.click(timeout=5000)


def _choose_time(page: Any, box: Any, when: Any) -> str:
    """Click the time field's down arrow, then the hour and minute."""
    _click_field_arrow(box)
    picker = page.locator(".tiktok-timepicker-time-picker-container:not(.tiktok-timepicker-invisible)")
    picker.wait_for(state="visible", timeout=5000)
    lists = picker.locator(".tiktok-timepicker-option-list")
    hour = f"{when.hour:02d}"
    minute = f"{(when.minute // 5) * 5:02d}"
    lists.nth(0).locator(".tiktok-timepicker-option-item", has_text=re.compile(rf"^{hour}$")).first.click(timeout=5000)
    lists.nth(1).locator(".tiktok-timepicker-option-item", has_text=re.compile(rf"^{minute}$")).first.click(timeout=5000)
    return f"{hour}:{minute}"


def _fill_schedule_inputs(page: Any, when: Any) -> dict[str, str]:
    """Choose the date and time in the schedule pickers."""
    inputs = page.locator("input")
    date_box = None
    time_box = None
    for index in range(inputs.count()):
        item = inputs.nth(index)
        try:
            current = str(item.input_value() or "").strip()
        except Exception:
            continue
        if date_box is None and re.fullmatch(r"\d{4}-\d{2}-\d{2}", current):
            date_box = item
            continue
        if time_box is None and re.search(r"\d{1,2}:\d{2}", current):
            time_box = item
    if date_box is None:
        return {"date": "", "time": ""}
    _choose_date(page, date_box, when)
    written_time = ""
    if time_box is not None:
        written_time = _choose_time(page, time_box, when)
    return {"date": str(date_box.input_value() or "").strip(), "time": written_time}


def _date_value_visible(page: dict[str, Any]) -> bool:
    """TikTok's schedule date is an unlabeled input whose value is YYYY-MM-DD."""
    for item in page.get("actions") or []:
        if not isinstance(item, dict) or item.get("kind") not in {"fill", "click"}:
            continue
        value = str(item.get("value") or "").strip()
        if _DATE_VALUE.fullmatch(value):
            return True
    return False


def _phrase_visible(page: dict[str, Any], phrase: str) -> bool:
    text = re.sub(r"\s+", " ", str(page.get("text") or "")).casefold()
    needle = re.sub(r"\s+", " ", phrase).casefold()
    if needle and needle in text:
        return True
    cleaned = (phrase or "").strip().strip(".")
    if _DATE_PHRASE.fullmatch(cleaned) and _date_value_visible(page):
        return True
    # "the Title box" is the Title field. YouTube writes "Title (required)", not those words.
    match = _CONTROL_BOX.match(cleaned)
    if not match:
        return False
    name = re.sub(r"\s+", " ", match.group(1)).casefold()
    if not name:
        return False
    if name == "date" and _date_value_visible(page):
        return True
    if re.search(rf"\b{re.escape(name)}\b", text):
        return True
    for item in page.get("actions") or []:
        if not isinstance(item, dict) or item.get("kind") not in {"fill", "click"}:
            continue
        label = re.sub(r"\s+", " ", str(item.get("label") or "")).casefold()
        if re.search(rf"\b{re.escape(name)}\b", label):
            return True
    return False


_INTO_BOX = re.compile(
    r"\binto\s+(?:the\s+)?(.+?)\s+(?:input\s+)?(?:box|field)\b",
    re.IGNORECASE,
)


def _box_name(command: str) -> str:
    """`Title` in `into the Title input box`."""
    match = _INTO_BOX.search(_command_body(command))
    if not match:
        return ""
    return re.sub(r"\s+", " ", match.group(1)).strip()


# YouTube Studio names these boxes by their placeholder, not by Title or Description.
_STUDIO_BOX = {
    "description": "tell viewers about your video",
}


def _name_in_label(name: str, label: str) -> bool:
    text = label or ""
    if re.search(rf"\b{re.escape(name)}\b", text, re.IGNORECASE):
        return True
    hint = _STUDIO_BOX.get(name.casefold())
    return bool(hint and hint in text.casefold())


_STAMP = re.compile(
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})[ T](?P<hour>\d{2}):(?P<minute>\d{2})"
)


def _typed_variable(body: str, variables: dict[str, Any]) -> str:
    """`Type $description` is the caption. `Type the hour from $post_date` is not."""
    match = re.search(r"\btype\s+\$\{?(\w+)\}?", body, re.IGNORECASE)
    if not match:
        return ""
    value = variables.get(match.group(1))
    if not isinstance(value, str):
        return ""
    return value.strip()


def _known_text(command: str, variables: dict[str, Any]) -> str:
    """The post title, description, or the part of $post_date this field needs."""
    body = _command_body(command)
    folded = body.casefold()
    if "post title" in folded:
        return str(variables.get("post_title") or variables.get("title") or "").strip()
    if "post description" in folded:
        return str(variables.get("post_description") or variables.get("description") or "").strip()
    typed = _typed_variable(body, variables)
    if typed:
        return typed
    return _schedule_piece(folded, variables, body)


def _schedule_piece(folded: str, variables: dict[str, Any], command: str) -> str:
    """Hour, minute, or AM/PM from a stored `YYYY-MM-DD HH:MM:SS` value."""
    raw = str(variables.get("post_date") or "")
    found = _STAMP.search(raw) or _STAMP.search(command)
    if not found:
        return ""
    hour = int(found.group("hour"))
    minute = int(found.group("minute"))
    if re.search(r"\bhours?\b", folded):
        return str(hour % 12 or 12)
    if re.search(r"\bminutes?\b", folded):
        return f"{minute:02d}"
    if re.search(r"\bam\s+or\s+pm\b", folded):
        return "AM" if hour < 12 else "PM"
    # YouTube Studio types one date and one time. "Oct 15, 2026" and "5:04 PM".
    if re.search(r"\bdate\b", folded):
        from datetime import datetime

        when = datetime(
            int(found.group("year")),
            int(found.group("month")),
            int(found.group("day")),
            hour,
            minute,
        )
        return f"{when:%b} {when.day}, {when.year}"
    if re.search(r"\btime\b", folded):
        return f"{hour % 12 or 12}:{minute:02d} {'AM' if hour < 12 else 'PM'}"
    return ""


def _already_clicked_day(actions: list[Any], day: str) -> bool:
    """The compiled click already chose this day, so the calendar is closed."""
    for item in actions:
        if not isinstance(item, dict) or str(item.get("operation") or "") != "CLICK":
            continue
        if str(item.get("label") or "") != day:
            continue
        if "gridcell" in str(item.get("selector") or ""):
            return True
    return False


def _chosen_day(command: str, variables: dict[str, Any]) -> str:
    """The day number in `choose the day in $post_date`."""
    folded = _command_body(command).casefold()
    if not re.search(r"\b(choose|select|pick)\s+the\s+day\b", folded):
        return ""
    raw = str(variables.get("post_date") or "")
    found = _STAMP.search(raw) or _STAMP.search(command)
    if not found:
        return ""
    return str(int(found.group("day")))


def _current_month_cells(actions: list[Any]) -> list[dict[str, Any]]:
    """Days of the open month. Leading and trailing days belong to the neighbors."""
    cells = [
        item
        for item in actions
        if isinstance(item, dict) and item.get("role") == "gridcell" and item.get("kind") == "click"
    ]
    first = next((index for index, cell in enumerate(cells) if str(cell.get("label")) == "1"), None)
    if first is None:
        return cells
    second = next(
        (index for index, cell in enumerate(cells) if index > first and str(cell.get("label")) == "1"),
        None,
    )
    end = second if second is not None else len(cells)
    return cells[first:end]


def _day_cell(page: dict[str, Any], day: str) -> dict[str, Any] | None:
    for cell in _current_month_cells(list(page.get("actions") or [])):
        if str(cell.get("label")) == day:
            return cell
    return None


def _wait_for_day(tab: Any, page: dict[str, Any], day: str) -> tuple[dict[str, Any], dict[str, Any] | None]:
    cell = _day_cell(page, day)
    if cell is not None or tab is None:
        return page, cell
    deadline = time.time() + 2
    while time.time() < deadline:
        time.sleep(0.25)
        page = _read_tab(tab)
        cell = _day_cell(page, day)
        if cell is not None:
            return page, cell
    return page, None


def _prefer_menu_item(
    command: str,
    resolved: dict[str, Any],
    targets: dict[str, Any],
) -> dict[str, Any]:
    """The Create menu item, not the dashboard button with the same name.

    That button opens "You're all set" instead of the upload dialog.
    """
    match = _CLICK_QUOTED.search(_command_body(command))
    if not match:
        return resolved
    name = match.group(1).strip()
    if str(resolved.get("role") or "").casefold() == "menuitem":
        return resolved
    if str(resolved.get("label") or "").strip().casefold() != name.casefold():
        return resolved
    group = targets.get("CLICK") if isinstance(targets.get("CLICK"), dict) else {}
    for action in group.values():
        if not isinstance(action, dict):
            continue
        if str(action.get("role") or "").casefold() != "menuitem":
            continue
        if str(action.get("label") or "").strip().casefold() != name.casefold():
            continue
        return dict(action)
    return resolved


def _dismiss_feature_notice(tab: Any, page: dict[str, Any]) -> dict[str, Any]:
    """Close YouTube's "You're all set" notice so the upload menu can be clicked."""
    text = str(page.get("text") or "").casefold()
    if "you're all set" not in text and "you already have access to this feature" not in text:
        return page
    for item in page.get("actions") or []:
        if not isinstance(item, dict) or item.get("kind") != "click":
            continue
        if str(item.get("label") or "").strip().casefold() != "got it":
            continue
        print("Click Got it", flush=True)
        _perform(tab, item, page, None)
        return _read_tab(tab)
    return page


def _named_file(command: str) -> str:
    """The filename in `choose youtube_captions_music.mp4`."""
    match = _CHOOSE_FILE.search(command or "")
    return match.group(1) if match else ""


def _video_selection_error(command: str, variables: dict[str, Any], click_label: str) -> str:
    """Error when this click is supposed to choose a video and cannot.

    An empty string means the click is not a video choice, or the chosen
    control can open the file dialog.
    """
    name, path = _upload_file(command, variables)
    if not name:
        return ""
    if not path:
        return f"Could not find {name}."
    from .browser import opens_file_dialog

    if not opens_file_dialog(click_label):
        return "Could not select the video."
    return ""


def _attach_chosen_file(
    command: str,
    variables: dict[str, Any],
    resolved: dict[str, Any],
    public: dict[str, Any],
) -> None:
    """Put the selected video on a click that opens the file dialog."""
    _name, path = _upload_file(command, variables)
    if not path:
        return
    resolved["files"] = [path]
    public["files"] = [path]


def _video_was_not_chosen(action: dict[str, Any], result: dict[str, Any] | None) -> bool:
    """True when a video click finished without the file dialog accepting the file."""
    if not action.get("files"):
        return False
    return str((result or {}).get("file_dialog") or "") != "chosen"


def _upload_file(command: str, variables: dict[str, Any]) -> tuple[str, str]:
    """(name, path) when this click should hand a file to the dialog.

    A name with an empty path means the command named a file that is missing.
    Both empty means this click does not choose a file.
    """
    named = _named_file(command)
    if named:
        return named, _resolve_named_file(named, variables)
    if _CHOOSE_SELECTED_VIDEO.search(command or ""):
        return "the selected video", _selected_video(variables)
    return "", ""


def _selected_video(variables: dict[str, Any]) -> str:
    """The video path stored for this post."""
    from pathlib import Path

    for key in ("video", "youtube_video", "story_video"):
        raw = str(variables.get(key) or "").strip()
        if not raw or raw.lower() == "none":
            continue
        path = Path(raw).expanduser()
        if path.is_file():
            return str(path)
    return ""


def _resolve_named_file(name: str, variables: dict[str, Any]) -> str:
    """The story file whose name matches `choose <file>`."""
    from pathlib import Path

    wanted = Path(name).name
    for key in ("youtube_video", "story_video", "video"):
        raw = str(variables.get(key) or "").strip()
        if not raw or raw.lower() == "none":
            continue
        path = Path(raw).expanduser()
        if path.name == wanted and path.is_file():
            return str(path)
    for key in ("story_folder", "short_folder"):
        raw = str(variables.get(key) or "").strip()
        if not raw or raw.lower() == "none":
            continue
        path = Path(raw).expanduser() / wanted
        if path.is_file():
            return str(path)
    return ""


def _page_down_action(page: dict[str, Any]) -> dict[str, Any] | None:
    for item in page.get("actions") or []:
        if not isinstance(item, dict):
            continue
        if item.get("id") == "scroll_down" or (item.get("kind") == "scroll" and int(item.get("delta") or 0) > 0):
            return item
    return None


def _scroll_mark(page: dict[str, Any]) -> tuple[Any, Any, str]:
    scroll = page.get("scroll") if isinstance(page.get("scroll"), dict) else {}
    return (scroll.get("top"), scroll.get("y"), str(page.get("text") or ""))


def _already_there_action(phrase: str) -> dict[str, Any]:
    """A showing check that passed because the phrase was already on the page."""
    return {
        "operation": "WAIT",
        "selector": "",
        "target": phrase,
        "choice": "WAIT",
        "id": "WAIT",
        "kind": "wait",
        "label": phrase,
        "message": "already there",
        "seconds": 0,
        "phrase": phrase,
        "already": True,
    }


def _recorded(
    operation: str,
    label: str,
    *,
    kind: str,
    action: dict[str, Any] | None = None,
    message: str = "",
) -> dict[str, Any]:
    source = action or {}
    return {
        "operation": operation,
        "target": "",
        "choice": source.get("id") or "",
        "id": source.get("id"),
        "kind": kind,
        "label": label,
        "node": source.get("node"),
        "text": None,
        "message": message,
        "confidence": None,
    }


def _browser_step(command: str) -> Step:
    text = command.strip()
    if not text.lower().startswith("/browser"):
        text = "/browser " + text
    return parse_step(text)


def _searched(command: str, env: dict[str, str], variables: dict[str, Any]) -> dict[str, str]:
    found: dict[str, str] = {}
    for name in _VAR_RE.findall(command):
        if name in variables:
            found[name] = "" if variables[name] is None else str(variables[name])
        elif name in env:
            found[name] = str(env[name])
        else:
            found[name] = ""
    return found


def _with_searched(message: str, searched: dict[str, str]) -> str:
    text = (message or "").strip()
    for name, value in searched.items():
        if value and value not in text:
            text = f"{text} Searched for {name}={value!r}.".strip()
        elif not value and name not in text:
            text = f"{text} Searched for {name}, which is empty.".strip()
    return text or "Blocked."


def _review_elements(elements: list[Any]) -> list[dict[str, Any]]:
    """The controls Jev was shown, kept so a compiled step can be reviewed."""
    reviewed: list[dict[str, Any]] = []
    for element in elements:
        if not isinstance(element, dict):
            continue
        item = {
            key: element[key]
            for key in ("label", "role", "selector", "operations", "checked", "selected", "expanded", "view")
            if key in element and element[key] not in (None, "", [])
        }
        if item:
            reviewed.append(item)
    return reviewed


def artifact_dir(script: Path) -> Path:
    """Folder of the script, JSON, and screenshots for one compiled step.

    A packet step keeps `b-compile.py` in a folder named from the step.
    An older script sits in a folder of the same name, or beside that folder.
    """
    from .step_cache import is_packet_script

    if is_packet_script(script):
        return script.parent
    if script.parent.name == script.stem:
        return script.parent
    return script.parent / script.stem


def compiled_json_path(script: Path) -> Path:
    """Actions JSON for a compiled step. Packet steps keep it as `b_01-context.json`."""
    from .step_cache import is_packet_script

    folder = artifact_dir(script)
    if is_packet_script(script):
        modern = folder / "b_01-context.json"
        legacy = folder / f"{script.stem}.json"
        if legacy.is_file() and not modern.is_file():
            return legacy
        return modern
    nested = folder / f"{script.stem}.json"
    sibling = script.with_suffix(".json")
    if nested.is_file():
        return nested
    if sibling.is_file():
        return sibling
    return nested


def compile_crop_path(script: Path) -> Path:
    """Crop a click reuses. Packet steps keep it as `b-crop.png`."""
    from .step_cache import is_packet_script

    folder = artifact_dir(script)
    if is_packet_script(script):
        modern = folder / "b-crop.png"
        legacy = folder / f"{script.stem}.crop.png"
        if legacy.is_file() and not modern.is_file():
            return legacy
        return modern
    return folder / f"{script.stem}.crop.png"


def resolve_screenshot(script: Path, name: str) -> Path:
    """A screenshot name is relative to the step folder, or beside an older script."""
    image = Path(name)
    if image.is_absolute():
        return image
    nested = artifact_dir(script) / name
    if nested.is_file() or not (script.parent / name).is_file():
        return nested
    return script.parent / name


def _shot_slug(text: str) -> str:
    from .step_cache import _fs_slug

    return _fs_slug(text)[:80]


def _action_shot_name(action: dict[str, Any], used: set[str]) -> str:
    """File stem for one action, from its operation and label."""
    operation = str(action.get("operation") or "")
    label = str(action.get("label") or action.get("phrase") or action.get("message") or "")
    base = _shot_slug(f"{operation} {label}".strip()) or "action"
    name = base
    extra = 2
    while name in used:
        name = f"{base}_{extra}"
        extra += 1
    used.add(name)
    return name


def _log_shot_name(log_json: Path, index: int, label: str) -> str:
    """`11_go_....json_01_img_goto.jpg` lists directly under that step json."""
    action = _shot_slug(label)[:48] or "action"
    return f"{log_json.name}_{index:02d}_img_{action}.jpg"


_SKIP_BOX = frozenset({"GOTO", "RELOAD", "BACK", "FORWARD", "PRESS", "DONE", "BLOCKED"})
_PHRASE_BOX_JS = r"""
(phrase) => {
  const wanted = String(phrase || "").replace(/\s+/g, " ").trim().toLowerCase();
  if (!wanted || !document.body) return null;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const range = document.createRange();
  let node;
  while ((node = walker.nextNode())) {
    const value = (node.textContent || "").replace(/\s+/g, " ");
    const at = value.toLowerCase().indexOf(wanted);
    if (at < 0) continue;
    try {
      range.setStart(node, at);
      range.setEnd(node, Math.min(value.length, at + wanted.length));
    } catch (err) {
      continue;
    }
    for (const r of range.getClientRects()) {
      if (r.width < 1 || r.height < 1) continue;
      if (r.bottom <= 0 || r.top >= innerHeight || r.right <= 0 || r.left >= innerWidth) continue;
      return {x: r.x, y: r.y, width: r.width, height: r.height};
    }
  }
  let best = null;
  let bestArea = Infinity;
  const visit = (root) => {
    if (!root || typeof root.querySelectorAll !== "function") return;
    for (const e of root.querySelectorAll("*")) {
      const text = (e.innerText || e.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
      if (!text.includes(wanted)) {
        if (e.shadowRoot) visit(e.shadowRoot);
        continue;
      }
      const r = e.getBoundingClientRect();
      const area = r.width * r.height;
      if (r.width < 2 || r.height < 2 || area >= bestArea) continue;
      if (r.bottom <= 0 || r.top >= innerHeight || r.right <= 0 || r.left >= innerWidth) continue;
      best = {x: r.x, y: r.y, width: r.width, height: r.height};
      bestArea = area;
      if (e.shadowRoot) visit(e.shadowRoot);
    }
  };
  visit(document);
  return best;
}
"""


def _locator_box(page: Any, selector: str) -> dict[str, float] | None:
    """CSS box of the control a role selector names. None when it is not on the page."""
    locate = getattr(page, "locator", None)
    if locate is None or not selector.strip():
        return None
    try:
        from .browser import _first_match

        locator = _first_match(locate(selector))
        try:
            box = locator.bounding_box(timeout=800)
        except TypeError:
            box = locator.bounding_box()
    except Exception:
        return None
    return _css_box(box)


def _phrase_box(page: Any, phrase: str) -> dict[str, float] | None:
    """CSS box of the visible words a verify is waiting for."""
    evaluate = getattr(page, "evaluate", None)
    if evaluate is None or not phrase.strip():
        return None
    try:
        found = evaluate(_PHRASE_BOX_JS, phrase)
    except Exception:
        return None
    return _css_box(found)


def _css_box(box: Any) -> dict[str, float] | None:
    if not isinstance(box, dict):
        return None
    x = float(box.get("x") or 0)
    y = float(box.get("y") or 0)
    width = float(box.get("width") or box.get("w") or 0)
    height = float(box.get("height") or box.get("h") or 0)
    if width < 1 or height < 1:
        return None
    return {"x": x, "y": y, "w": width, "h": height}


def _action_css_box(page: Any, action: dict[str, Any]) -> dict[str, float] | None:
    """The element a click, verify, type, or other page action uses."""
    operation = str(action.get("operation") or action.get("kind") or "").upper()
    if operation in _SKIP_BOX:
        return None
    selector = str(action.get("selector") or action.get("locator") or "").strip()
    if selector:
        found = _locator_box(page, selector)
        if found:
            return found
    phrase = str(action.get("phrase") or "").strip()
    if phrase:
        return _phrase_box(page, phrase)
    return None


def _paint_boxes(path: Path, boxes: list[dict[str, float]], page: Any) -> None:
    """Draw each CSS box onto the screenshot. Screenshot pixels follow the viewport."""
    from PIL import Image, ImageDraw

    picture = Image.open(path).convert("RGB")
    width, height = picture.size
    try:
        view = _viewport(page)
    except Exception:
        view = {"w": 0.0, "h": 0.0, "dpr": 1.0}
    sx = width / view["w"] if view["w"] else float(view["dpr"] or 1)
    sy = height / view["h"] if view["h"] else float(view["dpr"] or 1)
    draw = ImageDraw.Draw(picture)
    stroke = max(3, min(width, height) // 180)
    for box in boxes:
        x1 = int(box["x"] * sx)
        y1 = int(box["y"] * sy)
        x2 = int((box["x"] + box["w"]) * sx)
        y2 = int((box["y"] + box["h"]) * sy)
        if x2 < 0 or y2 < 0 or x1 >= width or y1 >= height:
            continue
        x1 = max(0, min(width - 1, x1))
        y1 = max(0, min(height - 1, y1))
        x2 = max(x1 + 1, min(width - 1, x2))
        y2 = max(y1 + 1, min(height - 1, y2))
        draw.rectangle([x1, y1, x2, y2], outline=(255, 40, 40), width=stroke)
    picture.save(path, quality=95)


def _mark_action_boxes(path: Path, page: Any, actions: list[dict[str, Any]]) -> None:
    boxes: list[dict[str, float]] = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        box = _action_css_box(page, action)
        if box:
            boxes.append(box)
    if not boxes:
        return
    try:
        _paint_boxes(path, boxes, page)
    except Exception:
        return


def compile_screenshot(
    tab: Any,
    path: Path,
    index: int = 1,
    *,
    name: str = "",
    directory: Path | None = None,
    exact: bool = False,
    actions: list[dict[str, Any]] | None = None,
) -> str:
    """Save a jpeg of the open page for one action. Return its file name.

    Compile writes into the step folder with the script and JSON. A run passes the log step folder.
    A click, verify, type, or other element action is outlined on that jpeg.
    """
    live = getattr(tab, "page", None)
    if live is None or not hasattr(live, "screenshot") or index < 1 or not str(path):
        return ""
    folder = directory if directory is not None else artifact_dir(path)
    if exact and name:
        filename = Path(name).name
        if not filename.lower().endswith(".jpg"):
            filename += ".jpg"
    else:
        filename = f"{_shot_slug(name) or str(index)}.jpg"
    from .step_cache import data_filename, is_packet_script

    if is_packet_script(path):
        filename = data_filename(filename)
    dest = folder / filename
    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(live.screenshot(type="jpeg", quality=72))
    except Exception:
        return ""
    if actions:
        _mark_action_boxes(dest, live, actions)
    return dest.name


def _with_shot(action: dict[str, Any], name: str) -> dict[str, Any]:
    if name:
        action["screenshot"] = name
    return action


def _remember_screenshots(script: str, names: list[str]) -> None:
    """Write each action's screenshot name back onto the compiled JSON."""
    if not script or not names:
        return
    import json

    json_path = compiled_json_path(Path(script))
    if not json_path.is_file():
        return
    try:
        saved = json.loads(json_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return
    if not isinstance(saved, dict):
        return
    saved["screenshots"] = names
    actions = saved.get("actions")
    if isinstance(actions, list):
        for action, name in zip(actions, names):
            if isinstance(action, dict):
                action["screenshot"] = name
    try:
        json_path.write_text(json.dumps(saved, indent=2) + "\n", encoding="utf-8")
    except OSError:
        return


def _read_tab(tab: Any) -> dict[str, Any]:
    if isinstance(tab, dict):
        page = tab
    elif hasattr(tab, "observe"):
        page = tab.observe()
    elif hasattr(tab, "evaluate"):
        from .browser import SNAPSHOT_JS, fingerprint

        page = tab.evaluate(SNAPSHOT_JS) or {}
        if not isinstance(page, dict):
            raise TypeError("tab snapshot must be a dict")
        page["fingerprint"] = fingerprint(page)
    else:
        raise TypeError("tab must be a browser session, a page, or a snapshot")
    if not isinstance(page, dict):
        raise TypeError("tab snapshot must be a dict")
    return page


def _can_act(tab: Any) -> bool:
    if isinstance(tab, dict):
        return False
    if hasattr(tab, "act"):
        return True
    return hasattr(tab, "evaluate") and hasattr(tab, "mouse")


def _resolve(decision: dict[str, Any], page: dict[str, Any]) -> dict[str, Any]:
    operation = decision["operation"]
    targets = decision.get("targets") or {}
    controls = decision.get("controls") or {}
    action: dict[str, Any] = {}
    target = str(decision.get("target") or "")
    if operation in targets and target in targets[operation]:
        action = dict(targets[operation][target])
    elif operation in controls:
        action = dict(controls[operation])
        if operation == "SCROLL_DOWN":
            action["delta"] = 560
            action["kind"] = action.get("kind") or "scroll"
        elif operation == "SCROLL_UP":
            action["delta"] = -560
            action["kind"] = action.get("kind") or "scroll"
    else:
        for item in (page or {}).get("actions") or []:
            if item.get("id") == decision.get("choice"):
                action = dict(item)
                break
    if not action:
        action = {"id": decision.get("choice"), "kind": operation.lower()}
    return action


def _current_action(
    page: dict[str, Any],
    step: Step,
    variables: dict[str, Any],
    operation: str,
    selector: str,
) -> dict[str, Any] | None:
    from . import model

    request = model.choose_request(page, step, [], variables, selectors=True)
    action = (request.get("targets") or {}).get(operation, {}).get(selector)
    return dict(action) if isinstance(action, dict) else None


def _public_action(decision: dict[str, Any], resolved: dict[str, Any], text: str | None) -> dict[str, Any]:
    selector = resolved.get("selector") or decision.get("target") or ""
    locator = str(decision.get("locator") or resolved.get("locator") or "")
    if locator and not selector:
        selector = locator
    action = {
        "operation": decision["operation"],
        "selector": selector,
        "target": selector or decision.get("target"),
        "choice": decision.get("choice"),
        "id": resolved.get("id"),
        "kind": resolved.get("kind"),
        "label": resolved.get("label") or "",
        "node": resolved.get("node"),
        "text": text,
        "message": decision.get("message") or "",
        "confidence": decision.get("confidence"),
    }
    if locator:
        action["locator"] = locator
    return action


def _action_answer(
    ask: Callable[[list[dict[str, str]]], dict[str, Any]] | None,
    request: dict[str, Any],
    *,
    goal: str,
) -> dict[str, Any]:
    if ask is not None:
        return ask(request["messages"])
    from . import model

    return model.ask_jev_browser(request, goal=goal)


def _field_text(
    ask: Callable[[list[dict[str, str]]], dict[str, Any]],
    command: str,
    resolved: dict[str, Any],
    page: dict[str, Any],
    variables: dict[str, Any],
) -> tuple[str | None, dict[str, Any], str]:
    import json

    from . import model

    context = {
        "goal": command,
        "field": {key: resolved.get(key) for key in ("label", "role", "value")},
        "page": {"title": page.get("title"), "text": str(page.get("text") or "")[:6000]},
        "variables": model._public_vars(variables),
    }
    messages = [
        {"role": "system", "content": TEXT_VALUE},
        {"role": "user", "content": json.dumps(context, default=str)},
    ]
    try:
        answer = ask(messages)
    except Exception as exc:
        return None, {"purpose": "text", "messages": messages, "reply": {}, "sent": True, "error": str(exc)}, str(exc)
    value = answer.get("text")
    if not isinstance(value, str) or not value.strip():
        return None, {"purpose": "text", "messages": messages, "reply": answer, "sent": True, "error": ""}, "No text to type."
    return value, {"purpose": "text", "messages": messages, "reply": answer, "sent": True, "error": ""}, ""


def _command_steps(command: str) -> list[str]:
    text = _command_body(command)
    text = re.sub(r"\s+the\s+click\s+", " then click ", text, flags=re.IGNORECASE)
    steps: list[str] = []
    for sentence in re.split(r"(?<=[.])\s+", text):
        verb = ""
        for bit in re.split(r",?\s+then\s+", sentence, flags=re.IGNORECASE):
            part = bit.strip(" .")
            if not part:
                continue
            first = part.split(None, 1)[0].lower()
            if first in {"click", "type", "select", "tick", "search", "wait", "open", "turn", "confirm"}:
                verb = first
                steps.append(part)
            elif verb == "click":
                steps.append(f"Click {part}")
            else:
                steps.append(part)
    return steps


def _command_needs_action(command: str) -> bool:
    if _ACTION_WORD.search(command or "") or re.search(r"\bgo\s+to\b", command or "", re.IGNORECASE):
        return True
    return bool(_command_url(command))


def _fill_command_actions(command: str, actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Keep the address and the verify when the model returns nothing for them.

    A blank page often comes back as DONE. The step already names the URL and
    the text to wait for, so those stay in the compiled actions.
    """
    out = [item for item in actions if isinstance(item, dict)]
    ops = {str(item.get("operation") or "").upper() for item in out}
    url = _command_url(command)
    if url and "GOTO" not in ops:
        out.insert(
            0,
            {
                "operation": "GOTO",
                "selector": "",
                "target": url,
                "choice": "GOTO",
                "id": "GOTO",
                "kind": "goto",
                "label": url,
                "message": "",
                "url": url,
                "key": "",
            },
        )
    waiting = _verify_clause(command) or _text_wait(command)
    if waiting and "WAIT" not in ops and "WAIT_FOR_LOCATOR" not in ops:
        phrase, seconds = waiting
        out.append(
            {
                "operation": "WAIT",
                "selector": "",
                "target": phrase,
                "choice": "WAIT",
                "id": "WAIT",
                "kind": "wait",
                "label": phrase,
                "message": "",
                "seconds": seconds,
                "phrase": phrase,
            }
        )
    return out


_PLUS_CLICK = re.compile(
    r"(?<!\S)\+click\s+(?P<name>.+?)(?=\s+(?:\+[A-Za-z]|\bwait\b|\bverify\b)|\s*$)",
    re.IGNORECASE,
)


def _plus_click_label(command: str) -> str | None:
    """The label in `+click`, or None when the step has no click param.

    A locator, a variable, or a point is not a label, so this returns empty
    and the model keeps that click.
    """
    match = _PLUS_CLICK.search(command or "")
    if not match:
        return None
    from .model import _click_name

    name = _click_name(match.group("name"))
    if not name or re.match(r"(?:locator\b|\$|\d+\s*,)", name, re.IGNORECASE):
        return ""
    return name


def _click_param_target(command: str, targets: dict[str, Any]) -> dict[str, Any] | None:
    """The page control named by `+click`."""
    from .model import _accessible_name, _locator_priority, _priority_names

    named = _priority_names(command)
    if not named:
        return None
    group = targets.get("CLICK") if isinstance(targets.get("CLICK"), dict) else {}
    matches = [
        action
        for action in group.values()
        if isinstance(action, dict) and _locator_priority(action, named) == "likely"
    ]
    if not matches:
        return None
    nav = bool(re.search(r"\b(?:nav|navigation|menu|sidebar)\b", command or "", re.IGNORECASE))

    def rank(action: dict[str, Any]) -> tuple[int, int, int]:
        shown = 0 if str(action.get("view") or "") == "shown" else 1
        role = str(action.get("role") or "").casefold()
        placed = 0 if nav and role in {"menuitem", "link", "treeitem"} else 1
        return (shown, placed, -len(_accessible_name(action)))

    matches.sort(key=rank)
    return matches[0]


def _click_from_target(action: dict[str, Any]) -> dict[str, Any]:
    selector = str(action.get("selector") or action.get("selector_key") or "")
    return {
        "operation": "CLICK",
        "selector": selector,
        "target": selector,
        "choice": action.get("id") or selector,
        "id": action.get("id"),
        "kind": action.get("kind") or "click",
        "role": action.get("role") or "",
        "label": action.get("label") or "",
        "node": action.get("node"),
        "text": None,
        "message": "",
        "confidence": None,
    }


def _verify_control(command: str, targets: dict[str, Any]) -> tuple[dict[str, Any], float, str] | None:
    """The page control named by `+verify`, when that phrase is a label."""
    found = _verify_clause(command)
    if found is None:
        return None
    phrase, seconds = found
    wanted = phrase.casefold().strip()
    if not wanted:
        return None
    group = targets.get("CLICK") if isinstance(targets.get("CLICK"), dict) else {}
    matches = [
        action
        for action in group.values()
        if isinstance(action, dict) and str(action.get("label") or "").strip().casefold() == wanted
    ]
    if not matches:
        return None
    nav = bool(re.search(r"\b(?:nav|navigation|menu|sidebar)\b", command or "", re.IGNORECASE))

    def rank(action: dict[str, Any]) -> tuple[int, int, int]:
        shown = 0 if str(action.get("view") or "") == "shown" else 1
        role = str(action.get("role") or "").casefold()
        placed = 0 if nav and role in {"menuitem", "link", "treeitem"} else 1
        return (shown, placed, -len(str(action.get("label") or "")))

    matches.sort(key=rank)
    return matches[0], seconds, phrase


def _wait_from_target(action: dict[str, Any], seconds: float, phrase: str) -> dict[str, Any]:
    selector = str(action.get("selector") or action.get("selector_key") or "")
    return {
        "operation": "WAIT_FOR_LOCATOR",
        "selector": selector,
        "target": selector,
        "choice": action.get("id") or selector,
        "id": action.get("id"),
        "kind": "wait_for_locator",
        "role": action.get("role") or "",
        "label": action.get("label") or phrase,
        "node": action.get("node"),
        "text": None,
        "message": "",
        "confidence": None,
        "seconds": seconds,
        "phrase": phrase,
    }


def _bind_verify_element(
    command: str,
    actions: list[dict[str, Any]],
    targets: dict[str, Any],
) -> list[dict[str, Any]]:
    """`+verify Content` checks the Content control, not the word in the page text."""
    found = _verify_control(command, targets)
    if found is None:
        return actions
    action, seconds, phrase = found
    element = _wait_from_target(action, seconds, phrase)
    if not element["selector"]:
        return actions
    replaced = False
    out: list[dict[str, Any]] = []
    for item in actions:
        operation = str(item.get("operation") or "").upper()
        item_phrase = str(item.get("phrase") or "").strip()
        same_phrase = item_phrase.casefold() == phrase.casefold()
        if (
            not replaced
            and operation in {"WAIT", "WAIT_FOR_LOCATOR"}
            and same_phrase
            and not str(item.get("selector") or "").strip()
        ):
            out.append(element)
            replaced = True
            continue
        out.append(item)
    if not replaced and not any(
        str(item.get("selector") or "") == element["selector"]
        and str(item.get("operation") or "").upper() in {"WAIT", "WAIT_FOR_LOCATOR"}
        for item in out
    ):
        out.append(element)
    return _order_click_and_verify(command, out)


def _element_wait_action(item: dict[str, Any], seconds: float, message: str) -> dict[str, Any]:
    selector = str(item.get("selector") or "")
    label = str(item.get("label") or selector)
    return {
        "operation": "WAIT_FOR_LOCATOR",
        "selector": selector,
        "target": selector,
        "choice": item.get("choice") or item.get("id") or selector,
        "id": item.get("id"),
        "kind": "wait_for_locator",
        "role": item.get("role") or "",
        "label": label,
        "node": item.get("node"),
        "text": None,
        "message": message,
        "confidence": item.get("confidence"),
        "seconds": seconds,
        "phrase": item.get("phrase") or label,
    }


def _replay_element_wait(
    tab: Any,
    item: dict[str, Any],
    page: dict[str, Any],
    *,
    seconds: float,
    dry_run: bool,
) -> tuple[dict[str, Any], dict[str, Any], str, str]:
    """Wait for the saved control. The action keeps that element's selector and node."""
    selector = str(item.get("selector") or "")
    label = str(item.get("label") or selector)
    if dry_run:
        waited = _element_wait_action(item, seconds, "")
        return waited, page, "done", ""
    live = getattr(tab, "page", None) if tab is not None else None
    if live is not None and _locator_box(live, selector):
        message = f"{label} is showing."
        return _element_wait_action(item, seconds, message), page, "done", message
    print(f"Waiting up to {seconds:g}s until {selector} exists.", flush=True)
    try:
        from .browser import wait_for_locator

        if live is None or not hasattr(live, "locator"):
            raise RuntimeError("wait for locator needs a Playwright page")
        wait_for_locator(live, selector, seconds)
    except Exception as exc:
        timed_out = "timeout" in type(exc).__name__.lower() or "timeout" in str(exc).lower()
        message = (
            f"{selector} did not exist within {seconds:g}s."
            if timed_out
            else f"Could not wait for {selector}: {exc}"
        )
        return _element_wait_action(item, seconds, message), page, "blocked", message
    message = f"{label} is showing."
    fresh = _read_tab(tab) if tab is not None else page
    return _element_wait_action(item, seconds, message), fresh, "done", message


def _order_click_and_verify(command: str, actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """`+verify` before `+click` checks first. `+click` before `+verify` clicks first."""
    if _plus_click_label(command) is None:
        return actions
    if not (_page_action_before_wait(command) or _wait_before_page_action(command)):
        return actions
    click_at = [index for index, item in enumerate(actions) if str(item.get("operation") or "").upper() == "CLICK"]
    wait_at = [
        index
        for index, item in enumerate(actions)
        if str(item.get("operation") or "").upper() in {"WAIT", "WAIT_FOR_LOCATOR"}
    ]
    if len(click_at) != 1 or len(wait_at) != 1:
        return actions
    click_first = _page_action_before_wait(command)
    if click_first and click_at[0] < wait_at[0]:
        return actions
    if not click_first and wait_at[0] < click_at[0]:
        return actions
    ordered = list(actions)
    left, right = click_at[0], wait_at[0]
    ordered[left], ordered[right] = ordered[right], ordered[left]
    return ordered


def _fill_click_param(
    command: str,
    actions: list[dict[str, Any]],
    targets: dict[str, Any],
) -> tuple[list[dict[str, Any]], str]:
    """Add the `+click` when the model skips it, then keep click and verify in param order."""
    label = _plus_click_label(command)
    out = [item for item in actions if isinstance(item, dict)]
    if label is None:
        return _order_click_and_verify(command, out), ""
    has_click = any(str(item.get("operation") or "").upper() == "CLICK" for item in out)
    if label and not has_click:
        found = _click_param_target(command, targets)
        if found is None:
            return out, f"{label} is not on the page."
        out.append(_click_from_target(found))
    return _order_click_and_verify(command, out), ""


def _wait_completes_command(command: str) -> bool:
    """`Wait until Close button` is finished once that control exists."""
    return not _command_needs_action(command)


def _only_done(batch: list[dict[str, Any]]) -> bool:
    operations = [str(item.get("operation") or "").upper() for item in batch]
    return bool(operations) and set(operations) <= {"DONE"}


def _answer_actions(answer: dict[str, Any]) -> list[dict[str, Any]]:
    raw = answer.get("actions")
    items = [item for item in raw if isinstance(item, dict)] if isinstance(raw, list) else []
    if not items and answer.get("operation"):
        items = [answer]
    status = str(answer.get("operation") or "").upper()
    if status in {"DONE", "BLOCKED"} and not any(
        str(item.get("operation") or "").upper() == status for item in items
    ):
        items.append({"operation": status, "message": answer.get("message") or ""})
    return items


def _perform(tab: Any, action: dict[str, Any], page: dict[str, Any], text: str | None) -> dict[str, Any]:
    if not _can_act(tab):
        raise RuntimeError("actual mode needs a live tab")
    if hasattr(tab, "act"):
        return tab.act(action, page, text=text)
    from .browser import perform

    return perform(tab, action, text)


def _print_actions(actions: list[dict[str, Any]], *, dry_run: bool) -> None:
    prefix = "DRY-RUN " if dry_run else ""
    print(f"{prefix}actions")
    for index, action in enumerate(actions, 1):
        operation = action.get("operation") or ""
        target = action.get("target") or ""
        label = action.get("text") or action.get("message") or action.get("label") or ""
        print(f"{index}. {operation} {target} {label}".strip())


def _print_blocked(message: str, status: str) -> None:
    if status == "blocked" and message:
        print(message)
