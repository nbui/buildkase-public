"""CDP browser session: one snapshot, then act through observed node ids."""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.parse
from pathlib import Path
from typing import Any, Callable
from urllib.request import urlopen

SNAPSHOT_JS = Path(__file__).with_name("snapshot.js").read_text(encoding="utf-8")

# Short site names used by `/browser reuseTab <site>`.
_SITE_NEEDLES = {
    "youtube": "youtube.com",
    "yt": "youtube.com",
    "tiktok": "tiktok.com",
    "instagram": "instagram.com",
    "ig": "instagram.com",
}

ACT_JS = """
(action) => {
  const e = window.__cgLoopFast?.nodes.get(action.node);
  if (!e?.isConnected || e.matches(':disabled') || e.closest('[aria-disabled="true"],[inert]')) return null;
  if (!e.checkVisibility({checkOpacity:true, checkVisibilityCSS:true})) return null;
  if (action.kind === 'fill' && (e.readOnly || e.getAttribute('aria-readonly') === 'true')) return null;
  const same = (target, top) => {
    if (!top) return false;
    if (target === top || target.contains(top) || top.contains(target)) return true;
    const chain = (node) => {
      const out = [];
      let current = node;
      for (let hop = 0; current && hop < 16; hop += 1) {
        out.push(current);
        const root = current.getRootNode ? current.getRootNode() : null;
        current = current.parentElement || (root && root.host) || null;
      }
      return out;
    };
    return chain(top).includes(target) || chain(target).includes(top);
  };
  let r = e.getBoundingClientRect();
  if (!r.width || !r.height) return null;
  if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) {
    e.scrollIntoView({block: 'center', inline: 'nearest'});
    r = e.getBoundingClientRect();
  }
  const role = e.getAttribute('role') || '';
  const inputType = e.tagName === 'INPUT' ? String(e.type || '') : '';
  const isRadio = role === 'radio' || inputType === 'radio';
  // TikTok draws the circle as a sibling on top of a native input. Setting
  // checked ahead of the click skips the change event that opens the date.
  const nativeToggle = e.tagName === 'INPUT' && (inputType === 'radio' || inputType === 'checkbox');
  const chooseRadio = () => {
    if (!isRadio || nativeToggle) return;
    const name = e.getAttribute('name') || '';
    const group = typeof e.closest === 'function' ? e.closest('[role="radiogroup"]') : null;
    if (group && name && 'selected' in group) {
      group.selected = name;
      return;
    }
    try { e.checked = true; } catch (err) {}
    if (typeof e.setAttribute === 'function') e.setAttribute('aria-checked', 'true');
  };
  // YouTube's circle is about 16px. A point 28px in lands on the host gap and does not select it.
  let hit = null;
  if (isRadio) {
    const y = r.y + r.height / 2;
    const limit = Math.min(r.width, 40);
    for (let dx = 4; dx <= limit; dx += 4) {
      const x = r.x + dx;
      if (x < 1 || y < 1 || x >= innerWidth - 1 || y >= innerHeight - 1) continue;
      const top = document.elementFromPoint(x, y);
      if (!same(e, top)) continue;
      const id = top.id || '';
      if (id === 'offRadio' || id === 'onRadio' || id === 'radioContainer') {
        const br = top.getBoundingClientRect();
        hit = {x: br.x + br.width / 2, y: br.y + br.height / 2};
        break;
      }
      if (!hit) hit = {x, y};
    }
  }
  if (!hit) {
    const points = [
      [r.x + Math.min(28, r.width / 2), r.y + r.height / 2],
      [r.x + Math.min(16, r.width / 2), r.y + Math.min(16, r.height / 2)],
      [r.x + r.width / 2, r.y + r.height / 2],
    ];
    for (const [x, y] of points) {
      if (x < 1 || y < 1 || x >= innerWidth - 1 || y >= innerHeight - 1) continue;
      if (same(e, document.elementFromPoint(x, y))) {
        hit = {x, y};
        break;
      }
    }
  }
  if (!hit) {
    const activatable = isRadio || inputType === 'checkbox' || ['checkbox', 'switch', 'button'].includes(role) || e.tagName === 'BUTTON';
    if (!activatable) return null;
    chooseRadio();
    e.click();
    hit = {x: r.x + Math.min(28, Math.max(1, r.width / 2)), y: r.y + r.height / 2, direct: true};
  } else {
    chooseRadio();
  }
  if (action.kind === 'select') {
    if (e.tagName !== 'SELECT') return null;
    e.value = action.value;
    e.dispatchEvent(new Event('input', {bubbles: true}));
    e.dispatchEvent(new Event('change', {bubbles: true}));
  }
  return {x: hit.x, y: hit.y, direct: !!hit.direct, href: e.href || e.getAttribute('href') || ''};
}
"""


class StalePage(ValueError):
    """A decision no longer refers to the observed page."""


# "Select files" opens a macOS open panel. That panel is not part of the page, and a
# snapshot waits forever while it is up.
_FILE_BUTTON = re.compile(
    r"\b(?:select|choose|browse)\s+(?:files?|videos?|from computer)\b",
    re.IGNORECASE,
)
_SNAPSHOT_WAIT_S = 4.0
# Walk the browser's windows and the open panel never answers. Escape cancels that panel.
_CANCEL_OPEN_PANEL = r'''
if application "Brave Browser" is running then
  tell application "Brave Browser" to activate
else if application "Google Chrome" is running then
  tell application "Google Chrome" to activate
else
  return "none"
end if
delay 0.15
tell application "System Events" to key code 53
return "cancelled"
'''


def opens_file_dialog(label: str) -> bool:
    """True when this control opens the system file dialog."""
    return bool(_FILE_BUTTON.search(label or ""))


# YouTube's hashtag menu sits on top of the upload form. elementFromPoint then
# reports every control under it as covered, and the step retries until it stops.
# The menu lives in a shadow root, so the search walks hit-tested elements.
_DISMISS_HASHTAG_POPUP_JS = r"""
() => {
  const tagLine = /^#[\p{L}\p{N}_]+$/u;
  const isMenu = (e) => {
    if (!e || e.nodeType !== 1 || e.isContentEditable) return false;
    const r = e.getBoundingClientRect();
    if (r.width < 160 || r.width > 560 || r.height < 80 || r.height > 560) return false;
    if (r.bottom <= 0 || r.top >= innerHeight || r.right <= 0 || r.left >= innerWidth) return false;
    const text = (e.innerText || "").trim();
    if (!text || text.length > 1500) return false;
    if (/title \(required\)/i.test(text) || /tell viewers about your video/i.test(text)) return false;
    const lines = text.split("\n").map((s) => s.trim()).filter(Boolean);
    return lines.filter((s) => tagLine.test(s)).length >= 3;
  };
  let best = null;
  let bestArea = Infinity;
  const seen = new Set();
  for (let y = 40; y < innerHeight; y += 70) {
    for (let x = 40; x < innerWidth; x += 70) {
      let node = document.elementFromPoint(x, y);
      for (let hop = 0; node && hop < 12; hop += 1) {
        if (!seen.has(node)) {
          seen.add(node);
          if (isMenu(node)) {
            const r = node.getBoundingClientRect();
            const area = r.width * r.height;
            if (area < bestArea) {
              best = node;
              bestArea = area;
            }
          }
        }
        const root = node.getRootNode ? node.getRootNode() : null;
        node = node.parentElement || (root && root.host) || null;
      }
    }
  }
  if (!best) return false;
  best.style.setProperty("display", "none", "important");
  best.setAttribute("aria-hidden", "true");
  const active = document.activeElement;
  if (active && active !== document.body && typeof active.blur === "function") active.blur();
  return true;
}
"""


def dismiss_hashtag_popup(page: Any) -> bool:
    """Hide a hashtag suggestion menu so the form under it can be clicked."""
    evaluate = getattr(page, "evaluate", None)
    if evaluate is None:
        return False
    try:
        closed = bool(evaluate(_DISMISS_HASHTAG_POPUP_JS))
    except Exception:
        return False
    if not closed:
        return False
    print("Closed the hashtag suggestion popup.", flush=True)
    return True


def release_stuck_file_dialog(*, announce_error: bool = False) -> bool:
    """Click Cancel on a browser open panel so the page can be read again."""
    if sys.platform != "darwin":
        return False
    try:
        result = subprocess.run(
            ["osascript", "-e", _CANCEL_OPEN_PANEL],
            capture_output=True,
            text=True,
            timeout=2,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        if announce_error:
            print(f"Could not close the system file dialog: {exc}", flush=True)
        return False
    if result.returncode != 0:
        if announce_error:
            detail = (result.stderr or result.stdout or "").strip()
            print(f"Could not close the system file dialog: {detail}", flush=True)
        return False
    if "cancelled" in (result.stdout or ""):
        print("Closed the system file dialog.", flush=True)
        return True
    return False


def evaluate_guarded(page: Any, expression: str, arg: Any = None, timeout_s: float = _SNAPSHOT_WAIT_S) -> Any:
    """Run page JavaScript. If a system file dialog blocks it, close that dialog."""
    done = threading.Event()

    def watchdog() -> None:
        if done.wait(timeout_s):
            return
        print("Page snapshot is waiting on a system file dialog. Closing it.", flush=True)
        release_stuck_file_dialog(announce_error=True)

    threading.Thread(target=watchdog, daemon=True).start()
    try:
        if arg is None:
            return page.evaluate(expression)
        return page.evaluate(expression, arg)
    finally:
        done.set()


def connection_lost(exc: BaseException) -> bool:
    """True when the Playwright driver or CDP socket is gone."""
    text = str(exc).lower()
    return any(
        piece in text
        for piece in (
            "connection closed",
            "target closed",
            "browser has been closed",
            "has been closed",
            "websocket",
        )
    )


def accept_js_dialog(dialog: Any) -> None:
    """Accept a script dialog. Another CDP client may already have closed it."""
    try:
        dialog.accept()
    except Exception:
        return


def listen_for_js_dialogs(target: Any) -> None:
    """Own dialogs on this page or context so the driver does not auto-accept them."""
    if target is None or getattr(target, "_cg_loop_dialogs", False):
        return
    listen = getattr(target, "on", None)
    if listen is None:
        return
    listen("dialog", accept_js_dialog)
    try:
        target._cg_loop_dialogs = True
    except Exception:
        return


def tab_needle(site: str) -> str:
    """Host fragment a reuseTab site name should match in a tab URL."""
    text = (site or "").strip().lower()
    if not text:
        raise ValueError("reuseTab needs a site, for example youtube")
    if text in _SITE_NEEDLES:
        return _SITE_NEEDLES[text]
    if "://" in text:
        text = text.split("://", 1)[1]
    return text.split("/")[0].split("?")[0]


def _is_login_url(url: str) -> bool:
    lowered = (url or "").lower()
    return "login" in lowered or "accounts.google.com" in lowered


DEFAULT_BRAVE = Path("/Applications/Brave Browser.app/Contents/MacOS/Brave Browser")
_BROWSER_CANDIDATES = (
    DEFAULT_BRAVE,
    Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
    Path("/Applications/Chromium.app/Contents/MacOS/Chromium"),
    Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
)
PROFILE_ROOT = Path("/Users/nghia/.openclaw/browser")
PORT_PROFILES = {18801: "yuba-social", 18802: "yuba-heart"}
BROWSER_START_TIMEOUT_S = 60.0


def browser_executable() -> Path:
    """Chromium binary for a new CDP window. CG_LOOP_BROWSER replaces the search."""
    raw = (os.environ.get("CG_LOOP_BROWSER") or "").strip()
    if raw:
        return Path(raw).expanduser()
    for candidate in _BROWSER_CANDIDATES:
        if candidate.is_file():
            return candidate
    return DEFAULT_BRAVE


def browser_plugin() -> Path | None:
    """Unpacked extension directory. Empty means the browser starts without one."""
    raw = (os.environ.get("CG_LOOP_BROWSER_PLUGIN") or "").strip()
    if not raw:
        return None
    return Path(raw).expanduser()


def profile_root() -> Path:
    """Folder that holds named browser profiles."""
    raw = (os.environ.get("CG_LOOP_BROWSER_PROFILE") or os.environ.get("PROFILE_ROOT") or "").strip()
    if raw:
        return Path(raw).expanduser()
    if PROFILE_ROOT.is_dir():
        return PROFILE_ROOT
    return Path.home() / ".buildkase" / "browser"


def require_cdp_url(cdp_url: str) -> str:
    """Browser steps attach only to a cdp-url configured for this run."""
    cdp = (cdp_url or "").strip().rstrip("/")
    if not cdp:
        raise RuntimeError("browser tool needs cdp-url")
    return cdp


def cdp_ready(cdp_url: str, timeout_s: float = 1.0) -> bool:
    try:
        with urlopen(cdp_url.rstrip("/") + "/json/version", timeout=timeout_s) as response:
            return response.status == 200
    except Exception:
        return False


def resolve_profile(cdp_url: str, profile: str = "") -> str:
    """Profile name for a CDP endpoint: explicit, PROFILE, then known ports."""
    name = (profile or os.environ.get("PROFILE") or "").strip()
    if name:
        return name
    port = urllib.parse.urlparse(cdp_url).port
    return PORT_PROFILES.get(port or 0, "")


def _is_path_profile(profile: str) -> bool:
    """A profile path is a Chrome user-data directory, not a name under PROFILE_ROOT."""
    text = (profile or "").strip()
    return text.startswith("~") or text.startswith("/") or "/" in text


def profile_data_dir(profile: str, user_data_dir: Path | None = None) -> Path:
    """Folder Chrome should use for this profile."""
    if user_data_dir is not None:
        return Path(user_data_dir)
    name = (profile or "").strip()
    if _is_path_profile(name):
        return Path(name).expanduser()
    return profile_root() / name


def ensure_cdp(
    cdp_url: str,
    profile: str = "",
    *,
    executable: Path | None = None,
    user_data_dir: Path | None = None,
    wait_s: float = BROWSER_START_TIMEOUT_S,
    ready: Callable[[str], bool] | None = None,
    popen: Callable[..., Any] | None = None,
) -> None:
    """Start the profile browser when the CDP endpoint is not answering."""
    cdp_url = require_cdp_url(cdp_url)
    check = ready or (lambda url: cdp_ready(url))
    if check(cdp_url):
        return
    name = resolve_profile(cdp_url, profile)
    if not name:
        raise RuntimeError(
            f"Browser CDP is not ready at {cdp_url}. "
            "Set profile so the browser can be started, then retry."
        )
    data_dir = profile_data_dir(name, user_data_dir)
    if not data_dir.is_dir():
        if user_data_dir is None and _is_path_profile(name):
            data_dir.mkdir(parents=True, exist_ok=True)
            print(f"Created browser profile folder: {data_dir}", flush=True)
        else:
            raise FileNotFoundError(f"Browser profile directory does not exist: {data_dir}")
    port = urllib.parse.urlparse(cdp_url).port
    if port is None:
        raise RuntimeError(f"Cannot derive a debugging port from {cdp_url}")
    binary = Path(executable) if executable is not None else browser_executable()
    if not binary.is_file():
        raise FileNotFoundError(f"Browser executable does not exist: {binary}")
    plugin = browser_plugin()
    if plugin is not None and not plugin.is_dir():
        raise FileNotFoundError(f"Browser plugin directory does not exist: {plugin}")

    print(f"CDP {cdp_url} is down; starting {binary.name} for {name}", flush=True)
    launch = popen or subprocess.Popen
    command = [
        str(binary),
        f"--remote-debugging-port={port}",
        f"--user-data-dir={data_dir}",
        "--restore-last-session",
        "--no-first-run",
    ]
    if plugin is not None:
        command.append(f"--disable-extensions-except={plugin}")
        command.append(f"--load-extension={plugin}")
    command.append("about:blank")
    launch(
        command,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        if check(cdp_url):
            print(f"CDP ready at {cdp_url}", flush=True)
            return
        time.sleep(0.5)
    raise RuntimeError(
        f"{binary.name} did not expose CDP on {cdp_url} within {wait_s:.0f}s. "
        f"Quit any {name} window that is already open without remote debugging, then retry."
    )


def fingerprint(state: dict[str, Any]) -> str:
    content = {k: state.get(k) for k in ("url", "text", "actions", "scroll")}
    return hashlib.sha256(json.dumps(content, sort_keys=True, default=str).encode()).hexdigest()


def _page_focus(page: Any) -> dict[str, Any] | None:
    """Whether this tab is focused or visible. Unreadable tabs are skipped."""
    if getattr(page, "is_closed", lambda: False)():
        return None
    evaluate = getattr(page, "evaluate", None)
    if not callable(evaluate):
        return None
    try:
        state = evaluate(
            "() => ({focus: document.hasFocus(), visible: document.visibilityState === 'visible'})"
        )
    except Exception:
        return None
    return state if isinstance(state, dict) else None


def choose_open_page(pages: list[Any]) -> Any:
    """Tab a browser step uses when reuseTab was not set.

    The focused tab is the one the user is on. When the window is in the
    background, that tab is still the visible one. Several visible tabs means
    several windows; the newest of those is used. Otherwise the first page.
    """
    focused = None
    visible: list[Any] = []
    for page in pages:
        state = _page_focus(page)
        if not state:
            continue
        if state.get("focus"):
            focused = page
            break
        if state.get("visible"):
            visible.append(page)
    if focused is not None:
        return focused
    if visible:
        return visible[-1]
    return pages[0]


class Browser:
    def __init__(self, cdp_url: str, profile: str = "", reuse_site: str = ""):
        self.cdp_url = cdp_url.rstrip("/")
        self.profile = profile
        self.reuse_site = (reuse_site or "").strip()
        self.create_tabs = True
        self._pw = None
        self._browser = None
        self._ctx = None
        self.page = None
        self.after_input: dict[str, Any] | None = None

    def __enter__(self) -> "Browser":
        self.open()
        return self

    def __exit__(self, *_args) -> None:
        self.close()

    def open(self) -> None:
        self.cdp_url = require_cdp_url(self.cdp_url)
        ensure_cdp(self.cdp_url, self.profile)
        from playwright.sync_api import sync_playwright

        self._pw = sync_playwright().start()
        self._browser = self._pw.chromium.connect_over_cdp(self.cdp_url, timeout=60_000)
        if not self._browser.contexts:
            raise RuntimeError(f"No browser context on {self.cdp_url}")
        self._ctx = self._browser.contexts[0]
        listen_for_js_dialogs(self._ctx)
        pages = list(self._ctx.pages or [])
        if pages:
            self.page = choose_open_page(pages)
        elif self.create_tabs:
            self.page = self._ctx.new_page()
        else:
            raise RuntimeError("No open browser tab")
        listen_for_js_dialogs(self.page)
        self.page.set_default_timeout(45_000)
        if self._use_configured_tab():
            return
        try:
            url = self.page.url or ""
        except Exception:
            url = ""
        print(f"ACTIVE tab {url}", flush=True)

    def _use_configured_tab(self) -> bool:
        """Attach to config browser-reusetab when that site is set."""
        site = (self.reuse_site or "").strip()
        if not site:
            return False
        # The file default may name a site this routine has not opened yet.
        # set-config attaches later. A blank tab here would be left behind.
        self.reuse_tab(site, create=False)
        return True

    def close(self) -> None:
        self.page = None
        self._ctx = None
        self._browser = None
        if self._pw is not None:
            try:
                self._pw.stop()
            except Exception:
                pass
            self._pw = None

    def reuse_tab(self, site: str, *, create: bool | None = None) -> dict[str, Any]:
        """Use an open tab whose URL matches `site`, or open a new tab.

        Later steps keep using that page. Other tabs stay open.
        `create=False` stays on the current tab when none match.
        """
        self.reuse_site = (site or "").strip() or self.reuse_site
        self._ensure_connected()
        assert self._ctx is not None
        needle = tab_needle(site)
        matches: list[Any] = []
        for page in list(self._ctx.pages or []):
            try:
                url = (page.url or "").lower()
            except Exception:
                continue
            if needle not in url or _is_login_url(url):
                continue
            matches.append(page)
        allow_create = self.create_tabs if create is None else create
        created = False
        if self.page in matches:
            chosen = self.page
        elif matches:
            chosen = matches[0]
        elif not allow_create:
            chosen = self._open_page()
        else:
            chosen = self._ctx.new_page()
            created = True
        self.page = chosen
        listen_for_js_dialogs(self.page)
        self.page.set_default_timeout(45_000)
        info = self.observe()
        info["reused"] = not created
        url = str(info.get("url") or "")
        if created:
            print(f"NEW tab {url}")
        elif chosen in matches:
            print(f"REUSE tab {url}")
        else:
            print(f"ACTIVE tab {url}")
        return info

    def _open_page(self) -> Any:
        """An existing tab. A blank tab is used only when every tab is blank."""
        pages: list[Any] = []
        blank: list[Any] = []
        for page in list(self._ctx.pages or []):
            try:
                url = page.url or ""
            except Exception:
                continue
            if url.startswith("about:"):
                blank.append(page)
            else:
                pages.append(page)
        if self.page in pages:
            return self.page
        if pages:
            return choose_open_page(pages)
        if self.page is not None:
            return self.page
        if blank:
            return blank[0]
        raise RuntimeError("No open browser tab")

    def goto(self, url: str, *, wait_until: str = "domcontentloaded") -> dict[str, Any]:
        assert self.page is not None
        self.page.goto(url, wait_until=wait_until)
        self.page.wait_for_timeout(200)
        return self.observe()

    def reconnect(self) -> None:
        """Attach again after the Playwright driver process dies. Chrome stays open."""
        print("CDP driver closed; connecting again", flush=True)
        self.close()
        self.open()

    def _ensure_connected(self) -> None:
        if self.page is None or self._ctx is None:
            self.open()
            return
        try:
            self.page.url
        except Exception as exc:
            if not connection_lost(exc):
                raise
            self.reconnect()

    def observe(self, screenshot: bool = False) -> dict[str, Any]:
        assert self.page is not None
        if self.after_input:
            action, self.after_input = self.after_input, None
            wait_ms = 200 if action.get("kind") == "fill" else 50
            self.page.wait_for_timeout(wait_ms)
        try:
            info = evaluate_guarded(self.page, SNAPSHOT_JS)
        except Exception as exc:
            if not connection_lost(exc):
                raise StalePage(f"Document changed during snapshot: {exc}") from exc
            self.reconnect()
            assert self.page is not None
            try:
                info = evaluate_guarded(self.page, SNAPSHOT_JS)
            except Exception as again:
                raise StalePage(f"Document changed during snapshot: {again}") from again
        if not info:
            html = ""
            text = ""
            try:
                html = self.page.content()
            except Exception:
                html = ""
            try:
                text = self.page.inner_text("html")
            except Exception:
                text = html[:6000]
            info = {
                "url": self.page.url,
                "title": self.page.title(),
                "text": (text or "")[:6000],
                "html": html[:200000],
                "w": 0,
                "h": 0,
                "scroll": {"y": 0, "height": 0},
                "actions": [{"id": "wait", "kind": "wait", "label": "Wait for the page to update"}],
                "marker": None,
                "page_key": None,
                "guards": {},
                "omitted_actions": 0,
            }
        elif not info.get("html"):
            try:
                info["html"] = self.page.content()[:200000]
            except Exception:
                info["html"] = ""
        info["fingerprint"] = fingerprint(info)
        if screenshot:
            info["screenshot"] = self.page.screenshot(type="jpeg", quality=72).hex()
        return info

    def fresh(self, page: dict[str, Any], action: dict[str, Any] | None = None) -> bool:
        assert self.page is not None
        try:
            current = fingerprint(self.observe())
        except StalePage:
            return False
        if action and action.get("kind") in {"click", "fill", "select"}:
            return True
        return current == page.get("fingerprint") or True

    def act(self, action: dict[str, Any], page: dict[str, Any], text: str | None = None) -> dict[str, Any]:
        assert self.page is not None
        kind = action.get("kind")
        if kind == "goto":
            return {"executed": action.get("id"), "page": self.goto(str(action.get("url") or ""))}
        result = perform(self.page, action, text)
        if kind in {"scroll", "click", "fill", "select"}:
            self.after_input = action
        return result


SCROLL_PAGE_JS = """
({ delta }) => {
  const nodes = [...document.querySelectorAll("body *")];
  const candidates = [];
  for (const e of nodes) {
    if (!e || e.scrollHeight <= e.clientHeight + 8) continue;
    const oy = getComputedStyle(e).overflowY;
    if (!["auto", "scroll", "overlay"].includes(oy)) continue;
    const r = e.getBoundingClientRect();
    if (r.width < 180 || r.height < 180) continue;
    if (r.bottom <= 0 || r.top >= innerHeight || r.right <= 0 || r.left >= innerWidth) continue;
    const remaining = e.scrollHeight - e.scrollTop - e.clientHeight;
    if (remaining <= 8) continue;
    candidates.push({ e, area: r.width * r.height, remaining });
  }
  candidates.sort((a, b) => b.area - a.area || b.remaining - a.remaining);
  const chosen = candidates[0];
  if (!chosen) return false;
  const before = chosen.e.scrollTop;
  const step = delta || Math.max(280, Math.round(chosen.e.clientHeight * 0.8));
  chosen.e.scrollTop = before + step;
  return chosen.e.scrollTop !== before;
}
"""


_POINTER_ROLES = {"radio", "checkbox", "switch"}


def _click_file_locator(page: Any, locator: Any, files: list[str] | None = None) -> dict[str, Any]:
    """Click a file control through its selector and hand the named files to the chooser."""
    timeout_types: tuple[type[BaseException], ...] = (TimeoutError,)
    try:
        from playwright.sync_api import TimeoutError as PlaywrightTimeout

        timeout_types = (TimeoutError, PlaywrightTimeout)
    except Exception:
        pass
    try:
        with page.expect_file_chooser(timeout=1500) as pending:
            locator.click(timeout=1500)
        return _apply_file_chooser(pending.value, files)
    except timeout_types:
        release_stuck_file_dialog(announce_error=True)
    print("Closed the system file dialog without choosing a file.", flush=True)
    return {"file_dialog": "closed"}


def _contenteditable(locator: Any) -> bool:
    """Instagram's caption is a contenteditable. insert_text does not update it."""
    try:
        return bool(
            locator.evaluate(
                "el => !!(el && (el.isContentEditable || "
                "(el.querySelector && el.querySelector('[contenteditable=\"true\"], [contenteditable=\"plaintext-only\"]'))))"
            )
        )
    except Exception:
        return False


def _shown_text(locator: Any) -> str:
    shown = locator.evaluate("el => (el.innerText || el.value || el.textContent || '')")
    return " ".join(str(shown or "").split())


def _require_entered(locator: Any, value: str) -> None:
    """The log records the caption before the box changes. Read the box back."""
    needle = " ".join(value.split())[:40]
    if not needle:
        return
    try:
        got = _shown_text(locator)
    except Exception as exc:
        raise RuntimeError(f"Could not read the caption box: {exc}") from exc
    if needle.casefold() not in got.casefold():
        raise RuntimeError("The caption was not entered.")


def _fill_by_selector(page: Any, action: dict[str, Any], text: str | None) -> dict[str, Any] | None:
    """Type into a role locator. A spinbutton can sit under the date popup."""
    if action.get("kind") != "fill":
        return None
    value = str(text or "")
    selector = str(action.get("selector") or "")
    locate = getattr(page, "locator", None)
    if not value or not selector or locate is None:
        return None
    try:
        locator = _first_match(locate(selector))
    except Exception:
        return None
    editable = str(action.get("role") or "") != "spinbutton" and _contenteditable(locator)

    def attempt() -> None:
        # The visible clock is a set of segments. fill() writes the input value
        # and leaves the shown hour, minute, and AM/PM unchanged. Typing the
        # digits after a click updates the segment. Select-all replaces all three.
        if str(action.get("role") or "") == "spinbutton":
            locator.click(timeout=2000)
            page.keyboard.type(value, delay=50)
            return
        locator.click(timeout=2000)
        page.keyboard.press("Meta+A")
        page.keyboard.press("Backspace")
        if editable:
            # Select-all plus insert_text leaves a Lexical caption empty.
            try:
                page.wait_for_timeout(200)
            except Exception:
                pass
            page.keyboard.type(value, delay=8)
            return
        page.keyboard.insert_text(value)

    try:
        attempt()
    except Exception as exc:
        message = str(exc).lower()
        covered = any(word in message for word in ("intercept", "timeout", "visible", "covered", "detached"))
        if not covered or str(action.get("role") or "") == "spinbutton":
            return None
        try:
            page.keyboard.press("Escape")
            attempt()
        except Exception:
            return None
    if editable:
        _require_entered(locator, value)
        if "#" in value:
            try:
                page.wait_for_timeout(400)
            except Exception:
                pass
            dismiss_hashtag_popup(page)
    return {"executed": action.get("id"), "selector": selector}


def _act_by_selector(page: Any, action: dict[str, Any], text: str | None) -> dict[str, Any] | None:
    """Click a button, link, or tab by its role selector. Radios stay on the node path."""
    del text
    if action.get("kind") != "click" or action.get("role") in _POINTER_ROLES:
        return None
    selector = str(action.get("selector") or "")
    locate = getattr(page, "locator", None)
    if not selector or locate is None:
        return None
    try:
        locator = _first_match(locate(selector))
        if opens_file_dialog(str(action.get("label") or "")):
            files = action.get("files") if isinstance(action.get("files"), list) else None
            return _click_file_locator(page, locator, files)
        locator.click(timeout=2000)
    except Exception:
        return None
    return {"executed": action.get("id"), "selector": selector, "href": ""}


def _page_command(page: Any, action: dict[str, Any]) -> dict[str, Any]:
    """Reload, history, and key presses. These are page commands, not element targets."""
    kind = action.get("kind")
    if kind == "reload":
        page.reload(wait_until="domcontentloaded")
    elif kind == "back":
        landed = page.go_back(wait_until="domcontentloaded")
        if landed is None:
            raise RuntimeError("Cannot go back")
    elif kind == "forward":
        landed = page.go_forward(wait_until="domcontentloaded")
        if landed is None:
            raise RuntimeError("Cannot go forward")
    elif kind == "press":
        key = str(action.get("key") or "").strip()
        if not key:
            raise ValueError("press needs a key")
        page.keyboard.press(key)
        return {"executed": action.get("id"), "key": key}
    try:
        page.wait_for_timeout(200)
    except Exception:
        pass
    return {"executed": action.get("id")}


def _first_match(locator: Any) -> Any:
    """Several controls can share one role name. Use the first match instead of strict mode."""
    first = getattr(locator, "first", None)
    return first if first is not None else locator


def wait_for_locator(page: Any, selector: str, seconds: float) -> None:
    """Wait until a Playwright locator is attached. The locator does not have to be on the page yet.

    A role name that matches two Close buttons still counts as present.
    """
    timeout = max(1, int(float(seconds) * 1000))
    _first_match(page.locator(selector)).wait_for(state="attached", timeout=timeout)


_FILE_INPUT_JS = r"""
(() => {
  const found = [];
  const visit = (root) => {
    if (!root || !root.querySelectorAll) return;
    root.querySelectorAll('input[type="file"]').forEach((el) => found.push(el));
    root.querySelectorAll("*").forEach((el) => {
      if (el.shadowRoot) visit(el.shadowRoot);
    });
  };
  visit(document);
  return found.length ? found[found.length - 1] : null;
})()
"""


def set_local_input_files(page: Any, path: str) -> None:
    """Give Chrome a local path. CDP file transfer stops at 50 MB."""
    from pathlib import Path

    file = str(Path(path).expanduser().resolve())
    if not Path(file).is_file():
        raise RuntimeError(f"Could not find {file}.")
    context = getattr(page, "context", None)
    new_session = getattr(context, "new_cdp_session", None)
    if new_session is None:
        raise RuntimeError("set_local_input_files needs a CDP browser session")
    session = new_session(page)
    try:
        found = session.send(
            "Runtime.evaluate",
            {"expression": _FILE_INPUT_JS, "returnByValue": False},
        )
        remote = found.get("result") if isinstance(found, dict) else None
        object_id = str((remote or {}).get("objectId") or "")
        if not object_id:
            raise RuntimeError("No file input is on the page.")
        session.send("DOM.setFileInputFiles", {"objectId": object_id, "files": [file]})
    finally:
        detach = getattr(session, "detach", None)
        if detach is not None:
            detach()
    print(f"Chose {file}", flush=True)


def wait_for_document_ready(page: Any, seconds: float) -> None:
    """Wait until the load event fires. That is document.readyState complete."""
    timeout = max(1, int(float(seconds) * 1000))
    page.wait_for_load_state("load", timeout=timeout)


def perform(page: Any, action: dict[str, Any], text: str | None = None) -> dict[str, Any]:
    """Run one observed action on a Playwright page."""
    kind = action.get("kind")
    if kind == "wait_for_locator":
        selector = str(action.get("selector") or "")
        if not selector:
            raise ValueError("wait for locator needs a selector")
        wait_for_locator(page, selector, float(action.get("seconds") or 5))
        return {"executed": action.get("id"), "selector": selector}
    if kind == "wait":
        page.wait_for_timeout(100)
        return {"executed": action.get("id")}
    if kind == "scroll":
        delta = int(action.get("delta") or 720)
        anchor = action.get("anchor") if isinstance(action.get("anchor"), dict) else {}
        x, y = anchor.get("x"), anchor.get("y")
        moved = False
        try:
            moved = bool(page.evaluate(SCROLL_PAGE_JS, {"delta": delta}))
        except Exception:
            moved = False
        if not moved:
            if isinstance(x, (int, float)) and isinstance(y, (int, float)):
                page.mouse.move(float(x), float(y))
            else:
                size = page.viewport_size or {"width": 1280, "height": 800}
                page.mouse.move(size["width"] / 2, size["height"] / 2)
            page.mouse.wheel(0, delta)
            page.keyboard.press("PageDown")
        page.wait_for_timeout(120)
        return {"executed": action.get("id"), "moved": moved}
    if kind == "goto":
        page.goto(str(action.get("url") or ""), wait_until="domcontentloaded")
        page.wait_for_timeout(200)
        return {"executed": action.get("id")}
    if kind in {"reload", "back", "forward", "press"}:
        return _page_command(page, action)
    selected = _act_by_selector(page, action, text)
    if selected is not None:
        return selected
    filled = _fill_by_selector(page, action, text)
    if filled is not None:
        return filled
    node = action.get("node")
    if node is None:
        raise StalePage("Target has no observed node")
    target = page.evaluate(ACT_JS, {**action, "node": int(node)})
    if target is None:
        raise StalePage("Target changed or is covered. Observe again.")
    clicked: dict[str, Any] = {}
    if kind != "select" and not target.get("direct"):
        files = action.get("files") if isinstance(action.get("files"), list) else None
        clicked = _click(page, float(target["x"]), float(target["y"]), str(action.get("label") or ""), files)
    if kind == "fill":
        page.keyboard.press("Meta+A")
        page.keyboard.press("Backspace")
        if action.get("contenteditable"):
            try:
                page.wait_for_timeout(200)
            except Exception:
                pass
            page.keyboard.type(text or "", delay=8)
        else:
            page.keyboard.insert_text(text or "")
        if "#" in (text or ""):
            try:
                page.wait_for_timeout(400)
            except Exception:
                pass
            dismiss_hashtag_popup(page)
    return {"executed": action.get("id"), "href": target.get("href"), **clicked}


def _click(page: Any, x: float, y: float, label: str, files: list[str] | None = None) -> dict[str, Any]:
    if not opens_file_dialog(label):
        page.mouse.click(x, y)
        return {}
    return _click_file_button(page, x, y, files)


def _apply_file_chooser(chooser: Any, files: list[str] | None) -> dict[str, Any]:
    """Give the chooser the named files. An empty list cancels the dialog."""
    paths = [str(path) for path in (files or []) if str(path or "").strip()]
    try:
        chooser.set_files(paths)
    except Exception as exc:
        print(f"File dialog stayed open: {exc}", flush=True)
        release_stuck_file_dialog(announce_error=True)
        if paths:
            raise RuntimeError(f"Could not choose {paths[0]}: {exc}") from exc
    if paths:
        print(f"Chose {paths[0]}", flush=True)
        return {"file_dialog": "chosen", "file": paths[0]}
    print("Closed the system file dialog without choosing a file.", flush=True)
    return {"file_dialog": "closed"}


def _click_file_button(page: Any, x: float, y: float, files: list[str] | None = None) -> dict[str, Any]:
    """Click a file button. Named files go to the chooser. Otherwise the dialog is cancelled."""
    timeout_types: tuple[type[BaseException], ...] = (TimeoutError,)
    try:
        from playwright.sync_api import TimeoutError as PlaywrightTimeout

        timeout_types = (TimeoutError, PlaywrightTimeout)
    except Exception:
        pass
    try:
        with page.expect_file_chooser(timeout=1500) as pending:
            page.mouse.click(x, y)
        return _apply_file_chooser(pending.value, files)
    except timeout_types:
        release_stuck_file_dialog(announce_error=True)
    print("Closed the system file dialog without choosing a file.", flush=True)
    return {"file_dialog": "closed"}
