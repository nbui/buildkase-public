#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.runlog import (  # noqa: E402
    RunLog,
    _format_block,
    _shrink,
    compile_notice,
    log_compile,
    messages_from_prompt,
    note_compile_attempt,
    prompt_markdown,
)
from cg_loop.trace import bind, unbind  # noqa: E402
from cg_loop.workflow import Step, Workflow, load_workflow, select_workflows  # noqa: E402


def _posts(count: int) -> str:
    rows = [
        {
            "title": f"Post {index}",
            "description": "Deep sleep isn't just resting. " * 40,
            "url": "https://studio.youtube.com/channel/example/videos/short",
            "views": index,
            "date": "Sep 17, 2026",
        }
        for index in range(count)
    ]
    return json.dumps(rows, indent=2, ensure_ascii=False)


class RunLogShrinkTests(unittest.TestCase):
    def test_long_extracted_json_keeps_a_sample(self) -> None:
        raw = _posts(6)
        self.assertGreater(len(raw), 2000)
        shrunk = _shrink({"extracted_data": raw})
        extracted = shrunk["extracted_data"]
        self.assertEqual(extracted["count"], 6)
        self.assertEqual(len(extracted["sample"]), 2)
        self.assertEqual(extracted["sample"][0]["title"], "Post 0")
        self.assertEqual(extracted["sample"][0]["views"], 0)
        self.assertIn("date", extracted["sample"][0])

        logged = "\n".join(_format_block(shrunk))
        self.assertIn("extracted_data:", logged)
        self.assertIn("sample:", logged)
        self.assertIn("title: Post 0", logged)
        self.assertIn("views: 0", logged)
        self.assertNotIn("extracted_data: [ …", logged)

    def test_short_extracted_json_is_logged_in_full(self) -> None:
        raw = json.dumps([{"title": "Only one", "views": 3}], indent=2)
        shrunk = _shrink({"extracted_data": raw})
        self.assertEqual(shrunk["extracted_data"], [{"title": "Only one", "views": 3}])
        logged = "\n".join(_format_block(shrunk))
        self.assertIn("title: Only one", logged)
        self.assertIn("views: 3", logged)

    def test_printed_reply_follows_the_step_line(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text("config:\n  name: demo\n", encoding="utf-8")
            workflow = Workflow(name="demo", path=path, group="hug_model_routine")
            log = RunLog(workflow, stamp="test", fallback=Path(tmp) / "fallback")
            step = Step(kind="hug", raw="/hug +m hug-json.md +print", tool="hug")
            log.pending_title = ("## Step 1/1", step.raw)
            log.begin(index=0, group="hug_model_routine", step=step, script=None, inputs={"print": True})
            buf = StringIO()
            with redirect_stdout(buf):
                log.finish(status="ok", outputs={"text": '{"place": "Unknown"}', "status": "ok"})
        text = buf.getvalue()
        self.assertLess(text.index("## Step 1/1"), text.index('{"place": "Unknown"}'))

    def test_python_print_follows_the_step_line(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text("config:\n  name: demo\n", encoding="utf-8")
            workflow = Workflow(name="demo", path=path, group="wf_post")
            log = RunLog(workflow, stamp="test", fallback=Path(tmp) / "fallback")
            step = Step(kind="goal", raw="/python print $post_date", tool="python")
            log.pending_title = ("## Step 5/5", step.raw)
            log.begin(index=4, group="wf_post", step=step, script=None, inputs={"command": step.raw})
            buf = StringIO()
            with redirect_stdout(buf):
                log.finish(
                    status="ok",
                    outputs={"status": "ok", "printed": "2026-10-19 00:00:00", "post_date": "2026-10-19 00:00:00"},
                )
        text = buf.getvalue()
        self.assertLess(text.index("## Step 5/5"), text.index("2026-10-19 00:00:00"))

    def test_json_object_stays_text(self) -> None:
        raw = '{"place": "Unknown"}'
        shrunk = _shrink({"text": raw})
        self.assertEqual(shrunk["text"], raw)
        logged = "\n".join(_format_block(shrunk))
        self.assertIn('text: {"place": "Unknown"}', logged)

    def test_many_small_items_sample_up_to_list_limit(self) -> None:
        shrunk = _shrink(list(range(25)))
        self.assertEqual(shrunk["count"], 25)
        self.assertEqual(shrunk["sample"], list(range(20)))

    def test_compile_notice_names_the_step_json_finish_writes(self) -> None:
        self.assertEqual(compile_notice("RECOMPILE script.py"), "RECOMPILE script.py")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text("config:\n  name: demo\n", encoding="utf-8")
            workflow = Workflow(name="demo", path=path, group="wf_post_full_sleep_story")
            log = RunLog(workflow, stamp="test", fallback=Path(tmp) / "fallback")
            step = Step(kind="goal", raw="/browser go to studio.youtube.com", tool="browser")
            step_json = log.upcoming_step_json("wf_post_full_sleep_story", step)
            notice = compile_notice(f"COMPILE browser {path}", step_json)
            self.assertIn(f"step json {step_json}", notice)
            saved = sys.stdout
            panel = StringIO()
            sys.stdout = panel
            try:
                bind(log.path)
                log_compile(f"COMPILE browser {path}", step_json)
                log_compile(f"api request a-request.py  {path}", folder=step_json.parent)
                log_compile(f"RECOMPILE failed {path}: Upload videos is not on the page.", step_json)
            finally:
                unbind()
                sys.stdout = saved
            self.assertEqual(panel.getvalue(), "")
            logged = log.path.read_text(encoding="utf-8")
            self.assertIn(f"COMPILE browser {path}", logged)
            self.assertIn(f"step json {step_json}", logged)
            self.assertIn(f"api request a-request.py  {path}", logged)
            self.assertIn("Upload videos is not on the page.", logged)
            log.begin(
                index=402,
                group="wf_post_full_sleep_story",
                step=step,
                script=None,
                inputs={},
            )
            log.finish(status="blocked", outputs={"message": "blocked"})
            self.assertTrue(step_json.is_file())
            self.assertEqual(step_json.name, "c-01-context.json")
            self.assertFalse((step_json.parent / "a-run.prompt.md").exists())

    def test_step_json_includes_the_screenshot_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            script = root / "click_kids.py"
            script.write_text("def run(ctx):\n    return {}\n", encoding="utf-8")
            image = root / "click_kids-1.jpg"
            image.write_bytes(b"jpeg")
            script.with_suffix(".json").write_text(
                json.dumps({"screenshots": [image.name]}) + "\n",
                encoding="utf-8",
            )
            workflow_path = root / "wf.yaml"
            workflow_path.write_text("config:\n  name: demo\n", encoding="utf-8")
            workflow = Workflow(name="demo", path=workflow_path, group="wf_post")
            log = RunLog(workflow, stamp="test", fallback=root / "fallback")
            step = Step(kind="goal", raw="/browser Click No, it's not made for kids", tool="browser")
            step_json = log.upcoming_step_json("wf_post", step)
            log.begin(
                index=6,
                group="wf_post",
                step=step,
                script=script,
                inputs={"step": "/browser Click No, it's not made for kids"},
            )
            log.finish(status="error", outputs={"error": "The named control is not on the page."})
            saved = json.loads(step_json.read_text(encoding="utf-8"))
            self.assertEqual(saved["outputs"]["image"], str(image))
            self.assertEqual(saved["outputs"]["error"], "The named control is not on the page.")

    def test_step_prompt_is_logged_as_markdown(self) -> None:
        user = json.dumps({"current_step": "/browser Wait max 10s until the Title box is showing.", "plan": "List actions"})
        outputs = {
            "llm_call": {
                "purpose": "action",
                "messages": [
                    {"role": "system", "content": "Return JSON only."},
                    {"role": "user", "content": user},
                ],
            }
        }
        text = prompt_markdown("/browser Wait max 10s until the Title box is showing.", outputs)
        self.assertIn("## system\n\nReturn JSON only.", text)
        self.assertIn('"current_step": "/browser Wait max 10s until the Title box is showing."', text)
        self.assertNotIn(user, text)
        loaded = messages_from_prompt(text)
        self.assertEqual(loaded[0], {"role": "system", "content": "Return JSON only."})
        self.assertIn("\n  \"current_step\":", loaded[1]["content"])
        self.assertEqual(prompt_markdown("/browser Wait max 10s until the Title box is showing.", {"llm_call": {"messages": loaded}}), text)

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text("config:\n  name: demo\n", encoding="utf-8")
            workflow = Workflow(name="demo", path=path, group="wf_post_full_sleep_story")
            log = RunLog(workflow, stamp="test", fallback=Path(tmp) / "fallback")
            log.begin(
                index=402,
                group="wf_post_full_sleep_story",
                step=Step(kind="goal", raw="/browser Wait max 10s until the Title box is showing.", tool="browser"),
                script=None,
                inputs={"step": "/browser Wait max 10s until the Title box is showing."},
            )
            log.finish(status="blocked", outputs=outputs)
            prompt = next(log.directory.rglob("a-run.prompt.md"))
            self.assertTrue(prompt.is_file())
            saved = prompt.read_text(encoding="utf-8")
            self.assertEqual(saved, text)
            self.assertIn("## user", saved)
            logged = log.path.read_text(encoding="utf-8")
            self.assertIn(f"prompt md {prompt.name}  {prompt}", logged)

    def test_each_wf_group_keeps_its_own_log(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "wf_one:",
                        "  - term echo one",
                        "wf_two:",
                        "  - term echo two",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            loaded = load_workflow(yaml_path)
            one = select_workflows(loaded, "wf_one")[0]
            two = select_workflows(loaded, "wf_two")[0]
            step = Step(kind="term", raw="term echo one")
            log_one = RunLog(one, stamp="20261005-210000", fallback=root / "fallback")
            log_one.begin(index=0, group=one.group, step=step, script=None, inputs={})
            log_one.finish(status="ok", outputs={"stdout": "one"})
            note_compile_attempt(
                one,
                step,
                index=0,
                mode="direct",
                status="compiled",
                path=None,
                elapsed_ms=1,
                result="compiled one",
            )
            log_two = RunLog(two, stamp="20261005-210100", fallback=root / "fallback")
            log_two.begin(index=0, group=two.group, step=step, script=None, inputs={})
            log_two.finish(status="ok", outputs={"stdout": "two"})

            logs = workflows / "cache" / "wf-demo"
            one_log = (logs / "wf_one" / "c-run.log").read_text(encoding="utf-8")
            two_log = (logs / "wf_two" / "c-run.log").read_text(encoding="utf-8")
            self.assertIn("term echo one", one_log)
            self.assertIn("stdout: one", one_log)
            self.assertNotIn("stdout: two", one_log)
            self.assertIn("stdout: two", two_log)
            self.assertIn("compiled one", (logs / "wf_one" / "c-compile.log").read_text(encoding="utf-8"))
            self.assertFalse((logs / "wf_two" / "c-compile.log").exists())

            RunLog(one, stamp="20261005-210200", fallback=root / "fallback")
            self.assertTrue((logs / "wf_one" / "archived").is_dir())
            self.assertFalse((logs / "wf_two" / "archived").exists())
            self.assertIn("stdout: two", (logs / "wf_two" / "c-run.log").read_text(encoding="utf-8"))
            self.assertFalse((logs / "wf_one" / "c-run.log").exists())
            kept = list((logs / "wf_one").glob("*/a_01-context.json"))
            self.assertEqual(len(kept), 1)
            self.assertFalse(list((logs / "wf_one").glob("*/c-compile.log")))
            self.assertFalse(list((logs / "wf_one").glob("*/c-*-context.json")))
            archived_steps = list((logs / "wf_one" / "archived").glob("*/*/a_01-context.json"))
            self.assertEqual(len(archived_steps), 1)
            self.assertTrue(list((logs / "wf_one" / "archived").glob("*/*/c-compile.log")))


if __name__ == "__main__":
    unittest.main()
