#!/usr/bin/env python3
"""Jev-style CG loop: indexed browser actions, terminal commands, workflow YAML."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "lib"))

from cg_loop.agent import Agent  # noqa: E402
from cg_loop.app_config import apply_app_env, workflows_root  # noqa: E402
from cg_loop.terminal import command_timeout  # noqa: E402
from cg_loop.clef import load_clef_if_needed  # noqa: E402
from cg_loop.model import (  # noqa: E402
    ChatError,
    configure,
    load_env_file,
    load_hug_chat_if_needed,
    load_laya_if_needed,
    load_von_if_needed,
)
from cg_loop.workflow import (  # noqa: E402
    apply_overrides,
    attach_folder_catalog,
    format_workflow_run_command,
    load_workflow,
    load_workflow_dir,
    parse_override,
    select_step_at_line,
    select_steps_between,
    select_workflows,
    workflow_from_goal,
    workflow_yaml_files,
)


def _looks_like_workflow(value: str) -> bool:
    path = Path(value).expanduser()
    if path.is_dir():
        return True
    return path.suffix.lower() in {".yaml", ".yml"} and path.is_file()


def _load_llm_env() -> None:
    """Read `.env.llm` when the shell did not export the OpenRouter key."""
    explicit = os.environ.get("CG_LLM_ENV", "").strip()
    if explicit:
        path = Path(explicit).expanduser()
    else:
        from cg_loop.workflow import project_root

        path = project_root().parent / ".env.llm"
    load_env_file(path)


def main() -> int:
    os.environ.setdefault("CG_LOOP_RESIDENT", "1")
    _load_llm_env()
    apply_app_env()
    parser = argparse.ArgumentParser(
        description=(
            "Browser+terminal agent with a dynamic indexed action space. "
            "Pass a workflow folder, a workflow YAML, or a natural-language goal."
        )
    )
    parser.add_argument(
        "--workflow",
        "-w",
        help="Workflow folder or YAML to run. A folder exposes every wf_* group.",
    )
    parser.add_argument("--url", default="", help="Open this URL before a free-form goal.")
    parser.add_argument(
        "--cdp-url",
        default="",
        help="Override config cdp-url.",
    )
    parser.add_argument(
        "--profile",
        default="",
        help="Override config profile.",
    )
    parser.add_argument(
        "--loop-count",
        type=int,
        default=None,
        help="Override config loop-count (repeat the workflow N times).",
    )
    parser.add_argument(
        "--loop-delay",
        type=float,
        default=None,
        help="Override config loop-delay (seconds between repeats).",
    )
    parser.add_argument(
        "--param",
        "-p",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Override a config field (cdp-url, profile, loop-count, loop-delay, log-keep, llm, model, llm-timeout, command-timeout, recompile, browser-recompile, browser-reusetab, recompile-on-error) or env var.",
    )
    parser.add_argument(
        "--env",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Override a workflow env var (e.g. SLIDES_SCRIPT=/path).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print operations without executing browser/terminal/LLM writes.",
    )
    parser.add_argument(
        "--compile",
        action="store_true",
        help="Rewrite the selected step scripts and do not run them.",
    )
    parser.add_argument(
        "--recompile",
        action="store_true",
        help="Rewrite every step script instead of reusing compiled/.",
    )
    parser.add_argument(
        "--browser-recompile",
        action="store_true",
        help="Rewrite /browser step scripts. Other steps stay reused.",
    )
    parser.add_argument(
        "--recompile-on-error",
        action="store_true",
        help="After a step script raises, rewrite that script once and run it again.",
    )
    parser.add_argument(
        "--pause",
        action="store_true",
        help="Wait for Enter before each executed action (jev 'Choose next').",
    )
    parser.add_argument(
        "--run",
        "-x",
        action="store_true",
        help="Execute (default). Kept for compatibility with the old dry-run CLI.",
    )
    parser.add_argument(
        "--only",
        default="",
        help="Run one wf_* group (wf_slides, slides). wf_all runs every group. Omit when one group is loaded.",
    )
    parser.add_argument(
        "--line",
        type=int,
        default=0,
        help="Run the step at this 1-based line of the workflow file. The editor cursor line.",
    )
    parser.add_argument(
        "--end",
        type=int,
        default=0,
        help="With --line, run the steps from that line through this line.",
    )
    parser.add_argument(
        "goal",
        nargs="*",
        help="Workflow folder, workflow YAML path, or a natural-language goal.",
    )
    args = parser.parse_args()
    positional = " ".join(args.goal).strip()
    workflow_path = args.workflow
    goal = ""
    if positional and _looks_like_workflow(positional.split()[0]):
        workflow_path = positional.split()[0]
        goal = positional[len(workflow_path) :].strip()
    elif positional:
        goal = positional

    if not workflow_path and goal:
        named = _workflow_in_root(goal.split()[0])
        if named:
            workflow_path = named
            goal = goal[len(goal.split()[0]) :].strip()
    if workflow_path:
        try:
            workflow = _load_command_workflow(workflow_path)
        except ValueError as exc:
            print(exc)
            return 2
        if goal:
            from cg_loop.workflow import parse_step

            workflow.steps.append(parse_step(goal))
    elif not goal:
        root = workflows_root()
        if root is None:
            print("Workflow YAML path or CG goal?")
            goal = input("> ").strip()
            if not goal:
                print("No goal or workflow provided.")
                return 1
            if _looks_like_workflow(goal):
                try:
                    workflow = _load_command_workflow(goal)
                except ValueError as exc:
                    print(exc)
                    return 2
            else:
                workflow = workflow_from_goal(
                    goal,
                    url=args.url,
                    cdp_url=args.cdp_url,
                    profile=args.profile or os.environ.get("CG_LOOP_PROFILE", ""),
                )
        else:
            try:
                workflow = _load_command_workflow(str(root))
            except ValueError as exc:
                print(exc)
                return 2
    elif _looks_like_workflow(goal):
        try:
            workflow = _load_command_workflow(goal)
        except ValueError as exc:
            print(exc)
            return 2
    else:
        workflow = workflow_from_goal(
            goal,
            url=args.url,
            cdp_url=args.cdp_url,
            profile=args.profile or os.environ.get("CG_LOOP_PROFILE", ""),
        )

    try:
        overrides, env_overrides = _cli_overrides(args)
        apply_overrides(workflow, overrides, env=env_overrides, lock=True)
    except ValueError as exc:
        print(exc)
        return 2

    dry_run = args.dry_run and not args.run
    try:
        if args.line and args.end and args.end != args.line:
            workflow = select_steps_between(workflow, args.line, args.end, only=args.only)
        elif args.line:
            workflow = select_step_at_line(workflow, args.line, only=args.only)
        else:
            workflow = select_workflows(workflow, args.only)[0]
        apply_overrides(workflow, {"WORKFLOW_RUN_COMMAND": format_workflow_run_command(sys.argv[1:])})
    except ValueError as exc:
        print(exc)
        return 2
    if args.line:
        for step in workflow.steps:
            print(f"step {workflow.group}:{step.line} {step.raw}")
    timeout = command_timeout(workflow.command_timeout)
    configure(
        workflow.llm,
        workflow.model,
        workflow.env,
        timeout=workflow.llm_timeout,
        fallbacks=workflow.fallbacks,
    )
    if workflow.loop_count > 1:
        print(f"loop: count={workflow.loop_count} delay={workflow.loop_delay}s")

    import time

    started = time.perf_counter()
    try:
        load_von_if_needed(workflow)
        load_laya_if_needed(workflow)
        load_hug_chat_if_needed(workflow)
        if not dry_run:
            load_clef_if_needed(workflow)
    except ChatError as exc:
        print(exc)
        return 1
    print(f"init {time.perf_counter() - started:.3f}s")

    final = None
    status = "ready"
    for round_i in range(max(1, workflow.loop_count)):
        if round_i:
            time.sleep(max(0.0, workflow.loop_delay))
        if workflow.loop_count > 1:
            print(f"\n=== loop {round_i + 1}/{workflow.loop_count} ===")
        with Agent(
            workflow,
            dry_run=dry_run,
            pause=args.pause,
            command_timeout=timeout,
            cdp_url=workflow.cdp_url,
            recompile=workflow.recompile,
            browser_recompile=workflow.browser_recompile,
            recompile_on_error=workflow.recompile_on_error,
            compile_only=args.compile,
        ) as agent:
            for state in agent.run():
                final = state
            status = (final or {}).get("status") or "blocked"
        if status == "blocked":
            return 1
    return 0


def _workflow_in_root(name: str) -> str:
    """A workflow file in the configured folder, including subfolders.

    Matches the file name, the stem, or the path relative to that folder.
    Empty when it is missing or more than one file matches.
    """
    root = workflows_root()
    if root is None or not name or any(ch.isspace() for ch in name):
        return ""
    try:
        root = root.resolve()
        files = workflow_yaml_files(root)
    except (OSError, ValueError):
        return ""
    needle = name.replace("\\", "/")
    hits: list[Path] = []
    for path in files:
        relative = path.relative_to(root).as_posix()
        relative_stem = str(Path(relative).with_suffix(""))
        if needle in {path.name, path.stem, relative, relative_stem}:
            hits.append(path.resolve())
    unique = list(dict.fromkeys(hits))
    if len(unique) == 1:
        return str(unique[0])
    return ""


def _load_command_workflow(value: str):
    """Load a folder of workflows, or one file plus the other workflows beside it.

    A folder is the catalog: every wf_* name can be called, and a repeated name
    is an error. A file still runs that file, and can call groups from the folder.
    """
    target = Path(value).expanduser()
    if target.is_dir():
        return load_workflow_dir(target)
    workflow = load_workflow(target)
    attach_folder_catalog(workflow, target.parent)
    return workflow


def _cli_overrides(args: argparse.Namespace) -> tuple[dict[str, str], dict[str, str]]:
    overrides: dict[str, str] = {}
    if args.cdp_url:
        overrides["cdp-url"] = args.cdp_url
    if args.profile:
        overrides["profile"] = args.profile
    if args.loop_count is not None:
        overrides["loop-count"] = str(args.loop_count)
    if args.loop_delay is not None:
        overrides["loop-delay"] = str(args.loop_delay)
    if args.recompile:
        overrides["recompile"] = "1"
    if args.browser_recompile:
        overrides["browser-recompile"] = "1"
    if args.recompile_on_error:
        overrides["recompile-on-error"] = "1"
    for item in args.param:
        key, value = parse_override(item)
        overrides[key] = value
    if args.compile:
        overrides["recompile"] = "1"
    env_overrides: dict[str, str] = {}
    for item in args.env:
        key, value = parse_override(item)
        env_overrides[key] = value
    return overrides, env_overrides


if __name__ == "__main__":
    raise SystemExit(main())
