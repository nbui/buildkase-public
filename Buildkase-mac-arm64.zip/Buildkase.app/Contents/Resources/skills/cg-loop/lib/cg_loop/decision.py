"""Pick a known tool for a step message. The loop then compiles or executes it.

A prefix is decided locally. A message with no tool goes to the decision model,
which picks one tool from the actions in workflows-app.yaml. `python-default`
skips that model and uses python.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable

from .app_config import load_app_config
from .workflow import Step, python_sentence

_TOOL_RE = re.compile(r"^/(?P<tool>[A-Za-z][\w-]*)\b")

# Parsed kinds that already have a local runner. Compile does not write a .py for these.
# load and generate are python actions. goto is a browser action.
_LOCAL_KINDS = {
    "term": "term",
    "load": "python",
    "goto": "browser",
    "reuse_tab": "browser",
    "browser_js": "browser",
    "browser_gemma": "browser",
    "openrouter": "openrouter",
    "lmstudio": "lmstudio",
    "locate": "locate",
    "clef": "clef",
    "cua": "cua",
    "hug": "hug",
    "workflow": "workflow",
    "set_config": "set_config",
    "condition": "condition",
    "generate": "python",
    "llm_call": "openrouter",
}

_KEYWORD_TOOLS = (
    ("python", ("python", "print $", "set $", "load ", "generate ", "folders in ")),
    ("locate", ("locate ", "/locate")),
    ("cua", ("launch ", "desktop")),
    ("term", ("echo ", "shell ", "bash ", "run ")),
    ("browser", ("click", "type ", "scroll", "navigate", "wait until", "page", "goto ")),
    ("lmstudio", ("lmstudio",)),
)


@dataclass(frozen=True)
class Decision:
    """The tool for a message, and whether this pass compiles or executes."""

    tool: str
    mode: str


def uses_python_default() -> bool:
    """True when a step with no /tool prefix should use python and skip the model."""
    name = (load_app_config().decision_model or "").strip().lower().replace("_", "-")
    return name == "python-default"


def decide_message(
    message: str,
    *,
    phase: str = "execute",
    ask: Callable[[str], str] | None = None,
    skip: frozenset[str] = frozenset(),
    rules: list[str] | None = None,
) -> Decision:
    """Pick one known tool. `phase` is `compile` or `execute`.

    `skip` drops tools that must not be chosen, such as `condition` when the
    message is the check itself. `rules` are extra instructions for Layla.
    `python-default` returns python and does not call the model.
    """
    if phase not in {"compile", "execute"}:
        raise ValueError(f"phase must be compile or execute, got {phase!r}")

    def default_ask(text: str) -> str:
        return ask_decision_model(text, skip=skip, rules=rules)

    tool = match_tool(message)
    if tool in skip:
        tool = ""
    if not tool and uses_python_default() and "python" not in skip:
        tool = "python"
    if not tool:
        try:
            tool = (ask or default_ask)(message)
        except Exception as exc:
            if str(exc).startswith("decision model picked"):
                raise
            tool = keyword_tool(message)
            if tool in skip:
                tool = ""
        if not tool:
            raise ValueError(f"decision model did not pick a tool for: {message}")
    tool = tool.strip().lower()
    if tool in skip:
        raise ValueError(f"decision model picked skipped tool {tool!r}")
    known = load_app_config().tools
    if tool not in known:
        raise ValueError(f"unknown tool {tool!r}; known: {', '.join(known)}")
    return Decision(tool=tool, mode=phase)


def match_tool(message: str) -> str:
    """The tool a message already names. Empty when the decision model should choose."""
    text = (message or "").strip()
    match = _TOOL_RE.match(text)
    if not match:
        return ""
    name = match.group("tool").lower()
    if name == "lmstudio" or name.startswith("lmstudio-"):
        return "browser" if text.lower().startswith("/browser") else "lmstudio"
    if name == "openrouter" or name.startswith("openrouter-"):
        return "browser" if text.lower().startswith("/browser") else "openrouter"
    known = load_app_config().tools
    if name in known:
        return name
    return ""


def keyword_tool(message: str) -> str:
    """A local guess when the decision model cannot be reached."""
    text = (message or "").strip().lower()
    if not text:
        return ""
    known = load_app_config().tools
    for tool, phrases in _KEYWORD_TOOLS:
        if tool in known and any(phrase in text for phrase in phrases):
            return tool
    return ""


def known_tool(step: Step) -> str:
    """The local tool a parsed step already is. Empty when the message still needs a decision."""
    if step.tool in {"browser", "term", "locate", "cua", "python", "hug"} and step.kind != "extract":
        return step.tool
    if step.kind == "openrouter" or step.tool == "openrouter":
        return "openrouter"
    if step.kind == "lmstudio" or step.tool == "lmstudio":
        return "lmstudio"
    return _LOCAL_KINDS.get(step.kind, "")


def skips_script(step: Step) -> bool:
    """Known tools run in process. Compile does not write a .py wrapper for them.

    A `/python` step the local helper already understands also skips the script.
    Page extracts and other `/python` steps still generate code.
    """
    from .python_helper import python_helper_handles
    from .step_cache import is_code_step

    if is_code_step(step):
        return False
    # `/browser +js <instruction>` compiles a function. The instruction is not JavaScript.
    if step.params.get("generate_js"):
        return False
    # A /browser extract still generates code. The RSS extract runs locally.
    if step.kind == "extract":
        return step.tool != "browser"
    if step.tool == "python" and step.kind == "goal" and python_helper_handles(python_sentence(step)):
        return True
    if step.tool == "python" and step.kind == "goal":
        return False
    # Von and Layla write the actions once. Later runs replay them. The model
    # runs again only when that step is recompiled. A /cua click, launch, or
    # sendkeys does the same: the script is b-compile.py in the step folder.
    if step.tool == "browser" and step.kind == "goal":
        return False
    if step.tool == "cua" and step.kind in {"goal", "cua"}:
        return False
    return bool(known_tool(step))


def ask_decision_model(
    message: str,
    *,
    skip: frozenset[str] = frozenset(),
    rules: list[str] | None = None,
) -> str:
    """Ask Layla which known tool the message uses. The configured model is layla."""
    from .model import _jev_post

    config = load_app_config()
    tools = {name: spec for name, spec in config.tools.items() if name not in skip}
    model = (config.decision_model or "von").strip() or "von"
    result = _jev_post(
        {
            "model": model,
            "state": {"step": message},
            "questions": {
                "tool": {
                    "type": "choice",
                    "criteria": {name: spec.criteria() or name for name, spec in tools.items()},
                    "instructions": {
                        "goal": message,
                        "rules": [
                            "Pick the one tool whose actions can do this step.",
                            "Open a page with browser. Read files or write content with python.",
                            *(rules or []),
                        ],
                    },
                }
            },
        }
    )
    answer = (result.get("answers") or {}).get("tool") or {}
    tool = str(answer.get("choice") or "").strip().lower()
    if tool not in tools:
        raise ValueError(f"decision model picked unknown tool {tool!r}")
    return tool
