#!/usr/bin/env bash
# Route a free-text idea into the correct CG ideas.yaml bank (LM Studio).
# Default dry-run; pass --write to append.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY="${ROOT}/venv/bin/python"
if [[ ! -x "$PY" ]]; then
  PY="python3"
fi

exec "$PY" "${ROOT}/scripts/add_idea.py" "$@"
