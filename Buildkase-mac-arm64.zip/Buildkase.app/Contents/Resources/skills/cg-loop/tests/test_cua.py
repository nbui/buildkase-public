#!/usr/bin/env python3
"""/cua launches an app and clicks a label the perception engine reads."""

from __future__ import annotations

import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path
from typing import Any

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.compiled import ensure_compiled, run_cua, validate_compiled  # noqa: E402
from cg_loop.cua import (  # noqa: E402
    LocateMiss,
    McpCuaDriver,
    Region,
    WindowState,
    actions_from_laya,
    compile_cua_actions,
    perception_fallback_click,
    regions_from,
    replay_cua_actions,
    send_keys,
    session_label,
    type_into,
    wait_action,
)
from cg_loop.workflow import load_workflow, parse_step, project_root  # noqa: E402

WORKFLOW = project_root() / "workflows" / "wf-cua.yaml"


class FakeDriver:
    def __init__(self, regions: list[Region]) -> None:
        self.regions = regions
        self.clicks: list[tuple[str, str, str]] = []

    def target_window(self, app: str = "") -> dict[str, int]:
        del app
        return {"pid": 7, "window_id": 11}

    def get_window_state(self, pid: int, window_id: int) -> WindowState:
        return WindowState(capture_id="cap-1", pid=pid, window_id=window_id)

    def parse_visual_regions(self, capture_id: str) -> list[Region]:
        del capture_id
        return self.regions

    def click_region(self, capture_id: str, region_id: str, strategy: str = "background_first") -> dict[str, Any]:
        self.clicks.append((capture_id, region_id, strategy))
        return {"status": "ok", "region_id": region_id, "capture_id": capture_id}


class CuaParseTest(unittest.TestCase):
    def test_workflow_launches_chrome_then_clicks(self) -> None:
        group = load_workflow(WORKFLOW).named_groups()["open_chrome_routine"]
        launch, click, keys, check, short = group.steps
        self.assertEqual(launch.tool, "cua")
        self.assertEqual(launch.extra, "launch")
        self.assertEqual(launch.params["app"], "Chrome")
        self.assertEqual(launch.url, "https://www.yahoo.com/")
        self.assertEqual(click.extra, "click")
        self.assertEqual(click.params["label"], "Search text box")
        self.assertEqual(keys.extra, "sendkeys")
        self.assertEqual(keys.params["label"], "clear")
        self.assertEqual(keys.params["text"], "Hello World^Enter")
        self.assertEqual(check.kind, "clef")
        self.assertEqual(check.extra, "Yahoo text exists?")
        self.assertEqual(check.params["image"], "/cua")
        self.assertEqual(check.params["verify"], "yes")
        self.assertEqual(short.kind, "clef")
        self.assertEqual(short.extra, "Yahoo text exists")
        self.assertEqual(short.params["image"], "/cua")
        self.assertEqual(short.params["verify"], "yes")

    def test_a_sentence_is_a_laya_command(self) -> None:
        step = parse_step(
            '/cua Open Chrome to https://www.yahoo.com/, click "Search text box", and type "Hello World" into it'
        )
        self.assertEqual(step.kind, "goal")
        self.assertEqual(step.tool, "cua")

    def test_plus_action_is_the_same_click(self) -> None:
        step = parse_step('/cua +click "Search text box"')
        self.assertEqual(step.kind, "cua")
        self.assertEqual(step.extra, "click")
        self.assertEqual(step.params["label"], "Search text box")
        self.assertEqual(step.raw, '/cua +click "Search text box"')
        launched = parse_step("/cua +launch Chrome https://www.yahoo.com/")
        self.assertEqual(launched.params["app"], "Chrome")
        self.assertEqual(launched.url, "https://www.yahoo.com/")

    def test_click_can_name_the_app(self) -> None:
        step = parse_step('/cua click "Play Video" in Chrome into $hit')
        self.assertEqual(step.params["label"], "Play Video")
        self.assertEqual(step.params["app"], "Chrome")
        self.assertEqual(step.var, "hit")

    def test_sendkeys_clear_then_text(self) -> None:
        step = parse_step('/cua sendkeys clear then "Hello World"')
        self.assertEqual(step.kind, "cua")
        self.assertEqual(step.extra, "sendkeys")
        self.assertEqual(step.params["label"], "clear")
        self.assertEqual(step.params["text"], "Hello World")

    def test_rejects_a_click_with_no_label(self) -> None:
        with self.assertRaises(ValueError):
            parse_step("/cua click")

    def test_wait_is_a_timed_pause(self) -> None:
        step = parse_step("/cua wait 10s")
        self.assertEqual(step.kind, "cua")
        self.assertEqual(step.extra, "wait")
        self.assertEqual(step.params["text"], "10s")
        self.assertEqual(step.params["seconds"], 10)
        group = load_workflow(WORKFLOW).named_groups()["wait_test_routine"]
        self.assertEqual(group.steps[0].extra, "wait")
        self.assertEqual(group.steps[1].tool, "browser")
        self.assertEqual(group.steps[2].tool, "python")

    def test_wait_sleeps_without_a_driver(self) -> None:
        with patch("cg_loop.cua.time.sleep") as slept:
            with patch("cg_loop.cua.open_driver", side_effect=AssertionError("driver")):
                found = wait_action("10s")
                result = run_cua(
                    {"dry_run": True, "env": {}, "variables": {}},
                    action="wait",
                    text="10s",
                )
        slept.assert_called_once_with(10)
        self.assertEqual(found["text"], "wait 10s")
        self.assertEqual(result["outputs"]["status"], "proposed")
        self.assertEqual(result["inputs"]["action"], "wait")
        self.assertEqual(result["inputs"]["text"], "10s")

    def test_wait_compiles_to_run_cua(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text("config:\n  name: demo\nwf_wait:\n  - /cua wait 10s\n", encoding="utf-8")
            group = load_workflow(path).named_groups()["wf_wait"]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            body = created.path.read_text(encoding="utf-8")
            self.assertEqual(created.status, "compiled")
            self.assertIn("run_cua", body)
            self.assertIn("action='wait'", body)
            self.assertIn("text='10s'", body)
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")


class CuaDriverTest(unittest.TestCase):
    def test_text_region_is_clicked_on_that_capture(self) -> None:
        driver = FakeDriver(
            [
                Region("r0", "icon", "Play Video", {"x": 0, "y": 0, "width": 4, "height": 4}),
                Region("r1", "text", "Play Video", {"x": 10, "y": 20, "width": 40, "height": 16}),
            ]
        )
        found = perception_fallback_click(driver, "Play Video")
        self.assertEqual(driver.clicks, [("cap-1", "r1", "background_first")])
        self.assertEqual(found["region_id"], "r1")

    def test_missing_perception_clicks_the_accessibility_label(self) -> None:
        class TreeDriver(FakeDriver):
            def __init__(self) -> None:
                super().__init__([])
                self.element_clicks: list[str] = []

            def parse_visual_regions(self, capture_id: str) -> list[Region]:
                del capture_id
                raise RuntimeError("the optional cua-perception extension is not installed")

            def find_elements(self, pid: int, window_id: int, query: str) -> list[dict[str, Any]]:
                del pid, window_id, query
                return [
                    {"label": "Example Domain", "role": "heading", "element_token": "s00000001:1"},
                    {"label": "Learn more", "role": "link", "element_token": "s00000001:2"},
                ]

            def click_element(self, pid: int, window_id: int, element_token: str) -> dict[str, Any]:
                del pid, window_id
                self.element_clicks.append(element_token)
                return {"status": "ok", "element_token": element_token}

        driver = TreeDriver()
        found = perception_fallback_click(driver, "Learn more")
        self.assertEqual(driver.element_clicks, ["s00000001:2"])
        self.assertIn("Learn more", found["text"])

    def test_missing_label_is_an_error(self) -> None:
        driver = FakeDriver([Region("r1", "text", "Pause", {"x": 0, "y": 0, "width": 8, "height": 8})])
        with self.assertRaises(LookupError):
            perception_fallback_click(driver, "Play Video")

    def test_visual_miss_uses_locateanything_and_saves_the_box(self) -> None:
        from PIL import Image

        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            image = folder / "window.png"
            Image.new("RGB", (40, 20), "white").save(image)
            log_json = folder / "02_click_search_text_box.json"

            class ShotDriver(FakeDriver):
                def __init__(self) -> None:
                    super().__init__([Region("r1", "text", "Yahoo", {"x": 0, "y": 0, "width": 8, "height": 8})])
                    self.points: list[tuple[str, float, float]] = []

                def get_window_state(self, pid: int, window_id: int) -> WindowState:
                    state = super().get_window_state(pid, window_id)
                    state.image = str(image)
                    return state

                def click_point(self, capture_id: str, x: float, y: float) -> dict[str, Any]:
                    self.points.append((capture_id, x, y))
                    return {"status": "ok", "capture_id": capture_id, "x": x, "y": y}

            driver = ShotDriver()
            marked = folder / "02_click_search_text_box.locate.jpg"

            def locate(query: str, path: str) -> dict[str, Any]:
                self.assertEqual(query, "Search text box")
                self.assertEqual(Path(path), log_json.with_suffix(".jpg"))
                from cg_loop.locate import mark_image

                drawn = mark_image(path, [{"x1": 4, "y1": 6, "x2": 30, "y2": 16}])
                return {
                    "x": 17,
                    "y": 11,
                    "box": {"x1": 4, "y1": 6, "x2": 30, "y2": 16},
                    "marked": drawn,
                    "text": "17,11 box=4,6,30,16",
                }

            with patch("cg_loop.locate.locate_image", side_effect=locate):
                found = perception_fallback_click(
                    driver,
                    "Search text box",
                    env={"CG_LOOP_STEP_JSON": str(log_json)},
                )
            self.assertEqual(driver.points, [("cap-1", 17.0, 11.0)])
            self.assertEqual(found["screenshots"][0], str(marked))
            self.assertTrue(marked.is_file())
            self.assertTrue(log_json.with_suffix(".jpg").is_file())

    def test_locateanything_miss_keeps_the_screenshot(self) -> None:
        from PIL import Image

        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "window.png"
            Image.new("RGB", (8, 8), "white").save(image)
            log_json = Path(tmp) / "02_click.json"

            class ShotDriver(FakeDriver):
                def get_window_state(self, pid: int, window_id: int) -> WindowState:
                    state = super().get_window_state(pid, window_id)
                    state.image = str(image)
                    return state

            driver = ShotDriver([])
            with patch("cg_loop.locate.locate_image", return_value={"box": None, "raw": "none", "x": None, "y": None}):
                with self.assertRaises(LocateMiss) as caught:
                    perception_fallback_click(driver, "Search text box", env={"CG_LOOP_STEP_JSON": str(log_json)})
            self.assertIn(str(log_json.with_suffix(".jpg")), caught.exception.screenshots)

    def test_type_focuses_the_locateanything_box(self) -> None:
        from PIL import Image

        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "window.png"
            Image.new("RGB", (8, 8), "white").save(image)

            class TypeDriver(FakeDriver):
                def __init__(self) -> None:
                    super().__init__([])
                    self.typed: list[dict[str, Any]] = []
                    self.points: list[tuple[float, float]] = []

                def get_window_state(self, pid: int, window_id: int) -> WindowState:
                    state = super().get_window_state(pid, window_id)
                    state.image = str(image)
                    return state

                def find_elements(self, pid: int, window_id: int, query: str) -> list[dict[str, Any]]:
                    del pid, window_id, query
                    return []

                def click_point(self, capture_id: str, x: float, y: float) -> dict[str, Any]:
                    del capture_id
                    self.points.append((x, y))
                    return {"status": "ok", "x": x, "y": y}

                def _driver_tool(self, name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
                    del timeout
                    self.typed.append({"name": name, **arguments})
                    return {}

            driver = TypeDriver()
            with patch(
                "cg_loop.locate.locate_image",
                return_value={"x": 3, "y": 4, "box": {"x1": 1, "y1": 2, "x2": 5, "y2": 6}, "marked": "", "text": "3,4"},
            ):
                found = type_into(driver, "Hello World", "Search text box")
            self.assertEqual(driver.points, [(3.0, 4.0)])
            self.assertEqual(driver.typed[0]["name"], "type_text")
            self.assertEqual(driver.typed[0]["text"], "Hello World")
            self.assertNotIn("element_token", driver.typed[0])
            self.assertIn("Hello World", found["text"])
            self.assertEqual(driver.typed[0]["target"]["window_id"], 11)
            self.assertEqual(driver.typed[0]["x"], 3.0)
            self.assertEqual(driver.typed[0]["y"], 4.0)

    def test_sendkeys_clears_then_types_at_the_last_click(self) -> None:
        class Keys:
            def __init__(self) -> None:
                self.calls: list[tuple[str, dict[str, Any]]] = []
                self.last_x = 1035.0
                self.last_y = 305.0

            def target_window(self, app: str = "") -> dict[str, int]:
                del app
                return {"pid": 17280, "window_id": 15033}

            def _driver_tool(self, name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
                del timeout
                self.calls.append((name, arguments))
                return {}

        driver = Keys()
        found = send_keys(driver, "Hello World", clear=True)
        names = [name for name, _args in driver.calls]
        self.assertEqual(names, ["hotkey", "press_key", "type_text"])
        chord, delete, typed = (args for _name, args in driver.calls)
        self.assertEqual(chord["keys"], ["cmd", "a"])
        self.assertEqual(chord["window_id"], 15033)
        self.assertEqual(chord["delivery_mode"], "foreground")
        self.assertNotIn("target", chord)
        self.assertEqual(delete["key"], "delete")
        self.assertEqual(typed["text"], "Hello World")
        self.assertEqual(typed["window_id"], 15033)
        self.assertNotIn("x", typed)
        self.assertEqual(found["text"], "sendkeys clear then Hello World")

    def test_sendkeys_types_then_presses_enter(self) -> None:
        class Keys:
            def __init__(self) -> None:
                self.calls: list[tuple[str, dict[str, Any]]] = []

            def target_window(self, app: str = "") -> dict[str, int]:
                del app
                return {"pid": 1, "window_id": 2}

            def _driver_tool(self, name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
                del timeout
                self.calls.append((name, arguments))
                return {}

        driver = Keys()
        found = send_keys(driver, "Hello World^Enter", clear=True)
        names = [name for name, _args in driver.calls]
        self.assertEqual(names, ["hotkey", "press_key", "type_text", "press_key"])
        self.assertEqual(driver.calls[2][1]["text"], "Hello World")
        self.assertEqual(driver.calls[3][1]["key"], "return")
        self.assertEqual(found["text"], "sendkeys clear then Hello World^Enter")
        with self.assertRaises(ValueError):
            send_keys(driver, "^NotAKey", clear=False)

    def test_regions_keep_text_and_bounds(self) -> None:
        regions = regions_from(
            {
                "regions": [
                    {
                        "id": "r9",
                        "kind": "text",
                        "text": "Learn more",
                        "bounds": {"x": 10, "y": 20, "width": 40, "height": 16},
                    }
                ]
            }
        )
        self.assertEqual(regions[0].type, "text")
        self.assertEqual(regions[0].center(), (30, 28))

    def test_launch_chrome_uses_the_bundle_and_url(self) -> None:
        driver = McpCuaDriver()
        calls: list[tuple[str, dict[str, Any]]] = []

        def tool(name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
            del timeout
            calls.append((name, arguments))
            return {"pid": 9, "windows": [{"pid": 9, "window_id": 4, "is_on_screen": True, "z_index": 2}]}

        driver._tool = tool  # type: ignore[method-assign]
        result =         driver.launch("Chrome", "https://example.com")
        names = [name for name, _args in calls]
        self.assertEqual(names[0], "get_session")
        self.assertIn("start_session", names)
        self.assertLess(names.index("start_session"), names.index("launch_app"))
        launch = calls[names.index("launch_app")]
        self.assertEqual(launch[1]["bundle_id"], "com.google.Chrome")
        self.assertEqual(launch[1]["urls"], ["https://example.com"])
        self.assertEqual(launch[1]["additional_arguments"], ["--new-window"])
        self.assertEqual(result["window_id"], 4)
        driver.close()
        self.assertEqual(calls[-1][0], "end_session")
        self.assertEqual(calls[-1][1]["session"], driver.session)

    def test_launch_uses_the_window_whose_title_matches_the_url(self) -> None:
        driver = McpCuaDriver()
        calls: list[tuple[str, dict[str, Any]]] = []

        def tool(name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
            del timeout
            calls.append((name, arguments))
            if name == "launch_app":
                return {
                    "pid": 9,
                    "windows": [
                        {
                            "pid": 9,
                            "window_id": 4,
                            "title": "Ads Manager - Google Chrome",
                            "is_on_screen": True,
                            "z_index": 5,
                        }
                    ],
                }
            if name == "list_windows":
                return {
                    "windows": [
                        {
                            "pid": 9,
                            "window_id": 4,
                            "title": "Ads Manager - Google Chrome",
                            "is_on_screen": True,
                            "z_index": 5,
                        },
                        {
                            "pid": 9,
                            "window_id": 8,
                            "title": "Yahoo | Mail - Google Chrome",
                            "is_on_screen": True,
                            "z_index": 1,
                        },
                    ]
                }
            return {}

        driver._tool = tool  # type: ignore[method-assign]
        result = driver.launch("Chrome", "https://www.yahoo.com/")
        self.assertEqual(result["window_id"], 8)
        driver.close()

    def test_refused_capture_clicks_the_point_on_the_window(self) -> None:
        driver = McpCuaDriver()
        sent: list[dict[str, Any]] = []

        def tool(name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
            del name, timeout
            sent.append(arguments)
            if arguments.get("capture_id"):
                raise RuntimeError("invalid_action_target")
            return {"ok": True}

        driver._tool = tool  # type: ignore[method-assign]
        driver._session_ready = True
        driver._announced = True
        driver._targets["cap"] = {"pid": 3, "window_id": 8}
        found = driver.click_point("cap", 17, 11)
        self.assertEqual(sent[0]["capture_id"], "cap")
        self.assertNotIn("capture_id", sent[1])
        self.assertEqual(sent[1]["x"], 17)
        self.assertEqual(sent[1]["y"], 11)
        self.assertEqual(sent[1]["window_id"], 8)
        self.assertEqual(found["x"], 17)
        driver.close()

    def test_existing_workflow_session_is_closed_then_started(self) -> None:
        driver = McpCuaDriver(session="cua")
        calls: list[tuple[str, dict[str, Any]]] = []

        def tool(name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
            del timeout
            calls.append((name, arguments))
            if name == "get_session":
                return {"status": "active", "session": "cua"}
            return {"pid": 9, "windows": [{"pid": 9, "window_id": 4, "is_on_screen": True, "z_index": 1}]}

        driver._tool = tool  # type: ignore[method-assign]
        driver.launch("Notes")
        names = [name for name, _args in calls]
        self.assertEqual(driver.session, "cua")
        self.assertLess(names.index("end_session"), names.index("start_session"))
        self.assertEqual(calls[names.index("start_session")][1]["session"], "cua")

    def test_session_held_elsewhere_restarts_the_workflow_name(self) -> None:
        driver = McpCuaDriver(session="cua")
        calls: list[tuple[str, dict[str, Any]]] = []
        starts = {"n": 0}

        def tool(name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
            del timeout
            calls.append((name, dict(arguments)))
            if name == "get_session":
                raise RuntimeError("session has ended; tool call 'get_session' was rejected")
            if name == "start_session":
                starts["n"] += 1
                if starts["n"] == 1:
                    raise RuntimeError("session is not available to this transport")
                return {"active": True, "session": "cua", "revived": True}
            if name == "end_session":
                return {"active": False, "session": "cua"}
            return {"pid": 9, "windows": [{"pid": 9, "window_id": 4, "is_on_screen": True, "z_index": 1}]}

        driver._tool = tool  # type: ignore[method-assign]
        driver.launch("Notes")
        self.assertEqual(driver.session, "cua")
        self.assertGreaterEqual(starts["n"], 2)
        started = [args for name, args in calls if name == "start_session"]
        self.assertTrue(started)
        self.assertTrue(all(args.get("session") == "cua" for args in started))

    def test_click_region_uses_background_delivery(self) -> None:
        driver = McpCuaDriver()
        sent: list[tuple[str, dict[str, Any]]] = []

        def tool(name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
            del timeout
            sent.append((name, arguments))
            return {"ok": True}

        driver._tool = tool  # type: ignore[method-assign]
        driver._regions["cap"] = {
            "r1": Region("r1", "text", "Learn more", {"x": 10, "y": 20, "width": 40, "height": 16})
        }
        driver._targets["cap"] = {"pid": 3, "window_id": 8}
        driver.click_region("cap", "r1", strategy="background_first")
        name, args = next(item for item in sent if item[0] == "click")
        self.assertEqual(name, "click")
        self.assertEqual(args["delivery_mode"], "background")
        self.assertEqual(args["capture_id"], "cap")
        self.assertEqual(args["x"], 30)
        self.assertEqual(args["y"], 28)


class CuaRunTest(unittest.TestCase):
    def test_click_screenshots_are_kept_on_the_step(self) -> None:
        marked = "/tmp/02_click.locate.jpg"
        with patch(
            "cg_loop.cua.perform",
            return_value={"status": "ok", "text": "click Search text box", "screenshots": [marked]},
        ):
            result = run_cua(
                {"dry_run": False, "env": {}, "variables": {}},
                action="click",
                label="Search text box",
            )
        self.assertEqual(result["outputs"]["screenshots"], [marked])

    def test_dry_run_does_not_call_the_driver(self) -> None:
        result = run_cua(
            {"dry_run": True, "env": {}, "variables": {}},
            action="launch",
            app="Chrome",
            url="https://example.com",
        )
        self.assertEqual(result["outputs"]["status"], "proposed")

    def test_workflow_defaults_to_this_machine(self) -> None:
        group = load_workflow(WORKFLOW).named_groups()["open_chrome_routine"]
        self.assertEqual(group.env["CUA"], "local")
        self.assertEqual(group.env["CUA_WORKFLOW"], "cua")
        self.assertEqual(session_label(group.env), "cua")
        self.assertNotIn("CUA_SPACE", group.env)

    def test_space_config_is_the_driver_target(self) -> None:
        from cg_loop.workflow import apply_overrides

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  cua: space",
                        "  cua-space: lab",
                        "  cua-url: http://10.0.0.5:3211",
                        "  cua-token: secret",
                        "wf_open:",
                        "  - /cua launch Chrome",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            loaded = load_workflow(path)
            group = loaded.named_groups()["wf_open"]
            self.assertEqual(group.env["CUA"], "space")
            self.assertEqual(group.env["CUA_SPACE"], "lab")
            self.assertEqual(group.env["CUA_URL"], "http://10.0.0.5:3211")
            self.assertEqual(group.env["CUA_TOKEN"], "secret")
            apply_overrides(loaded, {"cua": "local"})
            self.assertEqual(group.env["CUA"], "local")

    def test_space_launch_goes_through_the_space_driver(self) -> None:
        driver = McpCuaDriver.from_target(
            {
                "mode": "space",
                "space": "lab",
                "url": "http://10.0.0.5:3211",
                "token": "secret",
            }
        )
        calls: list[tuple[str, dict[str, Any]]] = []

        def tool(name: str, arguments: dict[str, Any], timeout: float = 30) -> dict[str, Any]:
            del timeout
            calls.append((name, dict(arguments)))
            if name == "add_space":
                return {"id": "direct:10.0.0.5:3211"}
            return {"pid": 9, "windows": [{"pid": 9, "window_id": 4, "is_on_screen": True, "z_index": 1}]}

        driver._tool = tool  # type: ignore[method-assign]
        driver.launch("Chrome", "https://example.com")
        self.assertEqual(calls[0][0], "add_space")
        self.assertEqual(calls[0][1]["token"], "secret")
        self.assertNotIn("session", calls[0][1])
        started = next(item[1] for item in calls if item[1].get("tool") == "start_session")
        self.assertEqual(started["arguments"]["session"], driver.session)
        forwarded = next(item[1] for item in calls if item[1].get("tool") == "launch_app")
        self.assertEqual(forwarded["space"], "direct:10.0.0.5:3211")
        self.assertEqual(forwarded["service"], "driver")
        self.assertEqual(forwarded["tool"], "launch_app")
        self.assertEqual(forwarded["arguments"]["bundle_id"], "com.google.Chrome")
        self.assertEqual(forwarded["arguments"]["session"], driver.session)

    def test_compile_remembers_the_locate_point(self) -> None:
        import json

        from PIL import Image

        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            image = folder / "window.png"
            Image.new("RGB", (40, 20), "white").save(image)
            path = folder / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_open:\n  - /cua click \"Play Video\"\n",
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_open"]
            point = {
                "label": "Play Video",
                "x": 17,
                "y": 11,
                "width": 40,
                "height": 20,
                "box": {"x1": 4, "y1": 6, "x2": 30, "y2": 16},
                "method": "locateanything",
                "image": str(image),
            }
            with patch("cg_loop.cua.compile_click_location", return_value=point):
                created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("replay_cua_click", text)
            self.assertNotIn("run_cua", text)
            saved = json.loads((created.path.parent / "b_01-context.json").read_text(encoding="utf-8"))
            self.assertEqual(saved["x"], 17)
            self.assertEqual(saved["y"], 11)
            self.assertEqual(saved["method"], "locateanything")
            self.assertTrue((created.path.parent / "b-crop.png").is_file())

    def test_saved_point_is_clicked_when_the_crop_still_matches(self) -> None:
        import json

        from PIL import Image

        from cg_loop.cua import replay_cua_click, save_click_crop

        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / "step"
            folder.mkdir()
            script = folder / "step.py"
            script.write_text("def run(ctx):\n    return {}\n", encoding="utf-8")
            image = folder / "window.png"
            picture = Image.new("RGB", (40, 20), "white")
            for x in range(4, 30):
                for y in range(6, 16):
                    picture.putpixel((x, y), (20, 40, 200))
            picture.save(image)
            box = {"x1": 4, "y1": 6, "x2": 30, "y2": 16}
            save_click_crop(str(image), box, folder / "step.crop.png")
            saved = {
                "command": '/cua click "Play Video"',
                "label": "Play Video",
                "x": 17,
                "y": 11,
                "width": 40,
                "height": 20,
                "box": box,
                "method": "locateanything",
            }
            (folder / "step.json").write_text(json.dumps(saved), encoding="utf-8")

            class PointDriver:
                def __init__(self) -> None:
                    self.points: list[tuple[float, float]] = []

                def target_window(self, app: str = "") -> dict[str, int]:
                    del app
                    return {"pid": 3, "window_id": 8}

                def get_window_state(self, pid: int, window_id: int) -> WindowState:
                    return WindowState(capture_id="cap", pid=pid, window_id=window_id, image=str(image))

                def click_window_point(self, pid: int, window_id: int, x: float, y: float) -> dict[str, Any]:
                    del pid, window_id
                    self.points.append((x, y))
                    return {"status": "ok", "x": x, "y": y}

            driver = PointDriver()
            with patch("cg_loop.cua.open_driver", return_value=driver), patch(
                "cg_loop.cua.resolve_click_point",
                side_effect=AssertionError("perception should not run"),
            ):
                found = replay_cua_click({"env": {}, "dry_run": False}, script)
            self.assertEqual(driver.points, [(17.0, 11.0)])
            self.assertEqual(found["outputs"]["status"], "ok")
            self.assertIn("saved", found["outputs"]["cua"]["text"])

    def test_cached_click_runs_before_perception_or_locate(self) -> None:
        import json

        from PIL import Image

        from cg_loop.cua import replay_cua_click, save_click_crop

        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / "step"
            folder.mkdir()
            script = folder / "step.py"
            script.write_text("def run(ctx):\n    return {}\n", encoding="utf-8")
            remembered = folder / "then.png"
            Image.new("RGB", (40, 20), "white").save(remembered)
            current = folder / "now.png"
            Image.new("RGB", (40, 20), "black").save(current)
            box = {"x1": 4, "y1": 6, "x2": 30, "y2": 16}
            save_click_crop(str(remembered), box, folder / "step.crop.png")
            saved = {
                "command": '/cua click "Search text box"',
                "label": "Search text box",
                "x": 17,
                "y": 11,
                "width": 40,
                "height": 20,
                "box": box,
            }
            (folder / "step.json").write_text(json.dumps(saved), encoding="utf-8")

            class PointDriver:
                def __init__(self) -> None:
                    self.points: list[tuple[float, float]] = []

                def target_window(self, app: str = "") -> dict[str, int]:
                    del app
                    return {"pid": 3, "window_id": 8}

                def get_window_state(self, pid: int, window_id: int) -> WindowState:
                    return WindowState(capture_id="cap", pid=pid, window_id=window_id, image=str(current))

                def click_window_point(self, pid: int, window_id: int, x: float, y: float) -> dict[str, Any]:
                    self.points.append((x, y))
                    return {"status": "ok", "x": x, "y": y}

            driver = PointDriver()
            order: list[str] = []

            def resolve(driver_arg: Any, label: str, app: str = "", env: dict[str, Any] | None = None) -> dict[str, Any]:
                del driver_arg, app, env
                order.append(f"resolve after {len(driver.points)} click")
                return {
                    "label": label,
                    "x": 3,
                    "y": 4,
                    "width": 40,
                    "height": 20,
                    "box": {"x1": 1, "y1": 1, "x2": 8, "y2": 8},
                    "method": "locateanything",
                    "image": str(current),
                }

            with patch("cg_loop.cua.open_driver", return_value=driver), patch(
                "cg_loop.cua.resolve_click_point", side_effect=resolve
            ):
                found = replay_cua_click({"env": {}, "dry_run": False}, script)
            self.assertEqual(driver.points, [(17.0, 11.0), (3.0, 4.0)])
            self.assertEqual(order, ["resolve after 1 click"])
            self.assertIn("locateanything", found["outputs"]["cua"]["text"])
            stored = json.loads((folder / "step.json").read_text(encoding="utf-8"))
            self.assertEqual(stored["x"], 3)

    def test_laya_turns_a_sentence_into_actions(self) -> None:
        command = 'Open Chrome to https://www.yahoo.com/, click "Search text box", and type "Hello World" into it'

        def ask(state: dict[str, Any], questions: dict[str, Any]) -> dict[str, Any]:
            self.assertEqual(state["command"], command)
            self.assertIn("Chrome", questions["action_1_app"]["criteria"])
            self.assertIn("https://www.yahoo.com/", questions["action_1_url"]["criteria"])
            self.assertIn("Hello World", questions["action_1_text"]["criteria"])
            return {
                "answers": {
                    "action_1": {"choice": "launch"},
                    "action_1_app": {"choice": "Chrome"},
                    "action_1_url": {"choice": "https://www.yahoo.com/"},
                    "action_2": {"choice": "click"},
                    "action_2_label": {"choice": "Search text box"},
                    "action_3": {"choice": "type"},
                    "action_3_label": {"choice": "Search text box"},
                    "action_3_text": {"choice": "Hello World"},
                    "action_4": {"choice": "done"},
                }
            }

        found = compile_cua_actions(command, ask=ask)
        self.assertEqual(found["model"], "laya")
        self.assertEqual(
            [(item["action"], item.get("app") or item.get("label"), item.get("url") or item.get("text")) for item in found["actions"]],
            [
                ("launch", "Chrome", "https://www.yahoo.com/"),
                ("click", "Search text box", ""),
                ("type", "Search text box", "Hello World"),
            ],
        )
        self.assertEqual(actions_from_laya({"action_1": {"choice": "done"}}), [])

    def test_sentence_compiles_to_saved_actions(self) -> None:
        planned = {
            "error": "",
            "actions": [
                {"action": "launch", "app": "Chrome", "url": "https://www.yahoo.com/", "label": "", "text": ""},
                {"action": "type", "app": "", "url": "", "label": "Search text box", "text": "Hello World"},
            ],
            "model": "laya",
            "state": {"command": "open"},
            "questions": {"action_1": {"type": "choice"}},
            "answers": {},
        }
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\n"
                "wf_open:\n"
                '  - /cua Open Chrome to https://www.yahoo.com/ and type "Hello World" into "Search text box"\n',
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_open"]
            with patch("cg_loop.cua.compile_cua_actions", return_value=planned):
                created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            self.assertIn("replay_cua_actions", created.path.read_text(encoding="utf-8"))
            replayed = replay_cua_actions("open", planned["actions"], dry_run=True)
            self.assertEqual(replayed["outputs"]["status"], "proposed")
            self.assertEqual(len(replayed["outputs"]["actions"]), 2)


class DriverCommandTests(unittest.TestCase):
    def test_configured_paths_replace_the_programs_on_path(self) -> None:
        from cg_loop.cua import local_driver_command, space_driver_command

        with patch.dict("os.environ", {"CG_LOOP_CUA_DRIVER": "/Tools/cua-driver", "CG_LOOP_CUA": "/Tools/cua"}):
            self.assertEqual(local_driver_command(), ["/Tools/cua-driver", "mcp"])
            self.assertEqual(space_driver_command(), ["/Tools/cua", "mcp"])
            local = McpCuaDriver.from_target({"session": "desk"})
            self.assertEqual(local.command[0], "/Tools/cua-driver")
            self.assertTrue(local.same_target({"session": "desk"}))
            space = McpCuaDriver.from_target({"mode": "space", "session": "lab", "url": "http://10.0.0.5:3211"})
            self.assertEqual(space.command[0], "/Tools/cua")
            self.assertTrue(space.same_target({"mode": "space", "session": "lab", "url": "http://10.0.0.5:3211"}))


if __name__ == "__main__":
    unittest.main()
