"""RSS / page article extraction for EXTRACT operations."""

from __future__ import annotations

import json
import os
import re
import xml.etree.ElementTree as ET
from html import unescape
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urljoin, urlsplit, urlunsplit

ITEM_RE = re.compile(
    r"<item\b[^>]*>(.*?)</item>",
    re.IGNORECASE | re.DOTALL,
)
TITLE_RE = re.compile(r"<title\b[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
LINK_RE = re.compile(r"<link\b[^>]*>(.*?)</link>", re.IGNORECASE | re.DOTALL)
DESC_RE = re.compile(
    r"<description\b[^>]*>(.*?)</description>",
    re.IGNORECASE | re.DOTALL,
)
PUB_RE = re.compile(r"<pubDate\b[^>]*>(.*?)</pubDate>", re.IGNORECASE | re.DOTALL)
CDATA_RE = re.compile(r"<!\[CDATA\[(.*?)\]\]>", re.DOTALL)
TAG_RE = re.compile(r"<[^>]+>")


def _group(pattern: re.Pattern[str], text: str) -> str:
    match = pattern.search(text)
    return match.group(1) if match else ""


def _strip(value: str) -> str:
    text = CDATA_RE.sub(r"\1", value or "")
    text = unescape(TAG_RE.sub(" ", text))
    return re.sub(r"\s+", " ", text).strip()


def parse_rss_items(source: str, *, base_url: str = "") -> list[dict[str, str]]:
    """Return RSS/Atom items from XML or a page that still contains <item> tags."""
    if not source:
        return []
    items = _from_xml(source, base_url=base_url)
    if items:
        return items
    found: list[dict[str, str]] = []
    for blob in ITEM_RE.findall(source):
        title = _strip(_group(TITLE_RE, blob))
        link = _strip(_group(LINK_RE, blob))
        desc = _strip(_group(DESC_RE, blob))
        published = _strip(_group(PUB_RE, blob))
        if not (title or link):
            continue
        if link and base_url:
            link = urljoin(base_url, link)
        found.append(
            {
                "title": title or link,
                "url": link,
                "text": desc,
                "summary": desc,
                "published": published,
            }
        )
        if len(found) >= 50:
            break
    return found


def _from_xml(source: str, *, base_url: str) -> list[dict[str, str]]:
    text = source.strip()
    if "<" not in text:
        return []
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return []
    items: list[dict[str, str]] = []
    for node in list(root.iter()):
        tag = node.tag.split("}")[-1].lower()
        if tag not in {"item", "entry"}:
            continue
        title = ""
        link = ""
        desc = ""
        published = ""
        for child in list(node):
            ctag = child.tag.split("}")[-1].lower()
            if ctag == "title":
                title = _strip(child.text or "")
            elif ctag == "link":
                link = (child.get("href") or _strip(child.text or "") or link)
            elif ctag in {"description", "summary", "content"}:
                desc = _strip("".join(child.itertext()))
            elif ctag in {"pubdate", "published", "updated", "date"}:
                published = _strip(child.text or "")
        if not (title or link):
            continue
        if link and base_url:
            link = urljoin(base_url, link)
        items.append(
            {
                "title": title or link,
                "url": link,
                "text": desc,
                "summary": desc,
                "published": published,
            }
        )
        if len(items) >= 50:
            break
    return items


SKIP_RE = re.compile(r"not in \$(\w+)", re.I)
_FILTER_SKIP = frozenset(
    {
        "load",
        "previous",
        "articles",
        "article",
        "urls",
        "url",
        "folder",
        "folders",
        "root",
        "roots",
        "from",
        "used",
        "existing",
        "list",
        "first",
        "latest",
    }
)


_TOPIC_PHRASES = ("blood pressure", "heart", "hypertension", "cardiac")
_RU_RE = re.compile(r"(?:/|[?&])RU=([^/&]+)", re.IGNORECASE)


def unwrap_news_url(href: str) -> str:
    """Yahoo result links hide the article in an RU= redirect. Return that article."""
    match = _RU_RE.search(href or "")
    if not match:
        return href
    target = unquote(match.group(1))
    if target.startswith(("http://", "https://")):
        return target
    return href


def _chrome_url(url: str) -> bool:
    parsed = urlsplit(url)
    host = (parsed.netloc or "").lower().removeprefix("www.")
    if host.endswith("yimg.com") or host in {"search.yahoo.com", "login.yahoo.com", "help.yahoo.com"}:
        return True
    if host.endswith("yahoo.com"):
        path = (parsed.path or "").rstrip("/")
        if host == "health.yahoo.com" and path.count("/") >= 2:
            return False
        return True
    return False


def _topic_words(phrase: str) -> list[str]:
    low = (phrase or "").lower()
    return [word for word in _TOPIC_PHRASES if word in low]


def _page_links(page: dict[str, Any], base_url: str) -> list[tuple[str, str]]:
    links: list[tuple[str, str]] = []
    for action in page.get("actions") or []:
        if action.get("kind") != "click":
            continue
        href = str(action.get("href") or "")
        label = str(action.get("label") or "").strip()
        if not href:
            continue
        if href.startswith("/") and base_url:
            href = urljoin(base_url, href)
        if not href.startswith("http"):
            continue
        href = unwrap_news_url(href)
        if _chrome_url(href) or "rss" in href.lower() or href.endswith(".xml"):
            continue
        links.append((label, href))
    return links


def _link_article(label: str, href: str) -> dict[str, str]:
    return {
        "title": label or href,
        "url": href,
        "text": "",
        "summary": label,
        "published": "",
    }


def article_from_page(
    page: dict[str, Any],
    *,
    phrase: str = "",
    skip_urls: set[str] | None = None,
) -> dict[str, str] | None:
    html = str(page.get("html") or "")
    text = str(page.get("text") or "")
    url = str(page.get("url") or "")
    skip = skip_urls or set()
    items = parse_rss_items(html or text, base_url=url)
    for item in items:
        if canonical_url(item.get("url") or "") not in skip:
            return item
    links = _page_links(page, url)
    topics = _topic_words(phrase)
    if topics:
        for label, href in links:
            if canonical_url(href) in skip:
                continue
            blob = f"{label} {href}".lower()
            if any(word in blob for word in topics):
                return _link_article(label, href)
        return None
    for label, href in links:
        if canonical_url(href) in skip:
            continue
        lowered = f"{label} {href}".lower()
        if any(token in lowered for token in ("release", "article", "story", "health", "science")):
            return _link_article(label, href)
    phrase_l = phrase.lower()
    if "latest" in phrase_l or "article" in phrase_l or "first" in phrase_l or "url" in phrase_l:
        for label, href in links:
            if "xml" not in href and canonical_url(href) not in skip:
                return _link_article(label, href)
    return None


def format_article(article: dict[str, Any] | None) -> str:
    if not article:
        return ""
    title = str(article.get("title") or "")
    url = str(article.get("url") or "")
    body = str(article.get("text") or article.get("summary") or "")
    parts = [p for p in (title, url, body) if p]
    return "\n\n".join(parts)


def skip_var_name(phrase: str) -> str:
    match = SKIP_RE.search(phrase or "")
    return match.group(1) if match else ""


def skip_url_set(variables: dict[str, Any], phrase: str) -> set[str]:
    name = skip_var_name(phrase)
    if not name:
        return set()
    return canonical_set(variables.get(name))


def canonical_url(url: str) -> str:
    text = (url or "").strip()
    if not text:
        return ""
    parsed = urlsplit(text)
    host = (parsed.netloc or "").lower().removeprefix("www.")
    path = (parsed.path or "").rstrip("/") or "/"
    scheme = (parsed.scheme or "https").lower()
    if not host and text.startswith("http"):
        return text.rstrip("/").lower()
    if not host:
        return text.rstrip("/").lower()
    return urlunsplit((scheme, host, path, "", ""))


def canonical_set(value: Any) -> set[str]:
    urls: list[str] = []
    if isinstance(value, dict):
        urls.append(str(value.get("url") or ""))
    elif isinstance(value, (list, tuple, set)):
        for item in value:
            if isinstance(item, dict):
                urls.append(str(item.get("url") or ""))
            else:
                urls.append(str(item))
    elif value:
        urls.extend(str(value).split())
    return {canonical_url(url) for url in urls if canonical_url(url)}


def url_from_package(folder: Path) -> str:
    path = Path(folder)
    txt = path / "source_url.txt"
    if txt.is_file():
        line = next((row.strip() for row in txt.read_text(encoding="utf-8").splitlines() if row.strip()), "")
        if line.startswith("http"):
            return line
    for name in ("run_meta.json", "facts.json", "story.json"):
        payload = _read_json(path / name)
        if not payload:
            continue
        for key in ("source_url", "url"):
            found = str(payload.get(key) or "").strip()
            if found.startswith("http"):
                return found
        facts = payload.get("facts")
        if isinstance(facts, dict):
            found = str(facts.get("source_url") or facts.get("url") or "").strip()
            if found.startswith("http"):
                return found
    return ""


_DATE_PREFIX = re.compile(r"^\d{8}_")


def title_from_package(folder: Path) -> str:
    """Posting title when the package has one, otherwise the folder name."""
    path = folder / "posting_data.txt"
    if path.is_file():
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            lines = []
        for index, line in enumerate(lines):
            if line.strip().lower() == "title" and index + 1 < len(lines):
                title = lines[index + 1].strip()
                if title:
                    return title
    name = _DATE_PREFIX.sub("", folder.name)
    return name.replace("_", " ").replace("-", " ").strip()


def load_previous_titles(roots: list[str]) -> list[str]:
    """Titles of packages under each root, newest folder first."""
    titles: list[str] = []
    seen: set[str] = set()
    for raw in roots:
        root = Path(raw).expanduser()
        if not str(root) or not root.is_dir():
            continue
        children = [
            child
            for child in root.iterdir()
            if child.is_dir() and not child.name.startswith(".")
        ]
        children.sort(key=lambda child: child.stat().st_mtime, reverse=True)
        for folder in children:
            title = title_from_package(folder)
            key = title.casefold()
            if not key or key in seen:
                continue
            seen.add(key)
            titles.append(title)
    return titles


def load_previous_urls(
    roots: list[str],
    *,
    filter_text: str = "",
) -> list[str]:
    """Read source URLs from package folders under each root (`source_url.txt`, then json)."""
    needle = _phrase_filter(filter_text)
    seen: set[str] = set()
    ordered: list[str] = []
    for raw in roots:
        root = Path(raw).expanduser()
        if not str(root) or not root.exists():
            continue
        for folder in _package_folders(root):
            url = url_from_package(folder)
            key = canonical_url(url)
            if not key or key in seen:
                continue
            if needle and needle not in key:
                continue
            seen.add(key)
            ordered.append(url)
    return ordered


def _phrase_filter(filter_text: str) -> str:
    text = filter_text or ""
    host = re.search(r"([a-z0-9-]+(?:\.[a-z]{2,})+)", text, re.I)
    if host:
        return host.group(1).lower()
    for word in re.findall(r"[a-z0-9-]{4,}", text.lower()):
        if word not in _FILTER_SKIP:
            return word
    return ""


def _package_folders(root: Path, *, max_depth: int = 4) -> list[Path]:
    markers = ("source_url.txt", "run_meta.json", "facts.json", "story.json")
    found: list[Path] = []
    seen: set[Path] = set()

    def consider(folder: Path) -> None:
        try:
            key = folder.resolve()
        except OSError:
            return
        if key in seen:
            return
        if any((folder / name).is_file() for name in markers):
            seen.add(key)
            found.append(folder)

    consider(root)
    if not root.is_dir():
        return found
    for dirpath, dirnames, _filenames in os.walk(root):
        folder = Path(dirpath)
        try:
            depth = 0 if folder == root else len(folder.relative_to(root).parts)
        except ValueError:
            depth = 0
        if depth > max_depth:
            dirnames[:] = []
            continue
        consider(folder)
    return found


def _read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}
