#!/usr/bin/env python3
"""browser_helper asks Jev for actions and runs that list."""

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.browser import StalePage  # noqa: E402
from cg_loop.browser_helper import _phrase_visible, browser_helper  # noqa: E402
from cg_loop.workflow import load_workflow, project_root  # noqa: E402

SLEEP = project_root() / "workflows" / "wf-sleep-story.yaml"

CREATE = 'role=button[name="Create"s]'
NEXT = 'role=button[name="Next"s]'


PAGE = {
    "url": "https://adsmanager.facebook.com/adsmanager/manage/ads",
    "title": "Ads Manager",
    "text": "Create\nAd setup\n",
    "actions": [
        {"id": "create", "kind": "click", "node": 7, "role": "button", "label": "Create"},
    ],
}


class Tab:
    def __init__(self, page: dict | None = None) -> None:
        self.page_state = dict(page or PAGE)
        self.acted: list[str] = []

    def observe(self) -> dict:
        return dict(self.page_state)

    def act(self, action: dict, page: dict, text: str | None = None) -> dict:
        del page, text
        self.acted.append(str(action.get("id")))
        return {"executed": action.get("id")}


class BrowserHelperTests(unittest.TestCase):
    def test_browser_actions_go_to_jev(self) -> None:
        from unittest.mock import patch

        from cg_loop.questions import NEXT_ACTION, TARGET

        seen: dict = {}

        def post(body: dict) -> dict:
            seen["body"] = body
            operations = body["questions"]["operation"]["criteria"]
            selector = next(iter(body["questions"]["click_target"]["criteria"]))
            locators = body["questions"]["locator"]["criteria"]
            self.assertIn(selector, locators)
            self.assertEqual(locators[selector]["priority"], "likely")
            self.assertIn(selector, body["questions"]["scroll_down_target"]["criteria"])
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "CLICK",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "CLICK" else 0) for key in operations},
                    },
                    "click_target": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {selector: 1},
                    },
                    "locator": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == selector else 0) for key in locators},
                    },
                },
            }

        with patch("cg_loop.model._jev_post", side_effect=post):
            result = browser_helper("/browser Click Create", Tab(), dry_run=True)
        body = seen["body"]
        self.assertEqual(body["model"], "von")
        self.assertEqual(body["questions"]["operation"]["instructions"]["rules"], NEXT_ACTION)
        rules = body["questions"]["click_target"]["instructions"]["rules"]
        self.assertEqual(rules[:2], [NEXT_ACTION, TARGET])
        self.assertIn("prefer view shown", rules[2].lower())
        self.assertEqual(set(body["state"]), {"page", "elements", "recent_actions"})
        self.assertEqual(result["status"], "dry-run")
        self.assertEqual(result["outputs"]["actions"][0]["operation"], "CLICK")
        self.assertEqual(result["outputs"]["actions"][0]["label"], "Create")
        self.assertEqual(result["outputs"]["actions"][0]["locator"], CREATE)
        self.assertIn("The first action of a go to is GOTO", NEXT_ACTION)

    def test_wf_test_dry_run_matches_actual_tab_data(self) -> None:
        group = load_workflow(SLEEP).named_groups()["test_routine"]
        self.assertIn("ADS_MANAGER", group.steps[0].raw)
        command = "/browser Click Create, then Create ad. Wait until the heading Ad setup is showing."

        def run(dry_run: bool) -> tuple[dict, list, list]:
            action_calls: list[list] = []
            tab = Tab()

            def ask(messages: list) -> dict:
                self.assertTrue(messages[0]["content"].startswith("List each browser action"))
                action_calls.append(messages)
                if len(action_calls) == 1:
                    return {
                        "actions": [
                            {"operation": "CLICK", "selector": CREATE, "confidence": 1},
                            {"operation": "DONE", "message": "Ad setup is showing", "confidence": 1},
                        ]
                    }
                return {"operation": "DONE", "confidence": 1}

            result = browser_helper(
                command,
                tab,
                dry_run=dry_run,
                env={"OPENROUTER_API_KEY": "sk-or-v1-secret", "ADS_MANAGER": "https://ads.example"},
                ask=ask,
            )
            return result, action_calls, tab.acted

        dry, dry_calls, dry_acted = run(True)
        live, live_calls, live_acted = run(False)

        self.assertEqual(dry["status"], "dry-run")
        self.assertFalse(dry["executed"])
        self.assertEqual(dry_acted, [])
        self.assertEqual(
            dry["outputs"]["steps"],
            [
                "Click Create",
                "Click Create ad",
                "Wait until the heading Ad setup is showing",
            ],
        )
        self.assertEqual([item["operation"] for item in dry["outputs"]["actions"]], ["CLICK"])
        self.assertEqual(dry["outputs"]["actions"][0]["label"], "Create")
        self.assertEqual(dry["outputs"]["actions"][0]["selector"], CREATE)
        self.assertEqual(dry["outputs"]["actions"][0]["node"], 7)
        offered = json.loads(dry_calls[0][1]["content"])
        self.assertEqual(list(offered["targets"]["CLICK"]), [CREATE])
        self.assertNotIn("index", offered["elements"][0])
        self.assertNotIn("click_target", dry_calls[0][0]["content"])
        self.assertNotIn("code", dry["outputs"])
        self.assertIn("Create", dry["llm_call"]["messages"][1]["content"])

        self.assertEqual(live["status"], "done")
        self.assertTrue(live["executed"])
        self.assertEqual(live_acted, ["create"])
        self.assertEqual([item["operation"] for item in live["outputs"]["actions"]], ["CLICK"])
        self.assertEqual(dry_calls[0], live_calls[0])

    def test_blocked_search_names_the_ad_set(self) -> None:
        command = (
            "/browser Click the Ad sets tab. Search for $ADSET. "
            "Tick the checkbox on the first row that contains that text. "
            "Stop when no ad set matches, and say which name you searched for."
        )

        def ask(messages: list) -> dict:
            payload = json.loads(messages[1]["content"])
            self.assertIn("Sleepkase Ad Set", payload["current_step"])
            return {"operation": "BLOCKED", "message": "No row", "confidence": 1}

        tab = Tab()
        result = browser_helper(
            command,
            tab,
            dry_run=False,
            env={"ADSET": "Sleepkase Ad Set"},
            ask=ask,
        )
        self.assertEqual(result["status"], "blocked")
        self.assertFalse(result["executed"])
        self.assertEqual(tab.acted, [])
        self.assertIn("Sleepkase Ad Set", result["message"])
        self.assertEqual(result["searched"]["ADSET"], "Sleepkase Ad Set")
        self.assertEqual(result["outputs"]["actions"], [])
        self.assertNotIn("code", result["outputs"])

    def test_page_actions_run_without_a_control(self) -> None:
        class PageTab:
            def __init__(self) -> None:
                self.url = "https://studio.youtube.com/channel/UC/videos"
                self.events: list[tuple[str, str]] = []

            def observe(self) -> dict:
                return {"url": self.url, "title": "Studio", "text": "Content", "actions": []}

            def goto(self, url: str, **_kwargs: object) -> dict:
                self.events.append(("goto", url))
                self.url = url
                return self.observe()

            def act(self, action: dict, page: dict, text: str | None = None) -> dict:
                del page, text
                self.events.append((str(action.get("kind") or ""), str(action.get("key") or "")))
                return {"executed": action.get("id")}

        calls = {"n": 0}

        def ask(_messages: list) -> dict:
            calls["n"] += 1
            if calls["n"] == 1:
                return {
                    "actions": [
                        {"operation": "GOTO", "url": "studio.youtube.com"},
                        {"operation": "RELOAD"},
                        {"operation": "PRESS", "key": "Escape"},
                        {"operation": "DONE"},
                    ]
                }
            return {"operation": "DONE"}

        tab = PageTab()
        result = browser_helper(
            "/browser go to studio.youtube.com, reload, then press Escape",
            tab,
            dry_run=False,
            ask=ask,
        )
        self.assertEqual(result["status"], "done")
        self.assertEqual(
            tab.events,
            [("goto", "https://studio.youtube.com"), ("reload", ""), ("press", "Escape")],
        )
        self.assertEqual(
            [item["operation"] for item in result["outputs"]["actions"]],
            ["GOTO", "RELOAD", "PRESS"],
        )

    def test_go_to_with_wait_always_navigates(self) -> None:
        command = "/browser go to studio.youtube.com. Wait max 5s until Content"

        class Later(Tab):
            def __init__(self) -> None:
                super().__init__(
                    {
                        "url": "https://studio.youtube.com/channel/UC/videos/upload?udvid=1",
                        "title": "Upload",
                        "text": "Content\nUpload video\n",
                        "actions": [],
                    }
                )
                self.events: list[str] = []

            def goto(self, url: str, **_kwargs: object) -> dict:
                self.events.append(url)
                self.page_state["url"] = url
                self.page_state["text"] = "Channel dashboard\nContent\n"
                return dict(self.page_state)

        def ask(_messages: list) -> dict:
            return {
                "actions": [
                    {"operation": "GOTO", "url": "https://studio.youtube.com"},
                    {"operation": "WAIT"},
                    {"operation": "DONE", "message": "Content is showing."},
                ]
            }

        tab = Later()
        result = browser_helper(command, tab, dry_run=False, ask=ask)
        self.assertEqual(tab.events, ["https://studio.youtube.com"])
        self.assertEqual(result["status"], "done")
        self.assertEqual(
            [item["operation"] for item in result["outputs"]["actions"]],
            ["GOTO", "WAIT"],
        )
        self.assertEqual(result["message"], "already there")

    def test_jev_returns_go_and_wait_in_one_reply(self) -> None:
        from unittest.mock import patch

        command = "/browser go to studio.youtube.com. Wait max 5s until Content"
        calls = {"n": 0}

        def post(body: dict) -> dict:
            calls["n"] += 1
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            self.assertIn("NONE", following)
            self.assertIn("WAIT", following)
            self.assertIn("GOTO", operations)
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "GOTO",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "GOTO" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "WAIT",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "WAIT" else 0) for key in following},
                    },
                },
            }

        class Nav(Tab):
            def __init__(self) -> None:
                super().__init__(
                    {
                        "url": "https://studio.youtube.com/channel/UC/videos/upload",
                        "title": "Upload",
                        "text": "Upload video\n",
                        "actions": [],
                    }
                )
                self.events: list[str] = []

            def goto(self, url: str, **_kwargs: object) -> dict:
                self.events.append(url)
                self.page_state["url"] = url
                self.page_state["text"] = "Content\n"
                return dict(self.page_state)

        tab = Nav()
        with patch("cg_loop.model._jev_post", side_effect=post):
            result = browser_helper(command, tab, dry_run=False)
        self.assertEqual(calls["n"], 1)
        self.assertEqual(tab.events, ["https://studio.youtube.com"])
        self.assertEqual(result["status"], "done")
        self.assertEqual(
            [item["operation"] for item in result["outputs"]["actions"]],
            ["GOTO", "WAIT"],
        )

    def test_verify_is_the_same_wait_after_goto(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import _text_wait, compile_browser_actions, replay_browser_actions

        command = "/browser go to studio.youtube.com verify Content max 10s"
        self.assertEqual(_text_wait(command), ("Content", 10.0))
        self.assertEqual(
            _text_wait("/browser go to studio.youtube.com. Wait max 10s until Content"),
            ("Content", 10.0),
        )

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            self.assertIn("GOTO", operations)
            self.assertNotIn("WAIT", operations)
            self.assertIn("WAIT", following)
            self.assertIn("Content", following["WAIT"])
            self.assertIn("10", following["WAIT"])
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "GOTO",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "GOTO" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "WAIT",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "WAIT" else 0) for key in following},
                    },
                },
            }

        class Nav(Tab):
            def __init__(self) -> None:
                super().__init__(
                    {
                        "url": "about:blank",
                        "title": "",
                        "text": "",
                        "actions": [],
                    }
                )
                self.events: list[str] = []

            def goto(self, url: str, **_kwargs: object) -> dict:
                self.events.append(url)
                self.page_state["url"] = url
                self.page_state["text"] = "Content\n"
                return dict(self.page_state)

        tab = Nav()
        with patch("cg_loop.model._jev_post", side_effect=post):
            compiled = compile_browser_actions(command, tab)
        self.assertEqual(compiled["error"], "")
        self.assertEqual([item["operation"] for item in compiled["actions"]], ["GOTO", "WAIT"])
        self.assertEqual(compiled["actions"][1]["phrase"], "Content")
        self.assertEqual(compiled["actions"][1]["seconds"], 10)
        self.assertFalse(compiled["actions"][1].get("selector"))
        result = replay_browser_actions(command, tab, compiled["actions"])
        self.assertEqual(tab.events, ["https://studio.youtube.com"])
        self.assertEqual(result["status"], "done")

    def test_click_verify_keeps_the_click_then_waits(self) -> None:
        from unittest.mock import patch

        command = "/browser Click Create verify Ad setup max 8s"

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            selector = next(iter(body["questions"]["click_target"]["criteria"]))
            locators = body["questions"]["locator"]["criteria"]
            self.assertIn("CLICK", operations)
            self.assertNotIn("WAIT", operations)
            self.assertIn("WAIT", following)
            self.assertIn("Ad setup", following["WAIT"])
            self.assertIn("8", following["WAIT"])
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "CLICK",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "CLICK" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "WAIT",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "WAIT" else 0) for key in following},
                    },
                    "click_target": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {selector: 1},
                    },
                    "locator": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == selector else 0) for key in locators},
                    },
                },
            }

        tab = Tab()
        with patch("cg_loop.model._jev_post", side_effect=post):
            result = browser_helper(command, tab, dry_run=False)
        self.assertEqual(tab.acted, ["create"])
        self.assertEqual(result["status"], "done")
        self.assertEqual(
            [item["operation"] for item in result["outputs"]["actions"]],
            ["CLICK", "WAIT"],
        )

    def test_click_param_is_kept_when_the_model_skips_it(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import compile_browser_actions

        command = "/browser +click Content in left nav +verify Content"
        content = 'role=menuitem[name="Content"s]'
        page = {
            "url": "https://studio.youtube.com/channel/UC/videos/upload",
            "title": "Channel content - YouTube Studio",
            "text": "Channel content\nContent\nAnalytics\nVideos\nShorts\n",
            "actions": [
                {"id": "content", "kind": "click", "node": 4, "role": "menuitem", "label": "Content", "view": "shown"},
                {
                    "id": "detect",
                    "kind": "click",
                    "node": 5,
                    "role": "menuitem",
                    "label": "Content detection",
                    "view": "shown",
                },
                {"id": "shorts", "kind": "click", "node": 8, "role": "tab", "label": "Shorts", "view": "shown"},
            ],
        }

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            clicks = body["questions"]["click_target"]["criteria"]
            self.assertEqual(clicks[content]["priority"], "likely")
            self.assertEqual(clicks['role=menuitem[name="Content detection"s]']["priority"], "other")
            self.assertNotIn("WAIT", operations)
            self.assertIn("WAIT", following)
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "DONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "DONE" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "WAIT",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "WAIT" else 0) for key in following},
                    },
                },
            }

        with patch("cg_loop.model._jev_post", side_effect=post):
            compiled = compile_browser_actions(command, Tab(page))
        self.assertEqual(compiled["error"], "")
        self.assertEqual([item["operation"] for item in compiled["actions"]], ["CLICK", "WAIT_FOR_LOCATOR"])
        self.assertEqual(compiled["actions"][0]["selector"], content)
        self.assertEqual(compiled["actions"][0]["role"], "menuitem")
        self.assertEqual(compiled["actions"][0]["label"], "Content")
        self.assertEqual(compiled["actions"][1]["selector"], content)
        self.assertEqual(compiled["actions"][1]["id"], "content")
        self.assertEqual(compiled["actions"][1]["node"], 4)
        self.assertEqual(compiled["actions"][1]["label"], "Content")

        class Shown:
            def locator(self, wanted: str):
                class Locator:
                    def bounding_box(self, timeout: int = 0) -> dict:
                        del timeout
                        return {"x": 8, "y": 120, "width": 96, "height": 28}

                    @property
                    def first(self) -> "Locator":
                        return self

                return Locator()

        tab = Tab(page)
        tab.page = Shown()
        from cg_loop.browser_helper import replay_browser_actions

        result = replay_browser_actions(command, tab, compiled["actions"])
        verify = result["actions"][1]
        self.assertEqual(verify["operation"], "WAIT_FOR_LOCATOR")
        self.assertEqual(verify["selector"], content)
        self.assertEqual(verify["id"], "content")
        self.assertEqual(verify["node"], 4)
        self.assertEqual(verify["message"], "Content is showing.")

    def test_verify_param_before_click_stays_first(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import compile_browser_actions

        command = "/browser +verify Ad setup max 8s +click Create"

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            self.assertIn("WAIT", operations)
            self.assertNotIn("CLICK", operations)
            self.assertIn("CLICK", following)
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "WAIT",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "WAIT" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "NONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "NONE" else 0) for key in following},
                    },
                },
            }

        with patch("cg_loop.model._jev_post", side_effect=post):
            compiled = compile_browser_actions(command, Tab())
        self.assertEqual(compiled["error"], "")
        self.assertEqual([item["operation"] for item in compiled["actions"]], ["WAIT", "CLICK"])
        self.assertEqual(compiled["actions"][0]["phrase"], "Ad setup")
        self.assertEqual(compiled["actions"][0]["seconds"], 8)
        self.assertEqual(compiled["actions"][1]["label"], "Create")
        self.assertIn('name="Create"', compiled["actions"][1]["selector"])

    def test_schedule_toggle_uses_its_visible_label_and_verifies_date(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import _text_wait, _verify_clause, compile_browser_actions

        command = "/browser click schedule content toggle verify Date"
        self.assertEqual(_verify_clause(command), ("Date", 5.0))
        self.assertEqual(_text_wait(command), ("Date", 5.0))
        page = {
            "url": "https://www.instagram.com/",
            "title": "Create new post",
            "text": "Add AI label\nLearn more\nSchedule content\n",
            "actions": [
                {
                    "id": "ai",
                    "kind": "click",
                    "node": 1,
                    "role": "switch",
                    "label": "Add AI label",
                    "name": "Add AI label",
                    "view": "shown",
                },
                {
                    "id": "schedule",
                    "kind": "click",
                    "node": 2,
                    "role": "switch",
                    "label": "Schedule content",
                    "name": "Schedule content",
                    "view": "shown",
                },
            ],
        }

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            clicks = body["questions"]["click_target"]["criteria"]
            ai = next(key for key, item in clicks.items() if item["element"] == "Add AI label")
            schedule = next(key for key, item in clicks.items() if item["element"] == "Schedule content")
            self.assertEqual(clicks[schedule]["priority"], "likely")
            self.assertEqual(clicks[ai]["priority"], "other")
            self.assertIn("Date", following["WAIT"])
            locators = body["questions"]["locator"]["criteria"]
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "CLICK",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "CLICK" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "WAIT",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "WAIT" else 0) for key in following},
                    },
                    "click_target": {
                        "choice": ai,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == ai else 0) for key in clicks},
                    },
                    "locator": {
                        "choice": ai,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == ai else 0) for key in locators},
                    },
                },
            }

        with patch("cg_loop.model._jev_post", side_effect=post):
            compiled = compile_browser_actions(command, Tab(page))
        self.assertEqual(compiled["error"], "")
        self.assertEqual(compiled["actions"][0]["label"], "Schedule content")
        self.assertIn("Schedule content", compiled["actions"][0]["selector"])
        self.assertEqual(compiled["actions"][1]["phrase"], "Date")
        self.assertEqual(compiled["actions"][1]["seconds"], 5)
        self.assertFalse(compiled["actions"][1].get("selector"))

    def test_am_pm_is_typed_when_jev_says_the_control_is_missing(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import compile_browser_actions

        command = "/browser Type AM or PM from $post_date into AM PM"
        page = {
            "url": "https://www.instagram.com/",
            "title": "Create new post",
            "text": "Time\n:\n",
            "actions": [
                {"id": "hours", "kind": "fill", "node": 1, "role": "spinbutton", "label": "Hours", "view": "shown"},
                {"id": "minutes", "kind": "fill", "node": 2, "role": "spinbutton", "label": "Minutes", "view": "shown"},
                {"id": "ampm", "kind": "fill", "node": 3, "role": "spinbutton", "label": "AM PM", "view": "shown"},
                {"id": "ampm-open", "kind": "click", "node": 3, "role": "spinbutton", "label": "Open AM PM", "view": "shown"},
            ],
        }

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            fields = body["questions"]["type_text_target"]["criteria"]
            am_pm = next(key for key, item in fields.items() if item["element"] == "AM PM")
            hours = next(key for key, item in fields.items() if item["element"] == "Hours")
            self.assertEqual(fields[am_pm]["priority"], "likely")
            self.assertEqual(fields[hours]["priority"], "other")
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "BLOCKED",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "BLOCKED" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "NONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "NONE" else 0) for key in following},
                    },
                },
            }

        with patch("cg_loop.model._jev_post", side_effect=post):
            compiled = compile_browser_actions(
                command,
                Tab(page),
                variables={"post_date": "2026-10-13 11:25:53"},
            )
        self.assertEqual(compiled["error"], "")
        self.assertEqual(compiled["actions"][0]["operation"], "TYPE_TEXT")
        self.assertIn('name="AM PM"', compiled["actions"][0]["selector"])

    def test_verify_then_click_waits_before_the_click(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import _text_wait

        command = "/browser verify Ad setup max 8s Click Create"
        self.assertEqual(_text_wait(command), ("Ad setup", 8.0))

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            selector = next(iter(body["questions"]["click_target"]["criteria"]))
            locators = body["questions"]["locator"]["criteria"]
            self.assertIn("WAIT", operations)
            self.assertNotIn("CLICK", operations)
            self.assertIn("Ad setup", operations["WAIT"])
            self.assertIn("8", operations["WAIT"])
            self.assertIn("CLICK", following)
            self.assertNotIn("WAIT", following)
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "WAIT",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "WAIT" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "CLICK",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "CLICK" else 0) for key in following},
                    },
                    "click_target": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {selector: 1},
                    },
                    "locator": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == selector else 0) for key in locators},
                    },
                },
            }

        tab = Tab()
        with patch("cg_loop.model._jev_post", side_effect=post):
            result = browser_helper(command, tab, dry_run=False)
        self.assertEqual(tab.acted, ["create"])
        self.assertEqual(result["status"], "done")
        self.assertEqual(
            [item["operation"] for item in result["outputs"]["actions"]],
            ["WAIT", "CLICK"],
        )

    def test_verify_can_be_a_locator_or_page_text(self) -> None:
        from unittest.mock import patch

        command = "/browser verify Content max 10s"
        content = 'role=menuitem[name="Content"s]'
        waits: list[tuple[str, str, int]] = []

        class Page:
            def locator(self, wanted: str):
                class Locator:
                    def wait_for(self, *, state: str, timeout: int) -> None:
                        waits.append((wanted, state, timeout))

                return Locator()

        tab = Tab(
            {
                "url": "https://studio.youtube.com",
                "title": "Studio",
                "text": "Channel dashboard\n",
                "actions": [
                    {"id": "content", "kind": "click", "role": "menuitem", "label": "Content", "node": 4},
                    {"id": "create", "kind": "click", "role": "button", "label": "Create", "node": 5},
                ],
            }
        )
        tab.page = Page()

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            locators = body["questions"]["wait_for_locator_target"]["criteria"]
            self.assertIn("Content", operations["WAIT"])
            self.assertIn("page text", operations["WAIT"])
            self.assertIn("10", operations["WAIT"])
            self.assertIn("locator", operations["WAIT_FOR_LOCATOR"])
            self.assertEqual(locators[content]["priority"], "likely")
            self.assertEqual(locators['role=button[name="Create"s]']["priority"], "other")
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "WAIT_FOR_LOCATOR",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "WAIT_FOR_LOCATOR" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "NONE",
                        "confidence": 1,
                        "probabilities": {
                            key: (1 if key == "NONE" else 0)
                            for key in body["questions"]["next_operation"]["criteria"]
                        },
                    },
                    "wait_for_locator_target": {
                        "choice": content,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == content else 0) for key in locators},
                    },
                    "locator": {
                        "choice": content,
                        "confidence": 1,
                        "probabilities": {
                            key: (1 if key == content else 0) for key in body["questions"]["locator"]["criteria"]
                        },
                    },
                },
            }

        with patch("cg_loop.model._jev_post", side_effect=post):
            result = browser_helper(command, tab, dry_run=False)
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["outputs"]["actions"][0]["operation"], "WAIT_FOR_LOCATOR")
        self.assertEqual(waits, [(content, "attached", 10000)])

    def test_repeated_goto_navigates_again(self) -> None:
        command = "/browser go to studio.youtube.com. Wait max 5s until Content"

        class Nav(Tab):
            def __init__(self) -> None:
                super().__init__(
                    {
                        "url": "https://studio.youtube.com/channel/UC",
                        "title": "Studio",
                        "text": "Content\n",
                        "actions": [],
                    }
                )
                self.events: list[str] = []

            def goto(self, url: str, **_kwargs: object) -> dict:
                self.events.append(url)
                self.page_state["url"] = "https://studio.youtube.com/channel/UC"
                self.page_state["text"] = "Content\n"
                return dict(self.page_state)

        def ask(_messages: list) -> dict:
            return {
                "actions": [
                    {"operation": "GOTO", "url": "https://studio.youtube.com"},
                    {"operation": "GOTO", "url": "https://studio.youtube.com"},
                    {"operation": "DONE"},
                ]
            }

        tab = Nav()
        result = browser_helper(command, tab, dry_run=False, ask=ask)
        self.assertEqual(tab.events, ["https://studio.youtube.com", "https://studio.youtube.com"])
        self.assertEqual(result["status"], "done")
        self.assertEqual(
            [item["operation"] for item in result["outputs"]["actions"]],
            ["GOTO", "GOTO"],
        )

    def test_goto_uses_the_url_in_the_command_when_the_reply_omits_it(self) -> None:
        url = (
            "https://www.instagram.com/accounts/insights/content/"
            "?media_type=all&metric=views&sort_by=newest&timeframe=30&view_type=card"
        )

        class Nav(Tab):
            def __init__(self) -> None:
                super().__init__(
                    {
                        "url": "https://www.instagram.com/",
                        "title": "Instagram",
                        "text": "Your reel has been shared.\n",
                        "actions": [],
                    }
                )
                self.events: list[str] = []

            def goto(self, url: str, **_kwargs: object) -> dict:
                self.events.append(url)
                self.page_state["url"] = url
                return dict(self.page_state)

        def ask(_messages: list) -> dict:
            return {"actions": [{"operation": "GOTO"}, {"operation": "DONE"}]}

        tab = Nav()
        result = browser_helper(f"/browser go {url}", tab, dry_run=False, ask=ask)
        self.assertEqual(result["status"], "done")
        self.assertEqual(tab.events, [url])

    def test_go_url_keeps_navigation_when_the_model_returns_done(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import compile_browser_actions

        command = "/browser go https://www.tiktok.com/tiktokstudio/content verify Views"

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            return {
                "model": "layla",
                "answers": {
                    "operation": {
                        "choice": "DONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "DONE" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "NONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "NONE" else 0) for key in following},
                    },
                },
            }

        tab = Tab({"url": "about:blank", "title": "", "text": "", "actions": []})
        with patch("cg_loop.model._jev_post", side_effect=post):
            compiled = compile_browser_actions(command, tab)
        self.assertEqual(compiled["error"], "")
        self.assertEqual([item["operation"] for item in compiled["actions"]], ["GOTO", "WAIT"])
        self.assertEqual(compiled["actions"][0]["url"], "https://www.tiktok.com/tiktokstudio/content")
        self.assertEqual(compiled["actions"][1]["phrase"], "Views")
        self.assertEqual(compiled["actions"][1]["seconds"], 5.0)

    def test_empty_compiled_actions_are_not_reused(self) -> None:
        import tempfile

        from cg_loop.compiled import validate_compiled
        from cg_loop.workflow import parse_step

        step = parse_step("/browser go https://www.tiktok.com/tiktokstudio/content verify Views")
        source = (
            '"""Compiled cg-loop step.\n\n'
            f"Source: {step.raw}\n"
            '"""\n'
            "def run(ctx):\n"
            "    from cg_loop.browser_helper import replay_browser_actions\n"
            "    return replay_browser_actions('', ctx.get('browser'), [])\n"
        )
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder) / "step"
            root.mkdir()
            script = root / "step.py"
            script.write_text(source, encoding="utf-8")
            (root / "step.json").write_text(
                json.dumps(
                    {
                        "command": step.raw,
                        "actions": [],
                        "page": {"url": "about:blank", "title": ""},
                    }
                ),
                encoding="utf-8",
            )
            self.assertEqual(validate_compiled(script, step), "compiled browser actions are missing")

    def test_wait_without_a_locator_sleeps_for_the_time(self) -> None:
        from unittest.mock import patch

        command = "/browser go to studio.youtube.com."

        class ReadyPage:
            def __init__(self) -> None:
                self.states: list[tuple[str, int]] = []

            def wait_for_load_state(self, state: str, timeout: int = 0) -> None:
                self.states.append((state, timeout))

        class Nav(Tab):
            def __init__(self) -> None:
                super().__init__(
                    {
                        "url": "https://studio.youtube.com/channel/UC/videos/upload",
                        "title": "Upload",
                        "text": "Content\n",
                        "actions": [
                            {"id": "wait", "kind": "wait", "label": "Wait for the page to update"},
                        ],
                    }
                )
                self.page = ReadyPage()
                self.events: list[str] = []

            def goto(self, url: str, **_kwargs: object) -> dict:
                self.events.append(url)
                self.page_state["url"] = url
                return dict(self.page_state)

        def ask(_messages: list) -> dict:
            return {
                "actions": [
                    {"operation": "GOTO", "url": "https://studio.youtube.com"},
                    {"operation": "WAIT"},
                ]
            }

        tab = Nav()
        slept: list[float] = []
        with patch("cg_loop.browser_helper.time.sleep", lambda seconds: slept.append(seconds)):
            result = browser_helper(command, tab, dry_run=False, ask=ask)
        self.assertEqual(tab.events, ["https://studio.youtube.com"])
        self.assertEqual(tab.page.states, [])
        self.assertEqual(slept, [5])
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["message"], "Waited 5s.")
        self.assertEqual(
            [item["operation"] for item in result["outputs"]["actions"]],
            ["GOTO", "WAIT"],
        )
        self.assertEqual(result["outputs"]["actions"][1]["message"], "Wait 5s")
        self.assertNotIn("document ready", result["outputs"]["actions"][1]["message"])

    def test_bare_wait_sleeps_without_a_page_check(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import compile_browser_actions, replay_browser_actions

        command = "/browser Wait 5s"
        slept: list[float] = []

        def refuse(_request: dict, *, goal: str = "") -> dict:
            raise AssertionError(goal)

        with patch("cg_loop.browser_helper.time.sleep", lambda seconds: slept.append(seconds)):
            with patch("cg_loop.model.ask_jev_browser", side_effect=refuse):
                compiled = compile_browser_actions(command, Tab())
            result = browser_helper(command, Tab(), dry_run=False, ask=refuse)
            replayed = replay_browser_actions(
                command,
                Tab(),
                [
                    {
                        "operation": "WAIT",
                        "selector": 'role=tab[name="Details"s]',
                        "phrase": "Details",
                        "seconds": 5,
                    }
                ],
            )
        self.assertEqual(slept, [5, 5])
        action = compiled["actions"][0]
        self.assertEqual(action["operation"], "WAIT")
        self.assertEqual(action["seconds"], 5)
        self.assertEqual(action["selector"], "")
        self.assertNotIn("phrase", action)
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["message"], "Waited 5s.")
        self.assertEqual(result["outputs"]["actions"][0]["message"], "Wait 5s")
        self.assertEqual(replayed["status"], "done")
        self.assertEqual(replayed["outputs"]["actions"][0]["message"], "Wait 5s")
        self.assertEqual(replayed["outputs"]["actions"][0]["selector"], "")
        self.assertNotIn("phrase", replayed["outputs"]["actions"][0])

    def test_select_files_chooses_the_story_video(self) -> None:
        import tempfile

        select = 'role=button[name="Select files"s]'
        with tempfile.TemporaryDirectory() as folder:
            video = Path(folder) / "youtube_captions_music.mp4"
            video.write_bytes(b"video")

            class FileTab(Tab):
                def __init__(self) -> None:
                    super().__init__(
                        {
                            "url": "https://studio.youtube.com/upload",
                            "title": "Upload",
                            "text": "Upload videos\nSelect files\n",
                            "actions": [
                                {
                                    "id": "select-files",
                                    "kind": "click",
                                    "node": 8,
                                    "role": "button",
                                    "label": "Select files",
                                }
                            ],
                        }
                    )
                    self.files: list[str] = []

                def act(self, action: dict, page: dict, text: str | None = None) -> dict:
                    del page, text
                    self.files = list(action.get("files") or [])
                    self.acted.append(str(action.get("id")))
                    return {"executed": action.get("id"), "file_dialog": "chosen"}

            def ask(_messages: list) -> dict:
                return {"actions": [{"operation": "CLICK", "selector": select, "confidence": 1}, {"operation": "DONE"}]}

            tab = FileTab()
            result = browser_helper(
                "/browser Click Select files and choose youtube_captions_music.mp4 from this story.",
                tab,
                dry_run=False,
                variables={"youtube_video": str(video), "story_folder": folder},
                ask=ask,
            )
            self.assertEqual(result["status"], "done")
            self.assertEqual(tab.acted, ["select-files"])
            self.assertEqual(tab.files, [str(video)])

    def test_select_from_computer_chooses_the_selected_video(self) -> None:
        import tempfile

        select = 'role=button[name="Select from computer"s]'
        with tempfile.TemporaryDirectory() as folder:
            video = Path(folder) / "output_music.mp4"
            video.write_bytes(b"video")

            class FileTab(Tab):
                def __init__(self) -> None:
                    super().__init__(
                        {
                            "url": "https://www.instagram.com/",
                            "title": "Create new post",
                            "text": "Select from computer\n",
                            "actions": [
                                {
                                    "id": "select-from-computer",
                                    "kind": "click",
                                    "node": 8,
                                    "role": "button",
                                    "label": "Select from computer",
                                }
                            ],
                        }
                    )
                    self.files: list[str] = []

                def act(self, action: dict, page: dict, text: str | None = None) -> dict:
                    del page, text
                    self.files = list(action.get("files") or [])
                    self.acted.append(str(action.get("id")))
                    return {"executed": action.get("id"), "file_dialog": "chosen"}

            def ask(_messages: list) -> dict:
                return {
                    "actions": [
                        {"operation": "CLICK", "selector": select, "confidence": 1},
                        {"operation": "DONE"},
                    ]
                }

            tab = FileTab()
            result = browser_helper(
                '/browser Click "Select from computer" and choose the selected video.',
                tab,
                dry_run=False,
                variables={"video": str(video), "story_folder": folder},
                ask=ask,
            )
            self.assertEqual(result["status"], "done")
            self.assertEqual(tab.acted, ["select-from-computer"])
            self.assertEqual(tab.files, [str(video)])
            self.assertEqual(result["outputs"]["actions"][0]["files"], [str(video)])

    def test_selected_video_missing_blocks_before_the_dialog(self) -> None:
        select = 'role=button[name="Select from computer"s]'

        class FileTab(Tab):
            def __init__(self) -> None:
                super().__init__(
                    {
                        "url": "https://www.instagram.com/",
                        "title": "Create new post",
                        "text": "Select from computer\n",
                        "actions": [
                            {
                                "id": "select-from-computer",
                                "kind": "click",
                                "node": 8,
                                "role": "button",
                                "label": "Select from computer",
                            }
                        ],
                    }
                )

            def act(self, action: dict, page: dict, text: str | None = None) -> dict:
                del action, page, text
                raise AssertionError("missing video must not open the file dialog")

        def ask(_messages: list) -> dict:
            return {"actions": [{"operation": "CLICK", "selector": select, "confidence": 1}]}

        result = browser_helper(
            '/browser Click "Select from computer" and choose the selected video.',
            FileTab(),
            dry_run=False,
            variables={"video": ""},
            ask=ask,
        )
        self.assertEqual(result["status"], "blocked")
        self.assertEqual(result["message"], "Could not find the selected video.")

    def test_video_click_stops_when_the_control_cannot_choose_a_file(self) -> None:
        import tempfile

        upload = 'role=button[name="Upload"s]'
        with tempfile.TemporaryDirectory() as folder:
            video = Path(folder) / "short.mp4"
            video.write_bytes(b"video")

            class UploadTab(Tab):
                def act(self, action: dict, page: dict, text: str | None = None) -> dict:
                    del action, page, text
                    raise AssertionError("a click that cannot choose a video must not run")

            def ask(_messages: list) -> dict:
                return {"actions": [{"operation": "CLICK", "selector": upload, "confidence": 1}]}

            result = browser_helper(
                "/browser Click Select video and choose the selected video.",
                UploadTab(
                    {
                        "url": "https://www.tiktok.com/tiktokstudio/upload",
                        "title": "TikTok Studio",
                        "text": "Upload\n",
                        "actions": [
                            {"id": "upload", "kind": "click", "node": 2, "role": "button", "label": "Upload"}
                        ],
                    }
                ),
                dry_run=False,
                variables={"video": str(video), "short_folder": folder},
                ask=ask,
            )
            self.assertEqual(result["status"], "blocked")
            self.assertEqual(result["message"], "Could not select the video.")

    def test_compiled_video_click_stops_when_upload_is_not_a_file_button(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.browser_helper import compile_browser_actions, replay_browser_actions

        upload = 'role=button[name="Upload"s]'
        page = {
            "url": "https://www.tiktok.com/tiktokstudio/upload",
            "title": "TikTok Studio",
            "text": "Upload\n",
            "actions": [{"id": "upload", "kind": "click", "node": 2, "role": "button", "label": "Upload"}],
        }
        with tempfile.TemporaryDirectory() as folder:
            video = Path(folder) / "short.mp4"
            video.write_bytes(b"video")
            variables = {"video": str(video), "short_folder": folder}
            command = "/browser Click Select video and choose the selected video."

            class UploadTab(Tab):
                def act(self, action: dict, page: dict, text: str | None = None) -> dict:
                    del action, page, text
                    raise AssertionError("a click that cannot choose a video must not run")

            tab = UploadTab(page)
            with patch(
                "cg_loop.model.ask_jev_browser",
                return_value={"actions": [{"operation": "CLICK", "selector": upload, "confidence": 1}]},
            ):
                compiled = compile_browser_actions(command, tab, variables=variables)
            self.assertEqual(compiled["error"], "Could not select the video.")
            self.assertEqual(compiled["actions"], [])
            with self.assertRaises(RuntimeError) as caught:
                replay_browser_actions(
                    command,
                    tab,
                    [{"operation": "CLICK", "selector": upload, "label": "Upload", "kind": "click", "id": "upload"}],
                    variables=variables,
                )
            self.assertEqual(str(caught.exception), "Could not select the video.")

    def test_video_click_stops_when_the_file_dialog_does_not_take_the_file(self) -> None:
        import tempfile

        select = 'role=button[name="Select video"s]'
        with tempfile.TemporaryDirectory() as folder:
            video = Path(folder) / "short.mp4"
            video.write_bytes(b"video")

            class ClosedDialog(Tab):
                def act(self, action: dict, page: dict, text: str | None = None) -> dict:
                    del page, text
                    self.acted.append(str(action.get("id")))
                    return {"executed": action.get("id"), "file_dialog": "closed"}

            def ask(_messages: list) -> dict:
                return {"actions": [{"operation": "CLICK", "selector": select, "confidence": 1}]}

            result = browser_helper(
                "/browser Click Select video and choose the selected video.",
                ClosedDialog(
                    {
                        "url": "https://www.tiktok.com/tiktokstudio/upload",
                        "title": "TikTok Studio",
                        "text": "Select video\n",
                        "actions": [
                            {
                                "id": "select-video",
                                "kind": "click",
                                "node": 8,
                                "role": "button",
                                "label": "Select video",
                            }
                        ],
                    }
                ),
                dry_run=False,
                variables={"video": str(video), "short_folder": folder},
                ask=ask,
            )
            self.assertEqual(result["status"], "blocked")
            self.assertEqual(result["message"], "Could not select the video.")

    def test_title_box_matches_the_title_field(self) -> None:
        self.assertFalse(_phrase_visible({"text": "Upload videos\nSelect files"}, "the Title box"))
        self.assertFalse(
            _phrase_visible(
                {"text": "Subtitles\nDashboard", "actions": [{"kind": "click", "label": "Subtitles"}]},
                "the Title box",
            )
        )
        self.assertTrue(_phrase_visible({"text": "Title (required)\nDescription"}, "the Title box"))
        self.assertTrue(
            _phrase_visible(
                {
                    "text": "",
                    "actions": [{"kind": "fill", "role": "textbox", "label": "Title"}],
                },
                "the Title box",
            )
        )

    def test_the_date_matches_an_unlabeled_date_input(self) -> None:
        page = {
            "text": "When to post\nNow\nSchedule\nWho can see this post",
            "actions": [
                {"kind": "fill", "role": "textbox", "label": "textbox", "value": "09:35"},
                {"kind": "fill", "role": "textbox", "label": "textbox", "value": "2026-10-10"},
            ],
        }
        self.assertTrue(_phrase_visible(page, "the date"))
        self.assertFalse(
            _phrase_visible(
                {"text": "When to post\nNow\nSchedule", "actions": [{"kind": "click", "label": "Schedule"}]},
                "the date",
            )
        )

    def test_stale_click_observes_again(self) -> None:
        class StaleThenReady(Tab):
            def act(self, action: dict, page: dict, text: str | None = None) -> dict:
                del page, text
                if not self.acted:
                    self.acted.append("stale")
                    raise StalePage("Target changed or is covered. Observe again.")
                self.acted.append(str(action.get("id")))
                return {"executed": action.get("id")}

        def ask(messages: list) -> dict:
            payload = json.loads(messages[1]["content"])
            recent = payload["recent_actions"]
            if not recent:
                return {"actions": [{"operation": "CLICK", "selector": CREATE, "confidence": 1}]}
            self.assertEqual(recent[-1]["action"], "Create")
            self.assertIn("covered", recent[-1]["error"])
            self.assertFalse(recent[-1]["page_changed"])
            return {"operation": "DONE", "message": "dialog is open", "confidence": 1}

        tab = StaleThenReady()
        result = browser_helper("/browser Click Create", tab, dry_run=False, ask=ask, max_steps=2)
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["message"], "dialog is open")
        self.assertEqual(tab.acted, ["stale"])
        self.assertFalse(result["executed"])

    def test_one_click_is_not_repeated(self) -> None:
        page = {
            "url": "https://studio.youtube.com/upload",
            "title": "Upload",
            "text": "Details\nVideo elements\nChecks\nNext",
            "actions": [
                {"id": "next", "kind": "click", "node": 99, "role": "button", "label": "Next"},
            ],
        }

        def ask(_messages: list) -> dict:
            return {
                "actions": [
                    {"operation": "CLICK", "selector": NEXT, "confidence": 1},
                    {"operation": "CLICK", "selector": NEXT, "confidence": 1},
                    {"operation": "DONE", "message": "Video elements is showing."},
                ]
            }

        tab = Tab(page)
        result = browser_helper(
            "/browser Click Next. Wait until Video elements text is showing.",
            tab,
            dry_run=False,
            ask=ask,
        )
        self.assertEqual(result["status"], "done")
        self.assertEqual([item["selector"] for item in result["outputs"]["actions"] if item["operation"] == "CLICK"], [NEXT])
        self.assertEqual(tab.acted, ["next"])

    def test_upload_videos_clicks_the_create_menu_item(self) -> None:
        button = 'role=button[name="Upload videos"s]'
        menu = 'role=menuitem[name="Upload videos"s]'

        def ask(_messages: list) -> dict:
            return {
                "actions": [
                    {"operation": "CLICK", "selector": button, "confidence": 1},
                    {"operation": "WAIT"},
                ]
            }

        tab = Tab(
            {
                "url": "https://studio.youtube.com/channel/UC",
                "title": "Channel dashboard",
                "text": "Create\nUpload videos\nSelect files\n",
                "actions": [
                    {
                        "id": "dash-upload",
                        "kind": "click",
                        "node": 4,
                        "role": "button",
                        "label": "Upload videos",
                    },
                    {
                        "id": "menu-upload",
                        "kind": "click",
                        "node": 9,
                        "role": "menuitem",
                        "label": "Upload videos",
                    },
                    {"id": "wait", "kind": "wait", "label": "Wait for the page to update"},
                ],
            }
        )
        result = browser_helper(
            '/browser Click "Upload videos" wait for "Select files" to show',
            tab,
            dry_run=False,
            ask=ask,
        )
        self.assertEqual(result["status"], "done")
        self.assertEqual(tab.acted, ["menu-upload"])
        self.assertEqual(result["outputs"]["actions"][0]["selector"], menu)
        self.assertEqual(result["outputs"]["actions"][0]["target"], menu)
        self.assertEqual(result["outputs"]["actions"][1]["operation"], "WAIT")
        self.assertEqual(result["message"], "already there")
        self.assertNotIn("document ready", result["outputs"]["actions"][1]["message"])

    def test_feature_notice_is_dismissed_before_the_click(self) -> None:
        create = 'role=button[name="Create"s]'

        class NoticeTab(Tab):
            def act(self, action: dict, page: dict, text: str | None = None) -> dict:
                del page, text
                self.acted.append(str(action.get("id")))
                if action.get("id") == "got-it":
                    self.page_state["text"] = "Create\n"
                    self.page_state["actions"] = [
                        {"id": "create", "kind": "click", "node": 3, "role": "button", "label": "Create"},
                    ]
                return {"executed": action.get("id")}

        def ask(_messages: list) -> dict:
            return {"actions": [{"operation": "CLICK", "selector": create, "confidence": 1}, {"operation": "DONE"}]}

        tab = NoticeTab(
            {
                "url": "https://studio.youtube.com/channel/UC",
                "title": "Channel dashboard",
                "text": "You're all set\nYou already have access to this feature.\nTry refreshing the page.\n",
                "actions": [
                    {"id": "got-it", "kind": "click", "node": 2, "role": "button", "label": "Got it"},
                    {"id": "create", "kind": "click", "node": 3, "role": "button", "label": "Create"},
                ],
            }
        )
        result = browser_helper("/browser Click Create", tab, dry_run=False, ask=ask)
        self.assertEqual(result["status"], "done")
        self.assertEqual(tab.acted, ["got-it", "create"])

    def test_typing_uses_the_text_model(self) -> None:
        title = 'role=textbox[name="Title"s]'
        page = {
            "url": "https://studio.youtube.com/upload",
            "title": "Upload",
            "text": "Title (required)\n",
            "actions": [
                {"id": "title", "kind": "fill", "node": 12, "role": "textbox", "label": "Title"},
            ],
        }
        calls = {"n": 0}

        def ask(messages: list) -> dict:
            if messages[0]["content"].startswith("Return a JSON object"):
                return {"text": "centering clay in ancient greece"}
            calls["n"] += 1
            if calls["n"] == 1:
                return {"actions": [{"operation": "TYPE_TEXT", "selector": title, "confidence": 1}]}
            return {"operation": "DONE", "confidence": 1}

        result = browser_helper(
            "/browser Type the post title into the Title input box.",
            Tab(page),
            dry_run=False,
            ask=ask,
        )
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["outputs"]["actions"][0]["operation"], "TYPE_TEXT")
        self.assertEqual(result["outputs"]["actions"][0]["text"], "centering clay in ancient greece")

    def test_title_type_does_not_use_the_channel_search(self) -> None:
        search = 'role=textbox[name="Search across your channel"s]'

        def ask(_messages: list) -> dict:
            return {"actions": [{"operation": "TYPE_TEXT", "selector": search, "confidence": 1}]}

        result = browser_helper(
            "/browser Type the post title into the Title input box.",
            Tab(
                {
                    "url": "https://studio.youtube.com/channel/UC",
                    "title": "Channel dashboard",
                    "text": "Subtitles\nSearch across your channel\nSelect files\n",
                    "actions": [
                        {
                            "id": "search",
                            "kind": "fill",
                            "node": 3,
                            "role": "textbox",
                            "label": "Search across your channel",
                        }
                    ],
                }
            ),
            dry_run=False,
            variables={"post_title": "Midnight sketches of a jet engine"},
            ask=ask,
        )
        self.assertEqual(result["status"], "blocked")
        self.assertEqual(result["message"], "Title input is not on the page.")
        self.assertEqual(result["outputs"]["actions"][0]["text"], None)

    def test_description_type_uses_the_studio_placeholder(self) -> None:
        description = 'role=textbox[name="Tell viewers about your video (type @ to mention a channel)"s]'
        story = "In a quiet workshop, Mara folds paper hopes into turbine blades."

        def ask(_messages: list) -> dict:
            return {"actions": [{"operation": "TYPE_TEXT", "selector": description, "confidence": 1}, {"operation": "DONE"}]}

        result = browser_helper(
            "/browser Type the post description into the Description box wait 1s",
            Tab(
                {
                    "url": "https://studio.youtube.com/channel/UC/videos/upload",
                    "title": "Upload",
                    "text": "Details\n",
                    "actions": [
                        {
                            "id": "description",
                            "kind": "fill",
                            "node": 8,
                            "role": "textbox",
                            "label": "Tell viewers about your video (type @ to mention a channel)",
                        }
                    ],
                }
            ),
            dry_run=False,
            variables={"description": story},
            ask=ask,
        )
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["outputs"]["actions"][0]["text"], story)

    def test_premature_done_asks_again(self) -> None:
        title = 'role=textbox[name="Title"s]'
        page = {
            "url": "https://studio.youtube.com/upload",
            "title": "Upload",
            "text": "Title (required)\n",
            "actions": [
                {"id": "title", "kind": "fill", "node": 12, "role": "textbox", "label": "Title"},
            ],
        }
        calls = {"n": 0}

        def ask(messages: list) -> dict:
            if messages[0]["content"].startswith("Return a JSON object"):
                return {"text": "centering clay in ancient greece"}
            calls["n"] += 1
            if calls["n"] == 1:
                return {"actions": [], "operation": "DONE", "message": ""}
            if calls["n"] == 2:
                return {"actions": [{"operation": "TYPE_TEXT", "selector": title, "confidence": 1}]}
            return {"operation": "DONE", "confidence": 1}

        result = browser_helper(
            "/browser Type the post title into the Title input box.",
            Tab(page),
            dry_run=False,
            ask=ask,
        )
        self.assertGreaterEqual(calls["n"], 2)
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["outputs"]["actions"][0]["operation"], "TYPE_TEXT")
        self.assertEqual(result["outputs"]["actions"][0]["text"], "centering clay in ancient greece")

    def test_timed_wait_keeps_the_locator(self) -> None:
        from unittest.mock import patch

        command = "/browser Type the post description into the Description box wait 1s"
        selector = 'role=textbox[name="Description"s]'
        slept: list[float] = []

        def ask(_messages: list) -> dict:
            return {
                "actions": [
                    {"operation": "WAIT", "locator": selector, "selector": selector},
                    {"operation": "DONE"},
                ]
            }

        tab = Tab(
            {
                "url": "https://studio.youtube.com/upload",
                "title": "Upload",
                "text": "Description\n",
                "actions": [
                    {"id": "description", "kind": "fill", "node": 4, "role": "textbox", "label": "Description"},
                ],
            }
        )
        with patch("cg_loop.browser_helper.time.sleep", lambda seconds: slept.append(seconds)):
            result = browser_helper(command, tab, dry_run=False, ask=ask)
        self.assertEqual(slept, [1])
        waited = result["outputs"]["actions"][0]
        self.assertEqual(waited["operation"], "WAIT")
        self.assertEqual(waited["seconds"], 1)
        self.assertEqual(waited["locator"], selector)
        self.assertEqual(waited["message"], "Wait 1s")
        self.assertNotIn("document ready", waited["message"])
        self.assertEqual(result["message"], "Waited 1s.")

    def test_wait_until_showing_does_not_go_anywhere(self) -> None:
        from unittest.mock import patch

        command = (
            "/browser Wait until Create is showing. "
            "Stop when the page is a login page, and say to log in by hand in this Chrome window, then run again."
        )

        class Later(Tab):
            def __init__(self) -> None:
                super().__init__(
                    {
                        "url": "https://studio.youtube.com/channel/UC",
                        "title": "Channel dashboard - YouTube Studio",
                        "text": "Channel dashboard\n",
                    }
                )
                self.reads = 0

            def observe(self) -> dict:
                self.reads += 1
                if self.reads > 1:
                    self.page_state["text"] = "Channel dashboard\nCreate\n"
                return dict(self.page_state)

        clock = {"now": 1_000.0}

        def fake_time() -> float:
            clock["now"] += 0.3
            return clock["now"]

        def fake_sleep(_seconds: float) -> None:
            clock["now"] += 0.3

        def ask(messages: list) -> dict:
            user = json.loads(messages[-1]["content"])
            self.assertNotIn("GOTO", user["operations"])
            self.assertIn("Create", user["operations"]["WAIT"])
            return {"actions": [{"operation": "WAIT"}, {"operation": "DONE"}]}

        with (
            patch("cg_loop.browser_helper.time.time", fake_time),
            patch("cg_loop.browser_helper.time.sleep", fake_sleep),
        ):
            result = browser_helper(command, Later(), dry_run=False, ask=ask)
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["outputs"]["actions"][0]["operation"], "WAIT")
        self.assertIn("Create", result["outputs"]["actions"][0]["message"])

    def test_wait_until_showing_compiles_when_the_phrase_is_already_visible(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import compile_browser_actions, replay_browser_actions

        command = "/browser +Wait until Create is showing. "
        page = {
            "url": "https://studio.youtube.com/channel/UC",
            "title": "Channel dashboard - YouTube Studio",
            "text": "Channel dashboard\nCreate\n",
            "actions": [
                {"id": "create", "kind": "click", "node": 1, "role": "button", "label": "Create", "view": "shown"},
            ],
        }
        with patch(
            "cg_loop.model.ask_jev_browser",
            return_value={"operation": "DONE", "actions": [{"operation": "DONE"}], "model": "jev-latest"},
        ):
            compiled = compile_browser_actions(command, Tab(page))
        self.assertEqual(compiled["error"], "")
        self.assertEqual([item["operation"] for item in compiled["actions"]], ["WAIT"])
        self.assertEqual(compiled["actions"][0]["phrase"], "Create")
        self.assertEqual(compiled["actions"][0]["message"], "already there")
        self.assertEqual(compiled["actions"][0]["seconds"], 0)
        self.assertTrue(compiled["actions"][0]["already"])
        self.assertFalse(compiled["actions"][0].get("selector"))
        slept: list[float] = []
        with patch("cg_loop.browser_helper.time.sleep", lambda seconds: slept.append(seconds)):
            result = replay_browser_actions(command, Tab(page), compiled["actions"])
        self.assertEqual(slept, [])
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["message"], "already there")
        self.assertEqual(result["actions"][0]["message"], "already there")

    def test_wait_polls_until_the_phrase_exists(self) -> None:
        from unittest.mock import patch

        command = "/browser Wait max 10s until Title"

        class Later(Tab):
            def __init__(self) -> None:
                super().__init__(
                    {"url": "https://studio.youtube.com/upload", "title": "Upload", "text": "Select files\n"}
                )
                self.reads = 0

            def observe(self) -> dict:
                self.reads += 1
                if self.reads > 1:
                    self.page_state["text"] = "Title\nDescription\n"
                return dict(self.page_state)

        clock = {"now": 1_000.0}

        def fake_time() -> float:
            clock["now"] += 0.3
            return clock["now"]

        def fake_sleep(_seconds: float) -> None:
            clock["now"] += 0.3

        def ask(messages: list) -> dict:
            if "List each browser action" in messages[0]["content"]:
                return {"actions": [{"operation": "WAIT"}, {"operation": "DONE"}]}
            raise AssertionError(messages[0]["content"][:40])

        with (
            patch("cg_loop.browser_helper.time.time", fake_time),
            patch("cg_loop.browser_helper.time.sleep", fake_sleep),
        ):
            result = browser_helper(command, Later(), dry_run=False, ask=ask)
        self.assertEqual(result["status"], "done")
        self.assertEqual(result["outputs"]["actions"][0]["operation"], "WAIT")
        self.assertIn("Title", result["outputs"]["actions"][0]["message"])

    def test_click_with_wait_max_runs_the_locator_jev_returns(self) -> None:
        command = '/browser click "Shorts" tab. Wait max 5s until Shorts'
        selector = 'role=tab[name="Shorts"s]'
        calls: list[str] = []
        waits: list[tuple[str, str, int]] = []

        class Page:
            def locator(self, wanted: str):
                class Locator:
                    def wait_for(self, *, state: str, timeout: int) -> None:
                        waits.append((wanted, state, timeout))
                        tab.page_state["text"] = "Videos\nShorts\n"
                        tab.page_state["actions"] = [
                            {"id": "shorts", "kind": "click", "role": "tab", "label": "Shorts", "node": 7}
                        ]

                return Locator()

        tab = Tab(
            {
                "url": "https://studio.youtube.com/channel/UC/videos/upload",
                "title": "Content",
                "text": "Channel content\nVideos\n",
                "actions": [{"id": "videos", "kind": "click", "role": "tab", "label": "Videos", "node": 3}],
            }
        )
        tab.page = Page()

        def ask(messages: list) -> dict:
            user = json.loads(messages[-1]["content"])
            offered = user["targets"].get("WAIT_FOR_LOCATOR") or {}
            self.assertIn(selector, offered)
            if not calls:
                calls.append("WAIT_FOR_LOCATOR")
                return {"operation": "WAIT_FOR_LOCATOR", "selector": selector}
            calls.append("CLICK")
            return {
                "actions": [
                    {"operation": "CLICK", "selector": selector},
                    {"operation": "DONE"},
                ]
            }

        result = browser_helper(command, tab, dry_run=False, ask=ask)
        self.assertEqual(calls, ["WAIT_FOR_LOCATOR", "CLICK"])
        self.assertEqual(waits, [(selector, "attached", 5000)])
        self.assertEqual(result["status"], "done")
        self.assertEqual(tab.acted, ["shorts"])
        self.assertEqual(
            [item["operation"] for item in result["outputs"]["actions"]],
            ["WAIT_FOR_LOCATOR", "CLICK"],
        )

    def test_wait_until_click_offers_a_button_locator(self) -> None:
        command = "/browser Wait max 10s until Click Close"
        selector = 'role=button[name="Close"s]'
        calls: list[str] = []
        waits: list[tuple[str, str, int]] = []

        class Page:
            def locator(self, wanted: str):
                class Locator:
                    def wait_for(self, *, state: str, timeout: int) -> None:
                        waits.append((wanted, state, timeout))
                        tab.page_state["text"] = "Video scheduled\nClose\n"
                        tab.page_state["actions"] = [
                            {"id": "close", "kind": "click", "role": "button", "label": "Close", "node": 9}
                        ]

                return Locator()

        tab = Tab(
            {
                "url": "https://studio.youtube.com/channel/UC",
                "title": "Channel dashboard - YouTube Studio",
                "text": "Channel dashboard\n",
                "actions": [{"id": "create", "kind": "click", "role": "button", "label": "Create", "node": 2}],
            }
        )
        tab.page = Page()

        def ask(messages: list) -> dict:
            user = json.loads(messages[-1]["content"])
            offered = user["targets"].get("WAIT_FOR_LOCATOR") or {}
            self.assertIn(selector, offered)
            self.assertNotIn("Click Close", str(user["operations"].get("WAIT") or ""))
            if not calls:
                calls.append("WAIT_FOR_LOCATOR")
                return {"operation": "WAIT_FOR_LOCATOR", "selector": selector}
            calls.append("CLICK")
            return {
                "actions": [
                    {"operation": "CLICK", "selector": selector},
                    {"operation": "DONE"},
                ]
            }

        result = browser_helper(command, tab, dry_run=False, ask=ask)
        self.assertEqual(calls, ["WAIT_FOR_LOCATOR", "CLICK"])
        self.assertEqual(waits, [(selector, "attached", 10000)])
        self.assertEqual(result["status"], "done")
        self.assertEqual(tab.acted, ["close"])

    def test_jev_returns_the_page_locator_with_the_action(self) -> None:
        from unittest.mock import patch

        command = "/browser Wait max 10s until Click Close"
        first = 'role=button[name="Close"s] >> nth=0'
        second = 'role=button[name="Close"s] >> nth=1'
        named = 'role=button[name="Close"s]'
        create = 'role=button[name="Create"s]'
        seen: dict = {}

        def post(body: dict) -> dict:
            seen["body"] = body
            operations = body["questions"]["operation"]["criteria"]
            locators = body["questions"]["wait_for_locator_target"]["criteria"]
            self.assertEqual(set(locators), {first, second, named, create})
            self.assertEqual(locators[first]["priority"], "likely")
            self.assertEqual(locators[second]["priority"], "likely")
            self.assertEqual(locators[named]["priority"], "likely")
            self.assertEqual(locators[create]["priority"], "other")
            self.assertIn("Prefer priority likely", " ".join(body["questions"]["wait_for_locator_target"]["instructions"]["rules"]))
            following = body["questions"]["next_operation"]["criteria"]
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "WAIT_FOR_LOCATOR",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "WAIT_FOR_LOCATOR" else 0) for key in operations},
                    },
                    "wait_for_locator_target": {
                        "choice": second,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == second else 0) for key in locators},
                    },
                    "next_operation": {
                        "choice": "DONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "DONE" else 0) for key in following},
                    },
                },
            }

        tab = Tab(
            {
                "url": "https://studio.youtube.com/channel/UC",
                "title": "Channel dashboard - YouTube Studio",
                "text": "Video scheduled\nClose\n",
                "actions": [
                    {"id": "create", "kind": "click", "role": "button", "label": "Create", "node": 2},
                    {"id": "close-menu", "kind": "click", "role": "button", "label": "Close", "node": 4},
                    {"id": "close-dialog", "kind": "click", "role": "button", "label": "Close", "node": 9},
                ],
            }
        )
        with patch("cg_loop.model._jev_post", side_effect=post):
            result = browser_helper(command, tab, dry_run=True)
        self.assertIn("wait_for_locator_target", seen["body"]["questions"])
        self.assertEqual(result["outputs"]["actions"][0]["operation"], "WAIT_FOR_LOCATOR")
        self.assertEqual(result["outputs"]["actions"][0]["selector"], second)

    def test_jev_does_not_offer_blocked_when_a_locator_wait_is_offered(self) -> None:
        from unittest.mock import patch

        command = '/browser click "Shorts" tab. Wait max 5s until Shorts'
        selector = 'role=tab[name="Shorts"s]'
        seen: dict = {}

        def post(body: dict) -> dict:
            seen["body"] = body
            operations = body["questions"]["operation"]["criteria"]
            self.assertNotIn("BLOCKED", operations)
            self.assertIn(selector, body["questions"]["wait_for_locator_target"]["criteria"])
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "DONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "DONE" else 0) for key in operations},
                    }
                },
            }

        tab = Tab(
            {
                "url": "https://studio.youtube.com/channel/UC/videos/upload",
                "title": "Content",
                "text": "Channel dashboard\n",
                "actions": [{"id": "content", "kind": "click", "role": "menuitem", "label": "Content", "node": 2}],
            }
        )
        with patch("cg_loop.model._jev_post", side_effect=post):
            result = browser_helper(command, tab, dry_run=True)
        self.assertNotIn("BLOCKED", seen["body"]["questions"]["operation"]["criteria"])
        self.assertEqual(result["status"], "dry-run")

    def test_wait_until_close_button_uses_the_button_locator(self) -> None:
        command = "/browser Wait max 5s until Close button"
        selector = 'role=button[name="Close"s] >> nth=0'
        waits: list[tuple[str, str, int]] = []

        class Page:
            def locator(self, wanted: str):
                class Locator:
                    def wait_for(self, *, state: str, timeout: int) -> None:
                        waits.append((wanted, state, timeout))

                return Locator()

        tab = Tab(
            {
                "url": "https://studio.youtube.com/channel/UC",
                "title": "Video published",
                "text": "Video scheduled\n",
                "actions": [
                    {"id": "close-icon", "kind": "click", "role": "button", "label": "Close", "node": 4},
                    {"id": "close-dialog", "kind": "click", "role": "button", "label": "Close", "node": 9},
                ],
            }
        )
        tab.page = Page()

        def ask(messages: list) -> dict:
            user = json.loads(messages[-1]["content"])
            offered = user["targets"].get("WAIT_FOR_LOCATOR") or {}
            self.assertIn(selector, offered)
            self.assertEqual(offered[selector]["priority"], "likely")
            self.assertNotIn("Close button", str(user["operations"].get("WAIT") or ""))
            return {
                "operation": "WAIT_FOR_LOCATOR",
                "selector": selector,
                "actions": [{"operation": "WAIT_FOR_LOCATOR", "selector": selector}, {"operation": "DONE"}],
            }

        result = browser_helper(command, tab, dry_run=False, ask=ask)
        self.assertEqual(result["status"], "done")
        self.assertEqual(waits, [(selector, "attached", 5000)])
        self.assertNotIn("Close button is not showing.", result.get("message", ""))

    def test_close_button_wait_stops_when_the_button_exists(self) -> None:
        command = "/browser Wait max 5s until Close button"
        selector = 'role=button[name="Close"s]'
        calls: list[str] = []
        waits: list[str] = []

        class Page:
            def locator(self, wanted: str):
                class Locator:
                    def wait_for(self, *, state: str, timeout: int) -> None:
                        del state, timeout
                        waits.append(wanted)

                return Locator()

        tab = Tab(
            {
                "url": "https://studio.youtube.com/channel/UC",
                "title": "Video published",
                "text": "Video scheduled\n",
                "actions": [
                    {"id": "close", "kind": "click", "role": "button", "label": "Close", "node": 4},
                    {"id": "wait", "kind": "wait", "label": "Wait for the page to update"},
                ],
            }
        )
        tab.page = Page()

        def ask(messages: list) -> dict:
            del messages
            calls.append("ask")
            return {
                "actions": [
                    {"operation": "WAIT_FOR_LOCATOR", "selector": selector},
                    {"operation": "WAIT", "selector": selector, "locator": selector},
                ]
            }

        result = browser_helper(command, tab, dry_run=False, ask=ask)
        self.assertEqual(calls, ["ask"])
        self.assertEqual(waits, [selector])
        self.assertEqual(result["status"], "done")
        self.assertEqual(len(result["outputs"]["actions"]), 1)

    def test_compile_asks_jev_once_and_replay_does_not(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import ensure_compiled, execute_compiled
        from cg_loop.workflow import load_workflow

        calls = {"n": 0}

        def post(body: dict) -> dict:
            calls["n"] += 1
            operations = body["questions"]["operation"]["criteria"]
            selector = next(iter(body["questions"]["click_target"]["criteria"]))
            following = body["questions"]["next_operation"]["criteria"]
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "CLICK",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "CLICK" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "NONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "NONE" else 0) for key in following},
                    },
                    "click_target": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {selector: 1},
                    },
                    "locator": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == selector else 0) for key in body["questions"]["locator"]["criteria"]},
                    },
                },
            }

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_post:",
                        "  - /browser Click Create",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            step = group.steps[0]

            class Shot:
                def screenshot(self, **_kwargs: object) -> bytes:
                    return b"jpeg-bytes"

            tab = Tab()
            tab.page = Shot()
            with patch("cg_loop.model._jev_post", side_effect=post):
                created = ensure_compiled(group, step, index=0, env=group.env, browser=tab)
                self.assertEqual(calls["n"], 1)
                self.assertEqual(created.status, "compiled")
                script = created.path.read_text(encoding="utf-8")
                self.assertIn("replay_browser_actions", script)
                self.assertNotIn("browser_helper(", script)
                from cg_loop.browser_helper import artifact_dir

                folder = artifact_dir(created.path)
                self.assertEqual(created.path.parent, folder)
                saved = json.loads((folder / "b_01-context.json").read_text(encoding="utf-8"))
                self.assertEqual(saved["actions"][0]["operation"], "CLICK")
                self.assertEqual(saved["actions"][0]["label"], "Create")
                self.assertEqual(saved["elements"][0]["label"], "Create")
                self.assertEqual(saved["elements"][0]["role"], "button")
                shot = "z-data_click_create.jpg"
                self.assertEqual(saved["screenshots"], [shot])
                self.assertEqual((folder / shot).read_bytes(), b"jpeg-bytes")
                again = ensure_compiled(group, step, index=0, env=group.env, browser=tab)
                self.assertEqual(again.status, "reused")
                self.assertEqual(calls["n"], 1)
                result = execute_compiled(created.path, {"browser": tab, "dry_run": False, "env": {}, "variables": {}})
            self.assertEqual(calls["n"], 1)
            self.assertEqual(result["status"], "done")
            self.assertEqual(tab.acted, ["create"])

    def test_blocked_compile_saves_the_page_for_review(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import _compile_replay_browser
        from cg_loop.workflow import parse_step

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "BLOCKED",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "BLOCKED" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "NONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "NONE" else 0) for key in following},
                    },
                },
            }

        class Shot:
            def screenshot(self, **_kwargs: object) -> bytes:
                return b"jpeg-bytes"

        tab = Tab(
            {
                "url": "https://studio.youtube.com/videos/short",
                "title": "Shorts",
                "text": "Content\n",
                "actions": [{"id": "create", "kind": "click", "role": "button", "label": "Create", "node": 7}],
            }
        )
        tab.page = Shot()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "step.py"
            with patch("cg_loop.model._jev_post", side_effect=post):
                body, reply = _compile_replay_browser(
                    parse_step("/browser Click No, it's not made for kids"),
                    path=path,
                    env={},
                    step_json="",
                    browser=tab,
                )
            self.assertEqual(body, "")
            self.assertIn("not on the page", reply.error)
            saved = json.loads((path.parent / path.stem / f"{path.stem}.json").read_text(encoding="utf-8"))
            self.assertEqual(saved["error"], reply.error)
            self.assertEqual(saved["actions"], [])
            self.assertEqual(saved["elements"][0]["label"], "Create")
            self.assertEqual(saved["page"]["url"], "https://studio.youtube.com/videos/short")
            self.assertEqual((path.parent / path.stem / saved["screenshots"][0]).read_bytes(), b"jpeg-bytes")
            self.assertEqual(saved["screenshots"], ["click_no_it_s_not_made_for_kids.jpg"])

    def test_replay_saves_one_screenshot_per_action(self) -> None:
        import tempfile

        from cg_loop.browser_helper import replay_browser_actions

        taken = {"n": 0}

        class Shot:
            def screenshot(self, **_kwargs: object) -> bytes:
                taken["n"] += 1
                return f"img-{taken['n']}".encode()

        tab = Tab()
        tab.page = Shot()
        with tempfile.TemporaryDirectory() as tmp:
            script = Path(tmp) / "step.py"
            script.write_text("def run(ctx):\n    return {}\n", encoding="utf-8")
            saved_path = script.with_suffix(".json")
            actions = [
                {"operation": "CLICK", "selector": CREATE, "label": "Create", "id": "create"},
                {"operation": "WAIT", "phrase": "Ad setup", "seconds": 1, "selector": ""},
            ]
            saved_path.write_text(json.dumps({"command": "click", "actions": actions}), encoding="utf-8")
            result = replay_browser_actions(
                "/browser Click Create verify Ad setup max 1s",
                tab,
                actions,
                screenshot_path=str(script),
            )
            self.assertEqual(
                [item["screenshot"] for item in result["outputs"]["actions"]],
                ["click_create.jpg", "wait_ad_setup.jpg"],
            )
            folder = script.parent / script.stem
            self.assertEqual((folder / "click_create.jpg").read_bytes(), b"img-1")
            self.assertEqual((folder / "wait_ad_setup.jpg").read_bytes(), b"img-2")
            stored = json.loads(saved_path.read_text(encoding="utf-8"))
            self.assertEqual(stored["screenshots"], ["click_create.jpg", "wait_ad_setup.jpg"])
            self.assertEqual(stored["actions"][1]["screenshot"], "wait_ad_setup.jpg")

    def test_replay_saves_run_screenshots_beside_the_step_log(self) -> None:
        import tempfile

        from cg_loop.browser_helper import replay_browser_actions

        class Shot:
            def screenshot(self, **_kwargs: object) -> bytes:
                return b"run-jpeg"

        tab = Tab()
        tab.page = Shot()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            script = root / "compiled" / "step.py"
            script.parent.mkdir()
            script.write_text("def run(ctx):\n    return {}\n", encoding="utf-8")
            saved_path = script.with_suffix(".json")
            actions = [
                {"operation": "CLICK", "selector": CREATE, "label": "Create", "id": "create"},
            ]
            saved_path.write_text(
                json.dumps({"command": "click", "actions": actions, "screenshots": ["compile.jpg"]}),
                encoding="utf-8",
            )
            log_json = root / "logs" / "02_click_create.json"
            log_json.parent.mkdir()
            result = replay_browser_actions(
                "/browser Click Create",
                tab,
                actions,
                env={"CG_LOOP_STEP_JSON": str(log_json)},
                screenshot_path=str(script),
            )
            shot = log_json.parent / "02_click_create.json_01_img_click_create.jpg"
            self.assertEqual(shot.read_bytes(), b"run-jpeg")
            self.assertEqual(result["outputs"]["screenshots"], [str(shot)])
            self.assertFalse((script.parent / script.stem).exists())
            stored = json.loads(saved_path.read_text(encoding="utf-8"))
            self.assertEqual(stored["screenshots"], ["compile.jpg"])

    def test_screenshot_outlines_the_click_and_the_verify_text(self) -> None:
        import io
        import tempfile

        from PIL import Image

        from cg_loop.browser_helper import artifact_dir, compile_screenshot

        class Page:
            def __init__(self) -> None:
                self.first = self
                self.seen: list[str] = []

            def locator(self, selector: str) -> "Page":
                self.seen.append(selector)
                return self

            def bounding_box(self, timeout: int = 0) -> dict[str, float]:
                del timeout
                return {"x": 10, "y": 16, "width": 36, "height": 18}

            def evaluate(self, script: str, arg: object = None) -> dict[str, float]:
                if arg is None and "devicePixelRatio" in script:
                    return {"w": 120, "h": 80, "dpr": 1}
                self.seen.append(str(arg))
                return {"x": 8, "y": 40, "width": 48, "height": 14}

            def screenshot(self, **_kwargs: object) -> bytes:
                buf = io.BytesIO()
                Image.new("RGB", (120, 80), (12, 12, 12)).save(buf, format="JPEG", quality=95)
                return buf.getvalue()

        page = Page()

        class Shot:
            def __init__(self) -> None:
                self.page = page

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            click_script = root / "click.py"
            verify_script = root / "verify.py"
            click = compile_screenshot(
                Shot(),
                click_script,
                1,
                name="click_create",
                actions=[{"operation": "CLICK", "selector": CREATE}],
            )
            verify = compile_screenshot(
                Shot(),
                verify_script,
                1,
                name="verify_views",
                actions=[{"operation": "WAIT", "selector": "", "phrase": "Views"}],
            )
            click_edge = Image.open(artifact_dir(click_script) / click).getpixel((10, 24))
            verify_edge = Image.open(artifact_dir(verify_script) / verify).getpixel((8, 46))
        self.assertEqual(page.seen[0], CREATE)
        self.assertIn("Views", page.seen)
        self.assertGreater(click_edge[0], 180)
        self.assertLess(click_edge[1], 90)
        self.assertGreater(verify_edge[0], 180)
        self.assertLess(verify_edge[1], 90)

    def test_replay_failure_raises(self) -> None:
        from cg_loop.browser_helper import replay_browser_actions

        with self.assertRaises(RuntimeError) as caught:
            replay_browser_actions(
                "/browser Click Create",
                Tab(),
                [{"operation": "CLICK", "selector": 'role=button[name="Missing"s]', "label": "Missing"}],
            )
        self.assertIn("is not on the page", str(caught.exception))

    def test_jev_browser_caps_choices_at_255(self) -> None:
        from unittest.mock import patch

        from cg_loop.model import _JEV_MAX_BYTES, _JEV_MAX_CHOICES, ask_jev_browser

        click = {}
        for index in range(1, 301):
            selector = f'role=button[name="Item {index}"s]'
            click[selector] = {
                "label": f"Item {index}",
                "role": "button",
                "selector": selector,
                "selector_key": selector,
                "priority": "likely" if index == 300 else "other",
                "view": "shown" if index >= 200 else "offscreen",
            }
        kept = 'role=button[name="Item 300"s]'
        request = {
            "messages": [
                {"role": "user", "content": json.dumps({"current_step": "Click Item 300"})},
            ],
            "operations": {"CLICK": "Click a control.", "DONE": "Done."},
            "targets": {"CLICK": click, "SCROLL_DOWN": dict(click)},
            "elements": [],
        }
        seen: dict = {}

        def post(body: dict) -> dict:
            seen["body"] = body
            questions = body["questions"]
            for name, question in questions.items():
                criteria = question["criteria"]
                self.assertLessEqual(len(criteria), _JEV_MAX_CHOICES, name)
            self.assertLessEqual(len(json.dumps(body)), _JEV_MAX_BYTES)
            self.assertIn(kept, questions["click_target"]["criteria"])
            self.assertIn(kept, questions["scroll_down_target"]["criteria"])
            self.assertIn(kept, questions["locator"]["criteria"])
            self.assertNotIn("Every locator is offered.", questions["scroll_down_target"]["instructions"]["rules"][-1])
            operations = questions["operation"]["criteria"]
            click_criteria = questions["click_target"]["criteria"]
            following = questions["next_operation"]["criteria"]
            locators = questions["locator"]["criteria"]
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "CLICK",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "CLICK" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "NONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "NONE" else 0) for key in following},
                    },
                    "click_target": {
                        "choice": kept,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == kept else 0) for key in click_criteria},
                    },
                    "locator": {
                        "choice": kept,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == kept else 0) for key in locators},
                    },
                },
            }

        with patch("cg_loop.model._jev_post", side_effect=post):
            result = ask_jev_browser(request, goal="Click Item 300")
        self.assertEqual(result["operation"], "CLICK")
        self.assertEqual(result["selector"], kept)
        self.assertTrue(seen["body"])


class ScheduleTextTests(unittest.TestCase):
    def test_post_date_fills_hour_minute_and_meridiem(self) -> None:
        from cg_loop.browser_helper import _known_text

        variables = {"post_date": "2026-10-13 13:05:00"}
        self.assertEqual(
            _known_text("/browser Type the hour from $post_date into Hours", variables),
            "1",
        )
        self.assertEqual(
            _known_text("/browser Type the minute from $post_date into Minutes", variables),
            "05",
        )
        self.assertEqual(
            _known_text("/browser Type AM or PM from $post_date into AM PM", variables),
            "PM",
        )
        self.assertEqual(
            _known_text("/browser Type the date from $post_date into the date input", variables),
            "Oct 13, 2026",
        )
        self.assertEqual(
            _known_text("/browser Type the time from $post_date into the time input", variables),
            "1:05 PM",
        )
        self.assertEqual(
            _known_text(
                "/browser Type the hour from 2026-10-13 00:09:00 into Hours",
                {},
            ),
            "12",
        )
        self.assertEqual(
            _known_text(
                "/browser Type the post title into the Title input box.",
                {"post_title": "Midnight", "post_date": "2026-10-13 13:05:00"},
            ),
            "Midnight",
        )
        self.assertEqual(
            _known_text(
                "/browser Type $description into the caption box",
                {"description": "The streets are quieting."},
            ),
            "The streets are quieting.",
        )

    def test_choose_the_day_uses_the_open_month(self) -> None:
        from cg_loop.browser_helper import _already_clicked_day, _chosen_day, _day_cell

        command = "/browser Click the date button and choose the day in $post_date"
        self.assertEqual(_chosen_day(command, {"post_date": "2026-10-15 12:09:10"}), "15")
        self.assertEqual(_chosen_day("/browser Click the date button", {"post_date": "2026-10-15 12:09:10"}), "")
        page = {
            "actions": [
                {"kind": "click", "role": "gridcell", "label": "27", "selector": "prev"},
                {"kind": "click", "role": "gridcell", "label": "1", "selector": "oct-1"},
                {"kind": "click", "role": "gridcell", "label": "15", "selector": "oct-15"},
                {"kind": "click", "role": "gridcell", "label": "27", "selector": "oct-27"},
                {"kind": "click", "role": "gridcell", "label": "1", "selector": "nov-1"},
            ]
        }
        self.assertEqual(_day_cell(page, "15")["selector"], "oct-15")
        self.assertEqual(_day_cell(page, "27")["selector"], "oct-27")
        self.assertEqual(_day_cell(page, "1")["selector"], "oct-1")
        clicked = [{"operation": "CLICK", "label": "15", "selector": 'role=gridcell[name="15"s]'}]
        self.assertTrue(_already_clicked_day(clicked, "15"))
        self.assertFalse(_already_clicked_day([{"operation": "CLICK", "label": "Tue, Oct 13, 2026", "selector": "role=button"}], "15"))


class SendKeysTests(unittest.TestCase):
    def test_three_command_forms(self) -> None:
        from cg_loop.browser_helper import sendkeys_command

        self.assertEqual(
            sendkeys_command("/browser sendkeys clear then $post_date"),
            (True, "$post_date"),
        )
        self.assertEqual(sendkeys_command("/browser sendkeys clear"), (True, ""))
        self.assertEqual(sendkeys_command("/browser sendkeys $post_date"), (False, "$post_date"))
        self.assertEqual(
            sendkeys_command("/browser +sendkeys clear then $post_date"),
            (True, "$post_date"),
        )
        self.assertIsNone(sendkeys_command("/browser Type the date into the date input"))

    def test_clear_deletes_then_types_the_variable(self) -> None:
        from cg_loop.browser_helper import run_sendkeys

        class Keys:
            def __init__(self) -> None:
                self.pressed: list[str] = []
                self.typed: list[str] = []

            def press(self, key: str) -> None:
                self.pressed.append(key)

            def type(self, text: str, delay: int = 0) -> None:
                del delay
                self.typed.append(text)

        class Page:
            def __init__(self) -> None:
                self.keyboard = Keys()

        class Tab:
            def __init__(self) -> None:
                self.page = Page()

        tab = Tab()
        result = run_sendkeys(
            {"variables": {"post_date": "2026-10-15 19:41:42"}, "browser": tab},
            "/browser sendkeys clear then $post_date",
        )
        self.assertEqual(tab.page.keyboard.pressed, ["Meta+A", "Backspace"])
        self.assertEqual(tab.page.keyboard.typed, ["2026-10-15 19:41:42"])
        self.assertEqual(result["outputs"]["status"], "ok")

        only = Tab()
        run_sendkeys({"browser": only}, "/browser sendkeys clear")
        self.assertEqual(only.page.keyboard.pressed, ["Meta+A", "Backspace"])
        self.assertEqual(only.page.keyboard.typed, [])

        typed = Tab()
        run_sendkeys(
            {"variables": {"post_date": "Oct 15, 2026"}, "browser": typed},
            "/browser sendkeys $post_date",
        )
        self.assertEqual(typed.page.keyboard.pressed, [])
        self.assertEqual(typed.page.keyboard.typed, ["Oct 15, 2026"])

        word = Tab()
        run_sendkeys({"browser": word}, "/browser sendkeys Enter")
        self.assertEqual(word.page.keyboard.pressed, [])
        self.assertEqual(word.page.keyboard.typed, ["Enter"])

        entered = Tab()
        run_sendkeys({"browser": entered}, "/browser sendkeys ^Enter")
        self.assertEqual(entered.page.keyboard.pressed, ["Enter"])
        self.assertEqual(entered.page.keyboard.typed, [])

        escaped = Tab()
        run_sendkeys({"browser": escaped}, "/browser sendkeys ^esc")
        self.assertEqual(escaped.page.keyboard.pressed, ["Escape"])

        both = Tab()
        run_sendkeys({"browser": both}, "/browser sendkeys clear then ^Enter")
        self.assertEqual(both.page.keyboard.pressed, ["Meta+A", "Backspace", "Enter"])

        chord = Tab()
        run_sendkeys({"browser": chord}, "/browser sendkeys ^command+a ^delete ^shift")
        self.assertEqual(chord.page.keyboard.pressed, ["Meta+A", "Delete", "Shift"])
        self.assertEqual(chord.page.keyboard.typed, [])

    def test_compile_sends_keys_without_a_textbox_lookup(self) -> None:
        import tempfile

        from cg_loop.compiled import ensure_compiled
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            workflows = Path(tmp) / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "config:\n  name: demo\nwf_post:\n  - /browser sendkeys clear then $post_date\n",
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            body = created.path.read_text(encoding="utf-8")
            self.assertIn("run_sendkeys", body)
            self.assertNotIn("replay_browser_actions", body)

    def test_bare_wait_compiles_without_a_tab(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import ensure_compiled, validate_compiled
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            workflows = Path(tmp) / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "config:\n  name: demo\nwf_wait:\n  - /browser wait 10s\n",
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).named_groups()["wf_wait"]
            with patch("cg_loop.model.ask_jev_browser", side_effect=AssertionError("model")):
                created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            body = created.path.read_text(encoding="utf-8")
            self.assertIn("replay_browser_actions", body)
            slept: list[float] = []
            with patch("cg_loop.browser_helper.time.sleep", lambda seconds: slept.append(seconds)):
                from cg_loop.compiled import execute_compiled

                result = execute_compiled(created.path, {"dry_run": False, "browser": None, "env": {}, "variables": {}})
        self.assertEqual(slept, [10])
        self.assertEqual(result["status"], "done")
        self.assertFalse(result["blocked"])


class ClickLocatorTests(unittest.TestCase):
    def test_click_uses_the_selector_instead_of_a_visible_name(self) -> None:
        import tempfile

        from cg_loop.browser_helper import click_locator_command, run_click_locator
        from cg_loop.compiled import ensure_compiled
        from cg_loop.workflow import load_workflow

        selector = "#time-of-day-container input"
        self.assertEqual(
            click_locator_command(f"/browser Click locator {selector}"),
            selector,
        )
        self.assertIsNone(click_locator_command('/browser Click "12:00 AM"'))

        class Field:
            def __init__(self) -> None:
                self.clicked = 0

            @property
            def first(self) -> "Field":
                return self

            def click(self, timeout: int = 0) -> None:
                del timeout
                self.clicked += 1

        class Page:
            def __init__(self) -> None:
                self.field = Field()
                self.selectors: list[str] = []

            def locator(self, wanted: str) -> Field:
                self.selectors.append(wanted)
                return self.field

        class Tab:
            def __init__(self) -> None:
                self.page = Page()

        tab = Tab()
        result = run_click_locator({"browser": tab}, f"/browser Click locator {selector}")
        self.assertEqual(result["outputs"]["status"], "ok")
        self.assertEqual(tab.page.selectors, [selector])
        self.assertEqual(tab.page.field.clicked, 1)

        with tempfile.TemporaryDirectory() as tmp:
            workflows = Path(tmp) / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                'config:\n  name: demo\nwf_post:\n  - /browser Click locator "#time-of-day-container input"\n',
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            body = created.path.read_text(encoding="utf-8")
            self.assertIn("run_click_locator", body)
            self.assertNotIn("replay_browser_actions", body)


class EnabledClickTests(unittest.TestCase):
    def test_command_names_the_control_and_the_timeout(self) -> None:
        from cg_loop.browser_helper import browser_helper, enabled_click_command

        parsed = enabled_click_command("/browser wait max 10s Close enabled and then Click Close")
        self.assertEqual(parsed, ("Close", 10.0))
        self.assertIsNone(enabled_click_command("/browser wait max 10s until Close"))
        result = browser_helper(
            "/browser wait max 10s Close enabled and then Click Close",
            None,
            dry_run=True,
            ask=lambda _messages: (_ for _ in ()).throw(AssertionError("Jev must not run")),
        )
        self.assertEqual(result["status"], "dry-run")
        self.assertEqual([item["operation"] for item in result["actions"]], ["WAIT", "CLICK"])

    def test_already_enabled_close_is_clicked_while_another_is_disabled(self) -> None:
        from cg_loop.browser_helper import choose_enabled_click

        upload = {
            "id": "ytcp-uploads-dialog-close-button",
            "label": "",
            "disabled": True,
            "x": 1163,
            "y": 60,
            "w": 36,
            "h": 36,
        }
        share = {"id": "close-button", "label": "Close", "disabled": False, "x": 910, "y": 735, "w": 67, "h": 36}
        action, picked, _pending = choose_enabled_click([upload, share], set())
        self.assertEqual(action, "click")
        self.assertEqual(picked["id"], "close-button")
        upload["disabled"] = False
        action, picked, _pending = choose_enabled_click([upload, share], set())
        self.assertEqual(action, "click")
        self.assertEqual(picked["id"], "ytcp-uploads-dialog-close-button")

    def test_disabled_close_is_waited_for_until_it_enables(self) -> None:
        from cg_loop.browser_helper import choose_enabled_click

        upload = {
            "id": "ytcp-uploads-dialog-close-button",
            "label": "",
            "disabled": True,
            "x": 1163,
            "y": 60,
            "w": 36,
            "h": 36,
        }
        action, _picked, pending = choose_enabled_click([upload], set())
        self.assertEqual(action, "wait")
        upload["disabled"] = False
        action, picked, _pending = choose_enabled_click([upload], pending)
        self.assertEqual(action, "click")
        self.assertEqual(picked["id"], "ytcp-uploads-dialog-close-button")


class _OptionalClick:
    def __init__(self) -> None:
        self.calls: list[tuple[int, bool]] = []

    def click(self, timeout: int = 3000, force: bool = False) -> None:
        self.calls.append((timeout, force))


class _OptionalMouse:
    def __init__(self) -> None:
        self.clicks: list[tuple[float, float]] = []

    def click(self, x: float, y: float) -> None:
        self.clicks.append((x, y))


class _OptionalPage:
    def __init__(self, found: list[dict]) -> None:
        self.found = found
        self.asked = ""
        self.locator_click = _OptionalClick()
        self.mouse = _OptionalMouse()
        self.selector = ""

    def evaluate(self, script: str, name: str) -> list[dict]:
        del script
        self.asked = name
        return self.found

    def locator(self, selector: str) -> _OptionalClick:
        self.selector = selector
        return self.locator_click


class _OptionalTab:
    def __init__(self, found: list[dict]) -> None:
        self.page = _OptionalPage(found)

    def observe(self) -> dict:
        return {"url": "https://www.tiktok.com/tiktokstudio/upload", "title": "Upload"}


class ScheduleClickTests(unittest.TestCase):
    def test_a_finished_click_does_not_wait_for_the_same_button(self) -> None:
        from cg_loop.browser_helper import replay_browser_actions

        selector = 'role=button[name="Schedule"s]'
        tab = Tab(
            {
                "url": "https://www.tiktok.com/tiktokstudio/upload",
                "title": "TikTok Studio",
                "text": "Schedule\nPost now\n",
                "actions": [
                    {"id": "schedule", "kind": "click", "role": "button", "label": "Schedule"},
                ],
            }
        )

        class Page:
            def locator(self, wanted: str) -> None:
                raise AssertionError(f"should not wait for {wanted}")

        tab.page = Page()
        result = replay_browser_actions(
            "/browser Click Schedule button",
            tab,
            [
                {
                    "operation": "CLICK",
                    "selector": selector,
                    "label": "Schedule",
                    "id": "schedule",
                    "kind": "click",
                },
                {
                    "operation": "WAIT",
                    "selector": selector,
                    "label": "Wait for the page to update",
                    "seconds": 5,
                },
            ],
        )
        self.assertEqual(tab.acted, ["schedule"])
        self.assertEqual(result["status"], "done")
        self.assertFalse(result["blocked"])
        self.assertEqual([item["operation"] for item in result["actions"]], ["CLICK"])

    def test_plain_click_is_not_offered_a_followup_wait(self) -> None:
        from unittest.mock import patch

        from cg_loop.model import ask_jev_browser, choose_request
        from cg_loop.workflow import parse_step

        page = {
            "url": "https://www.tiktok.com/tiktokstudio/upload",
            "title": "TikTok Studio",
            "text": "Schedule\n",
            "actions": [
                {"id": "schedule", "kind": "click", "role": "button", "label": "Schedule"},
            ],
        }
        step = parse_step("/browser Click Schedule button")
        request = choose_request(page, step, [], {}, selectors=True)

        def post(body: dict) -> dict:
            following = body["questions"]["next_operation"]["criteria"]
            self.assertNotIn("WAIT", following)
            self.assertNotIn("WAIT_FOR_LOCATOR", following)
            self.assertIn("NONE", following)
            operations = body["questions"]["operation"]["criteria"]
            selector = next(iter(body["questions"]["click_target"]["criteria"]))
            locators = body["questions"]["locator"]["criteria"]
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "CLICK",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "CLICK" else 0) for key in operations},
                    },
                    "next_operation": {
                        "choice": "NONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "NONE" else 0) for key in following},
                    },
                    "click_target": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {selector: 1},
                    },
                    "locator": {
                        "choice": selector,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == selector else 0) for key in locators},
                    },
                },
            }

        with patch("cg_loop.model._jev_post", side_effect=post):
            answer = ask_jev_browser(request, goal=step.raw)
        self.assertEqual(answer["operation"], "CLICK")
        self.assertEqual([item["operation"] for item in answer["actions"]], ["CLICK"])


class ClickIfExistsTests(unittest.TestCase):
    def test_command_names_the_control_and_the_pause(self) -> None:
        from cg_loop.browser_helper import browser_helper, click_if_exists_command

        parsed = click_if_exists_command("/browser wait 2s and click Post Now if it exists")
        self.assertEqual(parsed, ("Post Now", 2.0))
        self.assertEqual(
            click_if_exists_command('/browser wait 2 seconds and click "Post Now" if it exists.'),
            ("Post Now", 2.0),
        )
        self.assertEqual(
            click_if_exists_command("/browser click the Post Now button if it exists"),
            ("Post Now", 0.0),
        )
        self.assertIsNone(click_if_exists_command("/browser wait 1s"))
        self.assertIsNone(click_if_exists_command("/browser Click Schedule"))
        self.assertIsNone(
            click_if_exists_command("/browser wait max 10s Close enabled and then Click Close")
        )
        result = browser_helper(
            "/browser wait 2s and click Post Now if it exists",
            None,
            dry_run=True,
            ask=lambda _messages: (_ for _ in ()).throw(AssertionError("Jev must not run")),
        )
        self.assertEqual(result["status"], "dry-run")
        self.assertFalse(result["outputs"]["clicked"])
        self.assertEqual([item["operation"] for item in result["actions"]], ["WAIT", "CLICK"])

    def test_visible_enabled_control_is_preferred(self) -> None:
        from cg_loop.browser_helper import choose_existing_click

        hidden = {"id": "offscreen", "label": "Post Now", "disabled": False, "x": 0, "y": 0, "w": 0, "h": 0}
        disabled = {"id": "saving", "label": "Post Now", "disabled": True, "x": 10, "y": 10, "w": 80, "h": 32}
        ready = {"id": "post", "label": "Post Now", "disabled": False, "x": 20, "y": 20, "w": 80, "h": 32}
        self.assertEqual(choose_existing_click([hidden, disabled, ready])["id"], "post")
        self.assertEqual(choose_existing_click([hidden, disabled])["id"], "saving")
        self.assertIsNone(choose_existing_click([hidden]))

    def test_click_when_present_and_continue_when_absent(self) -> None:
        from unittest.mock import patch

        from cg_loop.browser_helper import browser_helper

        present = _OptionalTab(
            [{"id": "post-now", "label": "Post Now", "disabled": False, "x": 40, "y": 50, "w": 90, "h": 36}]
        )
        with patch("cg_loop.browser_helper.time.sleep") as slept:
            clicked = browser_helper(
                "/browser wait 2s and click Post Now if it exists",
                present,
                ask=lambda _messages: (_ for _ in ()).throw(AssertionError("Jev must not run")),
            )
        slept.assert_called_once_with(2.0)
        self.assertEqual(clicked["status"], "done")
        self.assertFalse(clicked["blocked"])
        self.assertTrue(clicked["outputs"]["clicked"])
        self.assertEqual(present.page.asked, "Post Now")
        self.assertEqual(present.page.selector, "#post-now")
        self.assertEqual(present.page.locator_click.calls, [(3000, True)])

        missing = _OptionalTab([])
        with patch("cg_loop.browser_helper.time.sleep") as slept:
            skipped = browser_helper("/browser click Post Now if it exists", missing)
        slept.assert_not_called()
        self.assertEqual(skipped["status"], "done")
        self.assertFalse(skipped["blocked"])
        self.assertFalse(skipped["outputs"]["clicked"])
        self.assertIn("not on the page", skipped["message"])

    def test_compile_calls_click_if_exists(self) -> None:
        import tempfile

        from cg_loop.compiled import ensure_compiled, validate_compiled
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-demo.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_post:\n"
                "  - /browser wait 2s and click Post Now if it exists\n",
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["wf_post"]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, group.steps[0]), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("click_if_exists", text)
            self.assertNotIn("browser_helper(", text)

    def test_js_instruction_compiles_to_run_browser_js(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import _generated_js_script
        from cg_loop.model import CompileReply
        from cg_loop.workflow import parse_step

        step = parse_step(
            "/browser +js if not already on https://www.instagram.com/scheduled_content/ +verify Schedule"
        )
        from cg_loop.decision import skips_script

        self.assertEqual(step.kind, "browser_js")
        self.assertTrue(step.params.get("generate_js"))
        self.assertFalse(skips_script(step))
        self.assertEqual(step.params.get("verify"), "Schedule")
        self.assertEqual(step.extra, "if not already on https://www.instagram.com/scheduled_content/")
        script = (
            "() => {\n"
            "  const target = 'https://www.instagram.com/scheduled_content/';\n"
            "  const here = location.href.replace(/\\/$/, '');\n"
            "  if (!here.startsWith(target.replace(/\\/$/, ''))) location.href = target;\n"
            "}"
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "b-compile.py"
            with patch(
                "cg_loop.model.generate_browser_js",
                return_value=CompileReply(text=script, model="test"),
            ) as generated:
                body, reply = _generated_js_script(step, path=path, env={}, page={}, step_json="")
            generated.assert_called_once()
        self.assertEqual(reply.error, "")
        self.assertIn("run_browser_js", body)
        self.assertIn("location.href", body)
        self.assertIn("verify Schedule", body)
        self.assertIn("'Schedule'", body)


if __name__ == "__main__":
    unittest.main()
