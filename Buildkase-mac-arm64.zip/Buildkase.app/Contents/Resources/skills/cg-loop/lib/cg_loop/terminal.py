"""Terminal command execution for TERM operations."""

from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
from pathlib import Path
from typing import Any
from urllib.parse import quote

DANGEROUS_PATTERNS = [
    "sudo ",
    "rm -rf",
    "rm -fr",
    "git reset --hard",
    "git clean -f",
    "mkfs",
    "diskutil erase",
    "shutdown",
    "reboot",
    ":(){",
]

_VAR_RE = re.compile(r"\$\{(\w+)\}|\$(\w+)")


def needs_confirmation(command: str) -> bool:
    lowered = command.lower()
    return any(pattern.lower() in lowered for pattern in DANGEROUS_PATTERNS)


def expand_command(command: str, env: dict[str, str], variables: dict[str, Any]) -> str:
    def repl(match: re.Match[str]) -> str:
        name = match.group(1) or match.group(2)
        if name in variables:
            value = variables[name]
            if isinstance(value, dict):
                return str(value.get("url") or value.get("text") or value.get("title") or "")
            return str(value)
        if name in env:
            return env[name]
        return os.environ.get(name, match.group(0))

    return _VAR_RE.sub(repl, command)


def expand_url(url: str, env: dict[str, str], variables: dict[str, Any]) -> str:
    """Fill `$NAME` in a browser URL. A keyword is encoded; a full http value is left as-is."""

    def lookup(name: str) -> str | None:
        if name in variables:
            value = variables[name]
            if isinstance(value, dict):
                return str(value.get("url") or value.get("text") or value.get("title") or "")
            return str(value)
        if name in env:
            return env[name]
        if name in os.environ:
            return os.environ[name]
        return None

    def repl(match: re.Match[str]) -> str:
        name = match.group(1) or match.group(2)
        value = lookup(name)
        if value is None:
            return match.group(0)
        if value.startswith(("http://", "https://")):
            return value
        return quote(value, safe="")

    return _VAR_RE.sub(repl, url)


def apply_venv(command: str, env: dict[str, str], *, cwd: str | None = None) -> dict[str, str]:
    """Prepend skill virtualenvs so `#!/usr/bin/env python3` uses the matching interpreter.

    A script under `skills/<name>/` picks `skills/<name>/venv` when that venv exists.
    `POST_PYTHON`-style env values that point inside a venv are included too.
    """
    merged = dict(env)
    bins = _venv_bins(command, merged, cwd=cwd)
    if not bins:
        return merged
    current = [part for part in merged.get("PATH", "").split(os.pathsep) if part]
    merged["PATH"] = os.pathsep.join([*bins, *[part for part in current if part not in bins]])
    merged["VIRTUAL_ENV"] = str(Path(bins[0]).parent)
    return merged


def _venv_bins(command: str, env: dict[str, str], *, cwd: str | None) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()
    for path in [*_command_paths(command, cwd), *_env_paths(env)]:
        bin_dir = _venv_bin(path)
        if bin_dir and bin_dir not in seen:
            seen.add(bin_dir)
            found.append(bin_dir)
    return found


def _command_paths(command: str, cwd: str | None) -> list[Path]:
    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = command.split()
    base = Path(cwd) if cwd else None
    paths: list[Path] = []
    for token in tokens:
        if not _path_token(token):
            continue
        candidate = Path(token)
        if not candidate.is_absolute() and base is not None:
            candidate = base / candidate
        if _exists(candidate):
            paths.append(candidate)
    return paths


def _env_paths(env: dict[str, str]) -> list[Path]:
    paths: list[Path] = []
    for value in env.values():
        text = str(value or "")
        if not _path_token(text) or not text.startswith("/"):
            continue
        candidate = Path(text)
        if _exists(candidate):
            paths.append(candidate)
    return paths


def _path_token(token: str) -> bool:
    """A shell word that might name a file. Script bodies are not paths."""
    if not token or token.startswith("-"):
        return False
    if "\n" in token or "\x00" in token or len(token) > 1024:
        return False
    return True


def _exists(candidate: Path) -> bool:
    try:
        return candidate.exists()
    except OSError:
        return False


def _venv_bin(path: Path) -> str | None:
    current = path if path.is_dir() else path.parent
    for _ in range(8):
        bin_dir = current / "venv" / "bin"
        if (bin_dir / "python3").is_file() or (bin_dir / "python").is_file():
            return str(bin_dir)
        if current.parent == current:
            break
        current = current.parent
    return None


def command_timeout(value: Any) -> int | None:
    """Seconds for one terminal command. Unset or 0 means no limit."""
    if value is None or value == "":
        return None
    try:
        seconds = int(value)
    except (TypeError, ValueError):
        return None
    return seconds if seconds > 0 else None


def print_command(command: str) -> None:
    print("\n" + "=" * 70)
    print(f"$ {command}")
    print("=" * 70)


def bkase_dir() -> str:
    """Directory that holds the `bkase` script, when this install has one."""
    from .workflow import SKILL_ROOT, cg_loop_location

    folders: list[Path] = []
    try:
        folders.append(cg_loop_location().parent)
    except (OSError, ValueError):
        pass
    folders.append(SKILL_ROOT / "scripts")
    seen: set[Path] = set()
    for folder in folders:
        try:
            resolved = folder.resolve()
        except OSError:
            continue
        if resolved in seen:
            continue
        seen.add(resolved)
        if (folder / "bkase").is_file():
            return str(resolved)
    return ""


def with_bkase(env: dict[str, str]) -> dict[str, str]:
    """Put `bkase` on PATH for bash scripts this command starts.

    A virtualenv bin that is already first stays first, so `python3` is unchanged.
    """
    folder = bkase_dir()
    if not folder:
        return env
    merged = dict(env)
    parts = [part for part in merged.get("PATH", "").split(os.pathsep) if part]
    if folder in parts:
        return merged
    insert_at = 1 if parts and _is_venv_bin(parts[0]) else 0
    parts.insert(insert_at, folder)
    merged["PATH"] = os.pathsep.join(parts)
    return merged


def _is_venv_bin(folder: str) -> bool:
    """A project virtualenv bin. `/usr/bin` also contains `python3` and is not one."""
    path = Path(folder)
    if path.name != "bin":
        return False
    if not ((path / "python").is_file() or (path / "python3").is_file()):
        return False
    parent = path.parent
    return (parent / "pyvenv.cfg").is_file() or parent.name == "venv"


def run_command(
    command: str,
    *,
    timeout: int | None,
    cwd: str | None = None,
    env: dict[str, str] | None = None,
    confirm: bool = True,
) -> dict[str, Any]:
    print_command(command)
    if confirm and needs_confirmation(command):
        answer = input("\nPotentially dangerous command. Run it? [y/N]: ").strip().lower()
        if answer not in {"y", "yes"}:
            return {
                "status": "rejected",
                "command": command,
                "message": "User rejected this command.",
            }
    merged = with_bkase(apply_venv(command, {**os.environ, **(env or {})}, cwd=cwd))
    venv = merged.get("VIRTUAL_ENV")
    if venv and venv != os.environ.get("VIRTUAL_ENV"):
        print(f"venv: {venv}")
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            executable="/bin/zsh",
            cwd=cwd,
            env=merged,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = (exc.stdout or "")[-20000:] if isinstance(exc.stdout, str) else ""
        stderr = (exc.stderr or "")[-20000:] if isinstance(exc.stderr, str) else ""
        print(stdout, end="")
        if stderr:
            print("\nSTDERR:\n" + stderr, end="")
        return {
            "status": "timeout",
            "command": command,
            "stdout": stdout,
            "stderr": stderr,
        }
    except Exception as exc:
        return {"status": "error", "command": command, "error": str(exc)}

    stdout = result.stdout[-20000:]
    stderr = result.stderr[-20000:]
    print(stdout, end="")
    if stderr:
        print("\nSTDERR:\n" + stderr, end="")
    return {
        "status": "completed" if result.returncode == 0 else "failed",
        "command": command,
        "exit_code": result.returncode,
        "stdout": stdout,
        "stderr": stderr,
    }


def dumps_result(result: dict[str, Any]) -> str:
    return json.dumps(result)
