"""The shared local-models process loads a model once and can be killed."""

from __future__ import annotations

import io
import json
import os
import subprocess
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

from cg_loop import resident


def _cache_repo(hub: Path, repo_id: str, revision: str, blob_name: str, payload: bytes) -> dict[str, Path]:
    """One cached model whose weight lives in the shared blob store."""
    org, name = repo_id.split("/", 1)
    folder = hub / f"models--{org}--{name}"
    marker = hub / "blobs" / ".huggingface-shared-blobs"
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text("1\n", encoding="utf-8")
    blob = hub / "blobs" / blob_name[:2] / blob_name
    blob.parent.mkdir(parents=True, exist_ok=True)
    blob.write_bytes(payload)
    (blob.parent / f"{blob_name}.refs").write_text(
        f"models--{org}--{name}/blobs/etag\n",
        encoding="utf-8",
    )
    etag = folder / "blobs" / "etag"
    etag.parent.mkdir(parents=True)
    etag.symlink_to(Path("..") / ".." / "blobs" / blob_name[:2] / blob_name)
    snapshot = folder / "snapshots" / revision
    snapshot.mkdir(parents=True)
    (snapshot / "weights").symlink_to(Path("..") / ".." / "blobs" / "etag")
    return {"folder": folder, "blob": blob}


class CatalogTest(unittest.TestCase):
    def test_catalog_lists_local_models_only(self) -> None:
        ids = {row["id"] for row in resident.catalog()}
        self.assertIn("andai-labs/LocateAnything-3B-MLX", ids)
        self.assertIn("mlx-community/clef-flash-4bit", ids)
        self.assertIn("prism-ml/Bonsai-4B-mlx-1bit", ids)
        self.assertIn("prism-ml/Ternary-Bonsai-8B-mlx-2bit", ids)
        self.assertIn("prism-ml/Ternary-Bonsai-2-9B-mlx-2bit", ids)
        self.assertIn("prism-ml/bonsai-image-ternary-4B-mlx-2bit", ids)
        self.assertIn("laya", ids)
        self.assertIn("von", ids)
        self.assertFalse(any(name.startswith("openrouter/") for name in ids))

    def test_catalog_includes_a_cached_repo_that_is_not_configured(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp) / "hub"
            snapshot = hub / "models--Example--SDXL-Lightning" / "snapshots" / "main"
            snapshot.mkdir(parents=True)
            (snapshot / "sdxl_lightning_4step.safetensors").write_bytes(b"weights")
            runtime = Path(tmp) / "runtime"
            runtime.mkdir()
            with patch.dict(
                os.environ,
                {"HF_HUB_CACHE": str(hub), "CG_LOOP_MODELS_DIR": str(runtime)},
            ):
                rows = {row["id"]: row for row in resident.catalog()}
        self.assertEqual(rows["Example/SDXL-Lightning"]["tool"], "hug")
        self.assertEqual(rows["Example/SDXL-Lightning"]["kind"], "generate")

    def test_status_shows_cached_models_missing_from_a_running_process(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp) / "hub"
            snapshot = hub / "models--org--extra" / "snapshots" / "main"
            snapshot.mkdir(parents=True)
            (snapshot / "model_index.json").write_text("{}", encoding="utf-8")
            runtime = Path(tmp) / "runtime"
            runtime.mkdir()
            stale = {
                "ok": True,
                "running": True,
                "pid": 9,
                "rss_bytes": 10,
                "models": [
                    {
                        "id": "prism-ml/Bonsai-4B-mlx-1bit",
                        "tool": "hug",
                        "kind": "text",
                        "status": "loaded",
                        "disk_bytes": 4,
                        "memory_bytes": 8,
                        "loaded_at": "2026-10-18T14:00:00",
                    }
                ],
            }
            with patch.dict(
                os.environ,
                {"HF_HUB_CACHE": str(hub), "CG_LOOP_MODELS_DIR": str(runtime)},
            ):
                with patch.object(resident, "_ping", return_value={"ok": True}), patch.object(
                    resident, "_rpc", return_value=stale
                ):
                    report = resident.status_report()
        ids = {row["id"]: row for row in report["models"]}
        self.assertEqual(ids["org/extra"]["kind"], "generate")
        self.assertEqual(ids["org/extra"]["status"], "on disk")
        self.assertEqual(ids["prism-ml/Bonsai-4B-mlx-1bit"]["status"], "loaded")
        self.assertEqual(ids["prism-ml/Bonsai-4B-mlx-1bit"]["memory_bytes"], 8)
        self.assertEqual(ids["prism-ml/Bonsai-4B-mlx-1bit"]["loaded_at"], "2026-10-18T14:00:00")

    def test_delete_removes_one_cached_repo_and_its_shared_blob(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp) / "hub"
            runtime = Path(tmp) / "runtime"
            runtime.mkdir()
            gone = _cache_repo(hub, "org/gone", "aaa", "aa" * 32, b"gone")
            stay = _cache_repo(hub, "org/stay", "bbb", "bb" * 32, b"stay")
            with patch.dict(os.environ, {"HF_HUB_CACHE": str(hub), "CG_LOOP_MODELS_DIR": str(runtime)}):
                report = resident.delete_report("org/gone")
            self.assertFalse(gone["folder"].exists())
            self.assertFalse(gone["blob"].exists())
            self.assertTrue(stay["folder"].exists())
            self.assertEqual(stay["blob"].read_bytes(), b"stay")
            ids = {row["id"] for row in report["models"]}
            self.assertNotIn("org/gone", ids)
            self.assertIn("org/stay", ids)

    def test_delete_unloads_before_removing_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp) / "hub"
            runtime = Path(tmp) / "runtime"
            runtime.mkdir()
            gone = _cache_repo(hub, "org/gone", "aaa", "aa" * 32, b"gone")
            calls: list[str] = []

            def rpc(payload, timeout=0):
                del timeout
                cmd = str(payload.get("cmd"))
                calls.append(cmd)
                if cmd == "unload":
                    self.assertTrue(gone["folder"].exists())
                return {"ok": True, "running": True, "pid": 1, "rss_bytes": 1, "models": []}

            with patch.dict(os.environ, {"HF_HUB_CACHE": str(hub), "CG_LOOP_MODELS_DIR": str(runtime)}):
                with patch.object(resident, "_ping", return_value={"ok": True}), patch.object(resident, "_rpc", side_effect=rpc):
                    resident.delete_report("org/gone")
            self.assertEqual(calls[0], "unload")
            self.assertFalse(gone["folder"].exists())

    def test_delete_refuses_an_installed_tool(self) -> None:
        with self.assertRaises(RuntimeError):
            resident.delete_report("laya")

    def test_disk_size_counts_a_blob_once(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            blob = root / "models--org--name" / "blobs" / "weights"
            blob.parent.mkdir(parents=True)
            blob.write_bytes(b"abcdef")
            link_dir = root / "models--org--name" / "snapshots" / "main"
            link_dir.mkdir(parents=True)
            (link_dir / "weights").symlink_to(blob)
            runtime = root / "runtime"
            runtime.mkdir()
            with patch.dict(os.environ, {"HF_HUB_CACHE": tmp, "CG_LOOP_MODELS_DIR": str(runtime)}):
                self.assertEqual(resident.disk_bytes("org/name", "hug"), 6)

    def test_disk_size_counts_a_shared_blob_once(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp) / "hub"
            _cache_repo(hub, "org/name", "main", "ab" * 32, b"abcdef")
            runtime = Path(tmp) / "runtime"
            runtime.mkdir()
            with patch.dict(os.environ, {"HF_HUB_CACHE": str(hub), "CG_LOOP_MODELS_DIR": str(runtime)}):
                self.assertEqual(resident.disk_bytes("org/name", "hug"), 6)
                self.assertEqual(resident.folder_report("org/name")["path"], str(hub / "models--org--name"))

    def test_disk_size_ignores_a_missing_shared_blob(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp) / "hub"
            folder = hub / "models--org--name"
            etag = folder / "blobs" / "etag"
            etag.parent.mkdir(parents=True)
            etag.symlink_to(Path("..") / ".." / "blobs" / "ab" / ("ab" * 32))
            snapshot = folder / "snapshots" / "main"
            snapshot.mkdir(parents=True)
            (snapshot / "weights").symlink_to(Path("..") / ".." / "blobs" / "etag")
            runtime = Path(tmp) / "runtime"
            runtime.mkdir()
            with patch.dict(os.environ, {"HF_HUB_CACHE": str(hub), "CG_LOOP_MODELS_DIR": str(runtime)}):
                self.assertEqual(resident.disk_bytes("org/name", "hug"), 0)

    def test_status_does_not_start_the_process(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            old = os.environ.get("CG_LOOP_MODELS_DIR")
            os.environ["CG_LOOP_MODELS_DIR"] = tmp
            resident._READY = False
            try:
                with patch.object(resident, "_spawn") as spawn:
                    report = resident.status_report()
                spawn.assert_not_called()
            finally:
                resident._READY = False
                if old is None:
                    os.environ.pop("CG_LOOP_MODELS_DIR", None)
                else:
                    os.environ["CG_LOOP_MODELS_DIR"] = old
        self.assertFalse(report["running"])
        self.assertTrue(report["models"])
        self.assertTrue(report["smart_memory"])
        self.assertEqual(report["memory_limit"], 80)


class ProcessTest(unittest.TestCase):
    def setUp(self) -> None:
        self._old = os.environ.get("CG_LOOP_MODELS_DIR")
        self._tmp = tempfile.TemporaryDirectory()
        os.environ["CG_LOOP_MODELS_DIR"] = self._tmp.name
        resident._META.clear()
        resident._UNLOAD_FAILED.clear()
        resident._READY = False
        resident._SERVING = False

    def tearDown(self) -> None:
        resident._META.clear()
        resident._UNLOAD_FAILED.clear()
        resident._READY = False
        resident._SERVING = False
        if self._old is None:
            os.environ.pop("CG_LOOP_MODELS_DIR", None)
        else:
            os.environ["CG_LOOP_MODELS_DIR"] = self._old
        self._tmp.cleanup()

    def test_a_second_load_reuses_the_weights(self) -> None:
        loads = {"n": 0}

        def fake_load(row: dict, *, download: bool) -> None:
            loads["n"] += 1

        thread = threading.Thread(target=resident._serve, daemon=True)
        with patch.object(resident, "_load_into_process", fake_load):
            thread.start()
            try:
                self.assertTrue(resident._wait_ping(5))
                first = resident._rpc({"cmd": "load", "id": "laya"}, timeout=5)
                second = resident._rpc({"cmd": "load", "id": "laya"}, timeout=5)
            finally:
                try:
                    resident._rpc({"cmd": "stop"}, timeout=5)
                except OSError:
                    pass
        thread.join(timeout=5)
        self.assertFalse(thread.is_alive())
        self.assertEqual(loads["n"], 1)
        self.assertTrue(any(row["id"] == "laya" and row["status"] == "loaded" for row in first["models"]))
        self.assertTrue(any(row["id"] == "laya" and row["status"] == "loaded" for row in second["models"]))

    def test_kill_ends_a_process_that_ignores_the_socket(self) -> None:
        proc = subprocess.Popen(["sleep", "60"], start_new_session=True)
        resident._pid_path().write_text(str(proc.pid), encoding="utf-8")
        try:
            report = resident.stop_report()
            self.assertIsNotNone(proc.wait(timeout=3))
        finally:
            if proc.poll() is None:
                proc.kill()
        self.assertFalse(report["running"])
        self.assertFalse(resident._pid_path().exists())

    def test_restart_kills_the_old_process_and_starts_another(self) -> None:
        proc = subprocess.Popen(["sleep", "60"], start_new_session=True)
        resident._pid_path().write_text(str(proc.pid), encoding="utf-8")
        try:
            with patch.object(resident, "_spawn") as spawn, patch.object(
                resident, "_wait_ping", return_value=True
            ):
                resident.restart_report()
            self.assertIsNotNone(proc.wait(timeout=3))
        finally:
            if proc.poll() is None:
                proc.kill()
        spawn.assert_called_once()


class MemoryTest(unittest.TestCase):
    def setUp(self) -> None:
        self._old = os.environ.get("CG_LOOP_MODELS_DIR")
        self._tmp = tempfile.TemporaryDirectory()
        os.environ["CG_LOOP_MODELS_DIR"] = self._tmp.name
        resident._META.clear()
        resident._UNLOAD_FAILED.clear()

    def tearDown(self) -> None:
        resident._META.clear()
        resident._UNLOAD_FAILED.clear()
        if self._old is None:
            os.environ.pop("CG_LOOP_MODELS_DIR", None)
        else:
            os.environ["CG_LOOP_MODELS_DIR"] = self._old
        self._tmp.cleanup()

    def test_missing_file_defaults_to_on(self) -> None:
        self.assertEqual(resident.memory_policy(), (True, 80))

    def test_storage_dir_is_where_disk_size_is_counted(self) -> None:
        store = Path(self._tmp.name) / "weights"
        blob = store / "hub" / "models--org--name" / "blobs" / "weights"
        blob.parent.mkdir(parents=True)
        blob.write_bytes(b"abcdef")
        (Path(self._tmp.name) / "memory.json").write_text(
            json.dumps({"dir": str(store)}), encoding="utf-8"
        )
        ignored = Path(self._tmp.name) / "ignored"
        with patch.dict(os.environ, {"HF_HUB_CACHE": str(ignored)}):
            self.assertEqual(resident.disk_bytes("org/name", "hug"), 6)

    def test_storage_dir_points_hugging_face_and_can_be_cleared(self) -> None:
        from cg_loop.app_config import apply_model_storage, reset_model_storage

        store = Path(self._tmp.name) / "weights"
        (Path(self._tmp.name) / "memory.json").write_text(
            json.dumps({"dir": str(store)}), encoding="utf-8"
        )
        previous = {key: os.environ.get(key) for key in ("HF_HOME", "HF_HUB_CACHE", "HUGGINGFACE_HUB_CACHE")}
        os.environ.pop("HF_HOME", None)
        os.environ["HF_HUB_CACHE"] = str(Path(self._tmp.name) / "old")
        reset_model_storage()
        try:
            apply_model_storage()
            self.assertEqual(os.environ["HF_HOME"], str(store))
            self.assertEqual(os.environ["HF_HUB_CACHE"], str(store / "hub"))
            self.assertTrue(store.is_dir())
            (Path(self._tmp.name) / "memory.json").write_text(json.dumps({"dir": ""}), encoding="utf-8")
            apply_model_storage()
            self.assertIsNone(os.environ.get("HF_HOME"))
            self.assertEqual(os.environ["HF_HUB_CACHE"], str(Path(self._tmp.name) / "old"))
        finally:
            reset_model_storage()
            for key, value in previous.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            from cg_loop.app_config import _refresh_hf_constants

            _refresh_hf_constants()

    def test_policy_file_turns_it_off(self) -> None:
        (Path(self._tmp.name) / "memory.json").write_text(
            json.dumps({"smart": False, "limit": 70}), encoding="utf-8"
        )
        self.assertEqual(resident.memory_policy(), (False, 70))

    def test_limit_is_clamped(self) -> None:
        (Path(self._tmp.name) / "memory.json").write_text(
            json.dumps({"smart": True, "limit": 10}), encoding="utf-8"
        )
        self.assertEqual(resident.memory_policy(), (True, 50))

    def test_pages_treat_inactive_memory_as_available(self) -> None:
        text = "\n".join(
            [
                "Mach Virtual Memory Statistics: (page size of 16384 bytes)",
                "Pages free: 100.",
                "Pages inactive: 50.",
                "Pages speculative: 0.",
                "Pages active: 1000.",
            ]
        )
        self.assertAlmostEqual(resident._percent_from_pages(16384 * 200, 16384, text), 25.0)

    def test_off_leaves_loaded_models_alone(self) -> None:
        (Path(self._tmp.name) / "memory.json").write_text(
            json.dumps({"smart": False, "limit": 50}), encoding="utf-8"
        )
        resident._META["laya"] = {"memory_bytes": 1, "loaded_at": 1, "used_at": 1}
        with patch.object(resident, "system_memory_percent", return_value=99):
            freed = resident._sweep()
        self.assertEqual(freed, [])
        self.assertIn("laya", resident._META)

    def test_unloads_the_least_recently_used_until_under_the_limit(self) -> None:
        resident._META["laya"] = {"memory_bytes": 1, "loaded_at": 1, "used_at": 1}
        resident._META["prism-ml/Bonsai-4B-mlx-1bit"] = {"memory_bytes": 1, "loaded_at": 2, "used_at": 5}

        def percent() -> float:
            if resident._META:
                return 90.0
            return 40.0

        def fake_unload(model_id: str) -> None:
            resident._META.pop(model_id, None)

        with patch.object(resident, "system_memory_percent", percent), patch.object(
            resident, "_unload", fake_unload
        ):
            freed = resident._sweep()
        self.assertEqual(freed, ["laya", "prism-ml/Bonsai-4B-mlx-1bit"])

    def test_keeps_the_model_a_request_is_about_to_use(self) -> None:
        resident._META["laya"] = {"memory_bytes": 1, "loaded_at": 1, "used_at": 1}
        resident._META["prism-ml/Bonsai-4B-mlx-1bit"] = {"memory_bytes": 1, "loaded_at": 2, "used_at": 9}

        def fake_unload(model_id: str) -> None:
            resident._META.pop(model_id, None)

        with patch.object(resident, "system_memory_percent", return_value=99), patch.object(
            resident, "_unload", fake_unload
        ):
            freed = resident._sweep(keep="laya")
        self.assertEqual(freed, ["prism-ml/Bonsai-4B-mlx-1bit"])
        self.assertIn("laya", resident._META)

    def test_von_stays_loaded(self) -> None:
        resident._META["von"] = {"memory_bytes": 1, "loaded_at": 1, "used_at": 1}
        resident._META["laya"] = {"memory_bytes": 1, "loaded_at": 2, "used_at": 2}

        def fake_unload(model_id: str) -> None:
            if model_id == "von":
                raise RuntimeError("von stays loaded until the models process stops")
            resident._META.pop(model_id, None)

        with patch.object(resident, "system_memory_percent", return_value=99), patch.object(
            resident, "_unload", fake_unload
        ):
            freed = resident._sweep()
        self.assertEqual(freed, ["laya"])
        self.assertIn("von", resident._META)

    def test_newer_tool_config_does_not_match_a_running_process(self) -> None:
        root = Path(self._tmp.name)
        pid = root / "models.pid"
        source = root / "hug.py"
        pid.write_text("99", encoding="utf-8")
        source.write_text("old", encoding="utf-8")
        os.utime(source, (1_000, 1_000))
        os.utime(pid, (2_000, 2_000))
        with patch.object(resident, "_pid_path", return_value=pid), patch.object(
            resident, "_source_files", return_value=[source]
        ):
            self.assertTrue(resident._sources_match_process())
            source.write_text("new", encoding="utf-8")
            os.utime(source, (3_000, 3_000))
            self.assertFalse(resident._sources_match_process())

    def test_a_stale_process_is_restarted(self) -> None:
        with patch.object(resident, "_process_ready", return_value=True), patch.object(
            resident, "_sources_match_process", return_value=False
        ), patch.object(resident, "_force_stop") as stop, patch.object(
            resident, "_spawn"
        ) as spawn, patch.object(resident, "_wait_ping", return_value=True):
            resident._ensure_started()
        stop.assert_called_once()
        spawn.assert_called_once()
        self.assertTrue(resident._READY)


class ChatReportTest(unittest.TestCase):
    def test_public_row_includes_the_url_and_file_support(self) -> None:
        with patch.object(resident, "disk_bytes", return_value=0):
            text = resident._public_row(
                {"id": "prism-ml/Bonsai-4B-mlx-1bit", "tool": "hug", "kind": "text"},
                None,
            )
            image = resident._public_row(
                {"id": "prism-ml/Ternary-Bonsai-2-9B-mlx-2bit", "tool": "hug", "kind": "image"},
                None,
            )
            local = resident._public_row({"id": "laya", "tool": "laya", "kind": "decision"}, None)
        self.assertEqual(text["url"], "https://huggingface.co/prism-ml/Bonsai-4B-mlx-1bit")
        self.assertFalse(text["files"])
        self.assertTrue(image["files"])
        self.assertEqual(image["url"], "https://huggingface.co/prism-ml/Ternary-Bonsai-2-9B-mlx-2bit")
        self.assertEqual(local["url"], "")
        self.assertFalse(local["files"])

    def test_chat_report_asks_a_text_model(self) -> None:
        seen: dict[str, object] = {}

        def rpc(message: dict[str, object], timeout: float) -> dict[str, object]:
            seen.update(message)
            return {"ok": True, "text": "pong"}

        with patch.object(
            resident, "_known", return_value={"id": "org/m", "tool": "hug", "kind": "text"}
        ), patch.object(resident, "_ensure_started"), patch.object(resident, "_rpc", side_effect=rpc):
            result = resident.chat_report("org/m", "ping", [])
        self.assertEqual(seen["cmd"], "hug")
        self.assertEqual(seen["message"], "ping")
        self.assertNotIn("messages", seen)
        self.assertNotIn("out", seen)
        self.assertEqual(result["text"], "pong")
        self.assertEqual(result["image"], "")

    def test_chat_report_keeps_the_thread(self) -> None:
        seen: dict[str, object] = {}

        def rpc(message: dict[str, object], timeout: float) -> dict[str, object]:
            seen.update(message)
            return {"ok": True, "text": "still here"}

        with patch.object(
            resident, "_known", return_value={"id": "org/m", "tool": "hug", "kind": "text"}
        ), patch.object(resident, "_ensure_started"), patch.object(resident, "_rpc", side_effect=rpc):
            resident.chat_report(
                "org/m",
                "and now",
                [],
                messages=[
                    {"role": "user", "content": "hello"},
                    {"role": "assistant", "content": "hi"},
                ],
            )
        self.assertEqual(
            seen["messages"],
            [
                {"role": "user", "content": "hello"},
                {"role": "assistant", "content": "hi"},
                {"role": "user", "content": "and now"},
            ],
        )
        self.assertEqual(seen["message"], "and now")

    def test_chat_report_keeps_earlier_drawing_requests(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            seen: dict[str, object] = {}

            def rpc(message: dict[str, object], timeout: float) -> dict[str, object]:
                seen.update(message)
                Path(str(message["out"])).write_bytes(b"png")
                return {"ok": True, "text": message["out"]}

            with patch.object(
                resident, "_known", return_value={"id": "org/draw", "tool": "hug", "kind": "generate"}
            ), patch.object(resident, "_ensure_started"), patch.object(
                resident, "_runtime_dir", return_value=Path(tmp)
            ), patch.object(resident, "_rpc", side_effect=rpc):
                resident.chat_report(
                    "org/draw",
                    "make it blue",
                    [],
                    messages=[
                        {"role": "user", "content": "a red cat"},
                        {"role": "assistant", "content": "[image]"},
                    ],
                )
        self.assertEqual(seen["message"], "a red cat\n\nmake it blue")
        self.assertNotIn("messages", seen)

    def test_chat_report_passes_uploaded_files_to_a_vision_model(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "shot.png"
            image.write_bytes(b"png")
            seen: dict[str, object] = {}

            def rpc(message: dict[str, object], timeout: float) -> dict[str, object]:
                seen.update(message)
                return {"ok": True, "text": "a cat"}

            with patch.object(
                resident, "_known", return_value={"id": "org/see", "tool": "hug", "kind": "image"}
            ), patch.object(resident, "_ensure_started"), patch.object(resident, "_rpc", side_effect=rpc):
                result = resident.chat_report("org/see", "what is this", [str(image)])
        self.assertEqual(seen["files"], [str(image)])
        self.assertEqual(result["text"], "a cat")

    def test_chat_report_returns_a_drawn_image(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:

            def rpc(message: dict[str, object], timeout: float) -> dict[str, object]:
                Path(str(message["out"])).write_bytes(b"png")
                return {"ok": True, "text": message["out"]}

            with patch.object(
                resident, "_known", return_value={"id": "org/draw", "tool": "hug", "kind": "generate"}
            ), patch.object(resident, "_ensure_started"), patch.object(
                resident, "_runtime_dir", return_value=Path(tmp)
            ), patch.object(resident, "_rpc", side_effect=rpc):
                result = resident.chat_report("org/draw", "a cat", [])
            self.assertEqual(result["text"], "")
            self.assertTrue(str(result["image"]).endswith(".png"))
            self.assertTrue(Path(str(result["image"])).is_file())

    def test_chat_report_refuses_a_missing_file_and_a_decision_model(self) -> None:
        with patch.object(
            resident, "_known", return_value={"id": "org/see", "tool": "hug", "kind": "image"}
        ):
            with self.assertRaises(RuntimeError):
                resident.chat_report("org/see", "look", ["/no/such/shot.png"])
        with patch.object(
            resident, "_known", return_value={"id": "laya", "tool": "laya", "kind": "decision"}
        ):
            with self.assertRaisesRegex(RuntimeError, "does not take a chat message"):
                resident.chat_report("laya", "hi", [])

    def test_hug_command_passes_the_thread(self) -> None:
        thread = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
            {"role": "user", "content": "and now"},
        ]
        spec = type("Spec", (), {"kind": "text"})()
        with patch.object(resident, "_touch", return_value=True), patch(
            "cg_loop.hug.runtime_spec", return_value=spec
        ), patch("cg_loop.hug._generate_text", return_value="ok") as generate:
            resident._hug_command(
                {"model": "org/m", "message": "and now", "download": False, "messages": thread}
            )
        self.assertEqual(generate.call_args.kwargs["messages"], thread)

    def test_locate_chat_keeps_the_thread(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            image = Path(tmp) / "shot.png"
            image.write_bytes(b"png")
            seen: dict[str, object] = {}

            def rpc(message: dict[str, object], timeout: float) -> dict[str, object]:
                seen.update(message)
                return {"ok": True, "result": {"text": "lower"}}

            with patch.object(
                resident, "_known", return_value={"id": "org/find", "tool": "locate", "kind": "image"}
            ), patch.object(resident, "_ensure_started"), patch.object(resident, "_rpc", side_effect=rpc):
                resident.chat_report(
                    "org/find",
                    "the one below",
                    [str(image)],
                    messages=[
                        {"role": "user", "content": "the button"},
                        {"role": "assistant", "content": "top left"},
                    ],
                )
        self.assertEqual(
            seen["query"],
            "User: the button\n\nAssistant: top left\n\nUser: the one below",
        )

    def test_locate_chat_needs_an_image(self) -> None:
        with patch.object(
            resident, "_known", return_value={"id": "org/find", "tool": "locate", "kind": "image"}
        ):
            with self.assertRaisesRegex(RuntimeError, "needs an image"):
                resident.chat_report("org/find", "the button", [])

    def test_chat_cli_reads_stdin(self) -> None:
        with patch.object(
            resident, "chat_report", return_value={"ok": True, "text": "pong", "image": ""}
        ) as report, patch(
            "cg_loop.app_config.apply_app_env"
        ), patch(
            "sys.stdin.read", return_value=json.dumps({"id": "org/m", "message": "ping", "files": []})
        ), patch("sys.stdout", new=io.StringIO()) as out:
            resident.main(["--chat"])
        report.assert_called_once_with("org/m", "ping", [], messages=[])
        self.assertIn("pong", out.getvalue())

    def test_chat_cli_keeps_the_thread(self) -> None:
        body = {
            "id": "org/m",
            "message": "and now",
            "files": [],
            "messages": [
                {"role": "user", "content": "hello"},
                {"role": "assistant", "content": "hi"},
            ],
        }
        with patch.object(
            resident, "chat_report", return_value={"ok": True, "text": "pong", "image": ""}
        ) as report, patch("cg_loop.app_config.apply_app_env"), patch(
            "sys.stdin.read", return_value=json.dumps(body)
        ), patch("sys.stdout", new=io.StringIO()):
            resident.main(["--chat"])
        report.assert_called_once_with("org/m", "and now", [], messages=body["messages"])


if __name__ == "__main__":
    unittest.main()
