Write a short spoken social-video story from this article.

Requirements:
- 180-260 words, 7-9 short scenes in markdown
- Sound like a person talking. Contractions. No AI vocabulary.
- Credit the website / lab / journal out loud when they are in the source.
- A first-time viewer should understand the main elements: who or what was involved, what changed or was compared, and what happened.
- If this is a study, trial, or experiment, name each group (what they did, ate, took, or received), what was measured or tested, and the result for each group when the source gives it.
- Do not invent numbers, quotes, groups, or outcomes.
- Do not mention Yuba, HeartKase, or any app.

Article:
{article}
