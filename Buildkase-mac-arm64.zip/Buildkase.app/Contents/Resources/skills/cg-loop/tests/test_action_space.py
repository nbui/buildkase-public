#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.model import action_space  # noqa: E402
from cg_loop.terminal import expand_command  # noqa: E402
from cg_loop.workflow import parse_step  # noqa: E402


class ActionSpaceTests(unittest.TestCase):
    def test_indexed_click_and_fill(self) -> None:
        page = {
            "url": "https://example.com",
            "html": "",
            "actions": [
                {"id": "e1", "kind": "click", "node": 10, "role": "link", "label": "Latest story", "href": "/a"},
                {"id": "e2", "kind": "fill", "node": 11, "role": "textbox", "label": "Search", "value": ""},
                {"id": "scroll_down", "kind": "scroll", "label": "Scroll down", "delta": 560},
                {"id": "wait", "kind": "wait", "label": "Wait"},
            ],
        }
        elements, targets, controls = action_space(page, parse_step("click the story"), {})
        self.assertEqual(elements[0]["index"], "1")
        self.assertIn("CLICK", elements[0]["operations"])
        self.assertIn("CLICK", targets)
        self.assertIn("TYPE_TEXT", targets)
        self.assertIn("WAIT", controls)
        self.assertIn("DONE", controls)
        self.assertIn("TERM", targets)

    def test_offscreen_radio_stays_offered_with_view(self) -> None:
        from unittest.mock import patch

        from cg_loop.model import ask_jev_browser, choose_request

        radio = 'role=radio[name="No, it\'s not made for kids"s]'
        page = {
            "url": "https://studio.youtube.com/",
            "title": "Upload",
            "text": "Details",
            "html": "",
            "actions": [
                {"id": "e1", "kind": "click", "node": 1, "role": "button", "label": "Next", "view": "shown"},
                {
                    "id": "e2",
                    "kind": "click",
                    "node": 2,
                    "role": "radio",
                    "label": "No, it's not made for kids",
                    "view": "offscreen",
                },
            ],
        }
        step = parse_step("/browser Click No, it's not made for kids")
        request = choose_request(page, step, [], {}, selectors=True)
        self.assertEqual(request["targets"]["CLICK"][radio]["view"], "offscreen")
        self.assertEqual(request["elements"][1]["view"], "offscreen")

        def post(body: dict) -> dict:
            criteria = body["questions"]["click_target"]["criteria"]
            self.assertEqual(criteria[radio]["view"], "offscreen")
            self.assertEqual(criteria[radio]["priority"], "likely")
            rules = " ".join(body["questions"]["click_target"]["instructions"]["rules"])
            self.assertIn("prefer view shown", rules.lower())
            self.assertEqual(body["questions"]["locator"]["criteria"][radio]["view"], "offscreen")
            operations = body["questions"]["operation"]["criteria"]
            locators = body["questions"]["locator"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "CLICK",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "CLICK" else 0) for key in operations},
                    },
                    "click_target": {
                        "choice": radio,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == radio else 0) for key in criteria},
                    },
                    "locator": {
                        "choice": radio,
                        "confidence": 1,
                        "probabilities": {key: (1 if key == radio else 0) for key in locators},
                    },
                    "next_operation": {
                        "choice": "NONE",
                        "confidence": 1,
                        "probabilities": {key: (1 if key == "NONE" else 0) for key in following},
                    },
                },
            }

        with patch("cg_loop.model._jev_post", post):
            answer = ask_jev_browser(request, goal=step.raw)
        self.assertEqual(answer["selector"], radio)

    def test_repeated_type_is_one_action(self) -> None:
        from unittest.mock import patch

        from cg_loop.model import ask_jev_browser, choose_request

        description = 'role=combobox[name="Description"s]'
        page = {
            "url": "https://www.tiktok.com/tiktokstudio/upload",
            "title": "TikTok Studio",
            "text": "Description\n",
            "html": "",
            "actions": [
                {"id": "e15", "kind": "fill", "node": 24, "role": "combobox", "label": "Description"},
            ],
        }
        step = parse_step("/browser Type the post description into the Description box.")
        request = choose_request(page, step, [], {}, selectors=True)

        def post(body: dict) -> dict:
            operations = body["questions"]["operation"]["criteria"]
            following = body["questions"]["next_operation"]["criteria"]
            targets = body["questions"]["type_text_target"]["criteria"]
            locators = body["questions"]["locator"]["criteria"]
            return {
                "model": "jev-latest",
                "answers": {
                    "operation": {
                        "choice": "TYPE_TEXT",
                        "confidence": 0.91,
                        "probabilities": {key: (1 if key == "TYPE_TEXT" else 0) for key in operations},
                    },
                    "type_text_target": {
                        "choice": description,
                        "confidence": 0.91,
                        "probabilities": {key: (1 if key == description else 0) for key in targets},
                    },
                    "locator": {
                        "choice": description,
                        "confidence": 0.91,
                        "probabilities": {key: (1 if key == description else 0) for key in locators},
                    },
                    "next_operation": {
                        "choice": "TYPE_TEXT",
                        "confidence": 0.66,
                        "probabilities": {key: (1 if key == "TYPE_TEXT" else 0) for key in following},
                    },
                },
            }

        with patch("cg_loop.model._jev_post", post):
            answer = ask_jev_browser(request, goal=step.raw)
        self.assertEqual([item["operation"] for item in answer["actions"]], ["TYPE_TEXT"])
        self.assertEqual(answer["actions"][0]["selector"], description)

    def test_browser_targets_are_selectors(self) -> None:
        from cg_loop.model import ChatError, choose_request, decision_from_answer

        page = {
            "url": "https://studio.youtube.com/upload",
            "html": "",
            "actions": [
                {"id": "next-a", "kind": "click", "node": 10, "role": "button", "label": "Next"},
                {"id": "next-b", "kind": "click", "node": 11, "role": "button", "label": "Next"},
                {"id": "video", "kind": "click", "node": 12, "role": "tab", "label": "Video elements"},
                {
                    "id": "playlists",
                    "kind": "select",
                    "node": 13,
                    "role": "combobox",
                    "label": "Playlists → Sleep",
                    "value": "sleep",
                },
            ],
        }
        step = parse_step("/browser Click Next. Wait until Video elements text is showing.")
        request = choose_request(page, step, [], {}, selectors=True)
        targets = request["targets"]["CLICK"]
        self.assertEqual(
            list(targets),
            [
                'role=button[name="Next"s] >> nth=0',
                'role=button[name="Next"s] >> nth=1',
                'role=tab[name="Video elements"s]',
            ],
        )
        self.assertNotIn("index", request["elements"][0])
        payload = json.loads(request["messages"][1]["content"])
        self.assertNotIn("[1]", payload["targets"]["CLICK"]['role=button[name="Next"s] >> nth=0']["element"])
        decision = decision_from_answer(
            {"operation": "CLICK", "selector": 'role=button[name="Next"s] >> nth=0'},
            request,
            started=0,
        )
        self.assertEqual(decision["target"], 'role=button[name="Next"s] >> nth=0')
        self.assertEqual(decision["choice"], "next-a")
        self.assertEqual(
            request["targets"]["SELECT"]['role=combobox[name="Playlists"s] >> option="Sleep"']["value"],
            "sleep",
        )
        with self.assertRaises(ChatError):
            decision_from_answer({"operation": "CLICK", "click_target": "1"}, request, started=0)

    def test_browser_tool_hides_shell(self) -> None:
        page = {
            "url": "https://studio.youtube.com/videos",
            "html": "",
            "actions": [
                {"id": "e1", "kind": "click", "node": 1, "role": "link", "label": "Shorts", "href": "/shorts"},
            ],
        }
        step = parse_step("/browser verify there is > 1 post with views")
        _elements, targets, controls = action_space(page, step, {})
        self.assertNotIn("TERM", targets)
        self.assertIn("CLICK", targets)
        self.assertIn("DONE", controls)
        for name in ("RELOAD", "BACK", "FORWARD", "PRESS", "SCROLL_DOWN", "SCROLL_UP"):
            self.assertIn(name, controls)
        self.assertNotIn("GOTO", controls)
        _elements, _targets, go_controls = action_space(
            page, parse_step("/browser go to studio.youtube.com"), {}
        )
        self.assertIn("GOTO", go_controls)
        plain = parse_step("verify there is > 1 post with views")
        _elements, plain_targets, _controls = action_space(page, plain, {})
        self.assertIn("TERM", plain_targets)

    def test_term_and_extract_heads(self) -> None:
        rss = """<rss><channel><item><title>A</title><link>https://x.test/a</link></item></channel></rss>"""
        page = {"url": "https://x.test/rss.xml", "html": rss, "actions": []}
        _elements, targets, controls = action_space(
            page,
            parse_step("get latest article to $article"),
            {},
        )
        self.assertIn("EXTRACT", targets)
        self.assertEqual(targets["EXTRACT"]["1"]["article"]["title"], "A")
        self.assertIn("EXTRACT", controls)

        skipped = "https://x.test/a"
        _elements, targets, _controls = action_space(
            page,
            parse_step("get first url not in $seen to $url"),
            {"seen": [skipped]},
        )
        self.assertNotIn("EXTRACT", targets)

        _elements, targets, controls = action_space(
            {"actions": []},
            parse_step("term $SLIDES_SCRIPT features/slides.feature --tags @meme_yuba"),
            {},
        )
        self.assertIn("TERM", targets)
        self.assertIn("SLIDES_SCRIPT", targets["TERM"]["1"]["command"])

    def test_expand_command_uses_env_and_article(self) -> None:
        expanded = expand_command(
            "$SLIDES_SCRIPT features/slides.feature --tags @meme_yuba",
            {"SLIDES_SCRIPT": "/tmp/run.sh"},
            {"article": {"title": "Hello", "url": "https://x.test/a"}},
        )
        self.assertEqual(expanded, "/tmp/run.sh features/slides.feature --tags @meme_yuba")
        url = expand_command("echo $article", {}, {"article": {"url": "https://x.test/a"}})
        self.assertEqual(url, "echo https://x.test/a")

    def test_shell_uses_skill_venv_for_script(self) -> None:
        import os
        import tempfile

        from cg_loop.terminal import apply_venv

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            bin_dir = root / "cg-post-from-folder" / "venv" / "bin"
            bin_dir.mkdir(parents=True)
            (bin_dir / "python3").write_text("#!/bin/sh\n", encoding="utf-8")
            script = root / "cg-post-from-folder" / "scripts" / "all_posts_pull_stats.py"
            script.parent.mkdir()
            script.write_text("#!/usr/bin/env python3\nprint('ok')\n", encoding="utf-8")
            other = root / "other" / "venv" / "bin"
            other.mkdir(parents=True)
            (other / "python3").write_text("#!/bin/sh\n", encoding="utf-8")
            env = apply_venv(
                f"{script} /tmp/all_posts.yaml",
                {"POST_PYTHON": str(other / "python3"), "PATH": "/usr/bin"},
            )
            self.assertTrue(env["PATH"].startswith(str(bin_dir) + os.pathsep))
            self.assertEqual(env["VIRTUAL_ENV"], str(bin_dir.parent))
            self.assertIn(str(other), env["PATH"])
            untouched = apply_venv("echo hello", {"PATH": "/usr/bin"})
            self.assertEqual(untouched["PATH"], "/usr/bin")
            self.assertNotIn("VIRTUAL_ENV", untouched)
            inline = apply_venv(
                f"{bin_dir / 'python3'} -c 'import yaml, json\n" + ("print(1)\n" * 40) + "'",
                {"PATH": "/usr/bin"},
                cwd=str(root),
            )
            self.assertTrue(inline["PATH"].startswith(str(bin_dir) + os.pathsep))
            long_token = apply_venv(f"echo {'a' * 400}", {"PATH": "/usr/bin"}, cwd=str(root))
            self.assertEqual(long_token["PATH"], "/usr/bin")


if __name__ == "__main__":
    unittest.main()
