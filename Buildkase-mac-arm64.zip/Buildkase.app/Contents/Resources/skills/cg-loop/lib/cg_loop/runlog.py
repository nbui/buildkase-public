"""Per-run step logs next to the workflow YAML."""

from __future__ import annotations

import json
import re
import shutil
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

from .step_cache import (
    ephemeral_name,
    step_packet_dir,
    step_slug,
    workflow_cache_dir,
    workflow_data_dir,
    workflow_log_dir,
    write_stage_context,
)
from .workflow import Step, Workflow, parse_step


class RunLog:
    def __init__(self, workflow: Workflow, *, stamp: str, fallback: Path):
        if workflow.path:
            base = workflow_log_dir(workflow, env=workflow.env)
            base.mkdir(parents=True, exist_ok=True)
            data_dir = workflow_data_dir(workflow, env=workflow.env)
            archived = archive_current_log(base, fallback_stamp=stamp, data_dir=data_dir)
            removed = prune_run_logs(base / "archived", keep=workflow.log_keep)
            self.directory = base
            self.cache_dir = workflow_cache_dir(workflow, env=workflow.env)
            self.data_dir = data_dir
            if archived:
                shown = quote(str(archived.resolve()), safe="/")
                print(f"archived log → file://{shown}")
            if removed:
                print(f"pruned {len(removed)} old log(s); keeping {workflow.log_keep}")
        else:
            self.directory = fallback
            self.cache_dir = None
            self.data_dir = fallback / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / "c-run.log"
        self.steps_dir = self.directory
        self.workflow = workflow
        self._seq = 0
        self._stack: list[dict[str, Any]] = []
        self._header_written = False
        self.compiles: list[Any] = []
        self.ok = 0
        self.blocked = 0
        self.error = 0
        self.step_ms = 0
        self.failed_rerun = 0
        self.workflow_name = workflow.name
        self.workflow_path = str(workflow.path or "")
        self.pending_title: tuple[str, str] | None = None

    def begin(
        self,
        *,
        index: int,
        group: str,
        step: Step,
        script: Path | None,
        inputs: dict[str, Any],
    ) -> None:
        self.directory.mkdir(parents=True, exist_ok=True)
        self.steps_dir.mkdir(parents=True, exist_ok=True)
        self._seq += 1
        self._stack.append(
            {
                "seq": self._seq,
                "index": index + 1,
                "group": group,
                "step": step.raw,
                "kind": step.kind,
                "script": str(script or ""),
                "inputs": inputs,
                "started": time.perf_counter(),
                "title": self.pending_title,
            }
        )
        self.pending_title = None
        lines = []
        if not self._header_written:
            self._header_written = True
            lines.extend(
                [
                    f"# {self.workflow_name}",
                    f"# workflow: {self.workflow_path or '-'}",
                    f"# started: {datetime.now().isoformat(timespec='seconds')}",
                    f"# cache: {self.cache_dir or '-'}",
                    f"# data: {self.data_dir}",
                    f"# log: {self.path}",
                    f"# compile: {self.directory / 'c-compile.log'}",
                    "",
                ]
            )
        label = f"[{group}] " if group else ""
        lines.append(f"## {self._seq} {label}{index + 1}. {step.raw}")
        lines.append(f"kind: {step.kind}")
        if script:
            lines.append(f"script: {script}")
        lines.append("inputs:")
        lines.extend(_format_block(_shrink(inputs)))
        self._append(lines)

    def note_command(self, command: str) -> None:
        """Record the bash line for the step that just began."""
        if self._stack:
            inputs = self._stack[-1].get("inputs")
            if isinstance(inputs, dict):
                inputs["command"] = command
        self._append([f"command: {command}", ""])

    def finish(self, *, status: str, outputs: dict[str, Any]) -> None:
        current = self._stack.pop() if self._stack else {}
        started = current.get("started")
        elapsed = round((time.perf_counter() - started) * 1000) if isinstance(started, (int, float)) else 0
        self.step_ms += elapsed
        if status == "ok":
            self.ok += 1
        elif status == "blocked":
            self.blocked += 1
        else:
            self.error += 1
        recorded = dict(outputs)
        images = _image_paths(str(current.get("script") or ""), recorded)
        if images:
            recorded["image"] = images[0] if len(images) == 1 else images
        shrunk = _shrink(recorded)
        lines = ["outputs:", *_format_block(shrunk), f"status: {status}", f"time: {format_duration(elapsed)}", ""]
        self._append(lines)
        payload = {
            "seq": current.get("seq"),
            "index": current.get("index"),
            "group": current.get("group") or "",
            "step": current.get("step") or "",
            "kind": current.get("kind") or "",
            "script": current.get("script") or "",
            "status": status,
            "time_ms": elapsed,
            "inputs": _shrink(current.get("inputs") or {}),
            "outputs": shrunk,
        }
        seq = int(current.get("seq") or 0)
        raw = str(current.get("step") or "")
        logged = parse_step(raw) if raw else None
        folder = self._step_folder(logged)
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"c-{seq:02d}-context.json"
        path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
        step_lines = [
            f"# {raw}",
            f"kind: {current.get('kind') or ''}",
            f"status: {status}",
            f"time: {format_duration(elapsed)}",
            "inputs:",
            *_format_block(_shrink(current.get("inputs") or {})),
            "outputs:",
            *_format_block(shrunk),
            "",
        ]
        if folder.resolve() != self.directory.resolve():
            with (folder / "c-run.log").open("a", encoding="utf-8") as handle:
                handle.write("\n".join(step_lines) + "\n")
        prompt = prompt_markdown(str(current.get("step") or ""), outputs)
        if prompt:
            prompt_path = folder / "a-run.prompt.md"
            prompt_path.write_text(prompt, encoding="utf-8")
            self._append([f"prompt md {prompt_path.name}  {prompt_path}"])
        title = current.get("title")
        if isinstance(title, tuple) and len(title) == 2:
            prefix, body = title
            print(f"\n\n{prefix} [{format_step_time(elapsed)}]: {body}", flush=True)
        shown = _printed_reply(current.get("inputs") or {}, outputs)
        if shown:
            print(shown, flush=True)
        print(f"file://{quote(str(folder.resolve()), safe='/')}", flush=True)

    def upcoming_step_json(self, group: str, step: Step | None = None) -> Path:
        """Path `begin` will write for the next step in this group."""
        del group
        folder = self._step_folder(step)
        return folder / f"c-{self._seq + 1:02d}-context.json"

    def _step_folder(self, step: Step | None) -> Path:
        if step is None or not self.workflow.path:
            return self.directory
        return step_packet_dir(self.workflow, step, env=self.workflow.env)

    def note_compile(self, result: Any, *, step_json: Path | str | None = None) -> None:
        self.compiles.append(result)
        if result.status == "compiled":
            log_compile(f"COMPILE {result.path}", step_json)
        elif result.status == "recompiled":
            log_compile(f"RECOMPILE {result.path}", step_json)
        elif result.status == "failed":
            log_compile(f"RECOMPILE failed {result.path}: {result.error}", step_json)

    def write_summary(self, *, total_ms: float, llm_ms: float) -> None:
        counts = {"compiled": 0, "reused": 0, "recompiled": 0, "failed": 0}
        compile_ms = 0
        failures: list[str] = []
        for item in self.compiles:
            compile_ms += int(getattr(item, "elapsed_ms", 0) or 0)
            status = str(getattr(item, "status", ""))
            if status in counts:
                counts[status] += 1
            if status == "failed":
                path = getattr(item, "path", "")
                name = path.name if isinstance(path, Path) else str(path)
                failures.append(f"{name}: {getattr(item, 'error', '')}")
        failed = counts["failed"] + self.failed_rerun
        lines = [
            "summary",
            f"  total: {format_duration(total_ms)}",
            f"  compile: {format_duration(compile_ms)}",
            f"  llm: {format_duration(llm_ms)}",
            f"  steps: {format_duration(self.step_ms)}",
            f"  ok: {self.ok}  blocked: {self.blocked}  error: {self.error}",
            (
                f"  compiled: {counts['compiled']}  reused: {counts['reused']}  "
                f"recompiled: {counts['recompiled']}  failed recompile: {failed}"
            ),
        ]
        lines.extend(f"  failed: {item}" for item in failures)
        print()
        print("\n".join(lines))
        self._append([""] + lines + [""])

    def _append(self, lines: list[str]) -> None:
        self.directory.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write("\n".join(lines) + "\n")


def note_compile_attempt(
    workflow: Workflow,
    step: Step,
    *,
    index: int,
    mode: str,
    status: str,
    path: Path | None,
    elapsed_ms: int,
    messages: list[dict[str, str]] | None = None,
    options: dict[str, Any] | None = None,
    thinking: str = "",
    model_result: str = "",
    result: str = "",
    error: str = "",
    model_name: str = "",
    reason: str = "",
    message_fields: str = "",
    llm_ms: int = 0,
    prompt_path: str = "",
    helper: str = "",
) -> None:
    """Append one compile attempt to `<workflow>/c-compile.log` and the step's `c-compile.log`.

    `mode` is reuse, direct, model, model-fallback, or skip. Model attempts
    include the request, the thinking, the raw reply, and the script written.
    `prompt_path` is the prompt that generated the Python. `helper` is the
    cg-loop helper when no prompt wrote the script.
    """
    if not workflow.path:
        return
    directory = workflow_log_dir(workflow, env=workflow.env)
    directory.mkdir(parents=True, exist_ok=True)
    step_dir = step_packet_dir(workflow, step, env=workflow.env)
    step_dir.mkdir(parents=True, exist_ok=True)
    write_stage_context(step_dir, step)
    targets = [directory / "c-compile.log", step_dir / "c-compile.log"]
    group = workflow.group or ""
    label = f"[{group}] " if group else ""
    body: list[str] = []
    body.append(f"kind: {step.kind}")
    body.append(f"mode: {mode}")
    body.append(f"status: {status}")
    if path:
        body.append(f"script: {path}")
    if model_name:
        body.append(f"model: {model_name}")
    if message_fields:
        body.append(f"message fields: {message_fields}")
    if reason:
        body.append(f"reason: {reason}")
    if prompt_path:
        body.append(f"prompt: {prompt_path}")
    if helper:
        body.append(f"helper: {helper}")
    if mode in {"model", "model-fallback"} and path is not None:
        from .browser_helper import artifact_dir
        from .model import api_request_files

        names = [item.name for item in api_request_files(artifact_dir(path))]
        if names:
            body.append("request: " + ", ".join(names))
    body.append(f"time: {format_duration(elapsed_ms)}")
    if llm_ms:
        body.append(f"llm time: {format_duration(llm_ms)}")
    body.append("")
    if mode in {"model", "model-fallback"}:
        sent = _format_messages(messages, options)
    elif mode == "direct":
        sent = "(not sent — step already names a tool call)"
    elif mode == "reuse":
        sent = "(not sent — existing script still valid)"
    else:
        sent = "(not sent — this step is not compiled)"
    body.extend(_section("sent", sent))
    body.append("")
    body.extend(_section("thinking", thinking or "(none)"))
    body.append("")
    if mode in {"model", "model-fallback"}:
        body.extend(_section("model result", model_result or "(empty)"))
        body.append("")
    body.extend(_section("result", result or "(empty)"))
    if error:
        body.append("")
        body.extend(_section("error", error))
    body.append("")
    for log_path in targets:
        seq = _compile_seq(log_path)
        lines: list[str] = []
        if seq == 1:
            lines.extend(
                [
                    f"# {workflow.name}",
                    f"# workflow: {workflow.path}",
                    f"# started: {datetime.now().isoformat(timespec='seconds')}",
                    f"# compile: {log_path}",
                    "",
                ]
            )
        lines.append(f"## {seq} {label}{index + 1}. {step.raw}")
        lines.extend(body)
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write("\n".join(lines) + "\n")


def _compile_seq(path: Path) -> int:
    if not path.is_file():
        return 1
    count = sum(1 for line in path.read_text(encoding="utf-8").splitlines() if line.startswith("## "))
    return count + 1


def prompt_markdown(step: str, outputs: dict[str, Any]) -> str:
    """The step's model prompt, as markdown you can paste into another model.

    The system section is the system message. The user section is the user message.
    JSON user content is pretty-printed and still valid JSON.
    """
    calls = _prompt_calls(outputs)
    if not calls:
        return ""
    lines = [f"# {step}".rstrip(), ""]
    for index, call in enumerate(calls, 1):
        messages = _prompt_messages(call)
        if not messages:
            continue
        purpose = str(call.get("purpose") or "").strip()
        if len(calls) > 1:
            title = f"{index}. {purpose}" if purpose else str(index)
            lines.extend([f"# {title}", ""])
        for message in messages:
            role = str(message.get("role") or "message")
            lines.extend([f"## {role}", "", _prompt_content(message.get("content")), ""])
    body = "\n".join(lines).rstrip()
    if "## " not in body:
        return ""
    return body + "\n"


_PROMPT_ROLE_RE = re.compile(r"(?m)^## (system|user|assistant)\s*$")


def messages_from_prompt(text: str) -> list[dict[str, str]]:
    """Copy each role section of prompt markdown back into a message."""
    marks = list(_PROMPT_ROLE_RE.finditer(text or ""))
    messages: list[dict[str, str]] = []
    for index, mark in enumerate(marks):
        start = mark.end()
        end = marks[index + 1].start() if index + 1 < len(marks) else len(text)
        content = text[start:end].strip()
        if content:
            messages.append({"role": mark.group(1), "content": content})
    return messages


def _prompt_calls(outputs: dict[str, Any]) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    many = outputs.get("llm_calls")
    if isinstance(many, list):
        found.extend(item for item in many if isinstance(item, dict))
    one = outputs.get("llm_call")
    if isinstance(one, dict) and one not in found:
        found.append(one)
    return found


def _prompt_messages(call: dict[str, Any]) -> list[dict[str, Any]]:
    messages = call.get("messages")
    if isinstance(messages, dict):
        messages = messages.get("sample")
    if not isinstance(messages, list):
        return []
    return [item for item in messages if isinstance(item, dict) and item.get("content") not in (None, "")]


def _prompt_content(content: Any) -> str:
    if isinstance(content, str):
        return _pretty_json(content).rstrip()
    return json.dumps(content, indent=2, ensure_ascii=False, default=str).rstrip()


def _format_messages(messages: list[dict[str, str]] | None, options: dict[str, Any] | None) -> str:
    lines: list[str] = []
    for key, value in (options or {}).items():
        lines.append(f"{key}: {_scalar(value)}")
    if lines:
        lines.append("")
    for message in messages or []:
        role = str(message.get("role") or "message")
        content = str(message.get("content") or "")
        if role == "user":
            content = _pretty_json(content)
        lines.append(f"--- {role} ---")
        lines.extend(content.splitlines() or [""])
        lines.append("")
    return "\n".join(lines).rstrip() or "(none)"


def _pretty_json(content: str) -> str:
    try:
        payload = json.loads(content)
    except json.JSONDecodeError:
        return content
    return json.dumps(payload, indent=2, ensure_ascii=False, default=str)


def _section(title: str, text: str) -> list[str]:
    body = _cap(text if str(text).strip() else "(none)")
    return [f"{title}:", *(f"  {line}" for line in body.splitlines() or [""])]


def _cap(text: str, limit: int = 80000) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "\n… truncated"


def _image_paths(script: str, outputs: dict[str, Any]) -> list[str]:
    """Absolute paths of screenshots saved for this compiled step."""
    from .browser_helper import artifact_dir, compiled_json_path, resolve_screenshot

    names: list[str] = []
    raw = outputs.get("screenshots") or []
    if isinstance(raw, str):
        raw = [raw]
    if isinstance(raw, list):
        names.extend(str(item) for item in raw if item)
    path = Path(script) if script else None
    # A run already saved its own shots. Compile shots stay with the compiled step.
    if path is not None and path.suffix == ".py" and not names:
        sibling = compiled_json_path(path)
        if sibling.is_file():
            try:
                saved = json.loads(sibling.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                saved = {}
            if isinstance(saved, dict):
                for name in saved.get("screenshots") or []:
                    text = str(name or "")
                    if text and text not in names:
                        names.append(text)
        if not names:
            folder = artifact_dir(path)
            if folder.is_dir():
                names.extend(item.name for item in sorted(folder.glob("*.jpg")))
            names.extend(item.name for item in sorted(path.parent.glob(f"{path.stem}-*.jpg")))
    resolved: list[str] = []
    for name in names:
        image = Path(name)
        if not image.is_absolute() and path is not None:
            image = resolve_screenshot(path, name)
        text = str(image)
        if text not in resolved:
            resolved.append(text)
    return resolved


def compile_notice(line: str, step_json: Path | str | None = None) -> str:
    """Compile line plus the step JSON that run will write."""
    if not step_json:
        return line
    return f"{line}\nstep json {step_json}"


def log_compile(line: str, step_json: Path | str | None = None, *, folder: Path | None = None) -> None:
    """Record a compile file path in the run log. The panel does not show it."""
    from .trace import bound, detail

    notice = compile_notice(line, step_json)
    if bound():
        detail(notice)
        return
    target = _unbound_compile_log(step_json, folder)
    if target is None:
        return
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a", encoding="utf-8") as handle:
            handle.write(notice.rstrip("\n") + "\n")
    except OSError:
        return


def _unbound_compile_log(step_json: Path | str | None, folder: Path | None) -> Path | None:
    if step_json:
        return Path(step_json).parent / "c-run.log"
    if folder is not None:
        return folder / "c-run.log"
    return None


def log_step_stem(seq: int, step: Step | None = None) -> str:
    """`05_type_the_post_description` so a run step is not only a number."""
    number = f"{seq:02d}"
    if step is None:
        return number
    slug = step_slug(step)
    if not slug:
        return number
    return f"{number}_{slug}"[:140]


def archive_current_log(base: Path, *, fallback_stamp: str, data_dir: Path | None = None) -> Path | None:
    """Copy the workflow folder into archived/<stamp>/, then drop logs and data.

    Prompts, config, compile context, and b-compile stay in place for the next run.
    """
    if not base.is_dir() or not _has_ephemeral(base):
        return None
    stamp = _stamp_from_log(base / "c-run.log") or _stamp_from_log(base / "run.log") or fallback_stamp
    dest = _unique_dir(base / "archived" / stamp)
    dest.mkdir(parents=True)
    _copy_live(base, dest)
    if data_dir is not None:
        resolved = data_dir.resolve()
        inside = resolved == base.resolve() or base.resolve() in resolved.parents
        if not inside and resolved.is_dir():
            target = dest / "z-data"
            if not target.exists():
                shutil.copytree(resolved, target)
            shutil.rmtree(resolved)
    _strip_ephemeral(base)
    return dest


def _copy_live(src: Path, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    for entry in src.iterdir():
        if entry.name in {"archived", "archive"}:
            continue
        target = dest / entry.name
        if entry.is_dir():
            shutil.copytree(entry, target, dirs_exist_ok=True)
        elif entry.is_file():
            shutil.copy2(entry, target)


def _has_ephemeral(base: Path) -> bool:
    for path in _live_files(base):
        if path.is_file() and ephemeral_name(path.name):
            return True
        if path.is_dir() and path.name == "z-data" and any(path.iterdir()):
            return True
    return False


def _strip_ephemeral(base: Path) -> None:
    """Remove run logs and output files. Leave a- and b- files for reuse."""
    data = base / "z-data"
    if data.is_dir():
        shutil.rmtree(data)
    for path in _live_files(base):
        if path.is_file() and path.exists() and ephemeral_name(path.name):
            path.unlink()
    folders = [
        item
        for item in base.rglob("*")
        if item.is_dir() and item.name not in {"archived", "archive"} and not _in_kept_tree(item)
    ]
    for path in sorted(folders, key=lambda item: len(item.parts), reverse=True):
        if path.is_dir() and not any(path.iterdir()):
            path.rmdir()


def _live_files(base: Path) -> list[Path]:
    found: list[Path] = []
    if not base.is_dir():
        return found
    for entry in base.iterdir():
        if entry.name in {"archived", "archive"}:
            continue
        found.append(entry)
        if entry.is_dir() and entry.name != "z-data":
            found.extend(path for path in entry.rglob("*") if "archived" not in path.parts and "archive" not in path.parts)
    return found


def _in_kept_tree(path: Path) -> bool:
    return "archived" in path.parts or "archive" in path.parts


def format_duration(ms: float) -> str:
    return f"{ms / 1000:.3f}s"


def format_step_time(ms: float) -> str:
    """Whole seconds after one second. Shorter steps stay in milliseconds."""
    if ms > 1000:
        return f"{int(ms / 1000 + 0.5)}s"
    return f"{int(round(ms))}ms"


def _stamp_from_log(path: Path) -> str:
    if not path.is_file():
        return ""
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.startswith("# started: "):
            continue
        raw = line.split(": ", 1)[1].strip()
        date, _, clock = raw.partition("T")
        if not date or not clock:
            return ""
        return date.replace("-", "") + "-" + clock.replace(":", "")
    return ""


def prune_run_logs(base: Path, *, keep: int, current: Path | None = None) -> list[Path]:
    """Delete older run folders so only the newest `keep` remain."""
    keep = max(1, int(keep))
    if not base.is_dir():
        return []
    current_resolved = current.resolve() if current else None
    runs = [path for path in base.iterdir() if path.is_dir()]
    runs.sort(key=lambda path: (path.stat().st_mtime, path.name))
    removed: list[Path] = []
    for path in runs[:-keep]:
        if current_resolved is not None and path.resolve() == current_resolved:
            continue
        shutil.rmtree(path)
        removed.append(path)
    return removed


def _unique_dir(path: Path) -> Path:
    if not path.exists():
        return path
    suffix = 2
    while True:
        candidate = path.parent / f"{path.name}-{suffix}"
        if not candidate.exists():
            return candidate
        suffix += 1


_LOG_TEXT_LIMIT = 2000
_LOG_LIST_LIMIT = 20
_LOG_SAMPLE_COUNT = 2


def _printed_reply(inputs: Any, outputs: Any) -> str:
    """Text shown after the step line: a python `printed` value, or a `+print` reply."""
    if not isinstance(outputs, dict):
        return ""
    printed = outputs.get("printed")
    if isinstance(printed, str) and printed:
        return printed
    if not isinstance(inputs, dict) or not inputs.get("print"):
        return ""
    text = outputs.get("text")
    if not isinstance(text, str):
        return ""
    return text


def _shrink(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _shrink(item) for key, item in value.items()}
    if isinstance(value, list):
        return _shrink_list(value)
    if isinstance(value, str):
        parsed = _json_container(value)
        if parsed is not None:
            return _shrink(parsed)
        if len(value) > _LOG_TEXT_LIMIT:
            return value[:_LOG_TEXT_LIMIT].rstrip() + "…"
    return value


def _shrink_list(value: list[Any]) -> Any:
    shrunk = [_shrink(item) for item in value]
    if len(shrunk) <= _LOG_LIST_LIMIT and _encoded_len(shrunk) <= _LOG_TEXT_LIMIT:
        return shrunk
    if _encoded_len(shrunk) <= _LOG_TEXT_LIMIT:
        shown = shrunk[:_LOG_LIST_LIMIT]
    else:
        shown = shrunk[:_LOG_SAMPLE_COUNT]
    return {"count": len(value), "sample": shown}


def _json_container(value: str) -> Any:
    """A JSON list is expanded in the log. A JSON object stays the original text."""
    stripped = value.strip()
    if not stripped.startswith("["):
        return None
    try:
        parsed = json.loads(stripped)
    except json.JSONDecodeError:
        return None
    if isinstance(parsed, (dict, list)):
        return parsed
    return None


def _encoded_len(value: Any) -> int:
    return len(json.dumps(value, ensure_ascii=False, default=str))


def _format_block(value: Any, indent: int = 2) -> list[str]:
    pad = " " * indent
    if isinstance(value, dict):
        if not value:
            return [f"{pad}{{}}"]
        lines: list[str] = []
        for key, item in value.items():
            if isinstance(item, (dict, list)):
                lines.append(f"{pad}{key}:")
                lines.extend(_format_block(item, indent + 2))
            else:
                lines.append(f"{pad}{key}: {_scalar(item)}")
        return lines
    if isinstance(value, list):
        if not value:
            return [f"{pad}[]"]
        lines = []
        for item in value:
            if isinstance(item, (dict, list)):
                lines.append(f"{pad}-")
                lines.extend(_format_block(item, indent + 2))
            else:
                lines.append(f"{pad}- {_scalar(item)}")
        return lines
    return [f"{pad}{_scalar(value)}"]


def _scalar(value: Any) -> str:
    if value is None:
        return ""
    text = str(value)
    if "\n" not in text:
        return text
    parts = [line.strip() for line in text.splitlines() if line.strip()]
    sample = " ".join(parts[:6])
    if len(sample) > 400:
        sample = sample[:400].rstrip() + " …"
    elif len(parts) > 6:
        sample += " …"
    return sample
