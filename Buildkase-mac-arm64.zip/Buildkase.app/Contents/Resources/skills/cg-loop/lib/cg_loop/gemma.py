"""Read a screenshot through LM Studio or OpenRouter.

`/browser /lmstudio-<model> extract the latest date into $post_date` screenshots
the open page and stores the extracted value in `$post_date`. `$post_date`
prints as that value. The full object stays on the variable. `<model>` is the
id LM Studio has loaded, such as `qwen3.8-27b-mlx` or `gemma-4`.

`/browser /openrouter-<vendor>/<name>` sends that same screenshot to OpenRouter.
`/openrouter-<vendor>/<name> <instruction> into $var` asks for text and stores the reply.
`/lmstudio-<model> <instruction> into $var` asks the local model for text and stores the reply.

The LM Studio address is workflow config `lmstudio`, or `LM_STUDIO_BASE_URL`.
The default is http://127.0.0.1:1234/v1. `CG_LOOP_GEMMA_MODEL` replaces the
model name only for `/lmstudio-gemma-4`.
OpenRouter uses `OPENROUTER_API_KEY` and `https://openrouter.ai/api/v1`.
"""

from __future__ import annotations

import base64
import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

DEFAULT_URL = "http://127.0.0.1:1234/v1"
OPENROUTER_URL = "https://openrouter.ai/api/v1"
MODEL_ID = "gemma-4"
# A local vision reply can sit well past three minutes. The earlier 180s cap cut it off.
REQUEST_TIMEOUT = 600.0
COMMAND = "lmstudio-gemma-4"
LMSTUDIO_PREFIX = "lmstudio-"
OPENROUTER_PREFIX = "openrouter-"
_STAMP = re.compile(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}")
_STAMP_LOOSE = re.compile(
    r"(?P<date>\d{4}-\d{2}-\d{2})[ T](?P<hour>\d{2}):(?P<minute>\d{2})(?::(?P<second>\d{2}))?"
)


def model_id(slug: str, env: dict[str, str] | None = None) -> str:
    """The LM Studio model id for `/lmstudio-<model>`.

    The suffix is sent as written, so `/lmstudio-qwen3.8-27b-mlx` asks for
    `qwen3.8-27b-mlx`. `/lmstudio-gemma-4` still asks for `gemma-4`, and
    `CG_LOOP_GEMMA_MODEL` replaces that name only.
    """
    merged = {**os.environ, **(env or {})}
    text = (slug or "").strip()
    if not text.lower().startswith(LMSTUDIO_PREFIX):
        raise ValueError(f"unknown lmstudio model /{slug}. Use /lmstudio-<model>")
    name = text[len(LMSTUDIO_PREFIX) :].strip()
    if not name or any(char.isspace() for char in name):
        raise ValueError(f"unknown lmstudio model /{slug}. Use /lmstudio-<model>")
    if text.lower() == COMMAND:
        override = (merged.get("CG_LOOP_GEMMA_MODEL") or "").strip()
        if override:
            return override
    return name


def openrouter_model(slug: str) -> str:
    """`openrouter-google/gemma-3-27b-it` becomes `google/gemma-3-27b-it`."""
    text = (slug or "").strip()
    if not text.lower().startswith(OPENROUTER_PREFIX):
        raise ValueError(f"unknown openrouter model /{slug}. Use /openrouter-<vendor>/<name>")
    model = text[len(OPENROUTER_PREFIX) :].strip()
    if "/" not in model or model.startswith("/") or model.endswith("/"):
        raise ValueError(f"openrouter model needs vendor/name: /openrouter-<model>, got /{text}")
    return model


def openrouter_checkpoint(model: str) -> str:
    """`openrouter/cloudflare/clef` is the OpenRouter model `cloudflare/clef`.

    A local Hugging Face id returns empty. The id after the prefix must be
    `vendor/name`.
    """
    text = (model or "").strip()
    prefix = "openrouter/"
    if not text.lower().startswith(prefix):
        return ""
    name = text[len(prefix) :].strip()
    if "/" not in name or name.startswith("/") or name.endswith("/") or any(char.isspace() for char in name):
        raise ValueError("openrouter model needs vendor/name, for example openrouter/cloudflare/clef")
    return name


def openrouter_url(env: dict[str, str] | None = None) -> str:
    """OpenRouter's OpenAI base URL, without a trailing slash."""
    merged = {**os.environ, **(env or {})}
    raw = (merged.get("OPENROUTER_BASE_URL") or OPENROUTER_URL).strip()
    return raw.rstrip("/") or OPENROUTER_URL


def lmstudio_url(env: dict[str, str] | None = None) -> str:
    """LM Studio's OpenAI base URL, without a trailing slash."""
    merged = {**os.environ, **(env or {})}
    raw = (merged.get("LM_STUDIO_BASE_URL") or DEFAULT_URL).strip()
    return raw.rstrip("/") or DEFAULT_URL


def extraction_prompt(instruction: str) -> str:
    """Ask for one JSON object. `value` is the result the instruction names."""
    task = (instruction or "").strip()
    if not task:
        raise ValueError("model extract needs an instruction")
    return (
        "Read the screenshot and follow the instruction. "
        "Reply with one JSON object and no other text.\n"
        f"Instruction: {task}\n"
        'JSON shape: {"value": "", "items": []}\n'
        "value is the single result the instruction asks for. "
        "Use an empty string when the screenshot does not show it. "
        "items lists every candidate, in the order they appear on the page."
    )


def parse_extraction(raw: str) -> dict[str, Any]:
    """Turn model text into the value stored in the workflow variable."""
    text = (raw or "").strip()
    data = _json_object(text)
    items: list[Any] = []
    value = ""
    if isinstance(data, dict):
        if data.get("value") is not None:
            value = str(data["value"]).strip()
        raw_items = data.get("items")
        if isinstance(raw_items, list):
            items = raw_items
    if value:
        value = _normalize_stamp(value) or _month_stamp(value) or value
    else:
        value = (
            _normalize_stamp(text)
            or _first_item_stamp(items)
            or ("" if data is not None else text.strip())
        )
    return {
        "value": value,
        "items": items,
        "data": data if isinstance(data, dict) else {},
        "raw": text,
        "text": value,
    }


def accepts_value(instruction: str, value: str) -> bool:
    """A timestamp instruction must come back as YYYY-MM-DD HH:MM:SS."""
    text = (value or "").strip()
    if not text:
        return False
    upper = (instruction or "").upper()
    if "YYYY-MM-DD" in upper and "HH:MM:SS" in upper:
        return _STAMP.fullmatch(text) is not None
    return True


def extract_image(
    slug: str,
    instruction: str,
    image: str,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Send `image` to LM Studio and return the extracted value."""
    path = Path(image).expanduser()
    if not path.is_file():
        raise FileNotFoundError(f"model image not found: {path}")
    if (slug or "").lower().startswith("local/"):
        model_name = slug.split("/", 1)[1]
        from .hug import ask_hug

        raw = ask_hug(model_name, extraction_prompt(instruction), [str(path)])
        found = parse_extraction(raw)
        found["model"] = model_name
        found["image"] = str(path)
        found["instruction"] = instruction
        found["local"] = model_name
        return found
    if (slug or "").lower().startswith(OPENROUTER_PREFIX):
        checkpoint = openrouter_model(slug)
        base = openrouter_url(env)
        provider = "openrouter"
    else:
        checkpoint = model_id(slug, env)
        base = lmstudio_url(env)
        provider = "lmstudio"
    raw = chat_completion(
        base,
        checkpoint,
        extraction_prompt(instruction),
        path.read_bytes(),
        env=env,
        provider=provider,
    )
    found = parse_extraction(raw)
    found["model"] = checkpoint
    found["image"] = str(path)
    found["instruction"] = instruction
    found[provider] = base
    return found


def complete_lmstudio_text(slug: str, instruction: str, env: dict[str, str] | None = None) -> dict[str, Any]:
    """Ask an LM Studio model for text. No screenshot."""
    task = (instruction or "").strip()
    if not task:
        raise ValueError("lmstudio needs an instruction")
    checkpoint = model_id(slug, env)
    base = lmstudio_url(env)
    raw = chat_completion(base, checkpoint, task, env=env, provider="lmstudio")
    text = raw.strip()
    return {"text": text, "raw": raw, "value": text, "model": checkpoint, "lmstudio": base}


def complete_text(slug: str, instruction: str, env: dict[str, str] | None = None) -> dict[str, Any]:
    """Ask an OpenRouter model for text. No screenshot."""
    task = (instruction or "").strip()
    if not task:
        raise ValueError("openrouter needs an instruction")
    checkpoint = openrouter_model(slug)
    base = openrouter_url(env)
    raw = chat_completion(base, checkpoint, task, env=env, provider="openrouter")
    text = raw.strip()
    return {"text": text, "raw": raw, "value": text, "model": checkpoint, "openrouter": base}


def chat_completion(
    base_url: str,
    model: str,
    prompt: str,
    image: bytes | None = None,
    *,
    env: dict[str, str] | None = None,
    timeout: float = REQUEST_TIMEOUT,
    provider: str = "lmstudio",
) -> str:
    """One chat completion. `image` is JPEG bytes. Omit it for a text call."""
    merged = {**os.environ, **(env or {})}
    key = _api_key(merged, provider)
    content: str | list[dict[str, Any]]
    if image:
        content = [
            {"type": "text", "text": prompt},
            {
                "type": "image_url",
                "image_url": {"url": "data:image/jpeg;base64," + base64.b64encode(image).decode("ascii")},
            },
        ]
    else:
        content = prompt
    payload = {
        "model": model,
        "temperature": 0,
        "messages": [{"role": "user", "content": content}],
    }
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {key}"}
    if provider == "openrouter":
        headers["X-OpenRouter-Title"] = "cg-loop"
    request = urllib.request.Request(
        f"{base_url.rstrip('/')}/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    name = "OpenRouter" if provider == "openrouter" else "LM Studio"
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = json.loads(response.read().decode("utf-8"))
    except TimeoutError as exc:
        raise RuntimeError(f"{name} at {base_url} timed out after {timeout:g}s") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"{name} at {base_url} did not answer: {exc}") from exc
    if not isinstance(body, dict):
        raise RuntimeError("LM Studio returned a non-object")
    return _message_text(body)


def _api_key(env: dict[str, str], provider: str) -> str:
    if provider == "openrouter":
        key = (env.get("OPENROUTER_API_KEY") or "").strip()
        if not key:
            raise RuntimeError("OPENROUTER_API_KEY is not set")
        return key
    return (env.get("LM_STUDIO_API_KEY") or "lm-studio").strip() or "lm-studio"


def _message_text(body: dict[str, Any]) -> str:
    choices = body.get("choices")
    if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
        raise RuntimeError("LM Studio returned no choices")
    message = choices[0].get("message")
    if not isinstance(message, dict):
        raise RuntimeError("LM Studio returned no message")
    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [
            str(part.get("text") or "")
            for part in content
            if isinstance(part, dict) and part.get("type", "text") == "text"
        ]
        return "".join(parts)
    raise RuntimeError("LM Studio returned no text")


_MONTHS = {
    "jan": 1,
    "feb": 2,
    "mar": 3,
    "apr": 4,
    "may": 5,
    "jun": 6,
    "jul": 7,
    "aug": 8,
    "sep": 9,
    "oct": 10,
    "nov": 11,
    "dec": 12,
}
_MONTH_DATE = re.compile(
    r"\b(?P<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+"
    r"(?P<day>\d{1,2}),?\s+(?P<year>\d{4})"
    r"(?:(?:\s+|T)(?P<hour>\d{1,2}):(?P<minute>\d{2})(?::(?P<second>\d{2}))?\s*(?P<ampm>AM|PM)?)?",
    re.IGNORECASE,
)


def _item_date(item: Any) -> str:
    """The date text on one candidate. A row may be a string or a date field."""
    if isinstance(item, str):
        return item.strip()
    if isinstance(item, dict):
        for key in ("date", "value", "text"):
            found = item.get(key)
            if isinstance(found, str) and found.strip():
                return found.strip()
    return ""


def _first_item_stamp(items: list[Any]) -> str:
    """The first candidate that names a date, in page order."""
    for item in items:
        text = _item_date(item)
        stamp = _normalize_stamp(text) or _month_stamp(text)
        if stamp:
            return stamp
    return ""


def _month_stamp(text: str) -> str:
    """`Oct 25, 2026` becomes `2026-10-25 00:00:00`. A missing clock is midnight."""
    match = _MONTH_DATE.search(text or "")
    if not match:
        return ""
    month = _MONTHS[match.group("mon")[:3].lower()]
    day = int(match.group("day"))
    year = int(match.group("year"))
    hour = match.group("hour")
    minute = int(match.group("minute") or "0")
    second = int(match.group("second") or "0")
    if hour is None:
        hour_n = 0
        minute = 0
        second = 0
    else:
        hour_n = int(hour)
        ampm = (match.group("ampm") or "").upper()
        if ampm == "PM" and hour_n < 12:
            hour_n += 12
        elif ampm == "AM" and hour_n == 12:
            hour_n = 0
    try:
        from datetime import datetime

        datetime(year, month, day, hour_n, minute, second)
    except ValueError:
        return ""
    return f"{year:04d}-{month:02d}-{day:02d} {hour_n:02d}:{minute:02d}:{second:02d}"


def _normalize_stamp(text: str) -> str:
    """The latest YYYY-MM-DD HH:MM:SS in `text`. A missing second becomes 00."""
    found: list[str] = []
    for match in _STAMP_LOOSE.finditer(text or ""):
        second = match.group("second") or "00"
        found.append(f"{match.group('date')} {match.group('hour')}:{match.group('minute')}:{second}")
    if not found:
        return ""
    return max(found)


def _json_object(text: str) -> dict[str, Any] | None:
    cleaned = text.strip()
    fence = re.search(r"```(?:json)?\s*([\s\S]*?)```", cleaned, re.IGNORECASE)
    if fence:
        cleaned = fence.group(1).strip()
    start = cleaned.find("{")
    if start < 0:
        return None
    depth = 0
    for index, char in enumerate(cleaned[start:], start):
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                try:
                    payload = json.loads(cleaned[start : index + 1])
                except json.JSONDecodeError:
                    return None
                return payload if isinstance(payload, dict) else None
    return None
