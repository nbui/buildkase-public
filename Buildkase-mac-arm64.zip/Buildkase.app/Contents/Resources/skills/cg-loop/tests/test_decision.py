"""Local tool decision and the workflows-app.yaml config."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import sys

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.app_config import apply_app_env, app_env, load_app_config, reset_app_config, workflows_root  # noqa: E402
from cg_loop.decision import ask_decision_model, decide_message, match_tool, skips_script  # noqa: E402
from cg_loop.workflow import parse_step, project_root, workflow_bash_command  # noqa: E402
from cg_loop.workflow import Workflow  # noqa: E402


class DecisionTests(unittest.TestCase):
    def tearDown(self) -> None:
        reset_app_config()

    def test_app_config_names_the_workflows_folder_and_the_python_provider(self) -> None:
        config = load_app_config(force=True)
        self.assertIsNotNone(config.workflows)
        assert config.workflows is not None
        self.assertTrue(config.workflows.is_dir())
        self.assertEqual(config.decision_model, "python-default")
        self.assertIsNotNone(config.venv)
        assert config.venv is not None
        self.assertTrue((config.venv / "bin" / "python").is_file())
        self.assertIn("browser", config.tools)
        self.assertIn("python", config.tools)
        self.assertIn("lmstudio", config.tools)
        for name in ("load", "goto", "generate", "llm-call"):
            self.assertNotIn(name, config.tools)
        browser = config.tools["browser"]
        goto = next(action for action in browser.actions if action.name == "goto")
        self.assertEqual(goto.inputs, ("url",))
        self.assertEqual(goto.outputs, ("page",))
        python = config.tools["python"]
        self.assertIn("load", {action.name for action in python.actions})
        self.assertIn("generate", {action.name for action in python.actions})
        click = next(action for action in browser.actions if action.name == "click")
        self.assertEqual(click.inputs, ("target",))
        self.assertEqual(config.python_llm, "local")
        self.assertEqual(config.python_model, "prism-ml/Ternary-Bonsai-8B-mlx-2bit")
        self.assertEqual(config.python_timeout, 180.0)
        self.assertIsNone(config.python_fallbacks)
        self.assertEqual(config.browser_llm, "local")
        self.assertEqual(config.browser_model, config.python_model)
        self.assertEqual(config.browser_timeout, 180.0)
        self.assertIsNone(config.browser_fallbacks)
        self.assertEqual(config.tools["locate"].model, "andai-labs/LocateAnything-3B-MLX")
        self.assertEqual(config.tools["clef"].model, "mlx-community/clef-flash-4bit")
        self.assertNotIn("model", {action.name for action in config.tools["locate"].actions})
        self.assertNotIn("model", {action.name for action in config.tools["clef"].actions})
        from cg_loop import model

        model.configure("local", "test-model", timeout=12)
        try:
            with model.using_python_provider():
                self.assertEqual(model.PROVIDER, "local")
                self.assertEqual(model._CHAT, "model")
                self.assertEqual(model.MODEL, config.python_model)
                self.assertEqual(model.LLM_TIMEOUT, 180.0)
            self.assertEqual(model.PROVIDER, "local")
            self.assertEqual(model._CHAT, "lmstudio")
            self.assertEqual(model.MODEL, "test-model")
            self.assertEqual(model.LLM_TIMEOUT, 12.0)
            with model.using_browser_provider():
                self.assertEqual(model.PROVIDER, "local")
                self.assertEqual(model._CHAT, "model")
                self.assertEqual(model.MODEL, config.browser_model)
                self.assertEqual(model.LLM_TIMEOUT, 180.0)
                self.assertEqual(model._PRIMARY[2], config.browser_model)
            self.assertEqual(model.PROVIDER, "local")
            self.assertEqual(model.MODEL, "test-model")
            self.assertEqual(model.LLM_TIMEOUT, 12.0)
        finally:
            model.configure("local", "qwen3.8-27b-mlx")
        self.assertEqual(workflows_root(), config.workflows)
        assert config.cg_loop is not None
        self.assertTrue(config.cg_loop.is_file())
        self.assertEqual(config.cg_loop.name, "bkase")
        assert config.env_file is not None
        self.assertTrue(config.env_file.name == ".env")

    def test_compile_fallbacks_override_only_when_the_section_lists_them(self) -> None:
        import os

        from cg_loop import model
        from cg_loop.workflow import parse_step

        with tempfile.TemporaryDirectory() as tmp:
            app = Path(tmp) / "workflows-app.yaml"
            app.write_text(
                "python:\n"
                "  llm: openrouter\n"
                "  model: python-model\n"
                "  llm-timeout: 15\n"
                "browser:\n"
                "  llm: openrouter\n"
                "  model: browser-model\n"
                "  llm-timeout: 45\n"
                "  fallbacks:\n"
                "    - llm: openrouter\n"
                "      model: backup-model\n"
                "      timeout: 20\n",
                encoding="utf-8",
            )
            previous_app = os.environ.get("CG_LOOP_APP")
            os.environ["CG_LOOP_APP"] = str(app)
            reset_app_config()
            seen: dict[str, str] = {}

            def fake_chat(messages: list[dict[str, str]]) -> dict[str, str]:
                seen["model"] = model.MODEL
                seen["provider"] = model.PROVIDER
                return {"action": "generate"}

            try:
                model.configure(
                    "local",
                    "chat-model",
                    {"OPENROUTER_API_KEY": "test"},
                    timeout=9,
                    fallbacks=[("openrouter", "workflow-backup", 30)],
                )
                with model.using_browser_provider():
                    self.assertEqual(model.MODEL, "browser-model")
                    self.assertEqual(model.LLM_TIMEOUT, 45.0)
                    self.assertEqual(model.FALLBACKS, [("openrouter", "backup-model", 20.0)])
                    self.assertEqual((model._PRIMARY[0], model._PRIMARY[2]), ("openrouter", "browser-model"))
                self.assertEqual(model.MODEL, "chat-model")
                self.assertEqual(model.LLM_TIMEOUT, 9.0)
                self.assertEqual(model.FALLBACKS, [("openrouter", "workflow-backup", 30.0)])
                with model.using_python_provider():
                    self.assertEqual(model.MODEL, "python-model")
                    self.assertEqual(model.LLM_TIMEOUT, 15.0)
                    self.assertEqual(model.FALLBACKS, [("openrouter", "workflow-backup", 30.0)])
                with patch("cg_loop.model._chat_json", side_effect=fake_chat):
                    step = parse_step("/browser +click Select files and choose the selected video.")
                    self.assertEqual(model.choose_compile_action(step), "generate")
                self.assertEqual(seen, {"model": "browser-model", "provider": "openrouter"})
                self.assertEqual(model.MODEL, "chat-model")
                self.assertEqual(model.PROVIDER, "local")
            finally:
                model.configure("local", "", fallbacks=[])
                if previous_app is None:
                    os.environ.pop("CG_LOOP_APP", None)
                else:
                    os.environ["CG_LOOP_APP"] = previous_app
                reset_app_config()

    def test_workflow_compile_override_replaces_the_local_default(self) -> None:
        from cg_loop import model
        from cg_loop.workflow import CompileOverride, Workflow

        story = Workflow(
            name="sleep",
            python_compile=CompileOverride(llm="openrouter", model="meta/muse-spark-1.2-contributor"),
            browser_compile=CompileOverride(llm="openrouter", model="meta/muse-spark-1.2-contributor"),
        )
        seen: dict[str, object] = {}

        def fake_ask(model_id: str, message: str, files: list[str], **kwargs: object) -> str:
            seen["model"] = model_id
            seen["messages"] = kwargs.get("messages")
            seen["max_tokens"] = kwargs.get("max_tokens")
            return "def run(ctx):\n    return {'outputs': {}}\n"

        model.configure("openrouter", "hosted", {"OPENROUTER_API_KEY": "test"})
        try:
            with patch("cg_loop.hug.ask_hug", side_effect=fake_ask):
                reply = model.compile_python_step({"step": "/python print today"})
            self.assertIn("def run", reply.text)
            self.assertEqual(seen["model"], "prism-ml/Ternary-Bonsai-8B-mlx-2bit")
            messages = seen["messages"]
            assert isinstance(messages, list)
            self.assertEqual(messages[0]["role"], "system")
            self.assertIn("/python print today", messages[1]["content"])
            self.assertGreater(int(seen["max_tokens"]), 256)
            with model.bind_compile_workflow(story):
                with model.using_python_provider():
                    self.assertEqual(model.PROVIDER, "openrouter")
                    self.assertEqual(model.MODEL, "meta/muse-spark-1.2-contributor")
                with model.using_browser_provider():
                    self.assertEqual(model.PROVIDER, "openrouter")
                    self.assertEqual(model.MODEL, "meta/muse-spark-1.2-contributor")
            self.assertEqual(model.PROVIDER, "openrouter")
            self.assertEqual(model.MODEL, "hosted")
        finally:
            model.configure("local", "")

    def test_app_env_fills_unset_process_vars_and_workflow_env(self) -> None:
        import os

        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            dotenv = root / "keys.env"
            dotenv.write_text(
                'HF_TOKEN=from-file\nexport OTHER=from-file\n# comment\nBLANK=\nQUOTED="~keep"\n',
                encoding="utf-8",
            )
            app = root / "workflows-app.yaml"
            app.write_text(
                "env-file: keys.env\n"
                "env:\n"
                "  HF_HOME: ~/.cache/huggingface\n"
                "  OTHER: from-yaml\n"
                "config:\n"
                "  env:\n"
                "    KEEP: base\n",
                encoding="utf-8",
            )
            workflow = root / "wf-sample.yaml"
            workflow.write_text(
                "config:\n"
                "  name: sample\n"
                "  env:\n"
                "    KEEP: file\n"
                "wf_sample:\n"
                "  - term echo hi\n"
                "wf_group:\n"
                "  config:\n"
                "    env:\n"
                "      HF_TOKEN: group\n"
                "  steps:\n"
                "    - term echo group\n",
                encoding="utf-8",
            )
            previous_app = os.environ.get("CG_LOOP_APP")
            previous_models = os.environ.get("CG_LOOP_MODELS_DIR")
            previous = {key: os.environ.get(key) for key in ("HF_TOKEN", "HF_HOME", "OTHER", "KEEP")}
            os.environ["CG_LOOP_APP"] = str(app)
            os.environ["CG_LOOP_MODELS_DIR"] = str(root / "models-runtime")
            os.environ.pop("HF_TOKEN", None)
            os.environ.pop("HF_HOME", None)
            os.environ["OTHER"] = "from-shell"
            reset_app_config()
            from cg_loop.app_config import reset_model_storage

            reset_model_storage()
            try:
                found = app_env()
                self.assertEqual(found["HF_TOKEN"], "from-file")
                self.assertEqual(found["OTHER"], "from-yaml")
                self.assertEqual(found["KEEP"], "base")
                self.assertTrue(found["HF_HOME"].endswith(".cache/huggingface"))
                self.assertNotIn("BLANK", found)
                apply_app_env()
                self.assertEqual(os.environ["HF_TOKEN"], "from-file")
                self.assertEqual(os.environ["OTHER"], "from-shell")
                self.assertTrue(os.environ["HF_HOME"].endswith(".cache/huggingface"))
                loaded = load_workflow(workflow)
                self.assertEqual(loaded.env["HF_TOKEN"], "from-file")
                self.assertEqual(loaded.env["OTHER"], "from-yaml")
                self.assertEqual(loaded.env["KEEP"], "file")
                group = loaded.named_groups()["wf_group"]
                self.assertEqual(group.env["HF_TOKEN"], "group")
                self.assertEqual(group.env["KEEP"], "file")
                self.assertEqual(loaded.env["QUOTED"], "~keep")
            finally:
                reset_app_config()
                if previous_app is None:
                    os.environ.pop("CG_LOOP_APP", None)
                else:
                    os.environ["CG_LOOP_APP"] = previous_app
                if previous_models is None:
                    os.environ.pop("CG_LOOP_MODELS_DIR", None)
                else:
                    os.environ["CG_LOOP_MODELS_DIR"] = previous_models
                for key, value in previous.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value

    def test_prefix_picks_a_known_tool_without_the_model(self) -> None:
        def refuse(_message: str) -> str:
            raise AssertionError("the model should not be called")

        decision = decide_message("/browser click Create", phase="execute", ask=refuse)
        self.assertEqual(decision.tool, "browser")
        self.assertEqual(decision.mode, "execute")
        self.assertEqual(match_tool("/term echo hi"), "term")
        self.assertEqual(
            match_tool("/lmstudio-qwen3.8-27b-mlx read the date into $day"),
            "lmstudio",
        )
        self.assertEqual(
            match_tool("/browser /lmstudio-qwen3.8-27b-mlx read the date into $day"),
            "browser",
        )

    def test_unprefixed_message_uses_the_decision_model(self) -> None:
        seen: list[str] = []

        def ask(message: str) -> str:
            seen.append(message)
            return "term"

        decision = decide_message("echo the title", phase="compile", ask=ask)
        self.assertEqual(seen, ["echo the title"])
        self.assertEqual(decision.tool, "term")
        self.assertEqual(decision.mode, "compile")

    def test_unknown_tool_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            decide_message("do a thing", phase="execute", ask=lambda _message: "not-a-tool")

    def test_known_tools_do_not_compile_to_python(self) -> None:
        self.assertTrue(skips_script(parse_step("term echo hi")))
        self.assertFalse(skips_script(parse_step("/browser click Create")))
        self.assertFalse(skips_script(parse_step('/cua click "Search text box"')))
        self.assertFalse(skips_script(parse_step("/cua launch Chrome https://www.yahoo.com/")))
        self.assertTrue(skips_script(parse_step("/locate the button, 'shot.jpg' into $loc")))
        self.assertFalse(skips_script(parse_step("/python write the date math into $post_date")))
        self.assertFalse(skips_script(parse_step("/python set $post_date= today + 48 hours")))
        self.assertFalse(
            skips_script(
                parse_step("/python add 1 day to $post_date and print in format YYYY-MM-DD HH:MM:SS")
            )
        )
        self.assertTrue(skips_script(parse_step("/python print $post_date")))
        self.assertTrue(skips_script(parse_step("goto https://example.com")))
        self.assertTrue(skips_script(parse_step("load previous articles to $seen from $DRAFT_ROOT")))
        self.assertTrue(skips_script(parse_step("generate one new idea")))
        self.assertTrue(skips_script(parse_step("llm-call story.md $article")))
        lmstudio = parse_step("/lmstudio-qwen3.8-27b-mlx summarize the notes into $plan")
        self.assertEqual(lmstudio.tool, "lmstudio")
        self.assertTrue(skips_script(lmstudio))

    def test_bash_command_omits_a_file_inside_the_workflows_folder(self) -> None:
        root = workflows_root()
        assert root is not None
        inside = Workflow(name="sleep story", group="wf_generate_story", path=root / "wf-sleep-story.yaml")
        command = workflow_bash_command(inside, {"STORY_TITLE": "Rome"})
        self.assertIn("--only wf_generate_story", command)
        self.assertIn("wf-sleep-story", command)
        self.assertNotIn("wf-sleep-story.yaml", command)
        self.assertTrue(command.startswith("bkase "))
        self.assertNotIn("/bkase", command)

    def test_run_command_quotes_the_bkase_line(self) -> None:
        from cg_loop.workflow import format_workflow_run_command

        command = format_workflow_run_command(
            ["--only", "generate_story_routine", "--param", "STORY_TITLE=Imagine You fighting in the Roman Army?", "--param", "STORY_WORDS=6000"]
        )
        self.assertTrue(command.startswith("bkase "))
        self.assertIn("--only", command)
        self.assertIn("generate_story_routine", command)
        self.assertIn("STORY_WORDS=6000", command)
        self.assertIn("Imagine You fighting in the Roman Army?", command)

        with tempfile.TemporaryDirectory() as tmp:
            outside = Workflow(name="other", group="wf_main", path=Path(tmp) / "wf-other.yaml")
            other = workflow_bash_command(outside)
        self.assertIn("wf-other.yaml", other)

    def test_nested_action_input_keeps_only_the_top_level_name(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "workflows-app.yaml"
            path.write_text(
                "tools:\n"
                "  browser: page\n"
                "tool-details:\n"
                "  browser:\n"
                "    click:\n"
                "      in:\n"
                "        target:\n"
                "          selector: role\n"
                "          label: Next\n"
                "      out: [page]\n",
                encoding="utf-8",
            )
            config = load_app_config(path, force=True)
        click = config.tools["browser"].actions[0]
        self.assertEqual(click.inputs, ("target",))
        self.assertEqual(click.outputs, ("page",))

    def test_tool_model_is_not_an_action(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "workflows-app.yaml"
            path.write_text(
                "tools:\n"
                "  locate: Find something.\n"
                "  clef: Answer one question.\n"
                "tool-details:\n"
                "  locate:\n"
                "    model: andai-labs/LocateAnything-3B-MLX\n"
                "    find:\n"
                "      in: [query, image]\n"
                "      out: [box]\n"
                "  clef:\n"
                "    model: mlx-community/clef-flash-4bit\n"
                "    ask:\n"
                "      in: [question]\n"
                "      out: [value]\n",
                encoding="utf-8",
            )
            config = load_app_config(path, force=True)
        self.assertEqual(config.tools["locate"].model, "andai-labs/LocateAnything-3B-MLX")
        self.assertEqual([action.name for action in config.tools["locate"].actions], ["find"])
        self.assertEqual(config.tools["clef"].model, "mlx-community/clef-flash-4bit")
        self.assertEqual([action.name for action in config.tools["clef"].actions], ["ask"])

    def test_decision_asks_von_with_action_params(self) -> None:
        with patch(
            "cg_loop.model._von_post",
            return_value={"answers": {"tool": {"choice": "browser"}}},
        ) as posted:
            tool = ask_decision_model("click the Create button")
        self.assertEqual(tool, "browser")
        body = posted.call_args.args[0]
        self.assertEqual(body["model"], "von")
        criteria = body["questions"]["tool"]["criteria"]
        self.assertIn("lmstudio", criteria)
        self.assertNotIn("goto", criteria)
        self.assertNotIn("load", criteria)
        self.assertIn("goto:", criteria["browser"])
        self.assertIn("in url", criteria["browser"])

    def test_von_weights_load_before_steps_only_when_a_step_calls_von(self) -> None:
        import tempfile

        from cg_loop.model import load_von_if_needed, workflow_needs_von
        from cg_loop.workflow import load_workflow

        loaded: list[str] = []

        class Backend:
            def _get_model(self) -> None:
                loaded.append("weights")

        class Engine:
            backend = Backend()

            @staticmethod
            def get_instance() -> "Engine":
                return Engine()

        from dataclasses import replace

        from cg_loop.app_config import load_app_config

        sleep = load_workflow(project_root() / "workflows" / "wf-sleep-story.yaml")
        tiktok = sleep.named_groups()["post_sleep_story_short_tiktok_routine"]
        base = load_app_config()
        von_decision = replace(base, decision_model="von")
        other_decision = replace(base, decision_model="jev-latest")
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            von_yaml = root / "wf-von.yaml"
            von_yaml.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: von run",
                        "  browser-tool-model: von",
                        "wf_go:",
                        "  - /browser go https://www.tiktok.com/tiktokstudio/content verify Views",
                    ]
                ),
                encoding="utf-8",
            )
            jev_yaml = root / "wf-jev.yaml"
            jev_yaml.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: jev run",
                        "  browser-tool-model: jev-latest",
                        "wf_term:",
                        "  - /term echo hi",
                    ]
                ),
                encoding="utf-8",
            )
            von_run = load_workflow(von_yaml)
            jev_run = load_workflow(jev_yaml)
        with patch("cg_loop.app_config.load_app_config", return_value=von_decision), patch("von.engine.VonEngine", Engine):
            self.assertTrue(workflow_needs_von(tiktok))
            load_von_if_needed(von_run)
            load_von_if_needed(jev_run)
        self.assertEqual(loaded, ["weights"])
        with patch("cg_loop.app_config.load_app_config", return_value=other_decision), patch("von.engine.VonEngine", Engine):
            self.assertFalse(workflow_needs_von(tiktok))
            self.assertFalse(workflow_needs_von(von_run))
            load_von_if_needed(tiktok)
            load_von_if_needed(von_run)
        self.assertEqual(loaded, ["weights"])

    def test_von_tokenizer_warning_stays_off_the_step_log(self) -> None:
        import logging

        from cg_loop.model import _quiet_von_logs

        logging.getLogger("transformers").setLevel(logging.WARNING)
        _quiet_von_logs()
        self.assertGreaterEqual(logging.getLogger("transformers").level, logging.ERROR)

    def test_missing_model_falls_back_to_a_local_guess(self) -> None:
        with patch("cg_loop.decision.ask_decision_model", side_effect=OSError("down")):
            decision = decide_message("click the Create button", phase="execute")
        self.assertEqual(decision.tool, "browser")

    def test_python_default_uses_python_when_the_message_has_no_prefix(self) -> None:
        from dataclasses import replace

        base = load_app_config(force=True)
        defaulted = replace(base, decision_model="python-default")
        underscored = replace(base, decision_model="python_default")
        with patch("cg_loop.decision.load_app_config", return_value=defaulted):
            with patch("cg_loop.decision.ask_decision_model", side_effect=AssertionError("model")):
                plain = decide_message("folders in $DRAFT_STORIES < 5", phase="execute")
                named = decide_message("/browser click the Create button", phase="execute")
        self.assertEqual(plain.tool, "python")
        self.assertEqual(named.tool, "browser")
        with patch("cg_loop.decision.load_app_config", return_value=underscored):
            with patch("cg_loop.decision.ask_decision_model", side_effect=AssertionError("model")):
                again = decide_message("click the Create button", phase="execute")
        self.assertEqual(again.tool, "python")


if __name__ == "__main__":
    unittest.main()
