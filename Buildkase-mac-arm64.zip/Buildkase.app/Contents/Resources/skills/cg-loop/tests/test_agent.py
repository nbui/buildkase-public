#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.agent import Agent, available_counts, condition_type, folder_state  # noqa: E402
from cg_loop import model  # noqa: E402
from cg_loop.workflow import Workflow, parse_step, project_root  # noqa: E402


class AgentDryRunTests(unittest.TestCase):
    def test_browser_recompile_rewrites_only_browser_steps(self) -> None:
        workflow = Workflow(name="demo", group="wf_demo")
        with tempfile.TemporaryDirectory() as tmp:
            browser_only = Agent(workflow, run_dir=Path(tmp), browser_recompile=True)
            everything = Agent(workflow, run_dir=Path(tmp), recompile=True)
        browser = parse_step("/browser Click Create")
        reuse = parse_step("/browser reuseTab youtube")
        term = parse_step("term echo hi")
        self.assertTrue(browser_only._wants_recompile(browser))
        self.assertTrue(browser_only._wants_recompile(reuse))
        self.assertFalse(browser_only._wants_recompile(term))
        self.assertTrue(everything._wants_recompile(term))
        self.assertTrue(browser_only._wants_recompile(term, force=True))

    def test_workflow_step_prints_bash_command_in_the_log(self) -> None:
        from cg_loop.workflow import load_workflow_dir, select_workflows

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            (workflows / "wf-child.yaml").write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: child",
                        "wf_child:",
                        "  - term echo child-ok",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            (workflows / "wf-parent.yaml").write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: parent",
                        "wf_parent:",
                        "  - type: workflow",
                        "    workflow: wf_child",
                        "    params:",
                        "      STORY_TITLE: A night in the forum",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            loaded = load_workflow_dir(workflows)
            parent = select_workflows(loaded, "wf_parent")[0]
            with Agent(parent, dry_run=True, run_dir=root / "run") as agent:
                list(agent.run())
            text = (workflows / "cache" / "wf-parent" / "wf_parent" / "c-run.log").read_text(encoding="utf-8")
            self.assertIn("cg_loop.sh", text)
            self.assertIn("--only wf_child", text)
            self.assertIn(str(workflows / "wf-child.yaml"), text)
            self.assertIn("--param 'STORY_TITLE=A night in the forum'", text)
            self.assertTrue(text.index("command: bash ") < text.index("term echo child-ok"))

    def test_workflow_tool_run_calls_cg_loop_with_the_name(self) -> None:
        import os
        from unittest.mock import patch

        from cg_loop.app_config import reset_app_config
        from cg_loop.workflow import load_workflow_dir, select_workflows

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            script = root / "cg_loop.sh"
            script.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
            (root / "workflows-app.yaml").write_text(
                f"workflows: {workflows}\ncg-loop: {script}\n",
                encoding="utf-8",
            )
            (workflows / "wf-child.yaml").write_text(
                "config:\n  name: child\nwf_child:\n  - term echo child-ok\n",
                encoding="utf-8",
            )
            (workflows / "wf-parent.yaml").write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: parent",
                        "wf_parent:",
                        "  - type: workflow",
                        "    workflow: wf_child",
                        "    params:",
                        "      STORY_TITLE: A night in the forum",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            os.environ["CG_LOOP_APP"] = str(root / "workflows-app.yaml")
            reset_app_config()
            try:
                parent = select_workflows(load_workflow_dir(workflows), "wf_parent")[0]
                with patch(
                    "cg_loop.agent.run_command",
                    return_value={"status": "completed", "exit_code": 0},
                ) as run:
                    with Agent(parent, dry_run=False, run_dir=root / "run") as agent:
                        list(agent.run())
                command = run.call_args.args[0]
            finally:
                os.environ.pop("CG_LOOP_APP", None)
                reset_app_config()
        self.assertEqual(run.call_count, 1)
        self.assertIn(str(script), command)
        self.assertIn("--only wf_child", command)
        self.assertIn("wf-child", command)
        self.assertNotIn("wf-child.yaml", command)
        self.assertIn("--param 'STORY_TITLE=A night in the forum'", command)
        self.assertFalse(run.call_args.kwargs.get("confirm", True))

    def test_config_steps_run_before_the_routine(self) -> None:
        import contextlib
        import io

        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-before.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: before",
                        "  steps:",
                        "    - term echo from-config",
                        "alpha_routine:",
                        "  - term echo from-routine",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(path).named_groups()["alpha_routine"]
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                with Agent(group, dry_run=True, run_dir=Path(tmp) / "run") as agent:
                    list(agent.run())
        text = out.getvalue()
        self.assertLess(text.index("echo from-config"), text.index("echo from-routine"))

    def test_term_only_dry_run(self) -> None:
        workflow = Workflow(
            name="term-only",
            steps=[parse_step("term echo cg-loop-ok")],
        )
        with Agent(workflow, dry_run=True, run_dir=SKILL / "runs" / "test-term") as agent:
            states = list(agent.run())
        self.assertGreaterEqual(len(states), 1)
        self.assertEqual(states[-1]["status"], "done")
        self.assertIn("last_command", agent.variables)

    def test_compile_only_writes_the_script_and_does_not_run_it(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        f"    WORKFLOW_CACHE: {root / 'cache'}",
                        "post_instagram_routine:",
                        "  - set-config browser-reusetab=instagram",
                        "  - term echo cg-loop-ok",
                        "  - /browser +wait 1s",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            with patch("cg_loop.agent.execute_compiled", side_effect=AssertionError("compiled step was run")):
                with Agent(
                    workflow,
                    dry_run=True,
                    run_dir=root / "run",
                    recompile=True,
                    compile_only=True,
                ) as agent:
                    states = list(agent.run())
            self.assertEqual(states[-1]["status"], "done")
            self.assertNotIn("last_command", agent.variables)
            self.assertEqual(workflow.extras[0].browser_reusetab, "instagram")
            script = next((root / "cache").rglob("b-compile.py"))
            self.assertIn("replay_browser_actions", script.read_text(encoding="utf-8"))

    def test_research_yaml_dry_run_without_cdp(self) -> None:
        from cg_loop.workflow import load_workflow, select_workflows

        loaded = load_workflow(project_root() / "workflows" / "wf-research-content.yaml")
        workflow = select_workflows(loaded, "research_routine")[0]
        with Agent(
            workflow,
            dry_run=True,
            run_dir=SKILL / "runs" / "test-research",
        ) as agent:
            states = list(agent.run())
        self.assertEqual(states[-1]["status"], "done")
        self.assertIn("seen", agent.variables)
        self.assertIn("remix_article_run.sh", workflow.env["REMIX_SCRIPT"])
        self.assertEqual(workflow.group, "research_routine")
        self.assertTrue(
            (project_root() / "cache" / "wf-research-content" / "research_routine" / "c-run.log").is_file()
        )

    def test_condition_substeps_follow_the_check(self) -> None:
        held = {"value": False}
        workflow = Workflow(
            name="condition",
            group="wf_condition",
            steps=[
                parse_step(
                    {
                        "condition": "if empty",
                        "steps": ["term echo from-condition"],
                    }
                )
            ],
        )

        def matches(_step: object) -> bool:
            return held["value"]

        with Agent(workflow, dry_run=True, run_dir=SKILL / "runs" / "test-condition") as agent:
            agent._condition_matches = matches  # type: ignore[method-assign]
            list(agent.run())
        self.assertNotIn("last_command", agent.variables)

        held["value"] = True
        with Agent(workflow, dry_run=True, run_dir=SKILL / "runs" / "test-condition") as agent:
            agent._condition_matches = matches  # type: ignore[method-assign]
            states = list(agent.run())
        self.assertEqual(states[-1]["status"], "done")
        self.assertIn("from-condition", agent.variables["last_command"]["command"])

    def test_condition_runs_its_steps_before_deciding(self) -> None:
        workflow = Workflow(
            name="condition",
            group="wf_condition",
            steps=[
                parse_step(
                    {
                        "condition": [
                            "term echo check-ran",
                            "if nothing scheduled then return true",
                        ],
                        "steps": ["term echo body-ran"],
                    }
                )
            ],
        )
        held = {"value": False}

        def matches(_step: object) -> bool:
            return held["value"]

        with tempfile.TemporaryDirectory() as tmp:
            with Agent(workflow, dry_run=True, run_dir=Path(tmp) / "false") as agent:
                agent._condition_matches = matches  # type: ignore[method-assign]
                list(agent.run())
                log = agent.runlog.path.read_text(encoding="utf-8")
            self.assertIn("echo check-ran", agent.variables["last_command"]["command"])
            self.assertIn("matched: False", log)
            self.assertEqual(log.count("kind: term"), 1)

            held["value"] = True
            with Agent(workflow, dry_run=True, run_dir=Path(tmp) / "true") as agent:
                agent._condition_matches = matches  # type: ignore[method-assign]
                states = list(agent.run())
                log = agent.runlog.path.read_text(encoding="utf-8")
            self.assertEqual(states[-1]["status"], "done")
            self.assertIn("matched: True", log)
            self.assertEqual(log.count("kind: term"), 2)
            self.assertIn("body-ran", agent.variables["last_command"]["command"])

    def test_step_condition_asks_layla_then_python(self) -> None:
        from unittest.mock import patch

        workflow = Workflow(
            name="condition",
            group="wf_condition",
            steps=[
                parse_step(
                    {
                        "condition": [
                            "/browser extract youtube videos scheduled",
                            "if no videos scheduled then return true",
                        ],
                        "steps": ["term echo body"],
                    }
                )
            ],
        )
        with Agent(workflow, dry_run=False, run_dir=SKILL / "runs" / "test-condition-evidence") as agent:
            seen: dict[str, str] = {}

            def ask(message: str) -> str:
                seen["message"] = message
                return "python"

            from cg_loop.decision import decide_message

            original = decide_message

            def routed(message: str, **kwargs: object) -> object:
                seen["skip"] = str(kwargs.get("skip"))
                return original(message, phase="execute", ask=ask)

            with self.assertRaises(ValueError) as raised:
                with patch("cg_loop.decision.decide_message", side_effect=routed):
                    agent._condition_matches(workflow.steps[0])
        self.assertIn("if no videos scheduled", seen["message"])
        self.assertIn("condition", seen["skip"])
        self.assertIn("python cannot check", str(raised.exception))

    def test_folder_condition_delegates_to_python(self) -> None:
        from unittest.mock import patch

        workflow = Workflow(
            name="condition",
            group="wf_condition",
            steps=[
                parse_step(
                    {
                        "condition": "folders in $DRAFT_STORIES < 5",
                        "steps": ["term echo body"],
                    }
                )
            ],
        )
        typed = parse_step(
            {
                "condition": "folders in $DRAFT_ROOT of type idea-heart < 2",
                "steps": ["term echo body"],
            }
        )
        with tempfile.TemporaryDirectory() as tmp:
            stories = Path(tmp) / "stories"
            for name in ("one", "two"):
                (stories / name).mkdir(parents=True)
            draft = Path(tmp) / "draft"
            for name in ("a", "b"):
                folder = draft / name
                folder.mkdir(parents=True)
                (folder / "type.txt").write_text("idea-heart\n", encoding="utf-8")
            (draft / "other").mkdir()
            (draft / "other" / "type.txt").write_text("research-social\n", encoding="utf-8")
            with Agent(workflow, dry_run=False, run_dir=Path(tmp) / "run") as agent:
                agent.env["DRAFT_STORIES"] = str(stories)
                agent.env["DRAFT_ROOT"] = str(draft)
                asked: list[str] = []

                def ask(message: str, **_kwargs: object) -> str:
                    asked.append(message)
                    return "python"

                from cg_loop import model as loop_model

                def refuse(_messages: list[dict[str, str]]) -> dict[str, bool]:
                    raise AssertionError("loop called the chat model")

                original = loop_model.ask_json
                loop_model.ask_json = refuse  # type: ignore[method-assign]
                try:
                    with patch("cg_loop.decision.ask_decision_model", side_effect=ask):
                        self.assertTrue(agent._condition_matches(workflow.steps[0]))
                        for extra in range(4):
                            (stories / f"more-{extra}").mkdir()
                        self.assertFalse(agent._condition_matches(workflow.steps[0]))
                        self.assertFalse(agent._condition_matches(typed))
                        (draft / "b" / "type.txt").write_text("other\n", encoding="utf-8")
                        self.assertTrue(agent._condition_matches(typed))
                finally:
                    loop_model.ask_json = original  # type: ignore[method-assign]
        self.assertEqual(asked[0], "folders in $DRAFT_STORIES < 5")
        self.assertEqual(asked[2], "folders in $DRAFT_ROOT of type idea-heart < 2")

    def test_folder_condition_still_counts_when_layla_picks_another_tool(self) -> None:
        from unittest.mock import patch

        workflow = Workflow(
            name="condition",
            group="wf_condition",
            steps=[
                parse_step(
                    {
                        "condition": "folders in $DRAFT_STORIES < 5",
                        "steps": ["term echo body"],
                    }
                )
            ],
        )
        with tempfile.TemporaryDirectory() as tmp:
            stories = Path(tmp) / "stories"
            (stories / "one").mkdir(parents=True)
            with Agent(workflow, dry_run=False, run_dir=Path(tmp) / "run") as agent:
                agent.env["DRAFT_STORIES"] = str(stories)
                with patch("cg_loop.decision.ask_decision_model", return_value="workflow"):
                    self.assertTrue(agent._condition_matches(workflow.steps[0]))

    def test_picked_story_folder_decides_the_condition(self) -> None:
        import json
        from unittest.mock import patch

        workflow = Workflow(
            name="demo",
            group="wf_post_full_sleep_story",
            steps=[
                parse_step(
                    {
                        "condition": "if story_folder is found and not none then return true",
                        "steps": ["term echo upload"],
                    }
                )
            ],
        )
        with tempfile.TemporaryDirectory() as tmp:
            with Agent(workflow, dry_run=False, run_dir=Path(tmp)) as agent:
                found = json.dumps(
                    {"story_folder": "/tmp/story", "title": "Trains", "description": "A night ride."}
                )
                with patch(
                    "cg_loop.agent.run_command",
                    return_value={"status": "completed", "stdout": found, "exit_code": 0},
                ):
                    agent._act_term("pick")
                self.assertEqual(agent.variables["story_folder"], "/tmp/story")
                self.assertEqual(agent.variables["post_title"], "Trains")
                self.assertTrue(agent._condition_matches(workflow.steps[0]))

                with patch(
                    "cg_loop.agent.run_command",
                    return_value={
                        "status": "completed",
                        "stdout": '{"stop": true, "story_folder": null}\n',
                        "exit_code": 0,
                    },
                ):
                    agent._act_term("pick")
                self.assertEqual(agent.variables["story_folder"], "none")
                self.assertFalse(agent._condition_matches(workflow.steps[0]))

    def test_term_has_no_timeout_unless_the_workflow_sets_one(self) -> None:
        from unittest.mock import patch

        parent = Workflow(
            name="parent",
            group="wf_parent",
            steps=[parse_step("term echo parent")],
            command_timeout=0,
        )
        child = Workflow(
            name="child",
            group="wf_child",
            steps=[parse_step("term echo child")],
            command_timeout=14400,
        )
        with tempfile.TemporaryDirectory() as tmp:
            with Agent(parent, dry_run=False, run_dir=Path(tmp)) as agent:
                with patch(
                    "cg_loop.agent.run_command",
                    return_value={"status": "completed", "stdout": "", "exit_code": 0},
                ) as run:
                    agent._apply_group(parent, agent._capture_group())
                    agent._act_term("echo parent")
                    self.assertIsNone(run.call_args.kwargs["timeout"])
                    state = agent._capture_group()
                    agent._apply_group(child, state)
                    agent._act_term("echo child")
                    self.assertEqual(run.call_args.kwargs["timeout"], 14400)
                    agent._end_group(state)
                    agent._act_term("echo parent again")
                    self.assertIsNone(run.call_args.kwargs["timeout"])

        from cg_loop.compiled import run_term

        with patch(
            "cg_loop.terminal.run_command",
            return_value={"status": "completed", "stdout": "", "exit_code": 0, "command": "echo"},
        ) as compiled:
            run_term({"env": {}, "variables": {}}, "echo")
        self.assertIsNone(compiled.call_args.kwargs["timeout"])

    def test_compiled_term_returns_the_picked_story(self) -> None:
        import json
        from unittest.mock import patch

        from cg_loop.compiled import run_term

        stdout = "\n".join(
            [
                json.dumps(
                    {
                        "story_folder": "/tmp/rome",
                        "title": "Rome",
                        "description": "The city stirs.",
                    },
                    indent=2,
                ),
                "Wrote /tmp/selected_story.json",
            ]
        )
        with patch(
            "cg_loop.terminal.run_command",
            return_value={"status": "completed", "stdout": stdout, "exit_code": 0, "command": "pick"},
        ):
            result = run_term({"env": {}, "variables": {}, "timeout": 30}, "pick")
        self.assertEqual(result["variables"]["story_folder"], "/tmp/rome")
        self.assertEqual(result["variables"]["post_title"], "Rome")

    def test_compiled_term_keeps_the_pick_after_other_text(self) -> None:
        import json
        from unittest.mock import patch

        from cg_loop.compiled import run_term

        pick = json.dumps(
            {
                "story_folder": "/tmp/posts/gut",
                "title": "A gut molecule",
                "description": "ImP and memory.",
                "video": "/tmp/posts/gut/output_music.mp4",
            }
        )
        stdout = "\n".join(
            [
                "FOLDER: /tmp/posts/gut",
                "note {not json",
                pick,
            ]
        )
        with patch(
            "cg_loop.terminal.run_command",
            return_value={"status": "completed", "stdout": stdout, "exit_code": 0, "command": "pick"},
        ):
            result = run_term({"env": {}, "variables": {}, "timeout": 30}, "pick")
        self.assertEqual(result["variables"]["story_folder"], "/tmp/posts/gut")
        self.assertEqual(result["variables"]["post_title"], "A gut molecule")
        self.assertEqual(result["variables"]["video"], "/tmp/posts/gut/output_music.mp4")

    def test_compiled_term_blocks_when_the_command_fails(self) -> None:
        from unittest.mock import patch

        from cg_loop.compiled import run_term

        with patch(
            "cg_loop.terminal.run_command",
            return_value={
                "status": "failed",
                "stdout": "",
                "stderr": "No ready unposted packages\n",
                "exit_code": 1,
                "command": "select",
            },
        ):
            result = run_term({"env": {}, "variables": {}, "timeout": 30}, "select")
        self.assertTrue(result["blocked"])
        self.assertNotIn("story_folder", result["variables"])

    def test_picked_short_folder_decides_the_condition(self) -> None:
        import json
        from unittest.mock import patch

        workflow = Workflow(
            name="demo",
            group="wf_post_sleep_story_short",
            steps=[
                parse_step(
                    {
                        "condition": "if short_folder is found and not none then return true",
                        "steps": ["term echo upload"],
                    }
                )
            ],
        )
        with tempfile.TemporaryDirectory() as tmp:
            with Agent(workflow, dry_run=False, run_dir=Path(tmp)) as agent:
                found = json.dumps(
                    {
                        "short_folder": "/tmp/story/shorts/short_01",
                        "video": "/tmp/story/shorts/short_01/short.mp4",
                        "title": "The watch",
                        "description": "A quiet hour.",
                    }
                )
                with patch(
                    "cg_loop.agent.run_command",
                    return_value={"status": "completed", "stdout": found, "exit_code": 0},
                ):
                    agent._act_term("pick")
                self.assertEqual(agent.variables["short_folder"], "/tmp/story/shorts/short_01")
                self.assertEqual(agent.variables["video"], "/tmp/story/shorts/short_01/short.mp4")
                self.assertEqual(agent.variables["post_title"], "The watch")
                self.assertTrue(agent._condition_matches(workflow.steps[0]))

                with patch(
                    "cg_loop.agent.run_command",
                    return_value={"status": "completed", "stdout": '{"stop": true}\n', "exit_code": 0},
                ):
                    agent._act_term("pick")
                self.assertEqual(agent.variables["short_folder"], "none")
                self.assertFalse(agent._condition_matches(workflow.steps[0]))

    def test_cached_code_step_dry_run(self) -> None:
        import tempfile

        from cg_loop.step_cache import write_step_script
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "workflows"
            root.mkdir()
            yaml_path = root / "wf-cached.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: cached",
                        "  env:",
                        f"    WORKFLOW_PATH: {root}",
                        "wf_cached:",
                        "  - msg: echo from cache",
                        "    type: shell",
                        "    params: {}",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            cached = root / "cache" / "wf-cached" / "echo_from_cache.sh"
            write_step_script(cached, "echo cached-ok\n", language="shell")
            with Agent(workflow, dry_run=True, run_dir=SKILL / "runs" / "test-cache") as agent:
                states = list(agent.run())
            self.assertEqual(states[-1]["status"], "done")
            command = agent.variables["last_command"]["command"]
            self.assertIn("b-compile.sh", command)
            self.assertIn(str(root / "cache" / "wf-cached"), command)

    def test_steps_compile_once_and_log_inputs_outputs(self) -> None:
        import tempfile

        from cg_loop.workflow import load_workflow, select_workflows

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            package = root / "drafts" / "pkg"
            package.mkdir(parents=True)
            (package / "source_url.txt").write_text(
                "https://www.sciencedaily.com/releases/2026/01/example.htm\n",
                encoding="utf-8",
            )
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        f"    DRAFT_ROOT: {root / 'drafts'}",
                        "wf_research:",
                        "  - load previous sciencedaily articles to $seen from $DRAFT_ROOT",
                        "  - term echo hello-from-step",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = select_workflows(load_workflow(yaml_path), "wf_research")[0]
            with Agent(workflow, dry_run=False, run_dir=root / "run") as agent:
                states = list(agent.run())
            self.assertEqual(states[-1]["status"], "done")
            seen = agent.variables["seen"]
            self.assertEqual(seen, ["https://www.sciencedaily.com/releases/2026/01/example.htm"])
            self.assertIn("hello-from-step", agent.variables["last_command"]["stdout"])

            cache = workflows / "cache" / "wf-demo"
            scripts = list((cache / "compiled").glob("*/steps/*/*.py")) if (cache / "compiled").is_dir() else []
            self.assertEqual(scripts, [])

            log_root = workflows / "cache" / "wf-demo" / "wf_research"
            self.assertTrue((log_root / "c-run.log").is_file())
            self.assertTrue((log_root / "c-compile.log").is_file())
            self.assertFalse((log_root / "archived").exists())
            text = (log_root / "c-run.log").read_text(encoding="utf-8")
            compile_log = (log_root / "c-compile.log").read_text(encoding="utf-8")
            self.assertIn("mode: known", compile_log)
            self.assertIn("no script", compile_log)
            self.assertIn("echo hello-from-step", compile_log)
            self.assertIn("load previous sciencedaily articles to $seen from $DRAFT_ROOT", text)
            self.assertIn("summary", text)
            self.assertIn("total:", text)
            self.assertIn("compile:", text)
            self.assertIn("llm:", text)
            self.assertIn("compiled: 0", text)
            self.assertIn("failed recompile: 0", text)
            self.assertIn(str(root / "drafts"), text)
            self.assertIn("https://www.sciencedaily.com/releases/2026/01/example.htm", text)
            self.assertIn("echo hello-from-step", text)
            self.assertIn("hello-from-step", text)
            step_files = sorted(log_root.glob("*/c-*-context.json"))
            self.assertEqual(len(step_files), 2)

            with Agent(workflow, dry_run=False, run_dir=root / "run-2") as agent:
                list(agent.run())
            archived = list((log_root / "archived").iterdir())
            self.assertEqual(len(archived), 1)
            self.assertTrue((archived[0] / "c-run.log").is_file())
            second_log = (log_root / "c-run.log").read_text(encoding="utf-8")
            self.assertIn("hello-from-step", second_log)
            self.assertIn("compiled: 0", second_log)
            self.assertIn("failed recompile: 0", second_log)
            self.assertTrue((archived[0] / "c-compile.log").is_file())
            second_compile = (log_root / "c-compile.log").read_text(encoding="utf-8")
            self.assertIn("mode: known", second_compile)

    def test_invalid_script_is_recompiled(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import ensure_compiled, validate_compiled
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_research:",
                        "  - term echo hello-from-step",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            step = group.steps[0]
            created = ensure_compiled(group, step, index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, step), "")
            created.path.write_text("this is not python\n", encoding="utf-8")
            rewritten = ensure_compiled(group, step, index=0, env=group.env)
            self.assertEqual(rewritten.status, "recompiled")
            self.assertEqual(validate_compiled(rewritten.path, step), "")
            rewritten.path.write_text("still broken\n", encoding="utf-8")
            with patch("cg_loop.compiled.render_step", return_value="not valid python"):
                failed = ensure_compiled(group, step, index=0, env=group.env)
            self.assertEqual(failed.status, "failed")
            self.assertIn("syntax error", failed.error)

    def test_python_verify_miss_recompiles_once(self) -> None:
        import tempfile

        from cg_loop.compiled import CompileResult
        from cg_loop.workflow import Workflow, parse_step

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            bad = root / "bad.py"
            bad.write_text(
                "def run(ctx):\n"
                "    value = '2026-10-12 16:20:00'\n"
                "    print(value, flush=True)\n"
                "    return {'outputs': {'status': 'ok', 'printed': value}}\n",
                encoding="utf-8",
            )
            good = root / "good.py"
            good.write_text(
                "def run(ctx):\n"
                "    value = 3\n"
                "    print(value, flush=True)\n"
                "    return {'outputs': {'status': 'ok', 'printed': value}}\n",
                encoding="utf-8",
            )
            workflow = Workflow(name="demo", group="wf_demo", path=root / "wf-demo.yaml")
            step = parse_step("/python print 2 + 1 +model local/demo +verify 3")
            with Agent(workflow, dry_run=False, run_dir=root / "run", recompile_on_error=True) as agent:
                def rewrite(*_args, **kwargs):
                    self.assertIn("3", kwargs.get("error", ""))
                    return CompileResult(good, "recompiled")

                agent._ensure_step = rewrite
                result = agent._execute_compiled(workflow, step, 0, bad)
            self.assertFalse(result.get("blocked"))
            self.assertEqual(str(result["outputs"]["printed"]), "3")

    def test_runtime_failure_recompiles_once(self) -> None:
        import tempfile

        from cg_loop.compiled import ensure_compiled
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_research:",
                        "  - term echo hello-from-step",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            step = group.steps[0]
            created = ensure_compiled(group, step, index=0, env=group.env)
            created.path.write_text(
                "def run(ctx):\n"
                "    from cg_loop.compiled import run_term\n"
                "    raise RuntimeError('boom')\n"
                "    return run_term(ctx, 'echo hello-from-step')\n",
                encoding="utf-8",
            )
            broken = created.path.read_text(encoding="utf-8")
            with Agent(workflow, dry_run=False, run_dir=root / "run", recompile_on_error=True) as agent:
                states = list(agent.run())
            self.assertEqual(states[-1]["status"], "done")
            self.assertIn("hello-from-step", agent.variables["last_command"]["stdout"])
            text = (workflows / "cache" / "wf-demo" / "main" / "c-run.log").read_text(encoding="utf-8")
            self.assertIn("compiled: 0", text)
            self.assertEqual(created.path.read_text(encoding="utf-8"), broken)

    def test_runtime_failure_does_not_recompile_unless_asked(self) -> None:
        import tempfile

        from cg_loop.compiled import ensure_compiled
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_research:",
                        "  - term echo hello-from-step",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            step = group.steps[0]
            created = ensure_compiled(group, step, index=0, env=group.env)
            broken = (
                "def run(ctx):\n"
                "    from cg_loop.compiled import run_term\n"
                "    raise RuntimeError('boom')\n"
                "    return run_term(ctx, 'echo hello-from-step')\n"
            )
            created.path.write_text(broken, encoding="utf-8")
            with Agent(workflow, dry_run=False, run_dir=root / "run") as agent:
                states = list(agent.run())
            self.assertEqual(states[-1]["status"], "done")
            self.assertIn("hello-from-step", agent.variables["last_command"]["stdout"])
            self.assertEqual(created.path.read_text(encoding="utf-8"), broken)

    def test_labeled_open_keeps_the_http_url(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import compiled_step_path, ensure_compiled
        from cg_loop.workflow import load_workflow

        url = "https://studio.youtube.com/channel/abc/videos"
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_research:",
                        f"  - open youtube {url} and wait for docuemnt ready",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            step = group.steps[0]
            created = compiled_step_path(group, step, index=0, env=group.env)
            created.parent.mkdir(parents=True, exist_ok=True)
            created.write_text(
                "def run(ctx):\n"
                "    from cg_loop.compiled import run_goto\n"
                f"    return run_goto(ctx, 'youtube {url}')\n",
                encoding="utf-8",
            )
            with patch("cg_loop.model.compile_step", side_effect=RuntimeError("should not ask the model")):
                fixed = ensure_compiled(group, step, index=0, env=group.env)
            self.assertEqual(fixed.status, "recompiled")
            body = fixed.path.read_text(encoding="utf-8")
            self.assertIn(f"run_goto(ctx, {url!r}, wait_until='load')", body)
            self.assertNotIn(f"'youtube {url}'", body)
            compile_log = (workflows / "cache" / "wf-demo" / "wf_research" / "c-compile.log").read_text(
                encoding="utf-8"
            )
            self.assertIn("mode: direct", compile_log)

            step.raw = "open the channel home"
            step.url = "the channel home"
            with patch("cg_loop.model.compile_step", side_effect=RuntimeError("down")):
                fallback = ensure_compiled(group, step, index=1, env=group.env)
            self.assertEqual(fallback.status, "compiled")
            self.assertIn("run_goal", fallback.path.read_text(encoding="utf-8"))
            compile_log = (workflows / "cache" / "wf-demo" / "wf_research" / "c-compile.log").read_text(
                encoding="utf-8"
            )
            self.assertIn("mode: model-fallback", compile_log)
            self.assertIn("down", compile_log)

    def test_run_folder_supplies_earlier_outputs(self) -> None:
        import json
        import tempfile

        from cg_loop.compiled import payload_from_run

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = root / "20260921-113324"
            steps = run / "steps"
            steps.mkdir(parents=True)
            script = root / "term_step.py"
            script.write_text("print('unused')\n", encoding="utf-8")
            (steps / "01.json").write_text(
                json.dumps(
                    {
                        "seq": 1,
                        "step": "load previous sciencedaily articles to $seen from $DRAFT_ROOT",
                        "script": str(root / "load.py"),
                        "inputs": {"roots": {"$DRAFT_ROOT": str(root / "drafts")}},
                        "outputs": {"seen": ["https://www.sciencedaily.com/a"]},
                    }
                ),
                encoding="utf-8",
            )
            (steps / "02.json").write_text(
                json.dumps(
                    {
                        "seq": 2,
                        "step": "term $REMIX_SCRIPT \"$url\"",
                        "script": str(script),
                        "inputs": {"command": "echo hi"},
                        "outputs": {"status": "ok", "command": "echo hi"},
                    }
                ),
                encoding="utf-8",
            )
            (run / "run.log").write_text("# workflow: -\n", encoding="utf-8")
            payload = payload_from_run(run, script)
            self.assertEqual(payload["env"]["DRAFT_ROOT"], str(root / "drafts"))
            self.assertEqual(payload["variables"]["seen"], ["https://www.sciencedaily.com/a"])
            self.assertNotIn("command", payload.get("variables") or {})

    def test_run_data_dir_moves_into_the_archived_log(self) -> None:
        import tempfile

        from cg_loop.runlog import RunLog
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_main:",
                        "  - wait",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            cache = workflows / "cache" / "wf-demo" / "main"
            data = cache / "z-data"
            data.mkdir(parents=True)
            (data / "temp.json").write_text('{"tab": 1}\n', encoding="utf-8")
            (cache / "c-run.log").write_text("# started: 2026-09-21T13:00:00\n", encoding="utf-8")

            first = RunLog(workflow, stamp="20260921-140000", fallback=root / "fallback")
            archived = cache / "archived" / "20260921-130000"
            self.assertEqual((archived / "z-data" / "temp.json").read_text(encoding="utf-8"), '{"tab": 1}\n')
            self.assertEqual(first.data_dir, data.resolve())
            self.assertTrue(data.is_dir())
            self.assertFalse((data / "temp.json").exists())
            (data / "note.txt").write_text("next\n", encoding="utf-8")
            (cache / "c-run.log").write_text("# started: 2026-09-21T14:00:00\n", encoding="utf-8")

            with Agent(workflow, dry_run=True, run_dir=root / "run") as agent:
                self.assertEqual(Path(agent.env["DATA"]), data.resolve())
                self.assertEqual(Path(agent._step_ctx()["data"]), data.resolve())
                self.assertEqual(
                    (cache / "archived" / "20260921-140000" / "z-data" / "note.txt").read_text(encoding="utf-8"),
                    "next\n",
                )
                self.assertFalse((data / "note.txt").exists())
                self.assertTrue(data.is_dir())

    def test_prune_run_logs_keeps_newest(self) -> None:
        import os
        import tempfile

        from cg_loop.runlog import prune_run_logs

        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            for index in range(6):
                path = base / f"run-{index}"
                path.mkdir()
                os.utime(path, (index + 10, index + 10))
            current = base / "run-5"
            removed = prune_run_logs(base, keep=5, current=current)
            self.assertEqual([path.name for path in removed], ["run-0"])
            self.assertEqual(
                sorted(path.name for path in base.iterdir()),
                [f"run-{index}" for index in range(1, 6)],
            )

    def test_tool_call_reply_is_a_term_choice(self) -> None:
        from cg_loop.model import _parse_json

        parsed = _parse_json(
            '<|tool_call_start|>[TERM(command=\'curl -s "https://example.com" | wc -l\')]'
        )
        self.assertEqual(parsed["operation"], "TERM")
        self.assertEqual(parsed["term_target"], "1")
        self.assertIn("curl -s", parsed["command"])
        done = _parse_json('{"operation": "DONE", "confidence": 1}')
        self.assertEqual(done["operation"], "DONE")
        program = _parse_json(
            "/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-post-from-folder/venv/bin/python3 -c '\n"
            "import yaml, json\n"
            "print(1)\n"
            "'"
        )
        self.assertEqual(program["operation"], "TERM")
        self.assertIn("import yaml, json", program["command"])

    def test_gpt2_whitespace_json_parses(self) -> None:
        from cg_loop.model import _parse_json

        raw = (
            "{\u010a\u0120\u0120\u0120\u0120\"text\":\u0120\"The\u0120hum\u0120of\u0120the\u0120hangar"
            "\u0120fades.\\n\\n#sleepstory\u0120#calm\"\u010a}"
        )
        parsed = _parse_json(raw)
        self.assertEqual(parsed["text"], "The hum of the hangar fades.\n\n#sleepstory #calm")

    def test_unusable_model_reply_is_logged(self) -> None:
        from unittest.mock import patch

        from cg_loop import model

        captured: list[dict] = []
        model.set_exchange_log(captured.append)

        class _Message:
            content = "this is not json"
            model = "test-model"

            def model_dump(self) -> dict:
                return {"content": self.content, "reasoning": "I guessed a shell command"}

        class _Choice:
            message = _Message()

        class _Response:
            choices = [_Choice()]
            model = "test-model"

        class _Completions:
            def create(self, **_kwargs: object) -> _Response:
                return _Response()

        class _Chat:
            completions = _Completions()

        class _Client:
            chat = _Chat()

        try:
            with patch.object(model, "client", return_value=_Client()):
                with self.assertRaises(model.ChatError):
                    model._chat_json([{"role": "user", "content": "verify views"}])
        finally:
            model.set_exchange_log(None)
        self.assertEqual(len(captured), 1)
        self.assertIn("I guessed a shell command", captured[0]["thinking"])
        self.assertIn("this is not json", captured[0]["result"])
        self.assertIn("Model did not return JSON", captured[0]["error"])

    def test_goal_survives_unusable_model_reply(self) -> None:
        from unittest.mock import patch

        from cg_loop import model

        import tempfile

        workflow = Workflow(
            name="goal",
            steps=[parse_step("verify there is > 1 post with views")],
            group="wf_stats_browser",
        )
        with tempfile.TemporaryDirectory() as tmp:
            with patch("cg_loop.model.choose_tool", return_value="term"):
                with patch("cg_loop.model.term_command", side_effect=model.ChatError("Model did not return JSON: nope")):
                    with Agent(workflow, dry_run=True, run_dir=Path(tmp)) as agent:
                        states = list(agent.run())
        self.assertEqual(states[-1]["status"], "blocked")

    def test_failed_command_is_generated_once(self) -> None:
        from unittest.mock import patch

        import tempfile

        contexts: list[dict] = []

        def term_command(context, fallback=""):
            contexts.append(context)
            command = "false" if len(contexts) == 1 else "true"
            return command, {"model": "test", "latency_ms": 1}

        def choose(*_args, **_kwargs):
            return {
                "choice": "TERM",
                "operation": "TERM",
                "target": None,
                "confidence": 1,
                "probabilities": {"TERM": 1},
                "raw_answers": {},
                "command": "",
                "latency_ms": 1,
                "elements": [],
                "targets": {},
                "controls": {"TERM": {"id": "TERM", "kind": "term"}},
                "operations": {"TERM": "term"},
            }

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflow = Workflow(
                name="goal",
                path=root / "wf-goal.yaml",
                steps=[parse_step("print latest youtube post")],
                env={"WORKFLOW_CACHE": str(root / "cache")},
            )
            with patch("cg_loop.model.choose_tool", return_value="term"):
                with patch("cg_loop.model.choose", side_effect=choose):
                    with patch("cg_loop.model.term_command", side_effect=term_command):
                        with Agent(workflow, run_dir=root / "run") as agent:
                            states = list(agent.run())
                        self.assertEqual(states[-1]["status"], "blocked")
                        self.assertEqual(agent.variables["last_command"]["status"], "failed")
        self.assertEqual(len(contexts), 1)

    def test_failed_command_regenerates_when_retries_are_enabled(self) -> None:
        from unittest.mock import patch

        import tempfile

        contexts: list[dict] = []

        def term_command(context, fallback=""):
            contexts.append(context)
            command = "false" if len(contexts) == 1 else "true"
            return command, {"model": "test", "latency_ms": 1}

        def choose(*_args, **_kwargs):
            return {
                "choice": "TERM",
                "operation": "TERM",
                "target": None,
                "confidence": 1,
                "probabilities": {"TERM": 1},
                "raw_answers": {},
                "command": "",
                "latency_ms": 1,
                "elements": [],
                "targets": {},
                "controls": {"TERM": {"id": "TERM", "kind": "term"}},
                "operations": {"TERM": "term"},
            }

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflow = Workflow(
                name="goal",
                path=root / "wf-goal.yaml",
                steps=[parse_step("/term print latest youtube post")],
                env={"WORKFLOW_CACHE": str(root / "cache")},
            )
            with patch("cg_loop.agent.MAX_STEP_TICKS", 3):
                with patch("cg_loop.model.choose", side_effect=choose):
                    with patch("cg_loop.model.term_command", side_effect=term_command):
                        with Agent(workflow, run_dir=root / "run") as agent:
                            list(agent.run())
                        self.assertEqual(agent.variables["last_command"]["status"], "completed")
        self.assertEqual(len(contexts), 2)
        self.assertIn("error", contexts[1])
        self.assertEqual(contexts[1]["previous_command"], "false")

    def test_unprefixed_step_asks_jev_which_tool(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop import model

        asked: list[str] = []

        def ask(message: str) -> str:
            asked.append(message)
            return "browser"

        workflow = Workflow(name="goal", steps=[parse_step("click the Shorts tab")])
        with tempfile.TemporaryDirectory() as tmp:
            with patch("cg_loop.decision.ask_decision_model", side_effect=ask):
                with Agent(workflow, dry_run=True, run_dir=Path(tmp)) as agent:
                    states = list(agent._run_goal(parse_step("click the Shorts tab")))
        self.assertEqual(asked, ["click the Shorts tab"])
        self.assertEqual(states[-1]["status"], "ready")
        with self.assertRaises(model.ChatError):
            model._validate_jev_choice({"choice": "browser", "confidence": 1, "probabilities": {"browser": 1}}, {"browser", "term"})

    def test_file_goal_asks_for_code_without_the_page(self) -> None:
        from unittest.mock import patch

        import tempfile

        seen: dict = {}

        def term_command(context, fallback=""):
            seen["context"] = context
            return "true", {"model": "test", "latency_ms": 1}

        def choose(*_args, **_kwargs):
            raise AssertionError("page chooser should not run for a file step")

        with tempfile.TemporaryDirectory() as tmp:
            workflow = Workflow(
                name="goal",
                path=Path(tmp) / "wf-goal.yaml",
                steps=[parse_step("log latest youtube post from $ALL_POSTS as json string")],
                env={
                    "ALL_POSTS": "/tmp/all_posts.yaml",
                    "OPENROUTER_API_KEY": "sk-or-v1-secret",
                    "WORKFLOW_CACHE": tmp,
                },
            )
            with patch("cg_loop.model.choose_tool", return_value="term"):
                with patch("cg_loop.model.choose", side_effect=choose):
                    with patch("cg_loop.model.term_command", side_effect=term_command):
                        with Agent(workflow, run_dir=Path(tmp) / "run") as agent:
                            list(agent.run())
        self.assertIn("/tmp/all_posts.yaml", seen["context"]["step"])
        self.assertEqual(seen["context"]["env"]["ALL_POSTS"], "/tmp/all_posts.yaml")
        self.assertNotIn("OPENROUTER_API_KEY", seen["context"]["env"])

    def test_browser_goal_does_not_replay_cached_shell(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_stats_browser:",
                        "  - /browser verify there is > 1 post with views",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            cached = (
                workflows
                / "cache"
                / "wf-demo"
                / "compiled"
                / "verify_there_is_1_post_with_views.sh"
            )
            cached.parent.mkdir(parents=True)
            cached.write_text("#!/bin/sh\necho should-not-run\n", encoding="utf-8")
            workflow = load_workflow(yaml_path)
            from cg_loop.compiled import compiled_step_path

            group = workflow.extras[0]
            script = compiled_step_path(group, group.steps[0], index=0, env=group.env)
            script.parent.mkdir(parents=True, exist_ok=True)
            script.write_text(
                "def run(ctx):\n"
                "    from cg_loop.compiled import browser_page\n"
                "    page = browser_page(ctx)\n"
                "    return {'outputs': {'verified': True}, 'page': page}\n",
                encoding="utf-8",
            )
            with patch("cg_loop.model.choose") as choose:
                with Agent(workflow, dry_run=True, run_dir=root / "run") as agent:
                    states = list(agent.run())
            self.assertEqual(states[-1]["status"], "done")
            choose.assert_not_called()
            self.assertNotIn("should-not-run", str(agent.variables.get("last_command")))

    def test_browser_goal_compiles_once(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import ensure_compiled, validate_compiled
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "    ALL_POSTS: /tmp/all_posts.yaml",
                        "    OPENROUTER_API_KEY: sk-or-v1-secret",
                        "wf_stats_browser:",
                        "  - /browser verify there is > 1 post with views",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            step = group.steps[0]
            with patch("cg_loop.model.choose_compile_action", return_value="helper"):
                created = ensure_compiled(group, step, index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, step), "")
            script = created.path.read_text(encoding="utf-8")
            self.assertIn("browser_helper", script)
            self.assertNotIn("run_goal", script)
            self.assertIn("verify there is > 1 post with views", script)
            note = (created.path.parent / "a-prompt.md").read_text(encoding="utf-8")
            self.assertIn("helper: replay_browser_actions", note)
            self.assertNotIn("## system", note)
            again = ensure_compiled(group, step, index=0, env=group.env)
            self.assertEqual(again.status, "reused")
            created.path.write_text(
                "def run(ctx):\n"
                "    from cg_loop.compiled import run_goal\n"
                "    return run_goal(ctx, 'again')\n",
                encoding="utf-8",
            )
            self.assertIn("run_goal", validate_compiled(created.path, step))

    def test_compile_generates_a_script_without_browser_helper(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import ensure_compiled, validate_compiled
        from cg_loop.model import CompileReply
        from cg_loop.workflow import load_workflow

        script = (
            "def run(ctx):\n"
            "    from datetime import datetime, timedelta\n"
            "    from cg_loop.compiled import browser_page\n"
            "    snap = browser_page(ctx)\n"
            "    pw = ctx['browser'].page\n"
            "    when = datetime.now().astimezone() + timedelta(hours=1)\n"
            "    pw.get_by_role('textbox').fill(when.strftime('%I:%M %p'))\n"
            "    return {'outputs': {}, 'page': snap}\n"
        )
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_schedule:",
                        "  - /browser Set Schedule the date and time to about 1 hour ahead.",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            step = group.steps[0]

            def compile_browser_step(context: dict) -> CompileReply:
                self.assertIn("about 1 hour ahead", context["step"])
                self.assertNotIn("browser_helper", script)
                return CompileReply(text=script, model="test-model", messages=[{"role": "system", "content": "compile"}])

            with patch("cg_loop.model.choose_compile_action", return_value="generate"):
                with patch("cg_loop.model.compile_browser_step", side_effect=compile_browser_step):
                    created = ensure_compiled(group, step, index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, step), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("timedelta(hours=1)", text)
            self.assertNotIn("browser_helper", text)
            self.assertIn("ctx['browser'].page", text)
            note = (created.path.parent / "a-prompt.md").read_text(encoding="utf-8")
            self.assertIn("## system", note)
            self.assertIn("compile", note)
            self.assertNotIn("helper:", note)

    def test_extract_is_generated_code_not_the_library(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import ensure_compiled, validate_compiled
        from cg_loop.model import CompileReply
        from cg_loop.workflow import load_workflow

        script = (
            "def run(ctx):\n"
            "    pw = ctx['browser'].page\n"
            "    value = pw.evaluate('''() => ({title: \"Knee\", url: location.href, published: \"Oct 11, 4:20 PM\", text: \"Oct 11, 4:20 PM\"})''')\n"
            "    return {'outputs': {'post': value}, 'variables': {'post': value}}\n"
        )
        library_script = (
            "def run(ctx):\n"
            "    from cg_loop.compiled import run_extract\n"
            "    return run_extract(ctx, phrase='latest post date', var='post')\n"
        )
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "wf_post:",
                        "  - /browser extract latest post date to $post",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            step = group.steps[0]
            old = root / "old.py"
            old.write_text(library_script, encoding="utf-8")
            self.assertIn("extract library", validate_compiled(old, step))

            def compile_extract_step(context: dict) -> CompileReply:
                self.assertEqual(context["var"], "post")
                self.assertIn("latest post date", context["step"])
                self.assertIn("Oct 11", context["page"]["text"])
                return CompileReply(
                    text=script,
                    model="test-model",
                    messages=[{"role": "system", "content": "extract"}, {"role": "user", "content": "page"}],
                )

            page = {"url": "https://www.tiktok.com/tiktokstudio/content", "title": "TikTok", "text": "Oct 11, 4:20 PM"}
            with patch("cg_loop.model.compile_extract_step", side_effect=compile_extract_step):
                created = ensure_compiled(group, step, index=1, env=group.env, page=page)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, step), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn(".evaluate(", text)
            self.assertNotIn("run_extract", text)
            self.assertNotIn("article_from_page", text)
            note = (created.path.parent / "a-prompt.md").read_text(encoding="utf-8")
            self.assertIn("## system", note)
            self.assertIn("extract", note)
            self.assertIn("## user", note)
            self.assertIn("page", note)

    def test_later_step_compiles_with_the_page_and_variables_so_far(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.model import CompileReply
        from cg_loop.workflow import load_workflow

        script = (
            "def run(ctx):\n"
            "    pw = ctx['browser'].page\n"
            "    value = pw.evaluate('''() => \"Oct 12, 4:20 PM\"''')\n"
            "    return {'outputs': {'post': value}, 'variables': {'post': value}}\n"
        )
        seen: dict[str, object] = {}

        def compile_extract_step(context: dict) -> CompileReply:
            seen["page"] = context.get("page")
            seen["variables"] = context.get("variables")
            return CompileReply(text=script, model="test-model", messages=[{"role": "user", "content": "page"}])

        class Page:
            def __init__(self) -> None:
                self.url = "https://www.sciencedaily.com/rss/top/health.xml"

            def evaluate(self, _expression: str) -> str:
                return "Oct 11, 4:20 PM"

        class Tab:
            def __init__(self) -> None:
                self.page = Page()
                self.info = {
                    "url": self.page.url,
                    "title": "ScienceDaily",
                    "text": "pubDate",
                    "actions": [],
                }

            def observe(self) -> dict:
                return dict(self.info)

            def reuse_tab(self, _site: str) -> dict:
                self.page.url = "https://www.tiktok.com/tiktokstudio/content"
                self.info = {
                    "url": self.page.url,
                    "title": "TikTok Studio",
                    "text": "Oct 11, 4:20 PM",
                    "actions": [],
                }
                shown = dict(self.info)
                shown["reused"] = True
                return shown

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "wf_post:",
                        "  - /browser reuseTab tiktok",
                        '  - /browser js "Oct 11, 4:20 PM" in $post_date',
                        "  - /browser extract latest post date to $post",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            agent = Agent(group, run_dir=root / "run")
            agent.cdp_url = "http://127.0.0.1:18801"
            agent.browser = Tab()  # type: ignore[assignment]
            with patch("cg_loop.model.compile_extract_step", side_effect=compile_extract_step):
                list(agent.run())
            page = seen["page"]
            self.assertIsInstance(page, dict)
            self.assertEqual(page["url"], "https://www.tiktok.com/tiktokstudio/content")
            self.assertEqual(page["text"], "Oct 11, 4:20 PM")
            self.assertEqual(seen["variables"].get("post_date"), "Oct 11, 4:20 PM")
            compiled = [
                path
                for path in (workflows / "cache" / "wf-demo" / "wf_post").glob("*/b-compile.py")
                if "extract" in path.parent.name
            ]
            self.assertEqual(len(compiled), 1)
            self.assertIn("Page: https://www.tiktok.com/tiktokstudio/content", compiled[0].read_text(encoding="utf-8"))

    def test_browser_step_fails_when_cdp_url_is_unset(self) -> None:
        import tempfile
        from unittest.mock import patch

        workflow = Workflow(
            name="stats",
            group="stats_report_routine",
            steps=[parse_step("/browser reuseTab youtube")],
        )
        with tempfile.TemporaryDirectory() as tmp:
            with patch("cg_loop.browser.ensure_cdp") as ensure:
                with self.assertRaises(RuntimeError) as caught:
                    with Agent(workflow, run_dir=Path(tmp)) as agent:
                        list(agent.run())
                ensure.assert_not_called()
        self.assertEqual(str(caught.exception), "browser tool needs cdp-url")

    def test_extract_reuses_when_the_open_page_changes(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import ensure_compiled
        from cg_loop.model import CompileReply
        from cg_loop.workflow import load_workflow

        def compile_extract_step(context: dict) -> CompileReply:
            url = context["page"]["url"]
            script = (
                "def run(ctx):\n"
                "    pw = ctx['browser'].page\n"
                f"    value = pw.evaluate('''() => \"{url}\"''')\n"
                "    return {'outputs': {'post': value}, 'variables': {'post': value}}\n"
            )
            return CompileReply(text=script, model="test-model", messages=[{"role": "user", "content": url}])

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "wf_post:",
                        "  - /browser extract latest post date to $post",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            step = group.steps[0]
            first = {"url": "https://www.sciencedaily.com/rss/top/health.xml", "title": "", "text": "rss", "links": []}
            second = {"url": "https://www.tiktok.com/tiktokstudio/content", "title": "TikTok", "text": "Oct 11", "links": []}
            with patch("cg_loop.model.compile_extract_step", side_effect=compile_extract_step):
                created = ensure_compiled(group, step, index=0, env=group.env, page=first)
                self.assertEqual(created.status, "compiled")
                again = ensure_compiled(group, step, index=0, env=group.env, page=first)
                self.assertEqual(again.status, "reused")
                moved = ensure_compiled(group, step, index=0, env=group.env, page=second)
            self.assertEqual(moved.status, "reused")
            self.assertEqual(moved.path, created.path)
            self.assertIn("Page: https://www.sciencedaily.com/rss/top/health.xml", moved.path.read_text(encoding="utf-8"))

    def test_local_file_input_is_generated(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import ensure_compiled, validate_compiled
        from cg_loop.model import CompileReply
        from cg_loop.workflow import load_workflow

        script = (
            "def run(ctx):\n"
            "    from cg_loop.compiled import browser_page\n"
            "    snap = browser_page(ctx)\n"
            "    pw = ctx['browser'].page\n"
            "    from cg_loop.compiled import set_local_input_files\n"
            "    set_local_input_files(pw, ctx['variables']['youtube_video'])\n"
            "    return {'outputs': {}, 'page': snap}\n"
        )
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_upload:",
                        "  - /browser Set the file input to the local path youtube_captions_music.mp4 from this story with set_local_input_files. Do not click Select files.",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            step = workflow.extras[0].steps[0]

            def compile_browser_step(context: dict) -> CompileReply:
                self.assertIn("set_local_input_files", context["step"])
                self.assertIn("local path", context["step"])
                return CompileReply(text=script, model="test-model", messages=[{"role": "system", "content": "compile"}])

            def refuse_helper(_step: object) -> str:
                raise AssertionError("a local file input is generated, not a browser_helper click")

            with patch("cg_loop.model.choose_compile_action", side_effect=refuse_helper):
                with patch("cg_loop.model.compile_browser_step", side_effect=compile_browser_step):
                    created = ensure_compiled(workflow.extras[0], step, index=0, env=workflow.extras[0].env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, step), "")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("set_local_input_files", text)
            self.assertNotIn("browser_helper", text)

    def test_browser_compile_sends_reference_source(self) -> None:
        import tempfile

        from cg_loop.compiled import ensure_compiled
        from cg_loop.model import CompileReply
        from cg_loop.questions import COMPILE_BROWSER
        from cg_loop.workflow import load_workflow

        self.assertIn("Do not import the file", COMPILE_BROWSER)
        self.assertIn("set_local_input_files", COMPILE_BROWSER)
        self.assertIn("Do not call set_input_files", COMPILE_BROWSER)
        sleep = load_workflow(project_root() / "workflows" / "wf-sleep-story.yaml")
        self.assertEqual(sleep.named_groups()["upload_sleep_ad_routine"].reference, "")
        self.assertEqual(sleep.named_groups()["post_sleep_story_short_routine"].reference, "")
        self.assertIn("browser-reusetab=adsmanager.facebook.com", sleep.named_groups()["test_routine"].steps[1].raw)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            example = root / "upload_ad.py"
            example.write_text(
                "def create_ad_in_adset(page):\n"
                "    page.get_by_role('button', name='Create', exact=True).click()\n",
                encoding="utf-8",
            )
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_ads:",
                        "  config:",
                        f"    reference: {example}",
                        "  steps:",
                        "  - /browser Click Create, then Create ad.",
                        "wf_other:",
                        "  - /browser Open the home page.",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            ads = workflow.named_groups()["wf_ads"]
            other = workflow.named_groups()["wf_other"]
            self.assertEqual(ads.reference, str(example))
            self.assertEqual(other.reference, "")

            created = ensure_compiled(ads, ads.steps[0], index=0, env=ads.env)
            self.assertEqual(created.status, "compiled")
            text = created.path.read_text(encoding="utf-8")
            self.assertIn("replay_browser_actions", text)
            self.assertNotIn("browser_helper(", text)
            self.assertNotIn("upload_ad", text)
            self.assertNotIn("subprocess", text)
            from cg_loop.browser_helper import browser_helper

            class Tab:
                def observe(self) -> dict:
                    return {"url": "https://adsmanager.facebook.com", "title": "Ads", "text": "Create", "actions": []}

            def ask(messages: list) -> dict:
                self.assertIn("Create", messages[1]["content"])
                return {"operation": "DONE", "confidence": 1}

            def compile_step(context: dict) -> CompileReply:
                source = context["reference"]
                self.assertEqual(source["path"], str(example))
                self.assertIn("exact=True", source["source"])
                self.assertIn("Do not import", source["note"])
                self.assertNotIn("reference", context["env"])
                return CompileReply(
                    text="def run(ctx):\n    return {'outputs': {}}\n",
                    model="test-model",
                )

            browser_helper(
                ads.steps[0].raw,
                Tab(),
                dry_run=True,
                reference=str(example),
                ask=ask,
                compile_step=compile_step,
            )
            with self.assertRaises(RuntimeError) as caught:
                browser_helper(
                    ads.steps[0].raw,
                    Tab(),
                    dry_run=True,
                    reference=str(root / "missing.py"),
                    ask=ask,
                    compile_step=compile_step,
                )
            self.assertIn("reference script not found", str(caught.exception))

    def test_position_named_script_is_kept_for_the_same_text(self) -> None:
        import tempfile

        from cg_loop.compiled import compiled_step_path, ensure_compiled, render_step
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_research:",
                        "  - term echo hello",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            step = group.steps[0]
            path = compiled_step_path(group, step, index=4, env=group.env)
            old = path.with_name("wf_research_01_term_echo_hello.py")
            old.parent.mkdir(parents=True)
            old.write_text(render_step(step, path=old, env=group.env), encoding="utf-8")
            adopted = ensure_compiled(group, step, index=4, env=group.env)
            self.assertEqual(adopted.status, "reused")
            self.assertEqual(adopted.path, path)
            self.assertFalse(old.exists())
            self.assertIn("echo hello", path.read_text(encoding="utf-8"))

    def test_script_moves_into_the_artifact_folder(self) -> None:
        import tempfile

        from cg_loop.compiled import compiled_step_path, ensure_compiled, prune_stale_steps, render_step
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_research:",
                        "  - term echo hello",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            step = group.steps[0]
            path = compiled_step_path(group, step, index=0, env=group.env)
            beside = path.parent.parent / path.name
            beside.parent.mkdir(parents=True)
            beside.write_text(render_step(step, path=beside, env=group.env), encoding="utf-8")
            folder = beside.parent / beside.stem
            folder.mkdir()
            (folder / f"{beside.stem}.json").write_text('{"step": "term echo hello"}\n', encoding="utf-8")
            (folder / "click_ok.jpg").write_bytes(b"jpeg")
            adopted = ensure_compiled(group, step, index=0, env=group.env)
            self.assertEqual(adopted.path, path)
            self.assertEqual(path.name, "b-compile.py")
            self.assertFalse(beside.exists())
            self.assertEqual((path.parent / "b_01-context.json").read_text(encoding="utf-8"), '{"step": "term echo hello"}\n')
            self.assertEqual((path.parent / "click_ok.jpg").read_bytes(), b"jpeg")
            leftover = path.parent.parent / path.name
            leftover.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
            prune_stale_steps(group, env=group.env)
            self.assertFalse(leftover.exists())
            self.assertTrue(path.is_file())
            self.assertTrue((path.parent / "b_01-context.json").is_file())
            self.assertTrue((path.parent / "click_ok.jpg").is_file())

    def test_legacy_compiled_folder_moves_into_the_step_folder(self) -> None:
        import tempfile

        from cg_loop.compiled import adopt_legacy_compiled, compiled_step_path, render_step
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_open:",
                        "  - /cua click \"Search text box\"",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            step = group.steps[0]
            path = compiled_step_path(group, step, index=0, env=group.env)
            legacy_dir = path.parent.parent.parent / "compiled" / "wf_open" / "steps" / "wf_open_click_search_text_box_old"
            legacy_dir.mkdir(parents=True)
            script = legacy_dir / "wf_open_click_search_text_box_old.py"
            script.write_text(render_step(step, path=script, env=group.env), encoding="utf-8")
            (legacy_dir / f"{script.stem}.json").write_text('{"command": "/cua click \\"Search text box\\""}\n', encoding="utf-8")
            (legacy_dir / f"{script.stem}.crop.png").write_bytes(b"crop")
            (legacy_dir / f"{script.stem}.prompt.md").write_text("prompt\n", encoding="utf-8")
            moved = adopt_legacy_compiled(group, env=group.env)
            self.assertEqual(moved, [path])
            self.assertEqual(path.name, "b-compile.py")
            self.assertTrue(path.is_file())
            self.assertTrue((path.parent / "b_01-context.json").is_file())
            self.assertEqual((path.parent / "b-crop.png").read_bytes(), b"crop")
            self.assertEqual((path.parent / "a-prompt.md").read_text(encoding="utf-8"), "prompt\n")
            self.assertFalse((path.parent.parent.parent / "compiled").exists())
            self.assertFalse(legacy_dir.exists())

    def test_changed_step_text_recompiles(self) -> None:
        import tempfile
        from unittest.mock import patch

        from cg_loop.compiled import compiled_step_path, ensure_compiled
        from cg_loop.workflow import load_workflow

        body = "verify " + ("post with views " * 6)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_stats_browser:",
                        f"  - /browser {body}",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            step = group.steps[0]
            with patch("cg_loop.model.choose_compile_action", return_value="helper"):
                created = ensure_compiled(group, step, index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            self.assertEqual(
                compiled_step_path(group, step, index=6, env=group.env),
                created.path,
            )
            step.raw = step.raw + " today"
            changed_path = compiled_step_path(group, step, index=6, env=group.env)
            self.assertNotEqual(changed_path, created.path)
            with patch("cg_loop.model.choose_compile_action", return_value="helper"):
                changed = ensure_compiled(group, step, index=6, env=group.env)
            self.assertEqual(changed.status, "compiled")
            self.assertEqual(changed.path, changed_path)
            self.assertIn("Source: " + step.raw, changed.path.read_text(encoding="utf-8"))
            self.assertIn("browser_helper", changed.path.read_text(encoding="utf-8"))
            self.assertTrue(created.path.is_file())

    def test_mismatched_python_or_json_recompiles_without_running(self) -> None:
        import json
        import tempfile
        from unittest.mock import patch

        from cg_loop.browser_helper import compiled_json_path
        from cg_loop.compiled import compiled_step_path, ensure_compiled, validate_compiled
        from cg_loop.workflow import load_workflow

        def compiled_actions(command, browser, env=None, variables=None):
            del browser, env, variables
            return {
                "actions": [{"operation": "CLICK", "label": "Schedule"}],
                "elements": [],
                "page": {"url": "https://www.instagram.com/", "title": "Instagram"},
                "model": "test",
            }

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_post:",
                        "  - /browser Click Schedule",
                        "  - term echo hello-from-step",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            click = group.steps[0]
            term = group.steps[1]
            with patch("cg_loop.browser_helper.compile_browser_actions", side_effect=compiled_actions):
                created = ensure_compiled(group, click, index=0, env=group.env, browser=object())
            self.assertEqual(created.status, "compiled")
            self.assertEqual(validate_compiled(created.path, click), "")
            with patch("cg_loop.browser_helper.compile_browser_actions", side_effect=compiled_actions) as again:
                reused = ensure_compiled(group, click, index=0, env=group.env, browser=object())
            self.assertEqual(reused.status, "reused")
            again.assert_not_called()

            compiled_json_path(created.path).write_text(
                json.dumps({"command": "/browser Click Next", "actions": []}) + "\n",
                encoding="utf-8",
            )
            stale = created.path.read_text(encoding="utf-8").replace(
                "def run(ctx):",
                "def run(ctx):\n    raise RuntimeError('executed stale')",
                1,
            )
            created.path.write_text(stale, encoding="utf-8")
            self.assertEqual(validate_compiled(created.path, click), "compiled json does not match")
            ran: list[str] = []

            def record(path: Path, ctx: dict) -> dict:
                del ctx
                ran.append(path.read_text(encoding="utf-8"))
                return {"status": "done", "outputs": {}}

            with Agent(workflow, dry_run=True, run_dir=root / "run") as agent:
                agent.env = dict(group.env)
                agent.browser = type("Browser", (), {"close": lambda self: None})()
                with patch("cg_loop.browser_helper.compile_browser_actions", side_effect=compiled_actions):
                    with patch("cg_loop.agent.execute_compiled", side_effect=record):
                        agent._execute_compiled(group, click, 0, created.path)
            self.assertEqual(len(ran), 1)
            self.assertNotIn("executed stale", ran[0])
            saved = json.loads(compiled_json_path(created.path).read_text(encoding="utf-8"))
            self.assertEqual(saved["command"], click.raw)

            term_path = compiled_step_path(group, term, index=1, env=group.env)
            term_path.parent.mkdir(parents=True, exist_ok=True)
            term_path.write_text(
                "\n".join(
                    [
                        '"""Compiled cg-loop step.',
                        "",
                        "Source: term echo other",
                        '"""',
                        "def run(ctx):",
                        "    raise RuntimeError('executed stale')",
                        "    from cg_loop.compiled import run_term",
                        "    return run_term(ctx, 'echo other')",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            self.assertEqual(validate_compiled(term_path, term), "step text changed")
            with Agent(workflow, dry_run=False, run_dir=root / "run-term") as agent:
                agent.env = dict(group.env)
                result = agent._execute_compiled(group, term, 1, term_path)
            self.assertNotIn("executed stale", term_path.read_text(encoding="utf-8"))
            self.assertIn("hello-from-step", result["outputs"]["stdout"])

    def test_workflow_start_removes_stale_steps_and_json(self) -> None:
        import json
        import tempfile

        from cg_loop.compiled import compiled_step_path, ensure_compiled, prune_stale_steps
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_research:",
                        "  - term echo hello-from-step",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            current = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            stale = current.path.with_name("wf_research_01_term_echo_old_step.py")
            stale.write_text("def run(ctx):\n    return {}\n", encoding="utf-8")
            kept_json = current.path.parent / "b_01-context.json"
            kept_json.write_text('{"step": "term echo hello-from-step"}\n', encoding="utf-8")
            folder = current.path.parent
            (folder / "c-01-context.json").write_text(
                json.dumps({"step": "term echo hello-from-step", "seq": 1}) + "\n",
                encoding="utf-8",
            )
            (folder / "c-02-context.json").write_text(
                json.dumps({"step": "term echo old-step", "seq": 2}) + "\n",
                encoding="utf-8",
            )
            (folder / "c-02-context.prompt.md").write_text("old\n", encoding="utf-8")
            removed = prune_stale_steps(group, env=group.env)
            names = {path.name for path in removed}
            self.assertIn(stale.name, names)
            self.assertIn("c-02-context.json", names)
            self.assertIn("c-02-context.prompt.md", names)
            self.assertTrue(current.path.is_file())
            self.assertTrue(kept_json.is_file())
            self.assertTrue((folder / "c-01-context.json").is_file())
            self.assertFalse(stale.exists())
            self.assertFalse((folder / "c-02-context.json").exists())
            self.assertEqual(
                compiled_step_path(group, group.steps[0], index=0, env=group.env),
                current.path,
            )

    def test_browser_compile_includes_open_page_and_retries_prose(self) -> None:
        from cg_loop.compiled import browser_page

        class Page:
            def __init__(self) -> None:
                self.waits = 0

            def wait_for_timeout(self, _ms: int) -> None:
                self.waits += 1

        class Browser:
            def __init__(self) -> None:
                self.n = 0
                self.page = Page()

            def observe(self) -> dict:
                self.n += 1
                text = "" if self.n == 1 else "Published\n50\n"
                return {"url": "https://studio.youtube.com", "title": "Studio", "text": text}

        browser = Browser()
        seen = browser_page({"browser": browser})
        self.assertEqual(seen["text"], "Published\n50\n")
        self.assertEqual(browser.page.waits, 1)

    def test_compile_text_splits_thinking(self) -> None:
        from cg_loop.model import split_model_text, thinking_from_mapping

        script, thinking = split_model_text("<think>use the url</think>\n\ndef run(ctx):\n    pass\n")
        self.assertIn("def run", script)
        self.assertNotIn("<think>", script)
        self.assertEqual(thinking, "use the url")
        mapped = thinking_from_mapping(
            {
                "content": "def run(ctx):\n    pass\n",
                "reasoning": "because the step is a url",
                "reasoning_details": [{"type": "reasoning.text", "text": "pick the url"}],
            }
        )
        self.assertIn("because the step is a url", mapped)
        self.assertIn("pick the url", mapped)
        self.assertNotIn("def run", mapped)

    def test_goal_step_is_logged_as_skipped(self) -> None:
        import tempfile

        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_research:",
                        "  - verify there is > 1 post with views",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            agent = Agent(workflow, dry_run=True, run_dir=root / "run")
            agent._compile_steps(workflow.extras[0])
            text = (workflows / "cache" / "wf-demo" / "wf_research" / "c-compile.log").read_text(encoding="utf-8")
            self.assertIn("verify there is > 1 post with views", text)
            self.assertIn("mode: skip", text)
            self.assertIn("not sent — this step is not compiled", text)
            self.assertIn("thinking:", text)

    def test_auto_group_skips_compile_and_restores_config(self) -> None:
        import os
        import tempfile

        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  profile: yuba-heart",
                        "  cdp-url: http://127.0.0.1:18802",
                        "  llm: local",
                        "  model: parent-model",
                        "  env:",
                        "    NAME: parent",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_live:",
                        "  config:",
                        "    profile: yuba-social",
                        "    cdp-url: http://127.0.0.1:18801",
                        "    llm: openrouter",
                        "    model: child-model",
                        "    env:",
                        "      NAME: child",
                        "  steps:",
                        "    - term echo $NAME",
                        "  auto:",
                        "    - /browser click the Shorts tab",
                        "wf_after:",
                        "  - term echo $NAME",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            agent = Agent(workflow, dry_run=True, run_dir=root / "run")
            group = workflow.extras[0]
            agent._compile_steps(group)
            compiled = list((workflows / "cache" / "wf-demo" / "compiled").rglob("*.py")) if (
                workflows / "cache" / "wf-demo" / "compiled"
            ).is_dir() else []
            self.assertEqual(compiled, [])
            text = (workflows / "cache" / "wf-demo" / "wf_live" / "c-compile.log").read_text(encoding="utf-8")
            self.assertIn("mode: known", text)
            self.assertIn("mode: auto", text)
            self.assertIn("click the Shorts tab", text)
            calls: list[str] = []

            def fake_goal(step):
                calls.append(step.raw)
                if False:
                    yield {}

            agent._run_goal = fake_goal  # type: ignore[method-assign]
            os.environ.pop("NAME", None)
            os.environ.pop("CDP_URL", None)
            try:
                list(agent._run_step(group.steps[1], index=1))
                self.assertEqual(calls, ["/browser click the Shorts tab"])
                state = agent._capture_group()
                agent._apply_group(group, state)
                self.assertEqual(agent.env["NAME"], "child")
                self.assertEqual(agent.env["PROFILE"], "yuba-social")
                self.assertEqual(os.environ["NAME"], "child")
                self.assertEqual(agent.cdp_url, "http://127.0.0.1:18801")
                self.assertEqual(agent.env["CDP_URL"], "http://127.0.0.1:18801")
                self.assertEqual(os.environ["CDP_URL"], "http://127.0.0.1:18801")
                agent._end_group(state)
                self.assertEqual(agent.env["NAME"], "parent")
                self.assertEqual(agent.env["PROFILE"], "yuba-heart")
                self.assertNotIn("NAME", os.environ)
                self.assertNotIn("CDP_URL", os.environ)
                self.assertEqual(agent.cdp_url, "http://127.0.0.1:18802")
            finally:
                from cg_loop.model import configure

                configure("local", "")



class FolderStateTests(unittest.TestCase):
    def test_lists_markers_on_packages_stories_and_shorts(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            draft = root / "draft_posts"
            approved = root / "approved_posts"
            stories = root / "approved_stories"
            (draft / "waiting").mkdir(parents=True)
            (draft / "waiting" / "type.txt").write_text("research\n", encoding="utf-8")
            (draft / "slides").mkdir()
            (draft / "slides" / "type.txt").write_text("slides\n", encoding="utf-8")
            marked = approved / "done"
            marked.mkdir(parents=True)
            for name in ("post_youtube.yaml", "post_tiktok.yaml", "post_instagram.yaml"):
                (marked / name).write_text("status: posted\n", encoding="utf-8")
            (approved / "open").mkdir()
            (approved / "open" / "post_youtube.yaml").write_text("status: posted\n", encoding="utf-8")
            story = stories / "rome"
            short = story / "shorts" / "short_01"
            short.mkdir(parents=True)
            (story / "post_youtube.yaml").write_text("status: posted\n", encoding="utf-8")
            (short / "post_tiktok.yaml").write_text("status: posted\n", encoding="utf-8")
            closed = stories / "closed"
            closed_short = closed / "shorts" / "short_01"
            closed_short.mkdir(parents=True)
            for name in ("post_youtube.yaml", "post_tiktok.yaml", "post_instagram.yaml"):
                (closed / name).write_text("status: posted\n", encoding="utf-8")
                (closed_short / name).write_text("status: posted\n", encoding="utf-8")

            env = {
                "DRAFT_ROOT": str(draft),
                "DRAFT_TYPE": "research",
                "APPROVED_ROOT": str(approved),
                "DRAFT_STORIES": str(root / "missing"),
                "APPROVED_STORIES": str(stories),
            }
            state = folder_state(env)
            counts = available_counts(env)
            slides = available_counts(env, type_name="slides")["posts"]
            social = available_counts(env, type_name="research-social")["posts"]

        self.assertEqual(
            state["DRAFT_ROOT"],
            [
                {"name": "slides", "markers": [], "type": "slides"},
                {"name": "waiting", "markers": [], "type": "research"},
            ],
        )
        self.assertEqual(state["DRAFT_STORIES"], [])
        self.assertEqual(
            state["APPROVED_ROOT"],
            [
                {
                    "name": "done",
                    "markers": ["post_youtube.yaml", "post_tiktok.yaml", "post_instagram.yaml"],
                },
                {"name": "open", "markers": ["post_youtube.yaml"]},
            ],
        )
        self.assertEqual(
            state["APPROVED_STORIES"][1],
            {
                "name": "rome",
                "markers": ["post_youtube.yaml"],
                "shorts": [{"name": "short_01", "markers": ["post_tiktok.yaml"]}],
            },
        )
        self.assertEqual(state["APPROVED_STORIES"][0]["name"], "closed")
        self.assertEqual(counts, {"posts": 1, "stories": 0})
        self.assertEqual(slides, 1)
        self.assertEqual(social, 0)
        self.assertEqual(condition_type("folders in $DRAFT_ROOT of type research-heart < 2", {}), "research-heart")


if __name__ == "__main__":
    unittest.main()
