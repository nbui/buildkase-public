"""The agent loop runs one browser, python, term, or locate step. It generates that step once."""

from __future__ import annotations

import json
import os
import re
import shlex
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator

from . import model
from .browser import Browser, StalePage
from .compiled import (
    COMPILED_KINDS,
    describe_inputs,
    ensure_compiled,
    execute_compiled,
    is_browser_script,
    is_cua_script,
    is_python_script,
    read_browser,
    run_generate,
    run_locate,
    run_clef,
    run_hug,
)
from .extract import article_from_page, format_article, load_previous_urls, skip_url_set
from .questions import MAX_STEP_TICKS, MAX_STEPS
from .runlog import RunLog, log_compile, note_compile_attempt
from .step_cache import (
    cache_env,
    find_step_script,
    invoke_command,
    is_code_step,
    script_from_command,
    should_cache_command,
    step_cache_path,
    write_step_script,
)
from .terminal import command_timeout, expand_command, print_command, run_command
from .workflow import (
    CONFIG_ALIASES,
    LOOP_TOOLS,
    SKILL_ROOT,
    Step,
    project_root,
    Workflow,
    apply_overrides,
    runnable_steps,
    config_alias_key,
    live_config_value,
    set_config_pairs,
    resolve_subworkflow,
    step_body,
    workflow_bash_command,
)

# Term steps use paths such as skills/cg-remix/scripts/sleep_original.py.
# That folder is the parent of skills/, not the directory above the project.
REPO_ROOT = project_root()
_POST_MARKERS = ("post_youtube.yaml", "post_tiktok.yaml", "post_instagram.yaml")
_FOLDER_ENV = ("DRAFT_ROOT", "APPROVED_ROOT", "DRAFT_STORIES", "APPROVED_STORIES")
REMIX_RUN = project_root() / "skills" / "cg-remix-article" / "scripts" / "remix_article_run.sh"
CATALOG_PATH = SKILL_ROOT / "references" / "command_catalog.md"
STORY_PROMPT = """Write a short spoken social-video story from this article.

Requirements:
- 180-260 words, 7-9 short scenes in markdown
- Sound like a person talking. Contractions. No AI vocabulary.
- Credit the website / lab / journal out loud when they are in the source.
- A first-time viewer should understand the main elements: who or what was involved, what changed or was compared, and what happened.
- If this is a study, trial, or experiment, name each group (what they did, ate, took, or received), what was measured or tested, and the result for each group when the source gives it.
- Do not invent numbers, quotes, groups, or outcomes.
- Do not mention Yuba, HeartKase, or any app.

Article:
{article}
"""


def loop_tool(step: Step) -> str:
    """The tool named by a /browser, /python, /term, /locate, /clef, /hug, or /cua prefix.

    Empty means the step has no prefix. The loop asks the local decision model.
    """
    if step.tool in LOOP_TOOLS:
        return step.tool
    return ""


def folder_state(env: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    """Child folders and post markers for the draft and approved roots."""
    state: dict[str, list[dict[str, Any]]] = {}
    for key in _FOLDER_ENV:
        raw = env.get(key)
        if not raw:
            continue
        root = Path(str(raw))
        if not root.is_dir():
            state[key] = []
            continue
        state[key] = [_folder_markers(child) for child in _child_dirs(root)]
    return state


def _child_dirs(root: Path) -> list[Path]:
    return sorted(path for path in root.iterdir() if path.is_dir() and not path.name.startswith("."))


def _marker_names(folder: Path) -> list[str]:
    return [name for name in _POST_MARKERS if (folder / name).is_file()]


def _folder_type(folder: Path) -> str:
    path = folder / "type.txt"
    if not path.is_file():
        return ""
    return path.read_text(encoding="utf-8").strip().splitlines()[0].strip()


def _folder_markers(folder: Path) -> dict[str, Any]:
    item: dict[str, Any] = {"name": folder.name, "markers": _marker_names(folder)}
    kind = _folder_type(folder)
    if kind:
        item["type"] = kind
    shorts_root = folder / "shorts"
    if shorts_root.is_dir():
        item["shorts"] = [
            {"name": short.name, "markers": _marker_names(short)} for short in _child_dirs(shorts_root)
        ]
    return item


_TYPE_IN_CONDITION = re.compile(r"\btype\s+(\$[\w]+|[\w-]+)")


def condition_type(text: str, env: dict[str, Any]) -> str:
    """The draft type named in a condition. $DRAFT_TYPE expands from env."""
    match = _TYPE_IN_CONDITION.search(text or "")
    if not match:
        return str(env.get("DRAFT_TYPE") or "").strip()
    token = match.group(1)
    if token.startswith("$"):
        return str(env.get(token[1:]) or "").strip()
    return token


def available_counts(env: dict[str, Any], *, type_name: str = "") -> dict[str, int]:
    """Draft folders of one type. Heart and Social each have their own type."""
    folders = folder_state(env)
    posts = list(folders.get("DRAFT_ROOT") or [])
    draft_type = type_name or str(env.get("DRAFT_TYPE") or "").strip()
    if draft_type:
        posts = [item for item in posts if item.get("type") == draft_type]
    return {
        "posts": len(posts),
        "stories": len(folders.get("DRAFT_STORIES") or []),
    }


class _VerifyMiss(RuntimeError):
    """A /python +verify check missed. The result is the blocked step."""

    def __init__(self, result: dict[str, Any]) -> None:
        self.result = result
        message = str((result.get("outputs") or {}).get("message") or "verify failed")
        super().__init__(message)


def _benchmark_python(step: Step) -> bool:
    """A /python step that names its own +model. A failure here does not stop later models."""
    return step.tool == "python" and bool(step.params.get("model"))


def _blocked_python(message: str) -> dict[str, Any]:
    print(message, flush=True)
    return {"blocked": True, "outputs": {"status": "blocked", "message": message, "error": message}}


def _runtime_error_text(exc: BaseException) -> str:
    text = f"{type(exc).__name__}: {exc}"
    if isinstance(exc, KeyError) and exc.args and exc.args[0] == "browser":
        text += ". ctx['env'] has no 'browser'. $rootProject is ctx['env']['rootProject']."
    return text


class Agent:
    def __init__(
        self,
        workflow: Workflow,
        *,
        dry_run: bool = False,
        pause: bool = False,
        run_dir: Path | None = None,
        command_timeout: int | None = None,
        cdp_url: str = "",
        recompile: bool = False,
        browser_recompile: bool = False,
        recompile_on_error: bool = False,
        compile_only: bool = False,
    ):
        self.workflow = workflow
        self.dry_run = dry_run
        self.compile_only = compile_only
        self.recompile = recompile or bool(workflow.recompile)
        self.browser_recompile = browser_recompile or bool(workflow.browser_recompile)
        self.recompile_on_error = recompile_on_error or bool(workflow.recompile_on_error)
        self.pause = pause
        self.command_timeout = command_timeout
        self.cdp_url = (cdp_url or workflow.cdp_url).rstrip("/")
        self.browser: Browser | None = None
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        self.runlog = RunLog(workflow, stamp=stamp, fallback=Path(run_dir) if run_dir else SKILL_ROOT / "runs" / stamp)
        self.data_dir = self.runlog.data_dir
        self.run_dir = Path(run_dir) if run_dir else self.data_dir
        self.variables: dict[str, Any] = {}
        self.env = dict(workflow.env)
        self.env["DATA"] = str(self.data_dir)
        run_command_text = str(self.env.get("WORKFLOW_RUN_COMMAND") or "").strip()
        if run_command_text:
            self.variables["workflow_run_command"] = run_command_text
        self.env.setdefault("rootProject", str(project_root()))
        self.catalog = _load_catalog()
        model.configure(
            workflow.llm,
            workflow.model,
            workflow.env,
            timeout=workflow.llm_timeout,
            fallbacks=workflow.fallbacks,
            browser_tool_model=workflow.browser_tool_model,
        )
        self._active_workflow = workflow
        self._workflow_stack: list[Path] = []
        self._group_stack: list[tuple[str, str]] = []
        self._running_step: Step | None = None
        self._step_json: Path | None = None
        self._workflow_bash = ""
        self._compiled: dict[tuple[str, str, int, str], Any] = {}
        self._saved_os: dict[str, str | None] = {}
        self.state: dict[str, Any] = {
            "status": "ready",
            "page": None,
            "decision": None,
            "history": [],
            "plan": workflow.plan_text(),
            "plan_index": 0,
            "elapsed_ms": 0,
            "started_at": None,
            "variables": self.variables,
        }

    def __enter__(self) -> "Agent":
        self.open()
        return self

    def __exit__(self, *_args) -> None:
        self.close()

    def open(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.env["DATA"] = str(self.data_dir)
        self._export_os("DATA", str(self.data_dir), override=True)
        for key, value in self.env.items():
            self._export_os(key, value, override=False)
        if self.cdp_url and _should_open_browser(self.workflow, dry_run=self.dry_run):
            self.browser = self._new_browser(self.cdp_url, self.workflow)
            self.browser.open()

    def close(self) -> None:
        from .cua import close_driver

        close_driver()
        self._restore_os(self._saved_os)
        self._saved_os = {}
        if self.browser:
            self.browser.close()
            self.browser = None

    def snapshot(self) -> dict[str, Any]:
        page = self.state.get("page") or {}
        elements, _targets, _controls = model.action_space(
            page,
            self._current_step(),
            self.variables,
            command_catalog=self.catalog,
        )
        return {
            **{k: v for k, v in self.state.items() if k != "browser"},
            "elements": elements,
            "variables": self.variables,
        }

    def run(self) -> Iterator[dict[str, Any]]:
        from .trace import bind, unbind

        model.reset_llm_time()
        model.set_exchange_log(self._log_model_exchange)
        wall = time.perf_counter()
        bind(self.runlog.path)
        try:
            if self.state["started_at"] is None:
                self.state["started_at"] = time.perf_counter()
            if self.dry_run:
                print("\n(dry-run — operations will be printed, not executed)\n")
            yield from self._run_workflow(self.workflow, announce=False)
            if self.state["status"] != "blocked":
                self.state["status"] = "done"
                self._stamp()
                yield self.snapshot()
        finally:
            model.set_exchange_log(None)
            unbind()
            self.runlog.write_summary(
                total_ms=(time.perf_counter() - wall) * 1000,
                llm_ms=model.llm_time_ms(),
            )

    def _run_workflow(self, workflow: Workflow, *, announce: bool = True) -> Iterator[dict[str, Any]]:
        path = workflow.path.resolve() if workflow.path else None
        pushed = False
        if path:
            if path in self._workflow_stack and path != self._workflow_stack[-1]:
                cycle = " -> ".join(str(item) for item in self._workflow_stack + [path])
                raise ValueError(f"workflow cycle: {cycle}")
            if path not in self._workflow_stack:
                self._workflow_stack.append(path)
                pushed = True
        previous = self._active_workflow
        runtime = self._capture_group()
        group_key = (str(path or ""), workflow.group)
        if workflow.group and group_key in self._group_stack:
            raise ValueError(f"workflow cycle: {workflow.group}")
        if workflow.group:
            self._group_stack.append(group_key)
        try:
            self._apply_group(workflow, runtime)
            self._active_workflow = workflow
            from .compiled import adopt_legacy_compiled

            adopt_legacy_compiled(workflow, self.env)
            if announce:
                print(f"\n\n==== additional workflow {workflow.group}: {workflow.name} ====")
            repeats = max(1, workflow.loop_count) if announce and workflow.owns_loop else 1
            for round_i in range(repeats):
                if round_i:
                    time.sleep(max(0.0, workflow.loop_delay))
                    print(f"\n=== {workflow.group} loop {round_i + 1}/{repeats} ===")
                steps = runnable_steps(workflow)
                for index, step in enumerate(steps):
                    self.state["plan_index"] = index
                    self.state["status"] = "ready"
                    auto = " (auto)" if step.auto else ""
                    self.runlog.pending_title = (
                        f"## Step {index + 1}/{len(steps)}",
                        f"{step.raw}{auto}",
                    )
                    if self.compile_only:
                        self._compile_only_step(workflow, step, index)
                    else:
                        yield from self._run_step(step, index=index)
                    if self.state["status"] == "blocked":
                        if step.tool == "python" and step.params.get("model"):
                            self.state["status"] = "ready"
                            continue
                        return
                for extra in workflow.extras:
                    yield from self._run_workflow(extra, announce=True)
                    if self.state["status"] == "blocked":
                        return
        finally:
            if workflow.group and self._group_stack and self._group_stack[-1] == group_key:
                self._group_stack.pop()
            self._end_group(runtime)
            self._active_workflow = previous
            if pushed and self._workflow_stack and self._workflow_stack[-1] == path:
                self._workflow_stack.pop()

    def _capture_group(self) -> dict[str, Any]:
        return {
            "env": dict(self.env),
            "os": {},
            "cdp": self.cdp_url,
            "switched_cdp": False,
            "model_workflow": self._active_workflow,
            "command_timeout": self.command_timeout,
        }

    def _apply_group(self, workflow: Workflow, state: dict[str, Any]) -> None:
        """Apply this group's config until `_end_group` restores `state`."""
        saved_env: dict[str, str] = state["env"]
        saved_os: dict[str, str | None] = state["os"]
        self.env.update(workflow.env)
        self.env["DATA"] = str(self.data_dir)
        self._export_os("DATA", str(self.data_dir), override=True, saved=saved_os)
        for key, value in workflow.env.items():
            self._export_os(key, value, override=saved_env.get(key) != value, saved=saved_os)
        group_cdp = (workflow.cdp_url or "").rstrip("/")
        if group_cdp and group_cdp != self.cdp_url:
            state["switched_cdp"] = True
            print(f"config: cdp-url={group_cdp} profile={workflow.profile or '-'}")
            self._use_cdp(group_cdp, workflow)
        parent = state["model_workflow"]
        if parent is not None and (workflow.llm, workflow.model, workflow.browser_tool_model) != (
            parent.llm,
            parent.model,
            parent.browser_tool_model,
        ):
            print(
                f"config: llm={workflow.llm or '-'} model={workflow.model or '-'} "
                f"browser-tool-model={model.resolve_browser_tool_model(workflow.browser_tool_model, self.env)}"
            )
        limit = command_timeout(workflow.command_timeout)
        if limit != self.command_timeout:
            shown = "none" if limit is None else f"{limit}s"
            print(f"config: command-timeout={shown}")
        self.command_timeout = limit
        model.configure(
            workflow.llm,
            workflow.model,
            self.env,
            timeout=workflow.llm_timeout,
            fallbacks=workflow.fallbacks,
            browser_tool_model=workflow.browser_tool_model,
        )
        if self.cdp_url:
            self.env["CDP_URL"] = self.cdp_url
            self._export_os("CDP_URL", self.cdp_url, override=True, saved=saved_os)

    def _end_group(self, state: dict[str, Any]) -> None:
        self.env.clear()
        self.env.update(state["env"])
        self.env["DATA"] = str(self.data_dir)
        self._restore_os(state["os"])
        os.environ["DATA"] = str(self.data_dir)
        if state["switched_cdp"]:
            self._use_cdp(str(state["cdp"] or ""), state["model_workflow"])
        parent = state["model_workflow"]
        if parent is not None:
            model.configure(
                parent.llm,
                parent.model,
                self.env,
                timeout=parent.llm_timeout,
                fallbacks=parent.fallbacks,
                browser_tool_model=parent.browser_tool_model,
            )
        self.command_timeout = state.get("command_timeout")

    def _export_os(
        self,
        key: str,
        value: str,
        *,
        override: bool,
        saved: dict[str, str | None] | None = None,
    ) -> None:
        """Publish one env value. Remember the previous process value so it can be restored."""
        target = self._saved_os if saved is None else saved
        if not override and key in os.environ:
            return
        if key not in target:
            target[key] = os.environ.get(key)
        os.environ[key] = value

    def _restore_os(self, saved: dict[str, str | None]) -> None:
        for key, previous in saved.items():
            if previous is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = previous

    def _use_cdp(self, cdp_url: str, workflow: Workflow | None) -> None:
        cdp = (cdp_url or "").rstrip("/")
        if self.browser is not None:
            self.browser.close()
            self.browser = None
        self.cdp_url = cdp
        if not cdp or workflow is None or not _should_open_browser(workflow, dry_run=self.dry_run):
            return
        self.browser = self._new_browser(cdp, workflow)
        self.browser.open()

    def _compile_steps(self, workflow: Workflow) -> None:
        for index, step in enumerate(runnable_steps(workflow)):
            self._compile_one(workflow, step, index)

    def _compile_one(self, workflow: Workflow, step: Step, index: int) -> None:
        from .decision import skips_script

        if step.auto:
            note_compile_attempt(
                workflow,
                step,
                index=index,
                mode="auto",
                status="skipped",
                path=None,
                elapsed_ms=0,
                result="auto mode — the agent loop runs this step",
            )
        elif skips_script(step):
            self._note_not_compiled(
                workflow,
                step,
                index,
                mode="known",
                result="known tool — local, no script",
            )
        elif is_browser_script(step) or is_python_script(step) or is_cua_script(step):
            pass
        elif step.kind not in COMPILED_KINDS:
            note_compile_attempt(
                workflow,
                step,
                index=index,
                mode="skip",
                status="skipped",
                path=None,
                elapsed_ms=0,
                result="not compiled — the agent loop runs this step",
            )
        else:
            self._ensure_step(workflow, step, index)
        for check_index, check in enumerate(step.checks, 1):
            self._compile_one(workflow, check, index * 100 + 50 + check_index)
        for sub_index, sub in enumerate(step.steps):
            self._compile_one(workflow, sub, index * 100 + sub_index + 1)

    def _compile_page(self, step: Step) -> dict[str, Any] | None:
        """The open page for a compile. Extract also keeps a short link list."""
        if step.kind == "extract":
            return self._extract_sample()
        if is_browser_script(step):
            return self._browser_sample()
        return None

    def _extract_sample(self) -> dict[str, Any] | None:
        if self.browser is None or self.dry_run:
            return self._browser_sample()
        try:
            page = self.browser.observe()
        except Exception as exc:
            return {"url": "", "title": "", "text": "", "observe_error": str(exc)}
        links: list[dict[str, str]] = []
        for action in page.get("actions") or []:
            if not isinstance(action, dict):
                continue
            href = str(action.get("href") or "")
            if not href:
                continue
            links.append({"label": str(action.get("label") or "")[:180], "href": href})
            if len(links) >= 20:
                break
        return {
            "url": str(page.get("url") or ""),
            "title": str(page.get("title") or ""),
            "text": str(page.get("text") or "")[:6000],
            "links": links,
        }

    def _browser_sample(self) -> dict[str, str] | None:
        if self.browser is None or self.dry_run:
            return None
        try:
            page = read_browser(self.browser)
        except Exception as exc:
            return {"url": "", "title": "", "text": "", "observe_error": str(exc)}
        return {
            "url": str(page.get("url") or ""),
            "title": str(page.get("title") or ""),
            "text": str(page.get("text") or "")[:4000],
        }

    def _step_ctx(self) -> dict[str, Any]:
        workflow = self._cache_workflow()
        env = dict(self.env)
        if self._step_json is not None:
            env["CG_LOOP_STEP_JSON"] = str(self._step_json)
        return {
            "env": env,
            "variables": self.variables,
            "dry_run": self.dry_run,
            "browser": self.browser,
            "cdp_url": self.cdp_url,
            "run_dir": str(self.run_dir),
            "data": str(self.data_dir),
            "data_numbers": self._data_numbers_on(),
            "timeout": self.command_timeout,
            "cwd": str(REPO_ROOT),
            "workflow_path": str(workflow.path or ""),
            "reference": str(getattr(workflow, "reference", "") or ""),
        }

    def _data_numbers_on(self) -> bool:
        from .data_numbers import data_numbers_enabled

        step = self._running_step
        return data_numbers_enabled(
            self._cache_workflow().data_numbers,
            step.raw if step is not None else "",
            self.env,
        )

    def _execution_ctx(self, step: Step, script: Path) -> dict[str, Any]:
        """Dry-run uses the same tab as an actual run when the step calls browser_helper.

        Older scripts click through Playwright themselves, so a dry-run keeps the
        browser off those steps.
        """
        ctx = self._step_ctx()
        if not ctx.get("dry_run") or not is_browser_script(step):
            return ctx
        try:
            source = script.read_text(encoding="utf-8")
        except OSError:
            source = ""
        if "browser_helper" not in source:
            ctx["browser"] = None
        return ctx

    def _apply_compiled(self, result: dict[str, Any]) -> None:
        if result.get("page") is not None:
            self.state["page"] = result["page"]
        if result.get("store_article"):
            self._store_article(str(result["store_article"]), result.get("article") or {})
        for key, value in (result.get("variables") or {}).items():
            if result.get("store_article") == key:
                continue
            self.variables[key] = value
        if result.get("blocked"):
            self.state["status"] = "blocked"

    def _run_step(self, step: Step, *, index: int = 0) -> Iterator[dict[str, Any]]:
        workflow = self._cache_workflow()
        previous_json = self._step_json
        from .trace import bind, unbind

        self._step_json = self.runlog.upcoming_step_json(workflow.group, step)
        bind(self._step_json.parent / "c-run.log")
        try:
            yield from self._run_bound_step(step, index=index, workflow=workflow, previous_json=previous_json)
        finally:
            unbind()

    def _run_bound_step(
        self,
        step: Step,
        *,
        index: int,
        workflow: Workflow,
        previous_json: Path | None,
    ) -> Iterator[dict[str, Any]]:
        try:
            script = self._script_for(workflow, step, index)
        except Exception:
            self._step_json = previous_json
            raise
        inputs = describe_inputs(step, self.env, self.variables, workflow_path=workflow.path)
        self.runlog.begin(index=index, group=workflow.group, step=step, script=script, inputs=inputs)
        outputs: dict[str, Any] = {}
        previous_step = self._running_step
        self._running_step = step
        try:
            if not self.dry_run and _step_needs_browser(step) and not (self.cdp_url or "").strip():
                raise RuntimeError("browser tool needs cdp-url")
            if step.kind == "condition":
                blocked = False
                for check_index, check in enumerate(step.checks, 1):
                    self.runlog.pending_title = (
                        f"## Condition {index + 1}.{check_index}/{len(step.checks)}",
                        check.raw,
                    )
                    yield from self._run_step(check, index=index * 100 + 50 + check_index)
                    if self.state["status"] == "blocked":
                        blocked = True
                        break
                matched = False if blocked else self._condition_matches(step)
                outputs = {
                    "condition": step.condition,
                    "matched": matched,
                    "checks": [check.raw for check in step.checks],
                }
                if blocked:
                    self.runlog.finish(status="blocked", outputs=outputs)
                    return
                if matched:
                    for sub_index, sub in enumerate(step.steps, 1):
                        self.runlog.pending_title = (
                            f"## Step {index + 1}.{sub_index}/{len(step.steps)}",
                            sub.raw,
                        )
                        yield from self._run_step(sub, index=index * 100 + sub_index)
                        if self.state["status"] == "blocked":
                            break
                else:
                    print(f"skip: {step.condition}")
                status = "blocked" if self.state["status"] == "blocked" else "ok"
                self.runlog.finish(status=status, outputs=outputs)
                return
            if step.kind == "workflow":
                self._workflow_bash = ""
                if script is not None:
                    self._execute_compiled(workflow, step, index, script)
                yield from self._run_subworkflow(step)
                outputs = {"status": self.state["status"]}
                if self._workflow_bash:
                    outputs["command"] = self._workflow_bash
            elif step.auto:
                ran_direct = (
                    not is_browser_script(step)
                    and not is_python_script(step)
                    and not is_cua_script(step)
                    and step.kind in COMPILED_KINDS
                    and self._direct_step(step)
                )
                if ran_direct:
                    last = self.variables.get("last_command")
                    outputs = last if isinstance(last, dict) else {}
                    if self.state["status"] != "blocked":
                        self.state["status"] = "ready"
                    self._stamp()
                    yield self.snapshot()
                else:
                    before = len(self.state["history"])
                    yield from self._run_goal(step)
                    outputs = self._goal_outputs(before)
            elif (
                step.kind in COMPILED_KINDS
                or is_browser_script(step)
                or is_python_script(step)
                or is_cua_script(step)
            ) and script is not None:
                result = self._execute_compiled(workflow, step, index, script)
                if result.get("delegate") == "goal":
                    before = len(self.state["history"])
                    yield from self._run_goal(step)
                    outputs = self._goal_outputs(before)
                    status = "blocked" if self.state["status"] == "blocked" else "ok"
                    self.runlog.finish(status=status, outputs=outputs)
                    return
                self._apply_compiled(result)
                outputs = dict(result.get("outputs") or {})
                if result.get("store_article"):
                    outputs[str(result["store_article"])] = self.variables.get(result["store_article"])
                if self.state["status"] != "blocked":
                    self.state["status"] = "ready"
                self._stamp()
                yield self.snapshot()
            elif self._direct_step(step):
                last = self.variables.get("last_command")
                outputs = dict(last) if isinstance(last, dict) else {}
                if step.var and step.var in self.variables and step.var not in outputs:
                    outputs[step.var] = self.variables[step.var]
                if self.state["status"] != "blocked":
                    self.state["status"] = "ready"
                self._stamp()
                yield self.snapshot()
            else:
                before = len(self.state["history"])
                yield from self._run_goal(step)
                outputs = self._goal_outputs(before)
            status = "blocked" if self.state["status"] == "blocked" else "ok"
            self.runlog.finish(status=status, outputs=outputs)
        except Exception as exc:
            outputs = {"error": str(exc)}
            shots = getattr(exc, "screenshots", None)
            if isinstance(shots, list) and shots:
                outputs["screenshots"] = [str(item) for item in shots if item]
            self.runlog.finish(status="error", outputs=outputs)
            raise
        finally:
            self._running_step = previous_step
            self._step_json = previous_json

    def _ensure_step(
        self,
        workflow: Workflow,
        step: Step,
        index: int,
        *,
        force: bool = False,
        error: str = "",
    ) -> Any:
        key = (str(workflow.path or ""), workflow.group, step.raw)
        force = self._wants_recompile(step, force=force)
        cached = self._compiled.get(key)
        if cached is not None and not force and cached.status != "failed":
            return cached
        with model.bind_compile_workflow(workflow):
            result = ensure_compiled(
                workflow,
                step,
                index=index,
                env=self.env,
                force=force,
                error=error,
                page=self._compile_page(step),
                step_json=str(self._step_json or ""),
                browser=self.browser
                if is_browser_script(step) or step.kind == "extract" or step.params.get("generate_js")
                else None,
                variables=self.variables,
                dry_run=self.dry_run,
            )
        self._compiled[key] = result
        self.runlog.note_compile(result, step_json=self._step_json)
        return result

    def _script_matching_step(self, workflow: Workflow, step: Step, index: int, script: Path) -> Path:
        """Recompile when the saved Python or JSON is a different step. Do not run that file."""
        from .compiled import _COMPILE_FRESH, validate_compiled

        problem = validate_compiled(script, step)
        if not problem or (problem not in _COMPILE_FRESH and not is_python_script(step)):
            return script
        log_compile(f"RECOMPILE {script}: {problem}", self._step_json)
        compiled = self._ensure_step(workflow, step, index, force=True, error=problem)
        if compiled.status == "failed":
            raise RuntimeError(compiled.error or problem)
        still = validate_compiled(compiled.path, step)
        if still:
            raise RuntimeError(still)
        return compiled.path

    def _wants_recompile(self, step: Step, *, force: bool = False) -> bool:
        """recompile rewrites every step. browser-recompile rewrites only /browser steps."""
        if force or self.recompile:
            return True
        return bool(self.browser_recompile and step.tool == "browser")

    def _execute_compiled(self, workflow: Workflow, step: Step, index: int, script: Path) -> dict[str, Any]:
        cached = self._compiled.get((str(workflow.path or ""), workflow.group, step.raw))
        if cached is not None and cached.status == "failed":
            raise RuntimeError(f"compiled step failed validation: {cached.error}")
        try:
            script = self._script_matching_step(workflow, step, index, script)
        except RuntimeError as exc:
            if _benchmark_python(step):
                return _blocked_python(str(exc))
            raise
        verify = str(step.params.get("verify") or "") if step.tool == "python" else ""

        def run(script_path: Path) -> dict[str, Any]:
            result = execute_compiled(
                script_path,
                self._execution_ctx(step, script_path),
                capture_stdout=bool(verify),
            )
            if verify:
                from .compiled import check_python_verify, python_named_files

                result = check_python_verify(
                    result,
                    verify,
                    files=python_named_files(step, self.env, self.variables),
                )
                if result.get("blocked"):
                    raise _VerifyMiss(result)
            return result

        try:
            return run(script)
        except _VerifyMiss as miss:
            if not self.recompile_on_error:
                return miss.result
            log_compile(f"RECOMPILE {script}: {miss}", self._step_json)
            compiled = self._ensure_step(workflow, step, index, force=True, error=str(miss))
            if compiled.status == "failed":
                return miss.result
            try:
                return run(compiled.path)
            except _VerifyMiss as again:
                self.runlog.failed_rerun += 1
                return again.result
        except Exception as exc:
            if not self.recompile_on_error:
                raise
            log_compile(f"RECOMPILE {script}: {exc}", self._step_json)
            compiled = self._ensure_step(workflow, step, index, force=True, error=_runtime_error_text(exc))
            if compiled.status == "failed":
                if _benchmark_python(step):
                    return _blocked_python(compiled.error or _runtime_error_text(exc))
                raise RuntimeError(compiled.error) from exc
            try:
                return run(compiled.path)
            except _VerifyMiss as again:
                self.runlog.failed_rerun += 1
                return again.result
            except Exception as again:
                self.runlog.failed_rerun += 1
                if _benchmark_python(step):
                    return _blocked_python(_runtime_error_text(again))
                raise

    def _new_browser(self, cdp_url: str, workflow: Workflow | None) -> Browser:
        browser = Browser(
            cdp_url,
            profile=workflow.profile if workflow else "",
            reuse_site=workflow.browser_reusetab if workflow else "",
        )
        browser.create_tabs = not self.compile_only
        return browser

    def _compile_only_step(self, workflow: Workflow, step: Step, index: int) -> None:
        """Write this step's script. The script is not executed."""
        from .trace import bind, unbind

        if step.kind == "set_config":
            print(f"COMPILE {step.raw}")
            self._direct_step(step)
            return
        previous_json = self._step_json
        self._step_json = self.runlog.upcoming_step_json(workflow.group, step)
        bind(self._step_json.parent / "c-compile.log")
        try:
            print(f"COMPILE {step.raw}")
            self._script_for(workflow, step, index)
            cached = self._compiled.get((str(workflow.path or ""), workflow.group, step.raw))
            if cached is not None and cached.status == "failed":
                self.state["status"] = "blocked"
                if cached.error:
                    print(cached.error)
                return
            if cached is not None and cached.path:
                print(f"compiled {cached.path}")
            for check_index, check in enumerate(step.checks, 1):
                self._compile_only_step(workflow, check, index * 100 + 50 + check_index)
                if self.state["status"] == "blocked":
                    return
            for sub_index, sub in enumerate(step.steps):
                self._compile_only_step(workflow, sub, index * 100 + sub_index + 1)
                if self.state["status"] == "blocked":
                    return
        finally:
            unbind()
            self._step_json = previous_json

    def _script_for(self, workflow: Workflow, step: Step, index: int) -> Path | None:
        """Compile this step now. Earlier steps have already set the page and variables."""
        from .decision import skips_script

        if step.auto:
            self._note_not_compiled(
                workflow,
                step,
                index,
                mode="auto",
                result="auto mode — the agent loop runs this step",
            )
            return None
        if is_code_step(step):
            found = find_step_script(workflow, step, env=self.env)
            if found is None:
                self._note_not_compiled(
                    workflow,
                    step,
                    index,
                    mode="skip",
                    result="code step runs from its script",
                )
            return found
        if skips_script(step):
            self._note_not_compiled(
                workflow,
                step,
                index,
                mode="known",
                result="known tool — local, no script",
            )
            return None
        if step.kind in COMPILED_KINDS or is_browser_script(step) or is_python_script(step) or is_cua_script(step):
            return self._ensure_step(workflow, step, index).path
        if step.tool in {"browser", "python"}:
            return None
        found = find_step_script(workflow, step, env=self.env) if step.kind in {"code", "goal"} else None
        if found is None:
            self._note_not_compiled(
                workflow,
                step,
                index,
                mode="skip",
                result="not compiled — the agent loop runs this step",
            )
        return found

    def _note_not_compiled(
        self,
        workflow: Workflow,
        step: Step,
        index: int,
        *,
        mode: str,
        result: str,
    ) -> None:
        note_compile_attempt(
            workflow,
            step,
            index=index,
            mode=mode,
            status="skipped",
            path=None,
            elapsed_ms=0,
            result=result,
        )

    def _goal_outputs(self, before: int) -> dict[str, Any]:
        outputs: dict[str, Any] = {"history": self.state["history"][before:]}
        tool = self.state.pop("tool_result", None)
        if isinstance(tool, dict) and isinstance(tool.get("outputs"), dict):
            outputs.update(tool["outputs"])
        if self.state.get("model_error"):
            outputs["error"] = self.state["model_error"]
        return outputs

    def _log_model_exchange(self, exchange: dict[str, Any]) -> None:
        step = self._current_step()
        workflow = self._active_workflow or self.workflow
        if step is None:
            return
        note_compile_attempt(
            workflow,
            step,
            index=int(self.state.get("plan_index") or 0),
            mode="model",
            status="failed" if exchange.get("error") else "ok",
            path=None,
            elapsed_ms=int(exchange.get("latency_ms") or 0),
            messages=exchange.get("messages"),
            thinking=str(exchange.get("thinking") or ""),
            model_result=str(exchange.get("result") or ""),
            result=str(exchange.get("parsed") or exchange.get("result") or ""),
            error=str(exchange.get("error") or ""),
            model_name=str(exchange.get("model") or ""),
            llm_ms=int(exchange.get("latency_ms") or 0),
        )

    def _run_goal(self, step: Step) -> Iterator[dict[str, Any]]:
        """Run one browser, python, term, locate, clef, hug, or cua step.

        A step with no prefix asks the local decision model which known tool to use.
        """
        from dataclasses import replace

        tool = loop_tool(step)
        if not tool:
            try:
                tool = model.choose_tool(step)
            except model.ChatError as exc:
                self.state["status"] = "blocked"
                self.state["model_error"] = str(exc)
                print(f"Stopped: {exc}")
                yield self.snapshot()
                return
        if tool not in LOOP_TOOLS:
            self.state["status"] = "blocked"
            self.state["model_error"] = (
                "Agent loop only runs browser, python, term, locate, clef, hug, and cua steps."
            )
            print(self.state["model_error"])
            yield self.snapshot()
            return
        from .python_helper import python_helper_handles
        from .workflow import python_sentence

        # The helper reads `$name` itself. Expanding it first turns `print $folder` into a path.
        if tool == "python" and python_helper_handles(python_sentence(step)):
            if step.tool != tool:
                step = replace(step, tool=tool)
        else:
            merged = {**os.environ, **self.env}
            raw = expand_command(step.raw, merged, self.variables)
            extra = expand_command(step.extra, merged, self.variables) if step.extra else step.extra
            if raw != step.raw or extra != step.extra:
                step = replace(step, raw=raw, extra=extra or step.extra, tool=tool)
            elif step.tool != tool:
                step = replace(step, tool=tool)
        if tool == "browser":
            yield from self._run_browser_tool(step)
            return
        if tool == "python":
            yield from self._run_python_tool(step)
            return
        if tool == "locate":
            yield from self._run_locate_tool(step)
            return
        if tool == "clef":
            yield from self._run_clef_tool(step)
            return
        if tool == "hug":
            yield from self._run_hug_tool(step)
            return
        if tool == "cua":
            yield from self._run_cua_tool(step)
            return
        self.state.pop("model_error", None)
        self.state["command_failures"] = 0
        self.state.pop("command_error", None)
        attempts = max(1, MAX_STEP_TICKS)
        for tick in range(1, attempts + 1):
            if len(self.state["history"]) >= MAX_STEPS:
                self.state["status"] = "blocked"
                yield self.snapshot()
                return
            print("\n🤖 generate term" if attempts == 1 else f"\n🤖 tick {tick}/{attempts}")
            try:
                yield self._tick(step)
            except StalePage as exc:
                print(f"(stale page: {exc} — observing again)")
                self.state["decision"] = None
                self.state["page"] = self._observe()
                self.state["status"] = "ready"
                yield self.snapshot()
                if tick >= attempts:
                    self.state["status"] = "blocked"
                    yield self.snapshot()
                    return
                continue
            except model.ChatError as exc:
                self.state["model_error"] = str(exc)
                self.state["status"] = "blocked"
                if exc.transport or tick >= attempts:
                    print(f"Stopped: {exc}")
                    yield self.snapshot()
                    return
                print(f"(model reply was not usable: {exc}; retrying primary)")
                self.state["status"] = "ready"
                continue
            if self.state["status"] in {"done", "blocked"}:
                if self.state["status"] == "done":
                    self.state["status"] = "ready"
                yield self.snapshot()
                return
        self.state["status"] = "blocked"
        print(f"Stopped after {attempts} term generation{'s' if attempts != 1 else ''}.")
        yield self.snapshot()

    def _run_browser_tool(self, step: Step) -> Iterator[dict[str, Any]]:
        """Run this browser step until its goal is met."""
        from .browser_helper import browser_helper

        if self.browser is None:
            if self.dry_run:
                print(f"DRY-RUN BROWSER {step.raw}")
                self.state["status"] = "ready"
                yield self.snapshot()
                return
            raise RuntimeError(f"browser tool needs a CDP session ({self.cdp_url or 'no cdp-url'})")
        workflow = self._cache_workflow()
        result = browser_helper(
            step.raw,
            self.browser,
            dry_run=self.dry_run,
            env=self.env,
            variables=self.variables,
            reference=str(getattr(workflow, "reference", "") or ""),
            workflow_path=str(workflow.path or ""),
            max_steps=1,
        )
        self._finish_tool(result)
        yield self.snapshot()

    def _run_python_tool(self, step: Step) -> Iterator[dict[str, Any]]:
        """One python generation. The helper writes the marker named in the step."""
        from .python_helper import python_helper

        from .workflow import python_sentence

        result = python_helper(
            python_sentence(step),
            dry_run=self.dry_run,
            env=self.env,
            variables=self.variables,
            browser=self.browser,
            cdp_url=self.cdp_url,
        )
        verify = str(step.params.get("verify") or "")
        if verify:
            from .compiled import check_python_verify, python_named_files

            result = check_python_verify(
                result,
                verify,
                files=python_named_files(step, self.env, self.variables),
            )
        self._finish_tool(result)
        yield self.snapshot()

    def _run_locate_tool(self, step: Step) -> Iterator[dict[str, Any]]:
        """Find one thing in an image and store its pixel position."""
        result = run_locate(
            self._step_ctx(),
            query=step.extra,
            image=step.command,
            var=step.var,
        )
        self._finish_tool(result)
        yield self.snapshot()

    def _run_clef_tool(self, step: Step) -> Iterator[dict[str, Any]]:
        """Ask Clef about the open page. `+verify` blocks the step on a mismatch."""
        from .clef import parse_clef_command

        if step.kind == "clef":
            question = step.extra
            options = list(step.params.get("options") or [])
            verify = str(step.params.get("verify") or "")
            image = str(step.params.get("image") or "")
            var = step.var
        else:
            question, options, verify, image, var = parse_clef_command(step_body(step) or step.raw)
        result = run_clef(
            self._step_ctx(),
            question=question,
            options=options,
            verify=verify,
            image=image,
            var=var,
        )
        self._finish_tool(result)
        yield self.snapshot()

    def _run_hug_tool(self, step: Step) -> Iterator[dict[str, Any]]:
        """Ask one Hugging Face model. `hug-model` fills in `+model` when the step omits it."""
        from .hug import parse_hug_command

        if step.kind == "hug":
            model = step.command
            message = step.extra
            files = list(step.params.get("files") or [])
            out = str(step.params.get("out") or "")
            var = step.var
            printed = bool(step.params.get("print"))
            extra = {
                key: value
                for key, value in step.params.items()
                if key not in {"files", "out", "print"}
            }
        else:
            call = parse_hug_command(step_body(step) or step.raw)
            model = call.model
            message = call.message
            files = list(call.files)
            out = call.out
            var = call.var
            printed = call.printed
            extra = dict(call.extra or {})
        result = run_hug(
            self._step_ctx(),
            model=model,
            message=message,
            files=files,
            out=out,
            var=var,
            printed=printed,
            extra=extra,
        )
        self._finish_tool(result)
        yield self.snapshot()

    def _run_cua_tool(self, step: Step) -> Iterator[dict[str, Any]]:
        """Run a cua sentence with the local cua tool. No generated script."""
        from .compiled import run_cua
        from .cua import compile_cua_actions, replay_cua_actions

        if step.kind != "goal":
            result = run_cua(
                self._step_ctx(),
                action=step.extra,
                app=str(step.params.get("app") or ""),
                url=step.url,
                label=str(step.params.get("label") or ""),
                text=str(step.params.get("text") or ""),
                var=step.var,
            )
            self._finish_tool(result)
            yield self.snapshot()
            return
        if self.dry_run:
            print(f"DRY-RUN CUA {step.raw}")
            self.state["status"] = "ready"
            yield self.snapshot()
            return
        compiled = compile_cua_actions(step.raw)
        detail = str(compiled.get("error") or "")
        actions = compiled.get("actions") or []
        if detail or not actions:
            self.state["status"] = "blocked"
            self.state["model_error"] = detail or "Laya returned no cua actions."
            print(self.state["model_error"])
            yield self.snapshot()
            return
        result = replay_cua_actions(
            step.raw,
            actions,
            dry_run=self.dry_run,
            env=self.env,
            variables=self.variables,
        )
        self._finish_tool(result)
        yield self.snapshot()

    def _finish_tool(self, result: dict[str, Any]) -> None:
        self.state["tool_result"] = result
        self._apply_compiled(result)
        outputs = result.get("outputs") if isinstance(result.get("outputs"), dict) else {}
        blocked = bool(result.get("blocked")) or str(outputs.get("status") or result.get("status") or "") == "blocked"
        self.state["status"] = "blocked" if blocked else "ready"
        self._stamp()

    def _direct_step(self, step: Step) -> bool:
        if step.kind == "goto":
            self._act_goto(step.url)
            return True
        if step.kind == "reuse_tab":
            if self.dry_run and not self.browser:
                print(f"DRY-RUN REUSE_TAB {step.extra}")
                return True
            if not self.browser:
                raise RuntimeError("reuseTab needs a browser CDP session")
            self.state["page"] = self.browser.reuse_tab(step.extra)
            return True
        if step.kind == "browser_js":
            if step.params.get("generate_js"):
                return False
            from .compiled import run_browser_js

            result = run_browser_js(self._step_ctx(), step.extra, step.var)
            self._apply_compiled(result)
            self.variables["last_command"] = result.get("outputs") or {}
            if result.get("blocked"):
                self.state["status"] = "blocked"
            return True
        if step.kind == "browser_gemma":
            from .compiled import run_browser_gemma

            result = run_browser_gemma(self._step_ctx(), step.command, step.extra, step.var)
            self._apply_compiled(result)
            self.variables["last_command"] = result.get("outputs") or {}
            if result.get("blocked"):
                self.state["status"] = "blocked"
            return True
        if step.kind == "openrouter":
            from .compiled import run_openrouter

            result = run_openrouter(self._step_ctx(), step.command, step.extra, step.var)
            self._apply_compiled(result)
            self.variables["last_command"] = result.get("outputs") or {}
            if result.get("blocked"):
                self.state["status"] = "blocked"
            return True
        if step.kind == "lmstudio":
            from .compiled import run_lmstudio

            result = run_lmstudio(self._step_ctx(), step.command, step.extra, step.var)
            self._apply_compiled(result)
            self.variables["last_command"] = result.get("outputs") or {}
            if result.get("blocked"):
                self.state["status"] = "blocked"
            return True
        if step.kind == "load":
            self._act_load(step)
            return True
        if step.kind == "extract":
            if not self.browser:
                if self.dry_run:
                    print("DRY-RUN EXTRACT (no browser)")
                    self.variables[step.var or "article"] = {
                        "title": "(dry-run)",
                        "url": "https://example.com/dry-run",
                        "text": "(dry-run)",
                    }
                    return True
                raise RuntimeError("extract needs a browser CDP session")
            page = self._observe()
            article = article_from_page(
                page,
                phrase=step.extra,
                skip_urls=skip_url_set(self.variables, step.extra),
            )
            if article:
                self._store_article(step.var or "article", article)
                return True
            print("EXTRACT: no unused URL in the observed list")
            self.state["status"] = "blocked"
            return True
        if step.kind == "llm_call":
            self._act_llm_call(step)
            return True
        if step.kind == "generate":
            self._act_generate(step)
            return True
        if step.kind == "term":
            result = self._act_term(step.command)
            if result.get("status") not in {"completed", "proposed"}:
                self.state["status"] = "blocked"
            return True
        if step.kind == "locate":
            result = run_locate(
                self._step_ctx(),
                query=step.extra,
                image=step.command,
                var=step.var,
            )
            self._apply_compiled(result)
            if result.get("blocked"):
                self.state["status"] = "blocked"
            return True
        if step.kind == "clef":
            result = run_clef(
                self._step_ctx(),
                question=step.extra,
                options=list(step.params.get("options") or []),
                verify=str(step.params.get("verify") or ""),
                image=str(step.params.get("image") or ""),
                var=step.var,
            )
            self._apply_compiled(result)
            self.variables["last_command"] = result.get("outputs") or {}
            if result.get("blocked"):
                self.state["status"] = "blocked"
            return True
        if step.kind == "hug":
            result = run_hug(
                self._step_ctx(),
                model=step.command,
                message=step.extra,
                files=list(step.params.get("files") or []),
                out=str(step.params.get("out") or ""),
                var=step.var,
                printed=bool(step.params.get("print")),
                extra={
                    key: value
                    for key, value in step.params.items()
                    if key not in {"files", "out", "print"}
                },
            )
            self._apply_compiled(result)
            self.variables["last_command"] = result.get("outputs") or {}
            if result.get("blocked"):
                self.state["status"] = "blocked"
            return True
        if step.kind == "cua":
            from .compiled import run_cua

            result = run_cua(
                self._step_ctx(),
                action=step.extra,
                app=str(step.params.get("app") or ""),
                url=step.url,
                label=str(step.params.get("label") or ""),
                text=str(step.params.get("text") or ""),
                var=step.var,
            )
            self._apply_compiled(result)
            if result.get("blocked"):
                self.state["status"] = "blocked"
            return True
        if step.kind == "set_config":
            # One line can set several values. A value already on the workflow,
            # including a --param override, wins.
            shown = [self._apply_config_pair(key, value) for key, value in set_config_pairs(step)]
            print("SET_CONFIG " + ", ".join(shown))
            return True
        if step.tool not in {"browser", "python"} and (
            is_code_step(step) or (step.kind == "goal" and find_step_script(self._cache_workflow(), step, env=self.env))
        ):
            self._act_cached_step(step)
            return True
        return False

    def _tick(self, step: Step) -> dict[str, Any]:
        if step.tool not in {"browser", "python"} and step.kind == "goal":
            page = self.state.get("page") or {"url": "", "title": "", "text": "", "actions": []}
            decision = {
                "choice": "TERM",
                "operation": "TERM",
                "target": None,
                "confidence": 1,
                "probabilities": {"TERM": 1},
                "command": "",
                "targets": {},
                "controls": {"TERM": {"id": "TERM", "kind": "term"}},
                "operations": {"TERM": "code"},
            }
            self.state["decision"] = decision
            self.state["status"] = "predicted"
            return self._act(step, decision, page)
        page = self._observe()
        fast = self._fast_path(step, page)
        if fast:
            decision = fast
        else:
            decision = model.choose(
                page,
                step,
                self.state["history"],
                self.variables,
                command_catalog=self.catalog,
                plan=self.workflow.plan_text(),
            )
        self.state["decision"] = decision
        self.state["status"] = "predicted"
        if self.pause:
            input("Choose next — press Enter to execute: ")
        return self._act(step, decision, page)

    def _fast_path(self, step: Step, page: dict[str, Any]) -> dict[str, Any] | None:
        elements, targets, controls = model.action_space(
            page, step, self.variables, command_catalog=self.catalog
        )
        if step.kind == "extract" and "EXTRACT" in targets:
            first = next(iter(targets["EXTRACT"].values()))
            return {
                "choice": first["id"],
                "operation": "EXTRACT",
                "target": "1",
                "confidence": 1,
                "probabilities": {first["id"]: 1},
                "elements": elements,
                "targets": targets,
                "controls": controls,
                "fast_path": True,
            }
        native = {
            "goto": "GOTO",
            "term": "TERM",
            "llm_call": "LLM_CALL",
            "generate": "GENERATE",
        }.get(step.kind)
        if native and native in controls and not targets.get("CLICK"):
            action = controls[native]
            return {
                "choice": action["id"],
                "operation": native,
                "target": None,
                "confidence": 1,
                "probabilities": {action["id"]: 1},
                "elements": elements,
                "targets": targets,
                "controls": controls,
                "fast_path": True,
            }
        return None

    def _act(self, step: Step, decision: dict[str, Any], page: dict[str, Any]) -> dict[str, Any]:
        operation = decision["operation"]
        selected = decision["choice"]
        text = None
        command = None
        article = None
        helper = None
        if operation in {"DONE", "BLOCKED"}:
            self.state["status"] = "done" if operation == "DONE" else "blocked"
            self._record(step, decision, page, text=None, command=None)
            return self.snapshot()
        action = self._resolve_action(decision)
        if operation == "TYPE_TEXT":
            context = {
                "goal": step.raw,
                "field": {k: action.get(k) for k in ("label", "role", "value")},
                "page": {"title": page.get("title"), "text": str(page.get("text") or "")[:6000]},
                "variables": model._public_vars(self.variables),
            }
            text, helper = model.field_text(context)
        if operation == "TERM":
            prior = self.state.get("command_error") or {}
            fallback = action.get("command") or step.command or str(decision.get("command") or "")
            if prior and fallback.strip() == str(prior.get("command") or "").strip():
                fallback = ""
            command_context = {
                "step": expand_command(step.raw, {**os.environ, **self.env}, self.variables),
                "catalog": self.catalog[:4000],
                "variables": model._public_vars(self.variables),
                "env": model.public_env(self.env),
            }
            if prior:
                command_context["previous_command"] = prior.get("command") or ""
                command_context["error"] = prior.get("error") or ""
            command, helper = model.term_command(command_context, fallback=fallback)
        if self.dry_run:
            print(f"DRY-RUN {operation} {selected} {text or command or action.get('label') or ''}")
            self.state["status"] = "done" if step.kind != "goal" else "ready"
            self._record(step, decision, page, text=text, command=command)
            return self.snapshot()

        if operation == "GOTO":
            self._act_goto(str(decision.get("url") or "") or action.get("url") or step.url)
        elif operation in {"RELOAD", "BACK", "FORWARD", "PRESS"}:
            if not self.browser:
                raise RuntimeError("Browser action requested but no CDP session is open")
            action = {**action, "kind": "press" if operation == "PRESS" else operation.lower()}
            if operation == "PRESS":
                action["key"] = str(decision.get("key") or action.get("key") or "")
            self.browser.act(action, page)
            self.state["status"] = "ready"
            self.state["page"] = self._observe()
        elif operation == "EXTRACT":
            article = action.get("article") or article_from_page(
                page,
                phrase=step.extra,
                skip_urls=skip_url_set(self.variables, step.extra),
            )
            if not article:
                raise StalePage("No article to extract")
            self._store_article(step.var or action.get("var") or "article", article)
            self.state["status"] = "done"
        elif operation == "LLM_CALL":
            self._act_llm_call(step)
            self.state["status"] = "done"
        elif operation == "GENERATE":
            self._act_generate(step)
            self.state["status"] = "done"
        elif operation == "TERM":
            result = self._act_term(command or "")
            if result.get("status") in {"completed", "proposed"}:
                self.state["status"] = "done"
                self.state["command_failures"] = 0
                self.state.pop("command_error", None)
                self._cache_generated_command(step, command or result.get("command") or "")
            else:
                detail = (result.get("stderr") or result.get("error") or result.get("status") or "failed").strip()
                failures = int(self.state.get("command_failures") or 0) + 1
                self.state["command_failures"] = failures
                self.state["command_error"] = {
                    "command": result.get("command") or command or "",
                    "error": detail[-1500:],
                    "exit_code": result.get("exit_code"),
                }
                retry = failures < min(3, max(1, MAX_STEP_TICKS))
                self.state["status"] = "ready" if retry else "blocked"
                note = "regenerating" if retry else "stopping"
                print(
                    f"command failed ({result.get('exit_code', result.get('status'))}); {note}\n{detail[-500:]}"
                )
        elif operation in {"CLICK", "TYPE_TEXT", "SELECT", "SCROLL_UP", "SCROLL_DOWN", "WAIT"}:
            if not self.browser:
                raise RuntimeError("Browser action requested but no CDP session is open")
            if action.get("kind") == "scroll" and not action.get("delta"):
                action = {**action, "delta": 560 if operation == "SCROLL_DOWN" else -560}
            result = self.browser.act(action, page, text=text)
            href = str(result.get("href") or "")
            if step.kind == "extract" and href.startswith("http"):
                self._store_article(
                    step.var or "article",
                    {"title": action.get("label") or href, "url": href, "text": "", "summary": ""},
                )
                self.state["status"] = "done"
            else:
                self.state["status"] = "ready"
            self.state["page"] = self._observe()
        else:
            raise ValueError(f"Unknown operation {operation}")

        self._record(
            step,
            decision,
            page,
            text=text,
            command=command,
            helper=helper,
            article=article,
        )
        return self.snapshot()

    def _resolve_action(self, decision: dict[str, Any]) -> dict[str, Any]:
        operation = decision["operation"]
        targets = decision.get("targets") or {}
        controls = decision.get("controls") or {}
        if operation in targets and decision.get("target") in targets[operation]:
            return targets[operation][decision["target"]]
        if operation in controls:
            return controls[operation]
        page = self.state.get("page") or {}
        for action in page.get("actions") or []:
            if action.get("id") == decision["choice"]:
                return action
        return {"id": decision["choice"], "kind": operation.lower()}

    def _act_load(self, step: Step) -> None:
        roots = [
            expand_command(token, {**os.environ, **self.env}, self.variables)
            for token in step.roots
        ]
        urls = load_previous_urls(roots, filter_text=step.extra)
        self.variables[step.var or "seen"] = urls
        print(f"LOAD ${step.var or 'seen'} {len(urls)} urls from {roots}")

    def _act_goto(self, url: str) -> None:
        from .terminal import expand_url

        if not url:
            raise ValueError("goto missing URL")
        url = expand_url(url, {**os.environ, **self.env}, self.variables)
        print(f"GOTO {url}")
        if self.dry_run:
            return
        if not self.browser:
            raise RuntimeError(f"goto needs a browser CDP session ({self.cdp_url or 'no cdp-url'})")
        self.state["page"] = self.browser.goto(url)

    def _act_term(self, command: str, *, extra_env: dict[str, str] | None = None) -> dict[str, Any]:
        expanded = expand_command(command, {**os.environ, **self.env}, self.variables)
        article = self.variables.get("article")
        env = cache_env(Step(kind="term", raw=""), self.variables, dict(self.env))
        if extra_env:
            env.update(extra_env)
        if isinstance(article, dict) and article.get("title"):
            env.setdefault("TOPIC", str(article["title"]))
        if self.dry_run:
            print(f"DRY-RUN TERM {expanded}")
            result = {"status": "proposed", "command": expanded}
            self.variables["last_command"] = result
            return result
        # A term such as the YouTube uploader opens its own CDP client. Drop this
        # one first so the two drivers do not both dismiss the same script dialog.
        paused = self._pause_browser()
        try:
            result = run_command(
                expanded,
                timeout=self.command_timeout,
                cwd=str(REPO_ROOT),
                env=env,
            )
        finally:
            if paused:
                try:
                    self._resume_browser()
                except Exception as exc:
                    print(f"CDP reconnect failed: {exc}", flush=True)
        self.variables["last_command"] = result
        if result.get("status") == "completed":
            from .compiled import keep_picked_story

            keep_picked_story(self.variables, str(result.get("stdout") or ""))
        return result

    def _pause_browser(self) -> bool:
        browser = self.browser
        if browser is None or getattr(browser, "_pw", None) is None:
            return False
        browser.close()
        return True

    def _resume_browser(self) -> None:
        browser = self.browser
        if browser is None:
            return
        browser.open()

    def _cache_workflow(self) -> Workflow:
        return self._active_workflow or self.workflow

    def _act_cached_step(self, step: Step) -> None:
        workflow = self._cache_workflow()
        path = find_step_script(workflow, step, env=self.env)
        if path is None:
            if self.dry_run:
                planned = step_cache_path(workflow, step, env=self.env)
                print(f"DRY-RUN generate step script → {planned}")
                self.variables["last_command"] = {
                    "status": "proposed",
                    "command": invoke_command(planned),
                }
                return
            path = self._generate_step_script(step)
        print(f"CACHE {path}")
        result = self._act_term(invoke_command(path), extra_env=cache_env(step, self.variables, self.env))
        if result.get("status") not in {"completed", "proposed"}:
            self.state["status"] = "blocked"

    def _generate_step_script(self, step: Step) -> Path:
        workflow = self._cache_workflow()
        path = step_cache_path(workflow, step, env=self.env)
        language = "python" if path.suffix.lower() == ".py" else "shell"
        print(f"GENERATE STEP SCRIPT {path}")
        body = model.write_step_script(
            {
                "workflow": workflow.name,
                "workflow_file": str(workflow.path or ""),
                "step": step.raw,
                "msg": step.workflow_name or step.raw,
                "language": language,
                "params": step.params,
                "env": self.env,
                "variables": model._public_vars(self.variables),
                "catalog": self.catalog[:4000],
            }
        )
        return write_step_script(path, body, language=language)

    def _cache_generated_command(self, step: Step, command: str) -> None:
        if step.tool in {"browser", "python"} or step.kind not in {"goal", "code"}:
            return
        workflow = self._cache_workflow()
        existing = find_step_script(workflow, step, env=self.env)
        if not should_cache_command(command, existing):
            return
        path = existing or step_cache_path(workflow, step, env=self.env)
        language = "python" if path.suffix.lower() == ".py" else "shell"
        write_step_script(path, script_from_command(command), language=language)
        print(f"CACHE WRITE {path}")

    def _act_llm_call(self, step: Step) -> Path:
        template_name = step.template or "story.md"
        article = self.variables.get(step.var or "article")
        source = format_article(article if isinstance(article, dict) else {"text": str(article or "")})
        prompt = _template_prompt(template_name, self.workflow.path) or STORY_PROMPT.format(article=source)
        if "{article}" in prompt:
            prompt = prompt.format(article=source)
        elif source and source not in prompt:
            prompt = prompt.rstrip() + "\n\nArticle:\n" + source
        print(f"LLM_CALL {template_name}")
        out = self.run_dir / Path(template_name).name
        if self.dry_run:
            out.write_text(f"(dry-run prompt)\n{prompt[:1000]}\n", encoding="utf-8")
        else:
            out.write_text(model.llm_write(prompt) + "\n", encoding="utf-8")
        self.variables["story_md"] = str(out)
        self.variables[Path(template_name).stem] = str(out)
        print(f"→ {out}")
        return out

    def _act_generate(self, step: Step) -> None:
        if not (step.extra or "").lower().startswith("story"):
            self._apply_compiled(run_generate(self._step_ctx(), var=step.var, extra=step.extra))
            return
        article = self.variables.get(step.var or "article") or {}
        if not isinstance(article, dict):
            article = {"text": str(article)}
        args = [str(REMIX_RUN)]
        if article.get("url"):
            args.append(str(article["url"]))
        elif article.get("text"):
            args.extend(["--text", str(article["text"])])
        elif self.dry_run:
            print("DRY-RUN GENERATE (no article yet)")
            return
        else:
            raise ValueError("generate story needs $article url or text")
        args.append("--story-only")
        command = " ".join(shlex.quote(part) for part in args)
        print(f"GENERATE {command}")
        result = self._act_term(command)
        if result.get("status") not in {"completed", "proposed"}:
            self.state["status"] = "blocked"
        else:
            self.variables["story_dir"] = _output_folder(result.get("stdout") or "")

    def _store_article(self, name: str, article: dict[str, Any]) -> None:
        article = dict(article)
        article = _enrich_article(article)
        self.variables[name] = article
        path = self.run_dir / f"{name}.json"
        path.write_text(json.dumps(article, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"EXTRACT ${name} → {article.get('title')} {article.get('url')}")

    def _observe(self) -> dict[str, Any]:
        if not self.browser:
            page = {"url": "", "title": "", "text": "", "html": "", "actions": []}
            self.state["page"] = page
            return page
        page = self.browser.observe()
        self.state["page"] = page
        return page

    def _condition_matches(self, step: Step) -> bool:
        text = (step.condition or "").strip()
        if not text:
            return True
        if self.dry_run:
            print(f"DRY-RUN CONDITION {text}")
            return True
        picked = _picked_story(text, self.variables)
        if picked is not None:
            print(f"CONDITION {text}: {str(picked).lower()}")
            return picked
        return self._condition_via_tool(text)

    def _condition_via_tool(self, text: str) -> bool:
        """Ask Layla which tool can decide this check, then run that tool.

        The loop does not call a chat model. A folder count is python.
        """
        from .decision import decide_message
        from .python_helper import folder_condition

        decision = decide_message(
            text,
            phase="execute",
            skip=frozenset({"condition"}),
            rules=[
                "This is a check. Pick the tool that can decide whether it is true.",
                "Count folders or compare values with python.",
            ],
        )
        tool = decision.tool
        print(f"CONDITION tool={tool}")
        result = folder_condition(text, self.env)
        if result is None:
            if tool != "python":
                raise ValueError(f"condition check needs python; decision model picked {tool}")
            raise ValueError(f"python cannot check this condition: {text}")
        if tool != "python":
            print(f"CONDITION {tool} cannot count folders; python counted them")
        print(f"CONDITION {text}: {str(result).lower()}")
        return result

    def _current_step(self) -> Step | None:
        if self._running_step is not None:
            return self._running_step
        index = int(self.state.get("plan_index") or 0)
        steps = (self._active_workflow or self.workflow).steps
        if 0 <= index < len(steps):
            return steps[index]
        return None

    def _run_subworkflow(self, step: Step) -> Iterator[dict[str, Any]]:
        env = {**os.environ, **self.env}
        name = expand_command(step.workflow_name, env, self.variables)
        params = {
            key: expand_command(value, env, self.variables) if isinstance(value, str) else value
            for key, value in step.params.items()
        }
        lookup = dict(params)
        if step.workflow_ref:
            lookup.setdefault("workflow", expand_command(step.workflow_ref, env, self.variables))
        nested = resolve_subworkflow(
            step,
            env=self.env,
            parent=self._active_workflow,
            stack=tuple(self._workflow_stack),
            name=name,
            params=lookup,
        )
        command = workflow_bash_command(nested, params)
        self._workflow_bash = command
        self.runlog.note_command(command)
        if not self.dry_run:
            result = run_command(
                command,
                timeout=command_timeout(nested.command_timeout),
                env=self.env,
                confirm=False,
            )
            self.variables["last_command"] = result
            if result.get("status") != "completed":
                detail = result.get("stderr") or result.get("error") or result.get("message") or "workflow run failed"
                self.state["status"] = "blocked"
                self.state["command_error"] = {"error": detail, "command": command}
            return
        print_command(command)
        loops = max(1, nested.loop_count)
        for round_i in range(loops):
            if round_i:
                time.sleep(max(0.0, nested.loop_delay))
                print(f"\n=== sub-loop {round_i + 1}/{loops} ===")
            yield from self._run_workflow(nested, announce=True)
            if self.state["status"] == "blocked":
                return

    def _record(
        self,
        step: Step,
        decision: dict[str, Any],
        page: dict[str, Any],
        *,
        text: str | None,
        command: str | None,
        helper: dict[str, Any] | None = None,
        article: dict[str, Any] | None = None,
    ) -> None:
        self._stamp()
        self.state["history"].append(
            {
                "step": step.raw,
                "action": decision.get("choice"),
                "kind": decision.get("operation"),
                "text": text,
                "command": command,
                "error": (self.state.get("command_error") or {}).get("error"),
                "article": (article or {}).get("url") if article else None,
                "page_changed": None,
                "url": (page or {}).get("url"),
                "elapsed_ms": self.state["elapsed_ms"],
                "helper": helper,
            }
        )
        self.state["decision"] = None

    def _stamp(self) -> None:
        started = self.state.get("started_at")
        if started is None:
            self.state["started_at"] = time.perf_counter()
            started = self.state["started_at"]
        self.state["elapsed_ms"] = round((time.perf_counter() - started) * 1000)

    def _needs_browser(self) -> bool:
        return _workflow_needs_browser(self.workflow)

    def _apply_config_pair(self, key: str, value: str) -> str:
        """Apply one config assignment and return the text to print for it."""
        alias = config_alias_key(key)
        if alias and CONFIG_ALIASES[alias] == "browser_reusetab":
            return self._apply_reusetab_config(alias, value)
        if alias:
            workflow = self._active_workflow or self.workflow
            if CONFIG_ALIASES[alias] == "cdp_url" and not (self.cdp_url or workflow.cdp_url):
                apply_overrides(workflow, {alias: value})
                self._use_cdp(value, workflow)
                if self.cdp_url:
                    self.env["CDP_URL"] = self.cdp_url
                    self._export_os("CDP_URL", self.cdp_url, override=True)
            live = live_config_value(workflow, alias, cdp_url=self.cdp_url)
            return f"{alias}={live if live != '' else value}"
        if key not in self.env:
            self.env[key] = value
            self._export_os(key, value, override=True)
        return f"{key}={self.env[key]}"

    def _apply_reusetab_config(self, alias: str, value: str) -> str:
        """`set-config browser-reusetab=` attaches later browser steps to that site."""
        workflow = self._active_workflow or self.workflow
        if "browser_reusetab" not in workflow.config_locks:
            apply_overrides(workflow, {alias: value})
            site = workflow.browser_reusetab
            if site:
                if self.dry_run and not self.browser:
                    print(f"DRY-RUN REUSE_TAB {site}")
                elif not self.browser:
                    raise RuntimeError("reuseTab needs a browser CDP session")
                else:
                    self.state["page"] = self.browser.reuse_tab(site)
        live = live_config_value(workflow, alias, cdp_url=self.cdp_url)
        return f"{alias}={live if live != '' else value}"


def _sets_reusetab(step: Step) -> bool:
    return any(
        CONFIG_ALIASES.get(config_alias_key(key)) == "browser_reusetab"
        for key, _value in set_config_pairs(step)
    )


def _step_needs_browser(step: Step) -> bool:
    """True when this step drives the page and therefore needs cdp-url."""
    if _sets_reusetab(step):
        return True
    if step.tool == "browser":
        return True
    return step.kind in {"goto", "extract", "reuse_tab", "browser_js", "browser_gemma"}


def _workflow_needs_browser(workflow: Workflow) -> bool:
    for step in workflow.all_steps():
        if _sets_reusetab(step):
            return True
        if step.kind in {"goto", "extract", "goal", "reuse_tab", "browser_js", "browser_gemma"}:
            return True
        if step.kind == "workflow" and step.nested is None:
            return True
    return False


def _should_open_browser(workflow: Workflow, *, dry_run: bool) -> bool:
    """Actual runs attach whenever a step needs the browser.

    A dry-run attaches only for `/browser` steps, so that helper sees the same
    tab an actual run would, and other workflows stay offline.
    """
    if not _workflow_needs_browser(workflow):
        return False
    if not dry_run:
        return True
    return any(is_browser_script(step) for step in workflow.all_steps())


def _load_catalog() -> str:
    try:
        return CATALOG_PATH.read_text(encoding="utf-8")
    except OSError:
        return ""


def _template_prompt(name: str, workflow_path: Path | None) -> str | None:
    candidates = []
    if workflow_path:
        candidates.append(workflow_path.parent / name)
    candidates.extend(
        [
            SKILL_ROOT / "references" / name,
            SKILL_ROOT / name,
        ]
    )
    for path in candidates:
        if path.is_file():
            return path.read_text(encoding="utf-8")
    return None


def _enrich_article(article: dict[str, Any]) -> dict[str, Any]:
    url = str(article.get("url") or "")
    text = str(article.get("text") or "")
    if not url or len(text) > 400:
        return article
    try:
        import sys

        remix_lib = project_root() / "skills" / "cg-remix-article" / "lib"
        if str(remix_lib) not in sys.path:
            sys.path.insert(0, str(remix_lib))
        from cg_remix_article.fetch import load_source

        loaded = load_source(source=url)
        if loaded.get("text"):
            article["text"] = loaded["text"]
        if loaded.get("title") and not article.get("title"):
            article["title"] = loaded["title"]
    except Exception as exc:
        print(f"(article fetch skipped: {exc})")
    return article


def _picked_story(text: str, variables: dict[str, Any]) -> bool | None:
    """True when this condition is the picked story or short, and that folder was found."""
    lowered = (text or "").lower()
    if "found" not in lowered:
        return None
    if "short_folder" in lowered:
        key = "short_folder"
    elif "story_folder" in lowered:
        key = "story_folder"
    else:
        return None
    folder = str(variables.get(key) or "").strip()
    return bool(folder) and folder.lower() not in {"none", "null"}


def _output_folder(stdout: str) -> str:
    for line in reversed(stdout.splitlines()):
        if line.startswith("Output folder:"):
            return line.split(":", 1)[1].strip()
    return ""
