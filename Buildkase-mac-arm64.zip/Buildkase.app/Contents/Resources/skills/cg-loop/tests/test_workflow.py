#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

from cg_loop.workflow import (  # noqa: E402
    apply_overrides,
    load_workflow,
    parse_set_config_items,
    parse_step,
    parse_steps,
    set_config_pairs,
    project_root,
    select_step_at_line,
    select_steps_between,
    step_body,
)

WORKFLOWS = project_root() / "workflows"
YAML = WORKFLOWS / "wf-research-content.yaml"


class WorkflowTests(unittest.TestCase):
    def test_parse_research_yaml(self) -> None:
        wf = load_workflow(YAML)
        self.assertEqual(wf.name, "research content")
        self.assertEqual(wf.profile, "")
        self.assertEqual(wf.cdp_url, "")
        self.assertEqual(wf.loop_count, 1)
        self.assertEqual(wf.loop_delay, 0.0)
        self.assertEqual(wf.log_keep, 5)
        self.assertEqual(wf.extras[0].log_keep, 5)
        self.assertIn("SLIDES_SCRIPT", wf.env)
        self.assertEqual(wf.group, "")
        self.assertEqual(wf.steps, [])
        self.assertIn("DRAFT_ROOT", wf.env)
        self.assertIn("APPROVED_ROOT", wf.env)
        self.assertEqual(
            [extra.group for extra in wf.extras],
            [
                "generate_content_routine",
                "generate_content2_routine",
                "research_routine",
                "research_idea_routine",
                "research_idea_heart_studies_routine",
                "yahoo_news_routine",
            ],
        )
        content = wf.named_groups()["generate_content_routine"]
        self.assertEqual([step.kind for step in content.steps], ["condition", "condition"])
        self.assertEqual(
            content.steps[0].condition,
            "folders in $DRAFT_ROOT of type idea-heart < 5",
        )
        self.assertEqual(content.steps[0].steps[0].workflow_ref, "research_idea_routine")
        self.assertEqual(content.steps[0].steps[0].params["DRAFT_TYPE"], "idea-heart")
        self.assertEqual(
            content.steps[1].condition,
            "folders in $DRAFT_ROOT of type yahoo-heart < 5",
        )
        self.assertEqual(content.steps[1].steps[0].workflow_ref, "yahoo_news_routine")
        self.assertEqual(content.steps[1].steps[0].params["profile"], "yuba-heart")
        self.assertEqual(content.steps[1].steps[0].params["DRAFT_TYPE"], "yahoo-heart")
        self.assertEqual(content.steps[1].steps[0].nested.group, "yahoo_news_routine")
        older = wf.named_groups()["generate_content2_routine"]
        self.assertEqual(
            older.steps[0].condition,
            "folders in $DRAFT_ROOT of type research-heart < 2",
        )
        self.assertEqual(older.steps[0].steps[0].params["profile"], "yuba-heart")
        self.assertEqual(older.steps[0].steps[0].params["DRAFT_TYPE"], "research-heart")
        self.assertEqual(
            older.steps[1].condition,
            "folders in $DRAFT_ROOT of type research-social < 2",
        )
        self.assertEqual(older.steps[1].steps[0].params["profile"], "yuba-social")
        self.assertEqual(older.steps[1].steps[0].params["DRAFT_TYPE"], "research-social")
        self.assertEqual(older.steps[1].steps[0].workflow_ref, "research_routine")
        self.assertEqual(
            older.steps[2].condition,
            "folders in $DRAFT_STORIES < 5",
        )
        self.assertEqual(
            wf.env["DRAFT_STORIES"],
            "/Users/nghia/Downloads/workspace/mocks_out/draft_sleep",
        )
        self.assertEqual(
            wf.env["APPROVED_STORIES"],
            "/Users/nghia/Downloads/workspace/mocks_out/approved_stories",
        )
        self.assertEqual(older.steps[0].steps[0].kind, "workflow")
        self.assertEqual(older.steps[0].steps[0].workflow_ref, "research_routine")
        self.assertEqual(older.steps[0].steps[0].nested.group, "research_routine")
        self.assertEqual(older.steps[2].steps[0].kind, "generate")
        self.assertEqual(older.steps[2].steps[0].var, "story_idea")
        self.assertIn("historical event", older.steps[2].steps[0].extra)
        self.assertIn("invention", older.steps[2].steps[0].extra)
        self.assertEqual(older.steps[2].steps[1].workflow_ref, "generate_story_routine")
        self.assertEqual(older.steps[2].steps[1].params["STORY_TITLE"], "$story_idea")
        self.assertIsNone(older.steps[2].steps[1].nested)
        research = wf.named_groups()["research_routine"]
        self.assertEqual([step.kind for step in research.steps], ["load", "goto", "extract", "term"])
        self.assertEqual(research.steps[0].var, "seen")
        self.assertEqual(research.steps[0].roots, ["$DRAFT_ROOT", "$APPROVED_ROOT"])
        idea = wf.named_groups()["research_idea_routine"]
        self.assertEqual([step.kind for step in idea.steps], ["load", "generate", "term"])
        self.assertEqual(idea.steps[0].var, "seen")
        self.assertEqual(idea.steps[0].roots, ["$ARCHIVE_ROOT", "$APPROVED_ROOT"])
        self.assertIn("ideas", idea.steps[0].extra)
        self.assertEqual(idea.steps[1].var, "idea")
        self.assertIn("blood pressure", idea.steps[1].extra)
        self.assertIn("$seen", idea.steps[1].extra)
        self.assertIn("one year ago", idea.steps[1].extra)
        self.assertIn("current event", idea.steps[1].extra)
        self.assertIn("--hint", idea.steps[2].command)
        self.assertIn('"$idea"', idea.steps[2].command)
        self.assertIn("$REMIX_SCRIPT", idea.steps[2].command)
        self.assertEqual(
            wf.env["ARCHIVE_ROOT"],
            "/Users/nghia/Downloads/workspace/video_archive",
        )
        self.assertEqual(content.steps[0].steps[0].params["profile"], "yuba-heart")
        self.assertEqual(content.steps[0].steps[0].nested.group, "research_idea_routine")
        yahoo = wf.named_groups()["yahoo_news_routine"]
        self.assertEqual(
            [step.kind for step in yahoo.steps],
            ["load", "goto", "extract", "generate", "term"],
        )
        self.assertIn("news.search.yahoo.com", yahoo.steps[1].url)
        self.assertEqual(yahoo.steps[2].var, "news")
        self.assertIn("blood pressure", yahoo.steps[2].extra)
        self.assertEqual(yahoo.steps[3].var, "idea")
        self.assertIn("$news", yahoo.steps[3].extra)
        self.assertIn("--hint", yahoo.steps[4].command)
        self.assertIn('"$idea"', yahoo.steps[4].command)

    def test_parse_post_yaml(self) -> None:
        post = load_workflow(YAML.parent / "wf-contet-post.yaml")
        self.assertEqual(post.name, "content post")
        self.assertEqual(post.llm, "")
        self.assertTrue(post.env.get("OPENROUTER_API_KEY"))
        self.assertEqual(
            [extra.group for extra in post.extras],
            ["post_youtube_routine", "post_instagram_routine", "post_tiktok_short_time_routine", "post_tiktok_routine"],
        )
        self.assertEqual(post.env["CHANNELS"], "youtube,tiktok,instagram")
        self.assertIn("POST_SELECTED", post.env)
        heart = post.named_groups()["post_youtube_routine"]
        self.assertEqual([step.kind for step in heart.steps], ["term", "reuse_tab", "goal"])
        self.assertIn("$SELECT_SCRIPT", heart.steps[0].command)
        self.assertIn("--profile $PROFILE", heart.steps[0].command)
        self.assertEqual(heart.env["PROFILE"], "yuba-heart")
        self.assertEqual(heart.steps[1].tool, "browser")
        self.assertEqual(heart.steps[1].extra, "youtube")

    def test_parse_stats_yaml(self) -> None:
        stats = load_workflow(YAML.parent / "wf-stats.yaml")
        self.assertEqual(stats.name, "stats")
        self.assertEqual(stats.llm, "")
        self.assertTrue(stats.env.get("OPENROUTER_API_KEY"))
        self.assertEqual(
            [extra.group for extra in stats.extras],
            ["stats_report_routine", "open_stats_routine"],
        )
        self.assertEqual(
            stats.named_groups()["stats_report_routine"].env.get("OPENROUTER_API_KEY"),
            stats.env["OPENROUTER_API_KEY"],
        )
        browser = stats.named_groups()["stats_report_routine"]
        self.assertEqual(
            [(step.tool, step.kind) for step in browser.steps[:6]],
            [
                ("browser", "reuse_tab"),
                ("browser", "goto"),
                ("browser", "goal"),
                ("browser", "goal"),
                ("browser", "goal"),
                ("", "goal"),
            ],
        )
        self.assertEqual(browser.steps[0].extra, "youtube")
        self.assertTrue(browser.steps[1].url.startswith("https://studio.youtube.com/"))
        self.assertEqual(browser.steps[2].raw, "/browser verify there is > 1 post with views")
        self.assertEqual(browser.steps[-1].kind, "term")
        self.assertIn("$HTML_REPORT_SCRIPT", browser.steps[-1].command)

    def test_parse_step_shapes(self) -> None:
        self.assertEqual(parse_step("goto https://example.com").kind, "goto")
        labeled = parse_step("open youtube https://studio.youtube.com/channel/abc/videos")
        self.assertEqual(labeled.kind, "goto")
        self.assertTrue(labeled.url.startswith("youtube https://"))
        self.assertEqual(parse_step("term echo hi").command, "echo hi")
        configured = parse_step("set_config out_dir=/tmp/stories")
        self.assertEqual(configured.kind, "set_config")
        self.assertEqual(configured.var, "OUT_DIR")
        self.assertEqual(configured.extra, "/tmp/stories")
        titled = parse_step('set_config STORY_TITLE="Ancient Rome"')
        self.assertEqual(titled.var, "STORY_TITLE")
        self.assertEqual(titled.extra, "Ancient Rome")
        with self.assertRaises(ValueError):
            parse_step("set_config no-equals")
        self.assertEqual(parse_step("get first url to $url").kind, "extract")
        self.assertEqual(parse_step("get first url to $url").var, "url")
        skip = parse_step("get first url not in $seen to $url")
        self.assertEqual(skip.kind, "extract")
        self.assertEqual(skip.var, "url")
        self.assertIn("not in $seen", skip.extra)
        loaded = parse_step(
            "load previous sciencedaily articles to $seen from $DRAFT_ROOT $APPROVED_ROOT"
        )
        self.assertEqual(loaded.kind, "load")
        self.assertEqual(loaded.var, "seen")
        self.assertEqual(loaded.roots, ["$DRAFT_ROOT", "$APPROVED_ROOT"])
        self.assertEqual(parse_step("generate story $article").kind, "generate")
        self.assertEqual(parse_step("click the first result").kind, "goal")
        browser_open = parse_step("/browser open youtube https://studio.youtube.com/channel/abc/videos")
        self.assertEqual(browser_open.tool, "browser")
        self.assertEqual(browser_open.kind, "goto")
        self.assertTrue(browser_open.url.startswith("youtube https://"))
        browser_goal = parse_step("/browser verify there is > 1 post with views")
        self.assertEqual(browser_goal.tool, "browser")
        self.assertEqual(browser_goal.kind, "goal")
        reuse = parse_step("/browser reuseTab youtube")
        self.assertEqual(reuse.tool, "browser")
        self.assertEqual(reuse.kind, "reuse_tab")
        self.assertEqual(reuse.extra, "youtube")
        plus_reuse = parse_step("/browser +reuseTab youtube")
        self.assertEqual(plus_reuse.kind, "reuse_tab")
        self.assertEqual(plus_reuse.extra, "youtube")
        plus_click = parse_step("/browser +click subscribe box")
        self.assertEqual(plus_click.tool, "browser")
        self.assertEqual(plus_click.kind, "goal")
        self.assertEqual(plus_click.raw, "/browser +click subscribe box")
        verified = parse_step("/browser +click Next +verify Related Video max 2s")
        self.assertEqual(verified.tool, "browser")
        self.assertEqual(verified.kind, "goal")
        opened = parse_step("/browser +go https://www.tiktok.com/tiktokstudio/content +verify Views")
        self.assertEqual(opened.tool, "browser")
        self.assertEqual(opened.kind, "goal")
        phrase = parse_step("/browser +verify Content")
        self.assertEqual(phrase.tool, "browser")
        self.assertEqual(phrase.kind, "goal")
        from cg_loop.browser_helper import _command_body, _verify_clause

        self.assertEqual(_verify_clause(verified.raw), ("Related Video", 2.0))
        self.assertEqual(_verify_clause(opened.raw), ("Views", 5.0))
        self.assertEqual(_verify_clause(phrase.raw), ("Content", 5.0))
        hover = parse_step("/browser +hover the menu +verify Open")
        self.assertEqual(hover.tool, "browser")
        self.assertEqual(hover.kind, "goal")
        self.assertEqual(_command_body(hover.raw), "hover the menu verify Open")
        quoted_click = parse_step('/browser +click "press +click"')
        self.assertEqual(quoted_click.extra, 'click "press +click"')
        typed = parse_step('/cua +type "hello into $place" into "Name"')
        self.assertEqual(typed.extra, "type")
        self.assertEqual(typed.params["text"], "hello into $place")
        self.assertEqual(typed.params["label"], "Name")
        self.assertEqual(typed.var, "")
        located = parse_step('/locate "close, into $x", \'shot.jpg\' into $loc')
        self.assertEqual(located.extra, "close, into $x")
        self.assertEqual(located.command, "shot.jpg")
        self.assertEqual(located.var, "loc")
        from cg_loop.browser_helper import _only_duration_wait

        self.assertEqual(_only_duration_wait("/browser +wait 1s"), 1)
        self.assertEqual(_only_duration_wait(step_body(parse_step("/python +wait 1s"))), 1)
        with self.assertRaises(ValueError):
            parse_step("/browser reuseTab")
        with self.assertRaises(ValueError):
            parse_step("/browser term echo hi")
        term_tool = parse_step("/term echo hi")
        self.assertEqual(term_tool.tool, "term")
        self.assertEqual(term_tool.kind, "goal")
        with self.assertRaises(ValueError):
            parse_step("/shell echo hi")
        self.assertEqual(parse_step("open the studio shorts page").kind, "goto")
        mapped = parse_step({"term": "ls"})
        self.assertEqual(mapped.kind, "term")
        self.assertEqual(mapped.command, "ls")
        typed = parse_step({"msg": "wf-contet-post", "type": "workflow", "params": {"profile": "yuba-heart"}})
        self.assertEqual(typed.kind, "workflow")
        self.assertEqual(typed.workflow_name, "wf-contet-post")
        self.assertEqual(typed.params["profile"], "yuba-heart")
        by_group = parse_step(
            {"msg": "wf_slides", "type": "workflow", "workflow": "wf-contet-post", "params": {}}
        )
        self.assertEqual(by_group.workflow_name, "wf_slides")
        self.assertEqual(by_group.workflow_ref, "wf-contet-post")
        all_groups = parse_step({"msg": "", "type": "workflow", "workflow": "wf-contet-post", "params": {}})
        self.assertEqual(all_groups.workflow_name, "")
        self.assertEqual(all_groups.workflow_ref, "wf-contet-post")
        piped = parse_step(
            {
                "msg": "wf_research|wf_slides",
                "type": "workflow",
                "workflow": "wf-contet-post",
            }
        )
        self.assertEqual(piped.workflow_name, "wf_research|wf_slides")
        code = parse_step({"msg": "pick unused url", "type": "python", "params": {}})
        self.assertEqual(code.kind, "code")
        self.assertEqual(code.extra, "python")
        self.assertEqual(code.workflow_name, "pick unused url")

    def test_set_config_applies_to_every_group(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-config.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: configured",
                        "set_config:",
                        "  - OUT_DIR=/tmp/stories",
                        '  - "STORY_TITLE=Ancient Rome"',
                        "wf_split:",
                        "  - set_config VOICE=deep",
                        "  - Split the book under $OUT_DIR",
                        "wf_voice:",
                        "  - Speak with $VOICE",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        self.assertEqual(wf.env["OUT_DIR"], "/tmp/stories")
        self.assertEqual(wf.env["STORY_TITLE"], "Ancient Rome")
        self.assertEqual(wf.env["VOICE"], "deep")
        for extra in wf.extras:
            self.assertEqual(extra.env["OUT_DIR"], "/tmp/stories")
            self.assertEqual(extra.env["VOICE"], "deep")
        self.assertEqual(wf.extras[0].steps[0].kind, "set_config")
        apply_overrides(wf, {"OUT_DIR": "/tmp/override", "VOICE": "soft"})
        self.assertEqual(wf.env["OUT_DIR"], "/tmp/override")
        self.assertEqual(wf.extras[1].env["VOICE"], "soft")
        self.assertEqual(wf.env["STORY_TITLE"], "Ancient Rome")

    def test_root_project_expands_in_config_and_set_config(self) -> None:
        import tempfile

        from cg_loop.terminal import expand_command

        root = project_root()
        script = "skills/cg-remix/scripts/upload_sleepkase.py"
        expected = str(root / script)
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / "workflows"
            folder.mkdir()
            path = folder / "wf-root.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: root",
                        "  env:",
                        f"    FROM_ENV: .$rootProject/{script}",
                        "wf_upload:",
                        f"  - set_config UPLOAD_SCRIPT=.$rootProject/{script}",
                        f"  - set_config BARE=$rootProject/{script}",
                        f"  - set_config BRACED=${{rootProject}}/{script}",
                        "  - set_config NOTE=see $rootProject/readme",
                        "  - set_config KEPT=$rootProjectExtra",
                        "  - set_config REL=../skills/cg-remix/scripts/upload_sleepkase.py",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        group = wf.extras[0]
        self.assertEqual(wf.env["rootProject"], str(root))
        self.assertEqual(group.env["rootProject"], str(root))
        self.assertEqual(wf.env["FROM_ENV"], expected)
        self.assertEqual(group.env["UPLOAD_SCRIPT"], expected)
        self.assertEqual(group.env["BARE"], expected)
        self.assertEqual(group.env["BRACED"], expected)
        self.assertEqual(group.steps[0].extra, expected)
        self.assertEqual(group.env["NOTE"], f"see {root}/readme")
        self.assertEqual(group.env["KEPT"], "$rootProjectExtra")
        self.assertEqual(
            group.env["REL"],
            str((folder / "../skills/cg-remix/scripts/upload_sleepkase.py").parent.resolve() / "upload_sleepkase.py"),
        )
        self.assertEqual(expand_command("echo $rootProject", group.env, {}), f"echo {root}")
        apply_overrides(wf, {"UPLOAD_SCRIPT": f".$rootProject/{script}"})
        self.assertEqual(wf.env["UPLOAD_SCRIPT"], expected)

    def test_set_config_comma_pairs(self) -> None:
        pairs = parse_set_config_items(
            'set_config STORY_WORDS=6000, KOKORO_VOICE=bm_lewis, TITLE="Rome, at night"'
        )
        self.assertEqual(
            pairs,
            [
                ("STORY_WORDS", "6000"),
                ("KOKORO_VOICE", "bm_lewis"),
                ("TITLE", "Rome, at night"),
            ],
        )
        steps = parse_steps(
            "set_config STORY_WORDS=6000, KOKORO_VOICE=bm_lewis, KOKORO_SPEED=0.7"
        )
        self.assertEqual(len(steps), 1)
        self.assertEqual(
            set_config_pairs(steps[0]),
            [("STORY_WORDS", "6000"), ("KOKORO_VOICE", "bm_lewis"), ("KOKORO_SPEED", "0.7")],
        )
        again = parse_step(steps[0].raw)
        self.assertEqual(set_config_pairs(again), set_config_pairs(steps[0]))
        with self.assertRaises(ValueError):
            parse_set_config_items('set_config TITLE="Rome')
        prompt = parse_step(
            'set-config PROMPT="a bunker, no text, Scene 1: Secret"'
        )
        self.assertEqual(prompt.extra, "a bunker, no text, Scene 1: Secret")
        again = parse_step(prompt.raw)
        self.assertEqual(again.var, "PROMPT")
        self.assertEqual(again.extra, prompt.extra)

        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-comma.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: comma",
                        "set_config:",
                        "  - WORDS=1000, VOICE=deep",
                        "wf_generate_story:",
                        "  - set_config STORY_WORDS=6000, KOKORO_VOICE=bm_lewis, KOKORO_SPEED=0.7",
                        "  - Write the story",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        self.assertEqual(wf.env["WORDS"], "1000")
        self.assertEqual(wf.env["VOICE"], "deep")
        group = wf.extras[0]
        self.assertEqual(group.env["STORY_WORDS"], "6000")
        self.assertEqual(group.env["KOKORO_VOICE"], "bm_lewis")
        self.assertEqual(group.env["KOKORO_SPEED"], "0.7")
        configured = [step for step in group.steps if step.kind == "set_config"]
        self.assertEqual(len(configured), 1)
        self.assertEqual(
            set_config_pairs(configured[0]),
            [("STORY_WORDS", "6000"), ("KOKORO_VOICE", "bm_lewis"), ("KOKORO_SPEED", "0.7")],
        )
        self.assertEqual(group.steps[-1].kind, "goal")

    def test_set_config_cdp_url_is_a_config_field(self) -> None:
        step = parse_step("set-config cdp-url=http://127.0.0.1:18802")
        self.assertEqual(step.kind, "set_config")
        self.assertEqual(step.var, "cdp-url")
        self.assertEqual(step.extra, "http://127.0.0.1:18802")
        with self.assertRaises(ValueError):
            parse_step("set-config nope-key=1")

        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-stats.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: stats",
                        "set_config:",
                        "  - cdp-url=http://127.0.0.1:18801",
                        "stats_report_routine:",
                        "  - set-config cdp-url=http://127.0.0.1:18802",
                        "  - goto https://studio.youtube.com",
                        "open_stats_routine:",
                        "  - goto https://studio.youtube.com",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        by_group = {extra.group: extra for extra in wf.extras}
        self.assertEqual(by_group["stats_report_routine"].cdp_url, "http://127.0.0.1:18802")
        self.assertEqual(by_group["open_stats_routine"].cdp_url, "http://127.0.0.1:18801")
        self.assertNotIn("cdp-url", by_group["stats_report_routine"].env)
        apply_overrides(wf, {"cdp-url": "http://127.0.0.1:18809"})
        self.assertEqual(by_group["stats_report_routine"].cdp_url, "http://127.0.0.1:18809")
        self.assertEqual(by_group["open_stats_routine"].cdp_url, "http://127.0.0.1:18809")

    def test_select_extra_group(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-groups.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: groups",
                        "wf_research:",
                        "  - load previous articles to $seen from $DRAFT_ROOT",
                        "  - goto https://example.com/rss",
                        "  - get first url not in $seen to $url",
                        "  - term echo research",
                        "wf_slides:",
                        "  - term echo slides",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        self._assert_group_selection(wf)

    def _assert_group_selection(self, wf) -> None:
        from cg_loop.workflow import select_workflows
        only = select_workflows(wf, "slides")
        self.assertEqual(len(only), 1)
        self.assertEqual(only[0].group, "wf_slides")
        for name in ("research", "wf_research"):
            main = select_workflows(wf, name)
            self.assertEqual(main[0].group, "wf_research")
            self.assertEqual(main[0].extras, [])
            self.assertEqual(
                [step.kind for step in main[0].steps],
                ["load", "goto", "extract", "term"],
            )
        both = select_workflows(wf, "wf_research|wf_slides")
        self.assertEqual(len(both), 1)
        self.assertEqual(both[0].group, "")
        self.assertEqual(len(both[0].extras), 2)
        self.assertEqual(both[0].extras[0].group, "wf_research")
        self.assertEqual(both[0].extras[1].group, "wf_slides")
        everything = select_workflows(wf, "wf_all")
        self.assertEqual(len(everything), 1)
        self.assertEqual(everything[0].extras[0].group, "wf_research")
        self.assertEqual(everything[0].extras[1].group, "wf_slides")
        with self.assertRaises(ValueError) as raised:
            select_workflows(wf, "")
        self.assertIn("wf_all", str(raised.exception))
        self.assertIn("wf_research", str(raised.exception))

    def test_step_at_cursor_line(self) -> None:
        wf = load_workflow(WORKFLOWS / "wf-cua.yaml")
        click = select_step_at_line(wf, 23)
        self.assertEqual(click.group, "open_chrome_routine")
        self.assertEqual(len(click.steps), 1)
        self.assertIn('+click "Search text box"', click.steps[0].raw)
        self.assertEqual(click.loop_count, 1)
        self.assertEqual(click.extras, [])
        browser = select_step_at_line(wf, 31)
        self.assertEqual(browser.group, "wait_test_routine")
        self.assertEqual(browser.steps[0].raw, "/browser +wait 10s")
        with self.assertRaises(ValueError) as header:
            select_step_at_line(wf, 21)
        self.assertIn("not a step", str(header.exception))
        with self.assertRaises(ValueError):
            select_step_at_line(wf, 27)
        with self.assertRaises(ValueError) as other:
            select_step_at_line(wf, 23, only="wait_test_routine")
        self.assertIn("open_chrome_routine", str(other.exception))

    def test_nested_step_at_cursor_line(self) -> None:
        wf = load_workflow(YAML)
        inner = select_step_at_line(wf, 57)
        self.assertEqual(inner.group, "generate_content_routine")
        self.assertEqual(inner.steps[0].kind, "workflow")
        self.assertEqual(inner.steps[0].workflow_ref, "research_idea_routine")
        self.assertEqual(len(inner.steps), 1)
        outer = select_step_at_line(wf, 54)
        self.assertEqual(outer.steps[0].kind, "condition")
        self.assertTrue(outer.steps[0].steps)
        params = select_step_at_line(wf, 59)
        self.assertEqual(params.steps[0].workflow_ref, "research_idea_routine")
        first = select_step_at_line(wf, 72)
        second = select_step_at_line(wf, 79)
        self.assertEqual(first.steps[0].line, 72)
        self.assertEqual(second.steps[0].line, 79)
        self.assertEqual(first.steps[0].raw, second.steps[0].raw)
        check = select_step_at_line(load_workflow(WORKFLOWS / "wf-sleep-story.yaml"), 305)
        self.assertIn("youtube video", check.steps[0].raw)
        self.assertNotEqual(check.steps[0].kind, "condition")

    def test_step_line_spans(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-lines.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: lines",
                        "wf_block:",
                        "  - |",
                        "    line a",
                        "    line b",
                        "  - term echo next",
                        "wf_config:",
                        "  - set_config A=1, B=2",
                        "wf_mixed:",
                        "  steps:",
                        "    - term echo compiled",
                        "  auto:",
                        "    - term echo live",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        block = select_step_at_line(wf, 5)
        self.assertEqual(block.group, "wf_block")
        self.assertIn("line a", block.steps[0].raw)
        self.assertEqual(select_step_at_line(wf, 6).steps[0].raw, block.steps[0].raw)
        self.assertEqual(select_step_at_line(wf, 7).steps[0].kind, "term")
        paired = select_step_at_line(wf, 9)
        self.assertEqual(paired.group, "wf_config")
        self.assertEqual(len(paired.steps), 1)
        self.assertEqual(set_config_pairs(paired.steps[0]), [("A", "1"), ("B", "2")])
        self.assertEqual(select_step_at_line(wf, 12).steps[0].raw, "term echo compiled")
        live = select_step_at_line(wf, 14)
        self.assertTrue(live.steps[0].auto)
        self.assertEqual(live.steps[0].raw, "term echo live")

    def test_workflow_files_record_step_lines(self) -> None:
        root = WORKFLOWS
        for path in sorted(root.rglob("wf-*.yaml")):
            loaded = load_workflow(path)
            lined = [
                step
                for group in loaded.extras
                if group.path is not None and group.path.resolve() == path.resolve()
                for step in group.steps
                if step.line
            ]
            self.assertTrue(lined, path.name)

    def test_step_at_cursor_line(self) -> None:
        wf = load_workflow(WORKFLOWS / "wf-cua.yaml")
        click = select_step_at_line(wf, 23)
        self.assertEqual(click.group, "open_chrome_routine")
        self.assertEqual(len(click.steps), 1)
        self.assertIn('+click "Search text box"', click.steps[0].raw)
        self.assertEqual(click.loop_count, 1)
        self.assertEqual(click.extras, [])
        browser = select_step_at_line(wf, 31)
        self.assertEqual(browser.group, "wait_test_routine")
        self.assertEqual(browser.steps[0].raw, "/browser +wait 10s")
        with self.assertRaises(ValueError) as header:
            select_step_at_line(wf, 21)
        self.assertIn("not a step", str(header.exception))
        with self.assertRaises(ValueError):
            select_step_at_line(wf, 27)
        with self.assertRaises(ValueError) as other:
            select_step_at_line(wf, 23, only="wait_test_routine")
        self.assertIn("open_chrome_routine", str(other.exception))

    def test_nested_step_at_cursor_line(self) -> None:
        wf = load_workflow(YAML)
        inner = select_step_at_line(wf, 57)
        self.assertEqual(inner.group, "generate_content_routine")
        self.assertEqual(inner.steps[0].kind, "workflow")
        self.assertEqual(inner.steps[0].workflow_ref, "research_idea_routine")
        self.assertEqual(len(inner.steps), 1)
        outer = select_step_at_line(wf, 54)
        self.assertEqual(outer.steps[0].kind, "condition")
        self.assertTrue(outer.steps[0].steps)
        params = select_step_at_line(wf, 59)
        self.assertEqual(params.steps[0].workflow_ref, "research_idea_routine")
        first = select_step_at_line(wf, 72)
        second = select_step_at_line(wf, 79)
        self.assertEqual(first.steps[0].line, 72)
        self.assertEqual(second.steps[0].line, 79)
        self.assertEqual(first.steps[0].raw, second.steps[0].raw)
        check = select_step_at_line(load_workflow(WORKFLOWS / "wf-sleep-story.yaml"), 305)
        self.assertIn("youtube video", check.steps[0].raw)
        self.assertNotEqual(check.steps[0].kind, "condition")

    def test_step_line_spans(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-lines.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: lines",
                        "wf_block:",
                        "  - |",
                        "    line a",
                        "    line b",
                        "  - term echo next",
                        "wf_config:",
                        "  - set_config A=1, B=2",
                        "wf_mixed:",
                        "  steps:",
                        "    - term echo compiled",
                        "  auto:",
                        "    - term echo live",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        block = select_step_at_line(wf, 5)
        self.assertEqual(block.group, "wf_block")
        self.assertIn("line a", block.steps[0].raw)
        self.assertEqual(select_step_at_line(wf, 6).steps[0].raw, block.steps[0].raw)
        self.assertEqual(select_step_at_line(wf, 7).steps[0].kind, "term")
        paired = select_step_at_line(wf, 9)
        self.assertEqual(paired.group, "wf_config")
        self.assertEqual(len(paired.steps), 1)
        self.assertEqual(set_config_pairs(paired.steps[0]), [("A", "1"), ("B", "2")])
        self.assertEqual(select_step_at_line(wf, 12).steps[0].raw, "term echo compiled")
        live = select_step_at_line(wf, 14)
        self.assertTrue(live.steps[0].auto)
        self.assertEqual(live.steps[0].raw, "term echo live")

    def test_workflow_files_record_step_lines(self) -> None:
        root = WORKFLOWS
        for path in sorted(root.rglob("wf-*.yaml")):
            loaded = load_workflow(path)
            lined = [
                step
                for group in loaded.extras
                if group.path is not None and group.path.resolve() == path.resolve()
                for step in group.steps
                if step.line
            ]
            self.assertTrue(lined, path.name)

    def test_step_at_cursor_line(self) -> None:
        wf = load_workflow(WORKFLOWS / "wf-cua.yaml")
        click = select_step_at_line(wf, 23)
        self.assertEqual(click.group, "open_chrome_routine")
        self.assertEqual(len(click.steps), 1)
        self.assertIn('+click "Search text box"', click.steps[0].raw)
        self.assertEqual(click.loop_count, 1)
        self.assertEqual(click.extras, [])
        browser = select_step_at_line(wf, 31)
        self.assertEqual(browser.group, "wait_test_routine")
        self.assertEqual(browser.steps[0].raw, "/browser +wait 10s")
        with self.assertRaises(ValueError) as header:
            select_step_at_line(wf, 21)
        self.assertIn("not a step", str(header.exception))
        with self.assertRaises(ValueError):
            select_step_at_line(wf, 27)
        with self.assertRaises(ValueError) as other:
            select_step_at_line(wf, 23, only="wait_test_routine")
        self.assertIn("open_chrome_routine", str(other.exception))

    def test_nested_step_at_cursor_line(self) -> None:
        wf = load_workflow(YAML)
        inner = select_step_at_line(wf, 57)
        self.assertEqual(inner.group, "generate_content_routine")
        self.assertEqual(inner.steps[0].kind, "workflow")
        self.assertEqual(inner.steps[0].workflow_ref, "research_idea_routine")
        self.assertEqual(len(inner.steps), 1)
        outer = select_step_at_line(wf, 54)
        self.assertEqual(outer.steps[0].kind, "condition")
        self.assertTrue(outer.steps[0].steps)
        params = select_step_at_line(wf, 59)
        self.assertEqual(params.steps[0].workflow_ref, "research_idea_routine")
        first = select_step_at_line(wf, 72)
        second = select_step_at_line(wf, 79)
        self.assertEqual(first.steps[0].line, 72)
        self.assertEqual(second.steps[0].line, 79)
        self.assertEqual(first.steps[0].raw, second.steps[0].raw)
        check = select_step_at_line(load_workflow(WORKFLOWS / "wf-sleep-story.yaml"), 305)
        self.assertIn("youtube video", check.steps[0].raw)
        self.assertNotEqual(check.steps[0].kind, "condition")

    def test_step_line_spans(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-lines.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: lines",
                        "wf_block:",
                        "  - |",
                        "    line a",
                        "    line b",
                        "  - term echo next",
                        "wf_config:",
                        "  - set_config A=1, B=2",
                        "wf_mixed:",
                        "  steps:",
                        "    - term echo compiled",
                        "  auto:",
                        "    - term echo live",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        block = select_step_at_line(wf, 5)
        self.assertEqual(block.group, "wf_block")
        self.assertIn("line a", block.steps[0].raw)
        self.assertEqual(select_step_at_line(wf, 6).steps[0].raw, block.steps[0].raw)
        self.assertEqual(select_step_at_line(wf, 7).steps[0].kind, "term")
        paired = select_step_at_line(wf, 9)
        self.assertEqual(paired.group, "wf_config")
        self.assertEqual(len(paired.steps), 1)
        self.assertEqual(set_config_pairs(paired.steps[0]), [("A", "1"), ("B", "2")])
        self.assertEqual(select_step_at_line(wf, 12).steps[0].raw, "term echo compiled")
        live = select_step_at_line(wf, 14)
        self.assertTrue(live.steps[0].auto)
        self.assertEqual(live.steps[0].raw, "term echo live")

    def test_steps_between_lines(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-range.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: range",
                        "wf_one:",
                        "  - term echo one",
                        "  - |",
                        "    line a",
                        "    line b",
                        "  - term echo three",
                        "  - condition: ready",
                        "    steps:",
                        "      - term echo inner",
                        "      - term echo inner two",
                        "  - term echo after",
                        "wf_two:",
                        "  - term echo other",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        both = select_steps_between(wf, 4, 8)
        self.assertEqual(both.group, "wf_one")
        self.assertEqual(both.loop_count, 1)
        self.assertEqual(
            [step.raw.splitlines()[0] for step in both.steps],
            ["term echo one", "line a", "term echo three"],
        )
        inside = select_steps_between(wf, 6, 7)
        self.assertEqual(inside.steps[0].raw.splitlines()[0], "line a")
        self.assertEqual(len(inside.steps), 1)
        inners = select_steps_between(wf, 11, 12)
        self.assertEqual([step.raw for step in inners.steps], ["term echo inner", "term echo inner two"])
        condition = select_steps_between(wf, 9, 12)
        self.assertEqual(len(condition.steps), 1)
        self.assertEqual(condition.steps[0].kind, "condition")
        tail = select_steps_between(wf, 12, 13)
        self.assertEqual([step.raw for step in tail.steps], ["term echo inner two", "term echo after"])
        with self.assertRaises(ValueError) as groups:
            select_steps_between(wf, 13, 15)
        self.assertIn("more than one group", str(groups.exception))
        with self.assertRaises(ValueError) as other:
            select_steps_between(wf, 4, 5, only="wf_two")
        self.assertIn("wf_one", str(other.exception))

    def test_workflow_files_record_step_lines(self) -> None:
        root = WORKFLOWS
        for path in sorted(root.rglob("wf-*.yaml")):
            loaded = load_workflow(path)
            lined = [
                step
                for group in loaded.extras
                if group.path is not None and group.path.resolve() == path.resolve()
                for step in group.steps
                if step.line
            ]
            self.assertTrue(lined, path.name)

    def test_extra_group_yaml_path(self) -> None:
        import tempfile

        child = YAML.parent / "wf-contet-post.yaml"
        with tempfile.TemporaryDirectory() as tmp:
            parent = Path(tmp) / "parent.yaml"
            parent.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: parent",
                        "wf_main:",
                        "  - term echo main",
                        f"wf_post: {child}",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(parent)
        self.assertEqual([extra.group for extra in wf.extras], ["wf_main", "wf_post"])
        nested = wf.extras[1]
        self.assertGreaterEqual(len(nested.all_steps()), 1)
        self.assertEqual(nested.all_steps()[0].kind, "term")
        self.assertEqual(
            [extra.group for extra in nested.extras],
            ["post_youtube_routine", "post_instagram_routine", "post_tiktok_short_time_routine", "post_tiktok_routine"],
        )
        heart = next(extra for extra in nested.extras if extra.group == "post_youtube_routine")
        self.assertEqual(len(heart.steps), 3)
        self.assertIn("$SELECT_SCRIPT", heart.steps[0].command)
        self.assertEqual(heart.steps[1].kind, "reuse_tab")
        self.assertEqual(heart.steps[2].kind, "goal")

    def test_openrouter_free_model_config(self) -> None:
        import tempfile

        from cg_loop.model import LOCAL_URL, configure, describe

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-llm.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: llm",
                        "  llm: openrouter",
                        "  model: openrouter/free",
                        "wf_main:",
                        "  - term echo hi",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        self.assertEqual(wf.llm, "openrouter")
        self.assertEqual(wf.model, "openrouter/free")
        self.assertEqual(wf.extras[0].llm, "openrouter")
        try:
            configure(wf.llm, wf.model)
            text = describe()
            self.assertIn("OpenRouter", text)
            self.assertIn("https://openrouter.ai/api/v1", text)
            self.assertIn("openrouter/free", text)
            self.assertIn("key=missing", text)
            configure(wf.llm, wf.model, {"OPENROUTER_API_KEY": "test-key"})
            self.assertIn("key=set", describe())
        finally:
            configure("local", "")
            local = describe()
            self.assertIn("LM Studio", local)
            self.assertIn(LOCAL_URL, local)
            self.assertNotIn("openrouter/free", local)

    def test_hug_text_model_is_the_chat_model(self) -> None:
        from unittest.mock import patch

        from cg_loop.model import (
            configure,
            describe,
            hug_models_for_run,
            llm_write,
            load_hug_chat_if_needed,
            workflow_needs_hug_chat,
        )
        from cg_loop.workflow import Workflow

        configure("local", "prism-ml/Ternary-Bonsai-8B-mlx-2bit")
        try:
            text = describe()
            self.assertIn("local:", text)
            self.assertNotIn("LM Studio", text)
            self.assertIn("prism-ml/Ternary-Bonsai-8B-mlx-2bit", text)
            with patch("cg_loop.hug.ask_hug", return_value="October Harbor") as ask:
                written = llm_write("one title")
            self.assertEqual(written, "October Harbor")
            self.assertEqual(ask.call_args.args[0], "prism-ml/Ternary-Bonsai-8B-mlx-2bit")
            self.assertIn("one title", ask.call_args.args[1])
            turns = ask.call_args.kwargs["messages"]
            self.assertEqual(turns[0]["role"], "system")
            self.assertIn("one title", turns[-1]["content"])
            self.assertGreater(ask.call_args.kwargs["max_tokens"], 256)
        finally:
            configure("local", "")
        configure("local", "prism-ml/Ternary-Bonsai-2-9B-mlx-2bit")
        try:
            self.assertIn("LM Studio", describe())
        finally:
            configure("local", "")
        story = Workflow(
            name="stories",
            model="prism-ml/Ternary-Bonsai-8B-mlx-2bit",
            steps=[parse_step("generate one creative sleep story title $story_idea")],
        )
        echo = Workflow(
            name="echo",
            model="prism-ml/Ternary-Bonsai-8B-mlx-2bit",
            steps=[parse_step("term echo hi")],
        )
        self.assertTrue(workflow_needs_hug_chat(story))
        self.assertFalse(workflow_needs_hug_chat(echo))
        with patch("cg_loop.resident.use_resident", return_value=True), patch("cg_loop.resident.call") as call:
            load_hug_chat_if_needed(story)
            load_hug_chat_if_needed(echo)
        self.assertEqual(call.call_count, 1)
        self.assertEqual(call.call_args.args[0], "load")
        self.assertEqual(call.call_args.args[1]["id"], "prism-ml/Ternary-Bonsai-8B-mlx-2bit")
        script = Workflow(
            name="script",
            model="qwen3.8-27b-mlx",
            steps=[parse_step("/python print today")],
        )
        page = Workflow(
            name="page",
            model="qwen3.8-27b-mlx",
            steps=[parse_step("/browser click the save button")],
        )
        self.assertEqual(hug_models_for_run(script), ["prism-ml/Ternary-Bonsai-8B-mlx-2bit"])
        self.assertEqual(hug_models_for_run(page), ["prism-ml/Ternary-Bonsai-8B-mlx-2bit"])
        self.assertEqual(hug_models_for_run(echo), [])

    def test_sleep_story_overrides_python_and_browser_compile(self) -> None:
        from cg_loop.model import hug_models_for_run

        sleep = load_workflow(WORKFLOWS / "wf-sleep-story.yaml")
        research = load_workflow(YAML)
        self.assertIsNone(research.python_compile)
        self.assertIsNone(research.browser_compile)
        assert sleep.python_compile is not None
        assert sleep.browser_compile is not None
        self.assertEqual(sleep.python_compile.llm, "openrouter")
        self.assertEqual(sleep.python_compile.model, "meta/muse-spark-1.2-contributor")
        self.assertIsNone(sleep.python_compile.timeout)
        self.assertEqual(sleep.browser_compile.llm, "openrouter")
        self.assertEqual(sleep.browser_compile.model, sleep.python_compile.model)
        group = next(item for item in sleep.extras if any(step.tool == "python" for step in item.all_steps()))
        self.assertEqual(group.python_compile, sleep.python_compile)
        self.assertEqual(group.browser_compile, sleep.browser_compile)
        self.assertNotIn("prism-ml/Ternary-Bonsai-8B-mlx-2bit", hug_models_for_run(group))

    def test_python_model_flag_picks_the_compiler_and_verify(self) -> None:
        from cg_loop import model
        from cg_loop.compiled import check_python_verify
        from cg_loop.decision import skips_script
        from cg_loop.model import hug_models_for_run
        from cg_loop.workflow import Workflow, python_sentence, python_step_slot

        local = parse_step(
            "/python print 2 + 1 +model local/prism-ml/Ternary-Bonsai-8B-mlx-2bit +verify 3"
        )
        self.assertEqual(local.extra, "print 2 + 1")
        self.assertEqual(local.params["llm"], "local")
        self.assertEqual(local.params["compile_model"], "prism-ml/Ternary-Bonsai-8B-mlx-2bit")
        self.assertEqual(local.params["verify"], "3")
        self.assertEqual(python_sentence(local), "/python print 2 + 1")
        self.assertFalse(skips_script(local))

        hosted = parse_step(
            "/python print the word apple +model openrouter/meta/muse-spark-1.2-contributor +verify apple"
        )
        self.assertEqual(hosted.params["llm"], "openrouter")
        self.assertEqual(hosted.params["compile_model"], "meta/muse-spark-1.2-contributor")
        self.assertEqual(hosted.extra, "print the word apple")

        dated = parse_step('/python print "something" + today')
        self.assertEqual(dated.extra, 'print "something" + today')
        self.assertNotIn("model", dated.params)

        quoted = parse_step(
            '/python print "use +model later" +model local/prism-ml/Bonsai-4B-mlx-1bit +verify later'
        )
        self.assertIn("+model", quoted.extra)
        self.assertEqual(quoted.params["compile_model"], "prism-ml/Bonsai-4B-mlx-1bit")

        printed = parse_step("/python print $post_date +verify 2026")
        self.assertTrue(skips_script(printed))
        self.assertEqual(python_sentence(printed), "/python print $post_date")

        with self.assertRaises(ValueError):
            parse_step("/python print 2 + 1 +model prism-ml/Ternary-Bonsai-8B-mlx-2bit")

        tests = load_workflow(WORKFLOWS / "wf-tests.yaml")
        bench = next(item for item in tests.extras if item.group == "python_benchmark_routine")
        self.assertEqual(
            [step.params["compile_model"] for step in bench.steps],
            [
                "prism-ml/Bonsai-4B-mlx-1bit",
                "prism-ml/Ternary-Bonsai-8B-mlx-2bit",
                "meta/muse-spark-1.2-contributor",
                "prism-ml/Ternary-Bonsai-8B-mlx-2bit",
            ],
        )
        self.assertEqual(
            [step.params["verify"] for step in bench.steps],
            ["beta.yaml", "First Light, The Lens, Keepers", "Vacuum tubes", "Harbor Watch"],
        )
        self.assertIn("bench-yaml", bench.steps[0].extra)
        self.assertIn("bench-slides.html", bench.steps[2].extra)
        self.assertNotIn("beta.yaml", bench.steps[0].extra)
        self.assertEqual(
            hug_models_for_run(bench),
            ["prism-ml/Bonsai-4B-mlx-1bit", "prism-ml/Ternary-Bonsai-8B-mlx-2bit"],
        )
        mixed = Workflow(
            name="mixed",
            steps=[
                parse_step("/python print today"),
                parse_step("/python print 2 + 1 +model local/prism-ml/Bonsai-4B-mlx-1bit +verify 3"),
            ],
        )
        self.assertEqual(
            hug_models_for_run(mixed),
            ["prism-ml/Ternary-Bonsai-8B-mlx-2bit", "prism-ml/Bonsai-4B-mlx-1bit"],
        )

        model.configure("openrouter", "hosted", {"OPENROUTER_API_KEY": "test"})
        try:
            with model.bind_python_step(python_step_slot(local)):
                with model.using_python_provider():
                    self.assertEqual(model.PROVIDER, "local")
                    self.assertEqual(model.MODEL, "prism-ml/Ternary-Bonsai-8B-mlx-2bit")
            with model.bind_python_step(python_step_slot(hosted)):
                with model.using_python_provider():
                    self.assertEqual(model.PROVIDER, "openrouter")
                    self.assertEqual(model.MODEL, "meta/muse-spark-1.2-contributor")
            self.assertEqual(model.PROVIDER, "openrouter")
            self.assertEqual(model.MODEL, "hosted")
        finally:
            model.configure("local", "")

        self.assertFalse(check_python_verify({"outputs": {"status": "ok", "printed": "3"}}, "3").get("blocked"))
        self.assertTrue(check_python_verify({"outputs": {"status": "ok", "printed": "13"}}, "3")["blocked"])
        self.assertFalse(check_python_verify({"outputs": {"status": "ok"}, "stdout": "3\n"}, "3").get("blocked"))
        self.assertFalse(check_python_verify({"outputs": {"printed": "apple"}}, "apple").get("blocked"))
        missed = check_python_verify({"outputs": {"printed": "pear"}}, "apple")
        self.assertTrue(missed["blocked"])
        self.assertIn("apple", missed["outputs"]["message"])

        from cg_loop.compiled import _compile_step_text, _compile_variables, validate_compiled

        self.assertEqual(
            _compile_variables({"workflow_run_command": "bkase", "post_date": "1"}),
            {"post_date": "1"},
        )
        expanded = _compile_step_text(bench.steps[0], {"rootProject": "/proj"}, {})
        self.assertIn("/proj/data/wf-test/bench-yaml", expanded)
        self.assertNotIn("$rootProject", expanded)

        import tempfile

        from cg_loop.compiled import python_named_files

        slide = parse_step(
            "/python Write an HTML presentation to $rootProject/data/wf-test/bench-slides.html. "
            "+model local/prism-ml/Bonsai-4B-mlx-1bit +verify Vacuum tubes"
        )
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            named = python_named_files(slide, {"rootProject": str(root)}, {})
            self.assertEqual(named, [root / "data" / "wf-test" / "bench-slides.html"])
            self.assertEqual(python_named_files(bench.steps[0], {"rootProject": str(root)}, {}), [])
            bad = root / "b-compile.py"
            bad.write_text('def run(ctx):\n    path = ctx["env"]["browser"]\n    return {"outputs": {}}\n', encoding="utf-8")
            self.assertIn("rootProject", validate_compiled(bad, bench.steps[0]))
            page = named[0]
            page.parent.mkdir(parents=True)
            page.write_text("<p>Vacuum tubes</p>", encoding="utf-8")
            thin = check_python_verify({"outputs": {"printed": "Vacuum tubes"}}, "Vacuum tubes", files=named)
            self.assertTrue(thin["blocked"])
            self.assertIn("not a presentation", thin["outputs"]["message"])
            page.write_text(
                "<!doctype html><html><body><h1>How Radar Was Invented</h1>"
                "<ul><li>Vacuum tubes</li></ul></body></html>",
                encoding="utf-8",
            )
            ready = check_python_verify({"outputs": {"printed": "nope"}}, "Vacuum tubes", files=named)
            self.assertFalse(ready.get("blocked"))
            absent = check_python_verify(
                {"outputs": {"printed": "Vacuum tubes"}},
                "Vacuum tubes",
                files=[root / "missing.html"],
            )
            self.assertIn("was not written", absent["outputs"]["message"])

    def test_unloaded_lm_studio_uses_the_fallback(self) -> None:
        from unittest.mock import patch

        from cg_loop import model

        calls: list[str] = []

        class Message:
            def __init__(self, content: str) -> None:
                self.content = content

            def model_dump(self) -> dict[str, str]:
                return {"content": self.content}

        class Response:
            def __init__(self, content: str, name: str) -> None:
                self.model = name
                self.choices = [type("Choice", (), {"message": Message(content)})()]

        class Client:
            def __init__(self) -> None:
                self.chat = self
                self.completions = self

            def create(self, **_kwargs: object) -> Response:
                calls.append(model.MODEL)
                if model.PROVIDER == "local":
                    raise RuntimeError(
                        "Error code: 400 - {'error': {'message': \"No models loaded. Please load a model\"}}"
                    )
                return Response("October Fog", model.MODEL)

            def close(self) -> None:
                return None

        try:
            model.configure(
                "local",
                "qwen3.8-27b-mlx",
                {"OPENROUTER_API_KEY": "test"},
                fallbacks=[("openrouter", "deepseek/deepseek-v3.2", 90)],
            )
            with patch.object(model, "client", return_value=Client()):
                text = model.llm_write("one title")
            self.assertEqual(text, "October Fog")
            self.assertEqual(
                calls,
                ["qwen3.8-27b-mlx", "qwen3.8-27b-mlx", "deepseek/deepseek-v3.2"],
            )
        finally:
            model.configure("local", "", fallbacks=[])

    def test_missing_openrouter_key_stops_without_a_retry(self) -> None:
        from cg_loop.model import ChatError, client, configure

        configure("openrouter", "openrouter/free", {"OPENROUTER_API_KEY": ""})
        try:
            with self.assertRaises(ChatError) as caught:
                client()
            self.assertIn("OPENROUTER_API_KEY is not set", str(caught.exception))
            self.assertTrue(caught.exception.transport)
        finally:
            configure("local", "")

    def test_load_env_file_does_not_replace_an_existing_key(self) -> None:
        import os
        import tempfile

        from cg_loop.model import load_env_file

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / ".env.llm"
            path.write_text("OPENROUTER_API_KEY=from-file\nNEW_CG_LOOP_FLAG=1\n", encoding="utf-8")
            previous = os.environ.get("OPENROUTER_API_KEY")
            os.environ["OPENROUTER_API_KEY"] = "already-set"
            os.environ.pop("NEW_CG_LOOP_FLAG", None)
            try:
                load_env_file(path)
                self.assertEqual(os.environ["OPENROUTER_API_KEY"], "already-set")
                self.assertEqual(os.environ["NEW_CG_LOOP_FLAG"], "1")
            finally:
                if previous is None:
                    os.environ.pop("OPENROUTER_API_KEY", None)
                else:
                    os.environ["OPENROUTER_API_KEY"] = previous
                os.environ.pop("NEW_CG_LOOP_FLAG", None)

    def test_command_timeout_config_and_param(self) -> None:
        import tempfile

        from cg_loop.workflow import select_workflows

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-command-timeout.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: command timeout",
                        "  command-timeout: 14400",
                        "wf_main:",
                        "  - term echo hi",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        self.assertEqual(wf.command_timeout, 14400)
        self.assertEqual(wf.extras[0].command_timeout, 14400)
        chosen = select_workflows(wf, "wf_main")[0]
        self.assertEqual(chosen.command_timeout, 14400)
        apply_overrides(wf, {"command-timeout": "7200"})
        self.assertEqual(wf.command_timeout, 7200)
        self.assertEqual(wf.extras[0].command_timeout, 7200)
        omitted = load_workflow(YAML)
        self.assertEqual(omitted.command_timeout, 0)

    def test_llm_timeout_config_and_param(self) -> None:
        import tempfile
        import time
        from unittest.mock import patch

        from cg_loop import model

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-timeout.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: timeout",
                        "  llm-timeout: 15",
                        "wf_main:",
                        "  - term echo hi",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        self.assertEqual(wf.llm_timeout, 15.0)
        self.assertEqual(wf.extras[0].llm_timeout, 15.0)
        apply_overrides(wf, {"llm-timeout": "12"})
        self.assertEqual(wf.llm_timeout, 12.0)
        self.assertEqual(wf.extras[0].llm_timeout, 12.0)
        with tempfile.TemporaryDirectory() as tmp:
            omitted_path = Path(tmp) / "wf-default-timeout.yaml"
            omitted_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: default timeout",
                        "wf_main:",
                        "  - term echo hi",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            omitted = load_workflow(omitted_path)
        self.assertEqual(omitted.llm_timeout, 30.0)
        try:
            model.configure("local", "test-model", timeout=wf.llm_timeout)
            self.assertIn("llm-timeout=12s", model.describe())

            class Slow:
                def __init__(self) -> None:
                    self.chat = self
                    self.completions = self
                    self.closed = False

                def create(self, **_kwargs: object) -> None:
                    time.sleep(2)

                def close(self) -> None:
                    self.closed = True

            slow = Slow()
            model.configure("local", "test-model", timeout=0.2)
            with patch.object(model, "client", return_value=slow):
                started = time.perf_counter()
                with self.assertRaises(TimeoutError):
                    model._completion(model="x", messages=[])
                self.assertLess(time.perf_counter() - started, 1.5)
            self.assertTrue(slow.closed)
        finally:
            model.configure("local", "")

    def test_a_stuck_close_does_not_extend_the_llm_timeout(self) -> None:
        import time
        from unittest.mock import patch

        from cg_loop import model

        class Slow:
            def __init__(self) -> None:
                self.chat = self
                self.completions = self

            def create(self, **_kwargs: object) -> None:
                time.sleep(5)

            def close(self) -> None:
                time.sleep(5)

        try:
            model.configure("local", "test-model", timeout=0.2, fallbacks=[])
            started = time.perf_counter()
            with patch.object(model, "client", return_value=Slow()):
                with self.assertRaises(TimeoutError):
                    model._completion(model="x", messages=[])
            self.assertLess(time.perf_counter() - started, 1.5)
        finally:
            model.configure("local", "", fallbacks=[])

    def test_bad_json_retries_the_primary_and_does_not_fall_back(self) -> None:
        from unittest.mock import patch

        from cg_loop import model

        calls: list[str] = []

        class Message:
            def __init__(self, content: str) -> None:
                self.content = content

            def model_dump(self) -> dict[str, str]:
                return {"content": self.content}

        class Response:
            def __init__(self, content: str, name: str) -> None:
                self.model = name
                self.choices = [type("Choice", (), {"message": Message(content)})()]

        class Client:
            def __init__(self) -> None:
                self.chat = self
                self.completions = self

            def create(self, **_kwargs: object) -> Response:
                calls.append(model.MODEL)
                return Response("User Safety: safe", "free")

            def close(self) -> None:
                return None

        try:
            model.configure(
                "openrouter",
                "openrouter/free",
                {"OPENROUTER_API_KEY": "test"},
                fallbacks=[("local", "qwen3.8-27b-mlx", 120)],
            )
            with patch.object(model, "client", return_value=Client()):
                with self.assertRaises(model.ChatError) as raised:
                    model._chat_json([{"role": "user", "content": "print the latest post"}])
                self.assertFalse(raised.exception.transport)
        finally:
            model.configure("local", "", fallbacks=[])
        self.assertEqual(calls, ["openrouter/free"])

    def test_transport_failure_skips_that_model_next_time(self) -> None:
        from unittest.mock import patch

        from cg_loop import model

        calls: list[str] = []

        class Client:
            def __init__(self) -> None:
                self.chat = self
                self.completions = self

            def create(self, **_kwargs: object) -> None:
                calls.append(model.MODEL)
                raise TimeoutError(f"LLM request timed out after {model.LLM_TIMEOUT:g}s")

            def close(self) -> None:
                return None

        try:
            model.configure(
                "openrouter",
                "openrouter/free",
                {"OPENROUTER_API_KEY": "test"},
                timeout=30,
                fallbacks=[("local", "qwen3.8-27b-mlx", 120)],
            )
            with patch.object(model, "client", return_value=Client()):
                with self.assertRaises(model.ChatError) as raised:
                    model._chat_json([{"role": "user", "content": "print the latest post"}])
                self.assertTrue(raised.exception.transport)
                self.assertEqual(
                    calls,
                    ["openrouter/free", "openrouter/free", "qwen3.8-27b-mlx", "qwen3.8-27b-mlx"],
                )
                calls.clear()
                with self.assertRaises(model.ChatError):
                    model._chat_json([{"role": "user", "content": "again"}])
                self.assertEqual(calls, [])
        finally:
            model.configure("local", "", fallbacks=[])

    def test_transport_failure_is_retried_once_on_the_same_model(self) -> None:
        from unittest.mock import patch

        from cg_loop import model

        calls: list[str] = []

        class Message:
            content = "The Quiet Harbor"

        class Response:
            choices = [type("Choice", (), {"message": Message()})()]

        class Client:
            def __init__(self) -> None:
                self.chat = self
                self.completions = self

            def create(self, **_kwargs: object) -> Response:
                calls.append(model.MODEL)
                if len(calls) == 1:
                    raise TimeoutError("LLM request timed out after 30s")
                return Response()

            def close(self) -> None:
                return None

        class Ok(Client):
            def create(self, **_kwargs: object) -> Response:
                calls.append(model.MODEL)
                return Response()

        try:
            model.configure(
                "openrouter",
                "openrouter/free",
                {"OPENROUTER_API_KEY": "test"},
                timeout=30,
                fallbacks=[("local", "qwen3.8-27b-mlx", 120)],
            )
            with patch.object(model, "client", return_value=Client()):
                text = model.llm_write("one title")
            self.assertEqual(text, "The Quiet Harbor")
            self.assertEqual(calls, ["openrouter/free", "openrouter/free"])
            calls.clear()
            with patch.object(model, "client", return_value=Ok()):
                model.llm_write("one title")
            self.assertEqual(calls, ["openrouter/free"])
        finally:
            model.configure("local", "", fallbacks=[])

    def test_fallback_timeout_does_not_drop_a_model_that_replied(self) -> None:
        from unittest.mock import patch

        from cg_loop import model

        calls: list[str] = []

        class Message:
            content = ""

            def model_dump(self) -> dict[str, str]:
                return {"content": ""}

        class Response:
            model = "free"
            choices = [type("Choice", (), {"message": Message()})()]

        class Client:
            def __init__(self) -> None:
                self.chat = self
                self.completions = self

            def create(self, **_kwargs: object) -> Response:
                calls.append(model.MODEL)
                if model.MODEL == "openrouter/free":
                    return Response()
                raise TimeoutError("Request timed out.")

            def close(self) -> None:
                return None

        try:
            model.configure(
                "openrouter",
                "openrouter/free",
                {"OPENROUTER_API_KEY": "test"},
                timeout=30,
                fallbacks=[("local", "qwen3.8-27b-mlx", 120)],
            )
            with patch.object(model, "client", return_value=Client()):
                with self.assertRaises(model.ChatError) as raised:
                    model._chat_json([{"role": "user", "content": "log the latest post"}])
                self.assertFalse(raised.exception.transport)
                self.assertIn("did not return JSON", str(raised.exception))
                calls.clear()
                with self.assertRaises(model.ChatError) as again:
                    model._chat_json([{"role": "user", "content": "again"}])
                self.assertFalse(again.exception.transport)
                self.assertEqual(calls, ["openrouter/free"])
        finally:
            model.configure("local", "", fallbacks=[])

    def test_param_overrides_config_then_used(self) -> None:
        wf = load_workflow(YAML)
        apply_overrides(
            wf,
            {
                "cdp-url": "http://127.0.0.1:19999",
                "profile": "yuba-social",
                "loop-count": "3",
                "loop-delay": "5",
                "log-keep": "2",
                "SLIDES_SCRIPT": "/tmp/slides.sh",
            },
        )
        self.assertEqual(wf.cdp_url, "http://127.0.0.1:19999")
        self.assertEqual(wf.profile, "yuba-social")
        self.assertEqual(wf.env["PROFILE"], "yuba-social")
        self.assertEqual(wf.loop_count, 3)
        self.assertEqual(wf.loop_delay, 5.0)
        self.assertEqual(wf.log_keep, 2)
        self.assertEqual(wf.extras[0].log_keep, 2)
        self.assertEqual(wf.env["SLIDES_SCRIPT"], "/tmp/slides.sh")
        apply_overrides(wf, {"llm": "openrouter", "model": "openrouter/free", "browser-tool-model": "jev-latest", "recompile": "1"})
        self.assertTrue(wf.recompile)
        self.assertTrue(wf.extras[0].recompile)
        apply_overrides(wf, {"browser-recompile": "1", "recompile": "0"})
        self.assertFalse(wf.recompile)
        self.assertTrue(wf.browser_recompile)
        self.assertTrue(wf.extras[0].browser_recompile)
        self.assertFalse(wf.extras[0].recompile)
        apply_overrides(wf, {"recompile-on-error": "1"})
        self.assertTrue(wf.recompile_on_error)
        self.assertTrue(wf.extras[0].recompile_on_error)
        self.assertEqual(wf.llm, "openrouter")
        self.assertEqual(wf.model, "openrouter/free")
        self.assertEqual(wf.browser_tool_model, "jev-latest")
        self.assertEqual(wf.extras[0].llm, "openrouter")
        self.assertEqual(wf.extras[0].model, "openrouter/free")
        self.assertEqual(wf.extras[0].browser_tool_model, "jev-latest")
        for extra in wf.extras:
            self.assertEqual(extra.cdp_url, "http://127.0.0.1:19999")
            self.assertEqual(extra.profile, "yuba-social")
            self.assertEqual(extra.env["PROFILE"], "yuba-social")
            self.assertEqual(extra.loop_count, 3)
            self.assertEqual(extra.loop_delay, 5.0)
            self.assertEqual(extra.env["SLIDES_SCRIPT"], "/tmp/slides.sh")

    def test_browser_tool_model_defaults_to_local_von(self) -> None:
        from unittest.mock import patch

        from cg_loop import model

        self.assertEqual(model._browser_model_name("", {}), "von")
        self.assertEqual(model._browser_model_name("layla", {}), "layla")
        self.assertEqual(model.browser_tool_backend("von"), "von")
        self.assertEqual(model.browser_tool_backend("layla"), "laya")
        self.assertEqual(model.browser_tool_backend("laya"), "laya")
        self.assertEqual(model.browser_tool_backend("jev-latest"), "jev")
        self.assertEqual(model._browser_model_name("", {"BROWSER_TOOL_MODEL": "jev-latest"}), "jev-latest")

        body = {
            "model": "von",
            "state": {"page": {"title": "Studio"}},
            "questions": {
                "operation": {
                    "type": "choice",
                    "instructions": {"goal": "Click Create", "rules": ["Prefer the button"]},
                    "criteria": {"CLICK": {"element": "Create", "role": "button"}, "DONE": "done"},
                }
            },
        }

        class Answer:
            choice = "CLICK"
            probabilities = {"CLICK": 0.7, "DONE": 0.3}
            confidence = 0.4

        class Resp:
            answers = {"operation": Answer()}

        seen: dict = {}

        def von_call(state, questions):
            seen["state"] = state
            seen["questions"] = questions
            return Resp()

        try:
            model.configure("local", "", browser_tool_model="")
            self.assertEqual(model.browser_model_name(), "von")
            with patch.object(model, "_von_call", von_call):
                result = model._jev_post(body)
            self.assertEqual(result["model"], "von")
            self.assertEqual(result["answers"]["operation"]["choice"], "CLICK")
            model._validate_jev_choice(result["answers"]["operation"], {"CLICK", "DONE"})
            self.assertIn("Click Create", seen["questions"]["operation"]["instructions"])
            self.assertIn("Create", seen["questions"]["operation"]["criteria"]["CLICK"])

            def laya_call(_state, _questions):
                return {
                    "answers": {
                        "operation": {
                            "choice": "DONE",
                            "probabilities": {"CLICK": 0.2, "DONE": 0.8},
                            "confidence": 0.5,
                        }
                    }
                }

            layla = {**body, "model": "layla"}
            with patch.object(model, "_laya_call", laya_call):
                result = model._jev_post(layla)
            self.assertEqual(result["model"], "layla")
            self.assertEqual(result["answers"]["operation"]["choice"], "DONE")

            def missing(*_args, **_kwargs):
                raise ImportError("no module named von")

            with patch.object(model, "_von_call", missing):
                with self.assertRaises(model.ChatError) as raised:
                    model._jev_post(body)
            self.assertIn("pip install von-sdk", str(raised.exception))
        finally:
            model.configure("local", "", browser_tool_model="")

    def test_missing_laya_is_installed_and_loaded(self) -> None:
        import sys
        from types import SimpleNamespace
        from unittest.mock import patch

        from cg_loop import model
        from cg_loop.workflow import Workflow, parse_step

        created: list[str] = []

        class Router:
            def __init__(self) -> None:
                created.append("router")

            def predict(self, state: dict, questions: dict) -> dict:
                created.append("predict")
                return {
                    "answers": {
                        "operation": {
                            "choice": "DONE",
                            "probabilities": {"DONE": 1.0},
                            "confidence": 1.0,
                        }
                    }
                }

        def install(name: str) -> None:
            created.append(name)
            sys.modules["laya"] = SimpleNamespace(Router=Router)

        workflow = Workflow(
            name="tiktok",
            steps=[parse_step("/browser go https://www.tiktok.com/tiktokstudio/content verify Views")],
            browser_tool_model="layla",
        )
        model._LAYA_ROUTER = None
        try:
            with patch.dict(sys.modules, {"laya": None}):
                with patch.object(model, "_install_package", install):
                    self.assertTrue(model.workflow_needs_laya(workflow))
                    model.load_laya_if_needed(workflow)
                    result = model._laya_call({"page": {}}, {"operation": {}})
            self.assertEqual(created, ["laya", "router", "predict"])
            self.assertEqual(result["answers"]["operation"]["choice"], "DONE")
            self.assertIs(model._LAYA_ROUTER, model.ensure_laya_router())
        finally:
            model._LAYA_ROUTER = None

    def test_subworkflow_lookup_from_env_path_list(self) -> None:
        import os
        import tempfile

        from cg_loop.workflow import find_workflow, workflow_search_paths

        with tempfile.TemporaryDirectory() as tmp:
            first = Path(tmp) / "a"
            second = Path(tmp) / "b"
            first.mkdir()
            second.mkdir()
            child = second / "wf-child.yaml"
            child.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: child wf",
                        "  profile: child-default",
                        "  env:",
                        "    CHILD_ONLY: 1",
                        "wf_child:",
                        "  - term echo child",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            parent = first / "wf-parent.yaml"
            parent.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: parent wf",
                        "  profile: parent-default",
                        "  env:",
                        f"    WORKFLOW_PATH:",
                        f"      - {first}",
                        f"      - {second}",
                        "wf_parent:",
                        "  - term echo parent",
                        "  - msg: child wf",
                        "    type: workflow",
                        "    params:",
                        "      profile: nested-profile",
                        "      CHILD_ENV: from-params",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(parent)
            self.assertIn(str(second), wf.env["WORKFLOW_PATH"].split(os.pathsep))
            parent_group = wf.extras[0]
            self.assertEqual(len(parent_group.steps), 2)
            self.assertEqual(parent_group.steps[1].kind, "workflow")
            nested = parent_group.steps[1].nested
            self.assertIsNotNone(nested)
            assert nested is not None
            self.assertEqual(nested.profile, "nested-profile")
            self.assertEqual(nested.env["PROFILE"], "nested-profile")
            self.assertEqual(nested.env["CHILD_ENV"], "from-params")
            self.assertEqual(nested.env["CHILD_ONLY"], "1")
            self.assertEqual(nested.all_steps()[0].kind, "term")
            found = find_workflow("wf-child", workflow_search_paths(wf.env, wf.path))
            self.assertEqual(found, child.resolve())

    def test_workflow_msg_selects_steps_groups(self) -> None:
        import tempfile

        from cg_loop.workflow import split_workflow_msg

        self.assertEqual(split_workflow_msg(""), ("", ""))
        self.assertEqual(split_workflow_msg("wf-contet-post"), ("wf-contet-post", ""))
        self.assertEqual(split_workflow_msg("wf_slides", explicit="wf-contet-post"), ("wf-contet-post", "wf_slides"))
        self.assertEqual(
            split_workflow_msg("wf_research|wf_slides", explicit="wf-contet-post"),
            ("wf-contet-post", "wf_research|wf_slides"),
        )
        self.assertEqual(split_workflow_msg("wf-contet-post"), ("wf-contet-post", ""))
        self.assertEqual(
            split_workflow_msg("wf-contet-post wf_research|wf_slides"),
            ("wf-contet-post", "wf_research|wf_slides"),
        )
        self.assertEqual(split_workflow_msg("child wf"), ("child wf", ""))

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            child = root / "wf-child.yaml"
            child.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: child",
                        "wf_research:",
                        "  - term echo default",
                        "wf_slides:",
                        "  - term echo slides",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            parent = root / "wf-parent.yaml"
            parent.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: parent",
                        "  env:",
                        f"    WORKFLOW_PATH: {root}",
                        "wf_parent:",
                        "  - msg: wf-child wf_all",
                        "    type: workflow",
                        "    params: {}",
                        "  - msg: wf_all",
                        "    type: workflow",
                        "    workflow: wf-child",
                        "  - msg: wf_slides",
                        "    type: workflow",
                        "    workflow: wf-child",
                        "  - msg: wf_research|wf_slides",
                        "    type: workflow",
                        "    workflow: wf-child",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(parent)
            parent_group = wf.extras[0]
            named = parent_group.steps[0].nested
            all_groups = parent_group.steps[1].nested
            slides_only = parent_group.steps[2].nested
            piped = parent_group.steps[3].nested
            assert named is not None and all_groups is not None and slides_only is not None and piped is not None
            self.assertEqual([step.command for step in named.extras[0].steps], ["echo default"])
            self.assertEqual(named.extras[0].group, "wf_research")
            self.assertEqual(named.extras[1].group, "wf_slides")
            self.assertEqual([step.command for step in all_groups.extras[0].steps], ["echo default"])
            self.assertEqual(all_groups.extras[1].group, "wf_slides")
            self.assertEqual(slides_only.group, "wf_slides")
            self.assertEqual(slides_only.extras, [])
            self.assertEqual([step.command for step in slides_only.steps], ["echo slides"])
            self.assertEqual(piped.group, "")
            self.assertEqual(piped.extras[0].group, "wf_research")
            self.assertEqual(piped.extras[1].group, "wf_slides")

    def test_step_cache_lives_under_workflows_cache(self) -> None:
        import tempfile

        from cg_loop.step_cache import (
            find_step_script,
            step_cache_path,
            workflow_cache_dir,
            write_step_script,
        )
        from cg_loop.workflow import Workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "workflows"
            root.mkdir()
            yaml_path = root / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        f"  env:",
                        f"    WORKFLOW_PATH: {root}",
                        "wf_demo:",
                        "  - msg: echo from cache",
                        "    type: shell",
                        "    params: {}",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(yaml_path)
            cache_dir = workflow_cache_dir(wf)
            self.assertEqual(cache_dir, (root / "cache" / "wf-demo").resolve())
            step = wf.extras[0].steps[0]
            path = step_cache_path(wf, step)
            self.assertEqual(path.name, "b-compile.sh")
            self.assertEqual(path.parent.parent, cache_dir / "main")
            grouped = step_cache_path(wf.extras[0], step)
            self.assertEqual(grouped.parent.parent, cache_dir / "wf_demo")
            self.assertTrue(grouped.parent.name.startswith("echo_from_cache_"))
            write_step_script(path, "echo cached-ok\n", language="shell")
            found = find_step_script(wf, step)
            self.assertEqual(found, path)
            self.assertIn("echo cached-ok", path.read_text(encoding="utf-8"))
            self.assertNotIn("cg-loop", str(path))

    def test_catalog_cache_lives_beside_workflows_app(self) -> None:
        import os
        import tempfile

        from cg_loop.app_config import reset_app_config
        from cg_loop.step_cache import workflow_cache_dir

        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            catalog = project / "workflows"
            catalog.mkdir()
            app = project / "workflows-app.yaml"
            app.write_text("workflows: workflows\n", encoding="utf-8")
            yaml_path = catalog / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "wf_demo:",
                        "  - msg: echo from cache",
                        "    type: shell",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            previous = os.environ.get("CG_LOOP_APP")
            os.environ["CG_LOOP_APP"] = str(app)
            reset_app_config()
            try:
                wf = load_workflow(yaml_path)
                self.assertEqual(
                    workflow_cache_dir(wf),
                    (project / "cache" / "wf-demo").resolve(),
                )
                self.assertEqual(
                    workflow_cache_dir(wf, env={"WORKFLOW_CACHE": str(project / "other")}),
                    (project / "other" / "wf-demo").resolve(),
                )
            finally:
                if previous is None:
                    os.environ.pop("CG_LOOP_APP", None)
                else:
                    os.environ["CG_LOOP_APP"] = previous
                reset_app_config()

    def test_group_object_auto_and_config(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-object.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: object",
                        "  profile: yuba-heart",
                        "  cdp-url: http://127.0.0.1:18802",
                        "  llm: openrouter",
                        "  model: openrouter/free",
                        "  loop-count: 1",
                        "  env:",
                        "    KEEP: parent",
                        "    NAME: parent",
                        "wf_compiled:",
                        "  - term echo parent",
                        "wf_auto:",
                        "  config:",
                        "    profile: yuba-social",
                        "    cdp-url: http://127.0.0.1:18801",
                        "    llm: local",
                        "    model: qwen3.8-27b-mlx",
                        "    env:",
                        "      NAME: child",
                        "      ONLY: group",
                        "  auto:",
                        "    - /browser click the Shorts tab",
                        "wf_both:",
                        "  config:",
                        "    loop-count: 3",
                        "    loop-delay: 2",
                        "    env:",
                        "      KEEP: child",
                        "  steps:",
                        "    - term echo compiled",
                        "  auto: true",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        self.assertEqual(wf.profile, "yuba-heart")
        self.assertEqual(wf.cdp_url, "http://127.0.0.1:18802")
        compiled, auto, both = wf.extras
        self.assertEqual(compiled.group, "wf_compiled")
        self.assertFalse(compiled.steps[0].auto)
        self.assertEqual(compiled.profile, "yuba-heart")
        self.assertEqual(compiled.env["KEEP"], "parent")
        self.assertEqual(compiled.env["NAME"], "parent")
        self.assertNotIn("ONLY", compiled.env)
        self.assertEqual(auto.profile, "yuba-social")
        self.assertEqual(auto.cdp_url, "http://127.0.0.1:18801")
        self.assertEqual(auto.llm, "local")
        self.assertEqual(auto.model, "qwen3.8-27b-mlx")
        self.assertEqual(auto.env["PROFILE"], "yuba-social")
        self.assertEqual(auto.env["NAME"], "child")
        self.assertEqual(auto.env["ONLY"], "group")
        self.assertEqual(auto.env["KEEP"], "parent")
        self.assertTrue(auto.steps[0].auto)
        self.assertEqual(auto.steps[0].kind, "goal")
        self.assertEqual(auto.steps[0].tool, "browser")
        self.assertFalse(auto.owns_loop)
        self.assertIn("[auto]", auto.plan_text())
        self.assertTrue(both.owns_loop)
        self.assertEqual(both.loop_count, 3)
        self.assertEqual(both.loop_delay, 2.0)
        self.assertEqual(both.env["KEEP"], "child")
        self.assertTrue(both.steps[0].auto)
        self.assertEqual(both.steps[0].kind, "term")
        self.assertEqual(wf.env["NAME"], "parent")
        self.assertEqual(wf.llm, "openrouter")

    def test_routine_config_overrides_scheduler_and_steps(self) -> None:
        import tempfile

        from cg_loop.workflow import runnable_steps

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-schedule.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: scheduled",
                        "  profile: parent",
                        "  cdp-url: http://127.0.0.1:18802",
                        "  scheduler: '0 9 * * *'",
                        "  steps:",
                        "    - set_config SHARED=from-config",
                        "    - term echo shared",
                        "alpha_routine:",
                        "  - term echo alpha",
                        "beta_routine_setup:",
                        "  profile: child",
                        "  cdp-url: http://127.0.0.1:18801",
                        "  scheduler: '15 8 * * 1-5'",
                        "  steps:",
                        "    - set_config SHARED=from-routine",
                        "beta_routine:",
                        "  - term echo beta",
                        "gamma_routine_setup:",
                        "  scheduler: false",
                        "gamma_routine:",
                        "  - term echo gamma",
                        "delta_routine:",
                        "  config:",
                        "    scheduler: '0 12 * * *'",
                        "  steps:",
                        "    - term echo delta",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        groups = {group.group: group for group in wf.extras}
        alpha, beta, gamma, delta = (groups[name] for name in ("alpha_routine", "beta_routine", "gamma_routine", "delta_routine"))
        self.assertEqual(alpha.scheduler, "0 9 * * *")
        self.assertEqual(alpha.profile, "parent")
        self.assertEqual(alpha.cdp_url, "http://127.0.0.1:18802")
        self.assertEqual([step.raw for step in alpha.before], ["set_config SHARED=from-config", "term echo shared"])
        self.assertEqual([step.raw for step in alpha.steps], ["term echo alpha"])
        self.assertEqual([step.raw for step in runnable_steps(alpha)], ["set_config SHARED=from-config", "term echo shared", "term echo alpha"])
        self.assertEqual(alpha.env["SHARED"], "from-config")
        self.assertEqual(beta.scheduler, "15 8 * * 1-5")
        self.assertEqual(beta.profile, "child")
        self.assertEqual(beta.cdp_url, "http://127.0.0.1:18801")
        self.assertEqual(beta.env["PROFILE"], "child")
        self.assertEqual([step.raw for step in beta.before], ["set_config SHARED=from-routine"])
        self.assertEqual([step.raw for step in beta.steps], ["term echo beta"])
        self.assertEqual(beta.env["SHARED"], "from-routine")
        self.assertEqual(gamma.scheduler, "")
        self.assertEqual([step.raw for step in gamma.before], ["set_config SHARED=from-config", "term echo shared"])
        self.assertEqual(delta.scheduler, "0 12 * * *")
        self.assertEqual([step.raw for step in delta.before], ["set_config SHARED=from-config", "term echo shared"])
        self.assertEqual([step.raw for step in delta.steps], ["term echo delta"])
        self.assertNotIn("beta_routine_setup", groups)
        chosen = select_step_at_line(wf, alpha.steps[0].line, only="alpha_routine")
        self.assertEqual([step.raw for step in chosen.before], [step.raw for step in alpha.before])
        self.assertEqual([step.raw for step in chosen.steps], ["term echo alpha"])

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-bad.yaml"
            path.write_text(
                "config:\n  scheduler: nope\nbad_routine:\n  - term echo bad\n",
                encoding="utf-8",
            )
            with self.assertRaises(ValueError) as bad:
                load_workflow(path)
        self.assertIn("five cron fields", str(bad.exception))

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-missing.yaml"
            path.write_text(
                "config:\n  name: missing\nmissing_routine_setup:\n  scheduler: '* * * * *'\nother_routine:\n  - term echo x\n",
                encoding="utf-8",
            )
            with self.assertRaises(ValueError) as missing:
                load_workflow(path)
        self.assertIn("no missing_routine", str(missing.exception))

    def test_setup_line_runs_that_step_only(self) -> None:
        import tempfile

        from cg_loop.workflow import runnable_steps

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-setup-line.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: setup-line",
                        "target_routine_setup:",
                        "  steps:",
                        "    - set_config A=1",
                        "    - term echo title",
                        "    - set_config B=2",
                        "target_routine:",
                        "  - term echo body",
                        "other_routine:",
                        "  - term echo other",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            wf = load_workflow(path)
        group = {item.group: item for item in wf.extras}["target_routine"]
        self.assertEqual([step.line for step in group.before], [5, 6, 7])
        one = select_step_at_line(wf, 6)
        self.assertEqual(one.group, "target_routine")
        self.assertEqual([step.raw for step in one.steps], ["term echo title"])
        self.assertEqual(one.before, [])
        self.assertEqual(runnable_steps(one), one.steps)
        body = select_step_at_line(wf, 9, only="target_routine")
        self.assertEqual([step.raw for step in body.steps], ["term echo body"])
        self.assertEqual([step.raw for step in body.before], [step.raw for step in group.before])
        pair = select_steps_between(wf, 5, 6)
        self.assertEqual([step.raw for step in pair.steps], ["set_config A=1", "term echo title"])
        self.assertEqual(pair.before, [])

    def test_app_defaults_fill_a_workflow_and_the_file_overrides(self) -> None:
        import os

        sleep = load_workflow(YAML.parent / "wf-sleep-story.yaml")
        self.assertEqual(sleep.llm, "")
        self.assertEqual(sleep.model, "")
        self.assertEqual(sleep.browser_tool_model, "jev-latest")
        self.assertEqual(sleep.llm_timeout, 30.0)
        self.assertEqual(sleep.loop_delay, 0.0)
        self.assertFalse(sleep.browser_recompile)
        self.assertEqual(sleep.browser_reusetab, "youtube")
        self.assertEqual(sleep.extras[0].browser_reusetab, "youtube")
        self.assertTrue(sleep.recompile_on_error)
        self.assertEqual(sleep.env["LM_STUDIO_BASE_URL"], "http://127.0.0.1:1234/v1")
        self.assertEqual(sleep.env["VIRTUAL_ENV"], str(SKILL / "venv"))
        self.assertTrue(sleep.env["PATH"].startswith(sleep.env["VIRTUAL_ENV"] + "/bin"))
        self.assertIn("/bin", sleep.env["PATH"].split(os.pathsep))
        apply_overrides(sleep, {"browser-recompile": "0", "recompile-on-error": "0", "venv": "/tmp/other-venv"})
        self.assertFalse(sleep.browser_recompile)
        self.assertFalse(sleep.recompile_on_error)
        self.assertEqual(sleep.env["VIRTUAL_ENV"], "/tmp/other-venv")
        self.assertTrue(sleep.env["PATH"].startswith("/tmp/other-venv/bin"))
        self.assertIn("/bin", sleep.env["PATH"].split(os.pathsep))
        self.assertNotIn(
            str(SKILL / "venv" / "bin"),
            sleep.env["PATH"].split(":")[0],
        )
        self.assertEqual(sleep.extras[0].env["VIRTUAL_ENV"], "/tmp/other-venv")

    def test_venv_path_keeps_process_directories(self) -> None:
        import os
        import tempfile

        previous = os.environ.get("PATH")
        os.environ["PATH"] = "/usr/bin:/bin:/usr/sbin"
        try:
            with tempfile.TemporaryDirectory() as tmp:
                yaml_path = Path(tmp) / "wf-demo.yaml"
                yaml_path.write_text(
                    "config:\n  name: demo\nwf_demo:\n  - term echo hi\n",
                    encoding="utf-8",
                )
                workflow = load_workflow(yaml_path)
        finally:
            if previous is None:
                os.environ.pop("PATH", None)
            else:
                os.environ["PATH"] = previous
        parts = workflow.env["PATH"].split(os.pathsep)
        self.assertEqual(parts[0], str(SKILL / "venv" / "bin"))
        self.assertEqual(parts[1:], ["/usr/bin", "/bin", "/usr/sbin"])

    def test_workflow_file_venv_replaces_the_shared_one(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            other = root / "other-venv"
            (other / "bin").mkdir(parents=True)
            yaml_path = root / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        f"  venv: {other}",
                        "wf_demo:",
                        "  - term echo hi",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            self.assertEqual(workflow.env["VIRTUAL_ENV"], str(other))
            self.assertEqual(workflow.extras[0].env["VIRTUAL_ENV"], str(other))
            self.assertTrue(workflow.env["PATH"].startswith(str(other / "bin")))
        youtube = load_workflow(YAML.parent / "wf-youtube-kw.yaml")
        self.assertEqual(youtube.llm, "local")
        self.assertEqual(youtube.model, "qwen3.8-27b-mlx")
        self.assertEqual(youtube.browser_tool_model, "jev-latest")
        self.assertEqual(youtube.llm_timeout, 120.0)
        self.assertEqual(youtube.loop_count, 1)


class ReuseTabTests(unittest.TestCase):
    def test_compiles_to_run_reuse_tab(self) -> None:
        import tempfile

        from cg_loop.compiled import ensure_compiled
        from cg_loop.workflow import load_workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_stats:",
                        "  - /browser reuseTab youtube",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
            group = workflow.extras[0]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            body = created.path.read_text(encoding="utf-8")
            self.assertIn("run_reuse_tab(ctx, 'youtube')", body)

    def test_reuse_tab_keeps_match_or_opens_one(self) -> None:
        from cg_loop.browser import Browser

        class Page:
            def __init__(self, url: str) -> None:
                self.url = url
                self.timeout = None

            def set_default_timeout(self, ms: int) -> None:
                self.timeout = ms

        class Context:
            def __init__(self, pages: list[Page]) -> None:
                self.pages = pages

            def new_page(self) -> Page:
                page = Page("about:blank")
                self.pages.append(page)
                return page

        studio = Page("https://studio.youtube.com/channel/abc/videos")
        login = Page("https://accounts.google.com/signin/youtube")
        other = Page("https://example.com")
        browser = Browser("http://127.0.0.1:9")
        browser._ctx = Context([other, login, studio])
        browser.page = other
        browser.observe = lambda: {"url": browser.page.url, "title": "", "text": ""}  # type: ignore[method-assign]

        info = browser.reuse_tab("youtube")
        self.assertTrue(info["reused"])
        self.assertEqual(browser.reuse_site, "youtube")
        self.assertIs(browser.page, studio)
        self.assertEqual(len(browser._ctx.pages), 3)

        again = browser.reuse_tab("youtube")
        self.assertIs(browser.page, studio)
        self.assertTrue(again["reused"])

        fresh = Browser("http://127.0.0.1:9")
        fresh._ctx = Context([other])
        fresh.page = other
        fresh.observe = lambda: {"url": fresh.page.url, "title": "", "text": ""}  # type: ignore[method-assign]
        opened = fresh.reuse_tab("tiktok")
        self.assertFalse(opened["reused"])
        self.assertEqual(fresh.reuse_site, "tiktok")
        self.assertEqual(fresh.page.url, "about:blank")
        self.assertEqual(len(fresh._ctx.pages), 2)
        self.assertIs(fresh._ctx.pages[0], other)

        held = Browser("http://127.0.0.1:9")
        held.create_tabs = False
        held._ctx = Context([other])
        held.page = other
        held.observe = lambda: {"url": held.page.url, "title": "", "text": ""}  # type: ignore[method-assign]
        stayed = held.reuse_tab("tiktok")
        self.assertTrue(stayed["reused"])
        self.assertIs(held.page, other)
        self.assertEqual(len(held._ctx.pages), 1)

        startup = Browser("http://127.0.0.1:9", reuse_site="youtube")
        startup._ctx = Context([other])
        startup.page = other
        startup.observe = lambda: {"url": startup.page.url, "title": "", "text": ""}  # type: ignore[method-assign]
        self.assertTrue(startup._use_configured_tab())
        self.assertIs(startup.page, other)
        self.assertEqual(len(startup._ctx.pages), 1)

        configured = Browser("http://127.0.0.1:9", reuse_site="youtube")
        configured._ctx = Context([other, studio])
        configured.page = other
        configured.observe = lambda: {"url": configured.page.url, "title": "", "text": ""}  # type: ignore[method-assign]
        self.assertTrue(configured._use_configured_tab())
        self.assertIs(configured.page, studio)

        active = Browser("http://127.0.0.1:9", reuse_site="")
        active.page = other
        self.assertFalse(active._use_configured_tab())
        self.assertIs(active.page, other)

    def test_workflow_reusetab_replaces_the_youtube_default(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            yaml_path = Path(tmp) / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  browser-reusetab: instagram",
                        "wf_demo:",
                        "  - term echo hi",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
        self.assertEqual(workflow.browser_reusetab, "instagram")
        self.assertEqual(workflow.extras[0].browser_reusetab, "instagram")
        apply_overrides(workflow, {"browser-reusetab": "tiktok"})
        self.assertEqual(workflow.browser_reusetab, "tiktok")
        self.assertEqual(workflow.extras[0].browser_reusetab, "tiktok")
        apply_overrides(workflow, {"browser-reusetab": ""})
        self.assertEqual(workflow.browser_reusetab, "")
        self.assertEqual(workflow.extras[0].browser_reusetab, "")

    def test_set_config_step_switches_the_tab_when_it_runs(self) -> None:
        import tempfile

        from cg_loop.agent import Agent

        with tempfile.TemporaryDirectory() as tmp:
            yaml_path = Path(tmp) / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "wf_demo:",
                        "  - set-config browser-reusetab=instagram",
                        "  - set-config browser-reusetab=tiktok",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            workflow = load_workflow(yaml_path)
        self.assertEqual(workflow.browser_reusetab, "youtube")
        self.assertEqual(workflow.extras[0].browser_reusetab, "youtube")
        group = workflow.extras[0]
        step = group.steps[0]
        self.assertEqual(step.kind, "set_config")
        self.assertEqual(step.var, "browser-reusetab")
        self.assertEqual(step.extra, "instagram")

        class Tab:
            def __init__(self) -> None:
                self.sites: list[str] = []

            def reuse_tab(self, site: str) -> dict:
                self.sites.append(site)
                return {"url": f"https://{site}.example", "reused": True}

        agent = Agent(group, dry_run=True, run_dir=Path(tempfile.mkdtemp()))
        tab = Tab()
        agent.browser = tab  # type: ignore[assignment]
        agent._direct_step(step)
        self.assertEqual(tab.sites, ["instagram"])
        self.assertEqual(group.browser_reusetab, "instagram")
        apply_overrides(group, {"browser-reusetab": "youtube"}, lock=True)
        agent._direct_step(group.steps[1])
        self.assertEqual(tab.sites, ["instagram"])
        self.assertEqual(group.browser_reusetab, "youtube")

    def test_observe_reconnects_when_the_driver_closes(self) -> None:
        from cg_loop.browser import Browser, accept_js_dialog, listen_for_js_dialogs

        class Page:
            def __init__(self, fail: bool) -> None:
                self.fail = fail

            def evaluate(self, _js: str) -> dict:
                if self.fail:
                    self.fail = False
                    raise RuntimeError("Page.evaluate: Connection closed while reading from the driver")
                return {"url": "https://www.tiktok.com/", "title": "TikTok", "text": "hi", "actions": []}

        browser = Browser("http://127.0.0.1:9")
        browser.page = Page(True)
        opened = {"n": 0}

        def reconnect() -> None:
            opened["n"] += 1
            browser.page = Page(False)

        browser.reconnect = reconnect  # type: ignore[method-assign]
        info = browser.observe()
        self.assertEqual(opened["n"], 1)
        self.assertEqual(info["url"], "https://www.tiktok.com/")

        class Dialog:
            def accept(self) -> None:
                raise RuntimeError("Protocol error (Page.handleJavaScriptDialog): No dialog is showing")

        class Target:
            def __init__(self) -> None:
                self.handlers: list = []

            def on(self, event: str, handler) -> None:
                self.handlers.append((event, handler))

        target = Target()
        listen_for_js_dialogs(target)
        listen_for_js_dialogs(target)
        self.assertEqual(len(target.handlers), 1)
        accept_js_dialog(Dialog())
        target.handlers[0][1](Dialog())


class EnsureCdpTests(unittest.TestCase):
    def test_starts_profile_when_cdp_is_down(self) -> None:
        import tempfile

        from cg_loop.browser import ensure_cdp

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            binary = root / "Brave Browser"
            binary.write_text("#!/bin/sh\n", encoding="utf-8")
            data = root / "yuba-heart"
            data.mkdir()
            launched: list[list[str]] = []
            checks = {"n": 0}

            def ready(_url: str) -> bool:
                checks["n"] += 1
                return checks["n"] > 1

            def popen(cmd, **_kwargs):
                launched.append(list(cmd))

            ensure_cdp(
                "http://127.0.0.1:18802",
                "yuba-heart",
                executable=binary,
                user_data_dir=data,
                wait_s=2,
                ready=ready,
                popen=popen,
            )

        self.assertEqual(len(launched), 1)
        cmd = launched[0]
        self.assertEqual(cmd[0], str(binary))
        self.assertIn("--remote-debugging-port=18802", cmd)
        self.assertIn(f"--user-data-dir={data}", cmd)

    def test_skips_launch_when_cdp_is_ready(self) -> None:
        from cg_loop.browser import ensure_cdp

        launched: list[list[str]] = []
        ensure_cdp(
            "http://127.0.0.1:18801",
            "yuba-social",
            ready=lambda _url: True,
            popen=lambda cmd, **_kwargs: launched.append(list(cmd)),
        )
        self.assertEqual(launched, [])

    def test_path_profile_is_created_and_started(self) -> None:
        import tempfile

        from cg_loop.browser import ensure_cdp

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            binary = root / "Brave Browser"
            binary.write_text("#!/bin/sh\n", encoding="utf-8")
            data = root / "fb_ads_profile"
            launched: list[list[str]] = []
            checks = {"n": 0}

            def ready(_url: str) -> bool:
                checks["n"] += 1
                return checks["n"] > 1

            def popen(cmd, **_kwargs):
                launched.append(list(cmd))

            ensure_cdp(
                "http://127.0.0.1:9222",
                str(data),
                executable=binary,
                wait_s=2,
                ready=ready,
                popen=popen,
            )
            self.assertTrue(data.is_dir())
            self.assertEqual(len(launched), 1)
            self.assertIn(f"--user-data-dir={data}", launched[0])
            self.assertIn("--remote-debugging-port=9222", launched[0])

    def test_env_picks_the_browser_and_plugin(self) -> None:
        import os
        import tempfile
        from unittest.mock import patch

        from cg_loop.browser import ensure_cdp

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            binary = root / "Chrome"
            binary.write_text("#!/bin/sh\n", encoding="utf-8")
            plugin = root / "plugin"
            plugin.mkdir()
            data = root / "profile"
            data.mkdir()
            launched: list[list[str]] = []
            checks = {"n": 0}

            def ready(_url: str) -> bool:
                checks["n"] += 1
                return checks["n"] > 1

            def popen(cmd, **_kwargs):
                launched.append(list(cmd))

            with patch.dict(os.environ, {"CG_LOOP_BROWSER": str(binary), "CG_LOOP_BROWSER_PLUGIN": str(plugin)}):
                ensure_cdp(
                    "http://127.0.0.1:9222",
                    "profile",
                    user_data_dir=data,
                    wait_s=2,
                    ready=ready,
                    popen=popen,
                )

        self.assertEqual(launched[0][0], str(binary))
        self.assertIn(f"--load-extension={plugin}", launched[0])
        self.assertIn(f"--disable-extensions-except={plugin}", launched[0])

    def test_missing_plugin_raises(self) -> None:
        import os
        import tempfile
        from unittest.mock import patch

        from cg_loop.browser import ensure_cdp

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            binary = root / "Chrome"
            binary.write_text("#!/bin/sh\n", encoding="utf-8")
            data = root / "profile"
            data.mkdir()
            with patch.dict(os.environ, {"CG_LOOP_BROWSER_PLUGIN": str(root / "missing-plugin")}):
                with self.assertRaises(FileNotFoundError):
                    ensure_cdp(
                        "http://127.0.0.1:9222",
                        "profile",
                        executable=binary,
                        user_data_dir=data,
                        ready=lambda _url: False,
                        popen=lambda cmd, **_kwargs: None,
                    )

    def test_missing_named_profile_raises(self) -> None:
        from cg_loop.browser import ensure_cdp

        with self.assertRaises(FileNotFoundError):
            ensure_cdp(
                "http://127.0.0.1:9222",
                "profile-does-not-exist-xyz",
                ready=lambda _url: False,
                popen=lambda cmd, **_kwargs: None,
            )

    def test_known_port_selects_profile(self) -> None:
        from cg_loop.browser import resolve_profile

        self.assertEqual(resolve_profile("http://127.0.0.1:18801"), "yuba-social")
        self.assertEqual(resolve_profile("http://127.0.0.1:18802", "yuba-heart"), "yuba-heart")


class ConditionCatalogTests(unittest.TestCase):
    def test_condition_list_is_steps_plus_a_return(self) -> None:
        step = parse_step(
            {
                "condition": [
                    "/browser go to youtube video",
                    "/browser extract youtube videos scheduled",
                    "if no videos scheduled then return true",
                ],
                "steps": ["term print no videos scheduled"],
            }
        )
        self.assertEqual(step.kind, "condition")
        self.assertEqual(step.condition, "if no videos scheduled then return true")
        self.assertEqual([check.tool for check in step.checks], ["browser", "browser"])
        self.assertEqual(step.checks[0].kind, "goal")
        self.assertEqual(step.checks[1].extra, "extract youtube videos scheduled")
        self.assertEqual(step.steps[0].command, "print no videos scheduled")
        folded = parse_step(
            {
                "condition": "\n".join(
                    [
                        "/browser go to youtube video",
                        "/browser extract youtube videos scheduled",
                        "if no videos scheduled then return true",
                    ]
                ),
                "steps": ["term echo ok"],
            }
        )
        self.assertEqual([check.raw for check in folded.checks], [check.raw for check in step.checks])
        with self.assertRaises(ValueError) as raised:
            parse_step({"condition": ["/browser go to youtube video"], "steps": ["term echo ok"]})
        self.assertIn("return true", str(raised.exception))

    def test_sleep_story_schedule_conditions(self) -> None:
        sleep = load_workflow(YAML.parent / "wf-sleep-story.yaml")
        group = sleep.named_groups()["post_sleep_story_social_content_routine"]
        videos, shorts = group.steps
        self.assertEqual(videos.condition, "if no videos scheduled then return true")
        self.assertEqual(
            [check.raw for check in videos.checks],
            [
                "/browser +go to youtube video",
                "/browser +extract youtube videos scheduled",
            ],
        )
        self.assertEqual(shorts.condition, "if no shorts scheduled then return true")
        self.assertEqual(shorts.checks[0].raw, "/browser +go to youtube shorts")
        self.assertIn("1.c1. /browser +go to youtube video", group.plan_text())

    def test_duplicate_key_in_one_file_errors(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "wf-dup.yaml"
            path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: dup",
                        "wf_main:",
                        "  - term echo a",
                        "wf_main:",
                        "  - term echo b",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            with self.assertRaises(ValueError) as raised:
                load_workflow(path)
        self.assertIn("duplicate key", str(raised.exception))
        self.assertIn("wf_main", str(raised.exception))

    def test_folder_resolves_groups_and_rejects_conflicts(self) -> None:
        import tempfile

        from cg_loop.workflow import load_workflow_dir

        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "wf-main.yaml").write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: main",
                        "wf_main:",
                        "  - term echo main",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            (folder / "wf-other.yaml").write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: other",
                        "wf_other:",
                        "  - condition: if empty",
                        "    steps:",
                        "      - type: workflow",
                        "        workflow: wf_main",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            loaded = load_workflow_dir(folder)
            other = loaded.named_groups()["wf_other"]
            called = other.steps[0].steps[0]
            self.assertEqual(called.kind, "workflow")
            self.assertIsNotNone(called.nested)
            assert called.nested is not None
            self.assertEqual(called.nested.group, "wf_main")
            self.assertEqual(called.nested.steps[0].command, "echo main")

            (folder / "wf-clash.yaml").write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: clash",
                        "wf_main:",
                        "  - term echo clash",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            with self.assertRaises(ValueError) as raised:
                load_workflow_dir(folder)
        message = str(raised.exception)
        self.assertIn("workflow key conflict", message)
        self.assertIn("wf_main", message)

    def test_workflow_search_includes_subfolders(self) -> None:
        import os
        import tempfile

        from cg_loop.app_config import reset_app_config
        from cg_loop.workflow import find_workflow, load_workflow_dir, workflow_bash_command, workflow_call_name, workflow_yaml_files
        from cg_loop.workflow import Workflow

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            nested = root / "stories"
            nested.mkdir()
            child = nested / "wf-child.yaml"
            child.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: child story",
                        "generate_story_routine:",
                        "  - term echo nested",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            cache = root / "cache"
            cache.mkdir()
            (cache / "wf-skip.yaml").write_text(
                "config:\n  name: skip\nwf_skip:\n  - term echo no\n",
                encoding="utf-8",
            )
            files = workflow_yaml_files(root)
            self.assertEqual(files, [child.resolve()])
            self.assertEqual(find_workflow("wf-child", [root]), child.resolve())
            self.assertEqual(find_workflow("child story", [root]), child.resolve())
            self.assertEqual(find_workflow("stories/wf-child", [root]), child.resolve())
            loaded = load_workflow_dir(root)
            self.assertEqual(loaded.named_groups()["generate_story_routine"].steps[0].command, "echo nested")

            app = root / "workflows-app.yaml"
            app.write_text(f"workflows: {root}\n", encoding="utf-8")
            previous = os.environ.get("CG_LOOP_APP")
            os.environ["CG_LOOP_APP"] = str(app)
            reset_app_config()
            try:
                named = Workflow(name="child story", group="generate_story_routine", path=child)
                self.assertEqual(workflow_call_name(named), "stories/wf-child")
                command = workflow_bash_command(named)
                self.assertIn("stories/wf-child", command)
                self.assertNotIn("wf-child.yaml", command)
            finally:
                if previous is None:
                    os.environ.pop("CG_LOOP_APP", None)
                else:
                    os.environ["CG_LOOP_APP"] = previous
                reset_app_config()

    def test_workflows_folder_has_unique_groups(self) -> None:
        from cg_loop.workflow import load_workflow_dir

        loaded = load_workflow_dir(YAML.parent)
        content = loaded.named_groups()["generate_content2_routine"]
        from cg_loop.workflow import resolve_subworkflow

        story = next(
            step
            for step in content.all_steps()
            if step.workflow_ref == "generate_story_routine" and step.params.get("STORY_TITLE") == "$story_idea"
        )
        self.assertEqual(story.workflow_ref, "generate_story_routine")
        self.assertEqual(story.params["STORY_TITLE"], "$story_idea")
        self.assertIsNone(story.nested)
        nested = resolve_subworkflow(
            story,
            parent=content,
            params={"STORY_TITLE": "A night in the forum"},
        )
        self.assertEqual(nested.group, "generate_story_routine")
        self.assertEqual(nested.env["STORY_TITLE"], "A night in the forum")
        from cg_loop.workflow import workflow_bash_command

        command = workflow_bash_command(nested, {"STORY_TITLE": "A night in the forum"})
        self.assertIn("bkase", command)
        self.assertIn("--only generate_story_routine", command)
        self.assertIn("wf-sleep-story", command)
        self.assertNotIn("wf-sleep-story.yaml", command)
        self.assertIn("--param 'STORY_TITLE=A night in the forum'", command)

    def test_generate_idea_passes_into_the_story_title(self) -> None:
        from cg_loop.compiled import run_generate, run_goal

        idea = run_generate(
            {"dry_run": True, "variables": {}, "env": {}},
            var="story_idea",
            extra="new idea for new sleep story $story_idea",
        )
        self.assertEqual(idea["variables"]["story_idea"], "(dry-run idea)")
        from cg_loop.compiled import idea_prompt

        from datetime import date

        prompt = idea_prompt(
            "one creative sleep story title. Use a month, a season, a historical event, an invention, a war, or the news.",
            avoid=["ancient rome"],
        )
        self.assertIn("Write one sleep story title only.", prompt)
        self.assertNotIn("Today is", prompt)
        self.assertIn("historical event", prompt)
        self.assertIn("Do not repeat: ancient rome", prompt)
        heart = idea_prompt(
            "one new idea about blood pressure. Connect it to history on this date one year ago, or to a current event.",
            avoid=["coffee and pressure"],
            today=date(2026, 10, 12),
        )
        self.assertIn("Write one idea only.", heart)
        self.assertNotIn("sleep story", heart)
        self.assertIn("Today is October 12, 2026.", heart)
        self.assertIn("Do not repeat: coffee and pressure", heart)
        from cg_loop.compiled import _idea_brief

        brief = _idea_brief(
            "one new idea $idea from $news. Say what that news does to your blood pressure.",
            {
                "news": {
                    "title": "Magnesium and blood pressure",
                    "url": "https://www.health.com/magnesium-blood-pressure",
                    "text": "A study this year looked at magnesium.",
                }
            },
            "idea",
        )
        self.assertIn("News:", brief)
        self.assertIn("https://www.health.com/magnesium-blood-pressure", brief)
        self.assertNotIn("$news", brief)
        news_prompt = idea_prompt(brief, today=date(2026, 10, 12))
        self.assertIn("Write one idea only.", news_prompt)
        self.assertNotIn("Today is", news_prompt)
        from cg_loop.compiled import _loaded_titles

        loaded = _loaded_titles(
            "one new idea $idea. Do not repeat $seen.",
            {"seen": ["Salt and blood pressure", "https://example.com/skip"]},
            "idea",
        )
        self.assertEqual(loaded, ["Salt and blood pressure"])
        avoided = idea_prompt("one new idea about blood pressure.", avoid=loaded)
        self.assertIn("Do not repeat: Salt and blood pressure", avoided)
        self.assertNotIn("$seen", _idea_brief(
            "one new idea $idea. Do not repeat $seen.",
            {"seen": ["Salt and blood pressure"]},
            "idea",
        ))
        goal = run_goal(
            {"env": {"STORY_TITLE": "A night in the forum"}, "variables": {}},
            "Choose one arc for $STORY_TITLE.",
        )
        self.assertEqual(goal["outputs"]["goal"], "Choose one arc for A night in the forum.")


class BrowserJsTests(unittest.TestCase):
    SOURCE = (
        '/browser js  document.querySelector(\'[data-tt="components_PublishStageLabel_FlexCenter"]\').textContent in $post_date'
    )

    def test_parses_js_into_the_variable(self) -> None:
        step = parse_step(self.SOURCE)
        self.assertEqual(step.tool, "browser")
        self.assertEqual(step.kind, "browser_js")
        self.assertEqual(step.var, "post_date")
        self.assertEqual(
            step.extra,
            'document.querySelector(\'[data-tt="components_PublishStageLabel_FlexCenter"]\').textContent',
        )
        with self.assertRaises(ValueError):
            parse_step("/browser js document.title")
        instruction = parse_step(
            "/browser +js if not already on https://www.instagram.com/scheduled_content/ +verify Schedule"
        )
        self.assertEqual(instruction.kind, "browser_js")
        self.assertTrue(instruction.params.get("generate_js"))
        self.assertEqual(instruction.params.get("verify"), "Schedule")

    def test_compiles_and_stores_the_page_result(self) -> None:
        import tempfile

        from cg_loop.compiled import ensure_compiled, execute_compiled, run_browser_js

        class Page:
            def __init__(self) -> None:
                self.expression = ""

            def evaluate(self, expression: str) -> str:
                self.expression = expression
                return "Oct 11, 2026, 4:20 PM"

        page = Page()

        class Tab:
            def __init__(self) -> None:
                self.page = page

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "  env:",
                        f"    WORKFLOW_PATH: {workflows}",
                        "wf_stats:",
                        f"  - {self.SOURCE}",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            self.assertEqual(created.status, "compiled")
            body = created.path.read_text(encoding="utf-8")
            self.assertIn("run_browser_js(ctx,", body)
            self.assertIn("'post_date'", body)
            result = execute_compiled(
                created.path,
                {"env": {}, "variables": {}, "dry_run": False, "browser": Tab()},
            )
        self.assertEqual(result["variables"]["post_date"], "Oct 11, 2026, 4:20 PM")
        self.assertTrue(page.expression.startswith("() => ("))
        self.assertIn("components_PublishStageLabel_FlexCenter", page.expression)

        kept = run_browser_js(
            {"dry_run": False, "browser": Tab()},
            "() => document.title",
            "title",
        )
        self.assertEqual(page.expression, "() => document.title")
        self.assertEqual(kept["variables"]["title"], "Oct 11, 2026, 4:20 PM")


class ScheduleDateTests(unittest.TestCase):
    def test_schedule_step_picks_the_date_from_the_calendar(self) -> None:
        import tempfile

        from cg_loop.browser_helper import set_schedule_datetime
        from cg_loop.compiled import ensure_compiled

        step = parse_step("/browser Set Schedule the date and time to $post_date.")
        self.assertEqual(step.tool, "browser")
        self.assertEqual(step.kind, "goal")

        class Node:
            def __init__(self, page: "Page") -> None:
                self.page = page

            def click(self, timeout: int = 0) -> None:
                del timeout

            def count(self) -> int:
                return 1

            def nth(self, index: int) -> "Node":
                del index
                return self

            @property
            def first(self) -> "Node":
                return self

            def wait_for(self, **_kwargs: object) -> None:
                return None

            def inner_text(self) -> str:
                return ""

            def locator(self, selector: str, has_text: object = None) -> "Node":
                del selector, has_text
                return self

        class Arrow(Node):
            def __init__(self, page: "Page", kind: str) -> None:
                super().__init__(page)
                self.kind = kind

            def click(self, timeout: int = 0) -> None:
                del timeout
                if self.kind == "date":
                    self.page.calendar_open = True
                elif self.kind == "next":
                    self.page.month = "October"
                else:
                    self.page.time_open = True

            def locator(self, selector: str, has_text: object = None) -> "Arrow":
                del selector, has_text
                return self

        class Day(Node):
            def __init__(self, page: "Page", day: str) -> None:
                super().__init__(page)
                self.day = day

            def click(self, timeout: int = 0) -> None:
                del timeout
                self.page.date_value = f"2026-10-{int(self.day):02d}"

        class TimeOption(Node):
            def __init__(self, page: "Page", text: str, part: str) -> None:
                super().__init__(page)
                self.text = text
                self.part = part

            def click(self, timeout: int = 0) -> None:
                del timeout
                if self.part == "hour":
                    self.page.hour = self.text
                else:
                    self.page.minute = self.text
                self.page.time_value = f"{self.page.hour}:{self.page.minute}"

        class Field(Node):
            def __init__(self, page: "Page", kind: str) -> None:
                super().__init__(page)
                self.kind = kind

            def input_value(self) -> str:
                return self.page.date_value if self.kind == "date" else self.page.time_value

            def locator(self, selector: str, has_text: object = None) -> Node:
                del selector, has_text
                return Arrow(self.page, self.kind)

        class Inputs(Node):
            def count(self) -> int:
                return 2

            def nth(self, index: int) -> Field:
                return Field(self.page, "date" if index == 0 else "time")

        class Calendar(Node):
            def wait_for(self, **_kwargs: object) -> None:
                if not self.page.calendar_open:
                    raise RuntimeError("calendar is closed")

            def locator(self, selector: str, has_text: object = None) -> Node:
                if selector == ".month-title":
                    node = Node(self.page)
                    node.inner_text = lambda: self.page.month  # type: ignore[method-assign]
                    return node
                if selector == ".year-title":
                    node = Node(self.page)
                    node.inner_text = lambda: "2026"  # type: ignore[method-assign]
                    return node
                if "arrow" in selector:
                    return Arrow(self.page, "next")
                text = getattr(has_text, "pattern", "")
                day = text.strip("^$")
                return Day(self.page, day)

        class TimeList(Node):
            def __init__(self, page: "Page", part: str) -> None:
                super().__init__(page)
                self.part = part

            def locator(self, selector: str, has_text: object = None) -> TimeOption:
                del selector
                text = str(getattr(has_text, "pattern", "")).strip("^$")
                return TimeOption(self.page, text, self.part)

        class TimeLists(Node):
            def nth(self, index: int) -> TimeList:
                return TimeList(self.page, "hour" if index == 0 else "minute")

        class TimePicker(Node):
            def wait_for(self, **_kwargs: object) -> None:
                if not self.page.time_open:
                    raise RuntimeError("time picker is closed")

            def locator(self, selector: str, has_text: object = None) -> TimeLists:
                del selector, has_text
                return TimeLists(self.page)

        class Page:
            def __init__(self) -> None:
                self.date_value = "2026-10-11"
                self.time_value = "18:25"
                self.hour = "18"
                self.minute = "25"
                self.month = "September"
                self.calendar_open = False
                self.time_open = False
                self.inputs = Inputs(self)

            def locator(self, selector: str, has_text: object = None) -> Node:
                del has_text
                if selector == "input":
                    return self.inputs
                if selector == ".calendar-wrapper":
                    return Calendar(self)
                return TimePicker(self)

        class Tab:
            def __init__(self) -> None:
                self.page = Page()

        page = Page()
        tab = Tab()
        tab.page = page
        result = set_schedule_datetime(
            {"variables": {"post_date": "2026-10-12 16:20:00"}, "browser": tab},
            "post_date",
        )
        self.assertEqual(result["outputs"]["date"], "2026-10-12")
        self.assertEqual(result["outputs"]["time"], "16:20")
        self.assertEqual(page.date_value, "2026-10-12")
        self.assertEqual(page.time_value, "16:20")
        self.assertTrue(page.calendar_open)
        self.assertTrue(page.time_open)

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workflows = root / "workflows"
            workflows.mkdir()
            yaml_path = workflows / "wf-demo.yaml"
            yaml_path.write_text(
                "\n".join(
                    [
                        "config:",
                        "  name: demo",
                        "wf_post:",
                        "  - /browser Set Schedule the date and time to $post_date.",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            group = load_workflow(yaml_path).extras[0]
            created = ensure_compiled(group, group.steps[0], index=0, env=group.env)
            body = created.path.read_text(encoding="utf-8")
            self.assertIn("set_schedule_datetime", body)
            self.assertNotIn("run_extract", body)


class KeywordSearchTests(unittest.TestCase):
    def test_goto_encodes_keyword_with_spaces(self) -> None:
        from cg_loop.compiled import run_goto

        result = run_goto(
            {
                "env": {"KEYWORD": "heart healthy foods"},
                "variables": {},
                "dry_run": True,
            },
            "https://www.youtube.com/results?search_query=$KEYWORD",
            wait_until="load",
        )
        self.assertEqual(
            result["outputs"]["url"],
            "https://www.youtube.com/results?search_query=heart%20healthy%20foods",
        )


if __name__ == "__main__":
    unittest.main()
