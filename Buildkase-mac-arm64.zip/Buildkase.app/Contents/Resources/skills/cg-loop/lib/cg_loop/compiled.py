"""Compile every workflow step into a reusable script that calls existing tools."""

from __future__ import annotations

import ast
import importlib.util
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .runlog import log_compile, note_compile_attempt, prompt_markdown
from .step_cache import (
    is_code_step,
    is_packet_script,
    is_step_folder,
    step_cache_path,
    step_packet_dir,
    workflow_compiled_dir,
    workflow_log_dir,
    write_stage_context,
    write_step_script,
)
from .workflow import SKILL_ROOT, Step, Workflow, python_body, python_sentence, python_step_slot, step_body

COMPILED_KINDS = frozenset(
    {
        "load",
        "goto",
        "reuse_tab",
        "browser_js",
        "browser_gemma",
        "openrouter",
        "extract",
        "term",
        "llm_call",
        "generate",
        "workflow",
        "locate",
        "clef",
        "cua",
        "hug",
    }
)
_LIB = SKILL_ROOT / "lib"


@dataclass(frozen=True)
class CompileResult:
    path: Path
    status: str
    error: str = ""
    elapsed_ms: int = 0


def compiled_step_path(
    workflow: Workflow,
    step: Step,
    *,
    index: int,
    env: dict[str, str] | None = None,
) -> Path:
    """`cache/<file>/<workflow>/<truncated step>_<hash>/b-compile.py`.

    The folder name is the truncated step plus a hash of the full text, so two
    steps that share a prefix stay in different folders. A later position of the
    same text reuses this file.
    """
    del index
    return step_packet_dir(workflow, step, env=env) / "b-compile.py"


def compiled_indexes(workflow: Workflow) -> list[tuple[int, Step]]:
    """Every step in this group, with the same index `_compile_one` uses."""
    found: list[tuple[int, Step]] = []

    def walk(step: Step, index: int) -> None:
        found.append((index, step))
        for check_index, check in enumerate(step.checks, 1):
            walk(check, index * 100 + 50 + check_index)
        for sub_index, sub in enumerate(step.steps):
            walk(sub, index * 100 + sub_index + 1)

    for index, step in enumerate(workflow.steps):
        walk(step, index)
    return found


def current_compiled_paths(workflow: Workflow, env: dict[str, str] | None = None) -> set[Path]:
    """Scripts this group would compile or reuse. Other files in the cache are stale."""
    keep: set[Path] = set()
    for index, step in compiled_indexes(workflow):
        if step.auto:
            continue
        if step.kind in COMPILED_KINDS or is_browser_script(step) or is_python_script(step) or is_cua_script(step):
            keep.add(compiled_step_path(workflow, step, index=index, env=env).resolve())
        if step.kind in {"code", "goal"} or is_code_step(step):
            preferred = step_cache_path(workflow, step, env=env)
            keep.add(preferred.resolve())
            for suffix in (".sh", ".py", ".bash"):
                keep.add(preferred.with_suffix(suffix).resolve())
    return keep


def prune_stale_steps(workflow: Workflow, env: dict[str, str] | None = None) -> list[Path]:
    """Delete compiled scripts and step JSON that are not steps of this group."""
    relocate_compiled_by_text(workflow, env)
    keep = current_compiled_paths(workflow, env)
    texts = {step.raw for _index, step in compiled_indexes(workflow)}
    removed: list[Path] = []
    removed.extend(_prune_compiled_files(workflow, env, keep))
    removed.extend(_prune_log_steps(workflow, env, texts))
    if removed:
        names = ", ".join(path.name for path in removed[:8])
        extra = f" (+{len(removed) - 8} more)" if len(removed) > 8 else ""
        print(f"removed {len(removed)} stale step file(s): {names}{extra}")
    return removed


def _prune_compiled_files(workflow: Workflow, env: dict[str, str] | None, keep: set[Path]) -> list[Path]:
    root = workflow_compiled_dir(workflow, env=env)
    if not root.is_dir():
        return []
    removed: list[Path] = []
    keep_dirs = {path.parent.resolve() for path in keep}
    for child in list(root.iterdir()):
        if child.name in {"archived", "z-data", "archive"}:
            continue
        if child.is_file():
            if child.suffix.lower() in {".py", ".sh", ".bash"} and child.resolve() not in keep:
                child.unlink()
                removed.append(child)
            continue
        if not child.is_dir():
            continue
        if child.resolve() not in keep_dirs:
            if _looks_like_step_dir(child):
                shutil_rmtree(child)
                removed.append(child)
            continue
        for item in list(child.iterdir()):
            if item.suffix.lower() in {".py", ".sh", ".bash"} and item.resolve() not in keep:
                item.unlink()
                removed.append(item)
    return removed


def _looks_like_step_dir(path: Path) -> bool:
    return is_step_folder(path)


def shutil_rmtree(path: Path) -> None:
    import shutil

    shutil.rmtree(path)


def _drop_artifact_files(path: Path, removed: list[Path]) -> None:
    """Remove screenshots stored with a compiled step that is going away."""
    folder = _artifact_folder(path)
    if folder is None or not folder.is_dir():
        return
    # An older script sits beside this folder. Leave the folder when the
    # generated script already lives inside it.
    if path.parent != folder:
        owned = folder / f"{folder.name}{path.suffix}"
        if owned.is_file():
            return
    for child in list(folder.iterdir()):
        if child.is_file() and child.resolve() != path.resolve():
            child.unlink()
            removed.append(child)


def _prune_log_steps(workflow: Workflow, env: dict[str, str] | None, texts: set[str]) -> list[Path]:
    """Drop live run records whose text is not a step of this group. Leave archived/ alone."""
    root = workflow_log_dir(workflow, env=env)
    if not root.is_dir():
        return []
    removed: list[Path] = []
    seen: set[Path] = set()
    for pattern in ("c-*-context.json", "c_*-context.json"):
        for path in sorted(root.rglob(pattern)):
            if path in seen:
                continue
            seen.add(path)
            if not path.is_file() or _in_archive(path):
                continue
            step_text = _logged_step_text(path)
            if step_text is None or step_text in texts:
                continue
            path.unlink()
            removed.append(path)
            prompt = path.with_name(f"{path.stem}.prompt.md")
            if prompt.is_file():
                prompt.unlink()
                removed.append(prompt)
    return removed


def _in_archive(path: Path) -> bool:
    return "archive" in path.parts or "archived" in path.parts


def _step_files(root: Path) -> list[Path]:
    found: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() in {".py", ".sh", ".bash", ".json"} or path.name.endswith(".prompt.md"):
            found.append(path)
    return found


def _companion_kept(path: Path, keep: set[Path]) -> bool:
    """A json or prompt file stays when its compiled script is still a current step."""
    if path.suffix.lower() == ".json":
        stem = path.stem
    elif path.name.endswith(".prompt.md"):
        stem = path.name[: -len(".prompt.md")]
    else:
        return False
    candidates = [path.parent / f"{stem}{suffix}" for suffix in (".py", ".sh", ".bash")]
    if path.parent.name == stem:
        candidates.extend(path.parent.parent / f"{stem}{suffix}" for suffix in (".py", ".sh", ".bash"))
    return any(candidate.resolve() in keep for candidate in candidates)


def adopt_legacy_compiled(workflow: Workflow, env: dict[str, str] | None = None) -> list[Path]:
    """Move `cache/<file>/compiled/<group>/` scripts into each step folder as `b-compile`."""
    from .step_cache import workflow_cache_dir, workflow_group_dir

    cache = workflow_cache_dir(workflow, env=env)
    group = workflow_group_dir(workflow, env=env).name
    return _adopt_legacy_cache(cache, only_group=group)


def _adopt_legacy_cache(cache: Path, *, only_group: str | None = None) -> list[Path]:
    compiled_root = cache / "compiled"
    if not compiled_root.is_dir():
        return []
    moved: list[Path] = []
    if only_group in {None, "main"}:
        for src in list(compiled_root.iterdir()):
            if src.is_file() and src.suffix.lower() in {".py", ".sh", ".bash"}:
                placed = _place_legacy_script(cache / "main", src)
                if placed is not None:
                    moved.append(placed)
        if (compiled_root / "steps").is_dir():
            moved.extend(_adopt_legacy_group(cache / "main", compiled_root / "steps"))
    for child in list(compiled_root.iterdir()):
        if not child.is_dir() or child.name in {"steps", "__pycache__"}:
            continue
        if only_group is not None and child.name != only_group:
            continue
        moved.extend(_adopt_legacy_group(cache / child.name, child))
        _sweep_legacy_files(cache / child.name, child)
        _fold_orphan_step_dirs(cache / child.name, child)
    if only_group in {None, "main"} and (compiled_root / "steps").is_dir():
        _sweep_legacy_files(cache / "main", compiled_root / "steps")
        _fold_orphan_step_dirs(cache / "main", compiled_root)
    _remove_empty_dirs(compiled_root)
    return moved


def _adopt_legacy_group(group_dir: Path, legacy: Path) -> list[Path]:
    """One old `compiled/<group>` tree becomes step folders under `<group>/`."""
    moved: list[Path] = []
    if not legacy.is_dir():
        return moved
    for src in _legacy_scripts(legacy):
        placed = _place_legacy_script(group_dir, src)
        if placed is not None:
            moved.append(placed)
    _remove_empty_dirs(legacy)
    return moved


def _place_legacy_script(group_dir: Path, src: Path) -> Path | None:
    """Move one old script into `<group>/<step>/b-compile.py` (or `.sh`)."""
    import hashlib

    from .step_cache import packet_script_name, step_folder_name
    from .workflow import parse_step

    try:
        text = src.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    source = _stored_source(text)
    folder: Path | None = None
    if source:
        try:
            step = parse_step(source)
        except ValueError:
            step = None
        if step is not None:
            digest = hashlib.sha256(_step_source(step).encode("utf-8")).hexdigest()[:10]
            matches = [
                item
                for item in group_dir.glob(f"*_{digest}")
                if item.is_dir() and item.name not in {"archived", "archive", "z-data"}
            ] if group_dir.is_dir() else []
            folder = matches[0] if len(matches) == 1 else group_dir / step_folder_name(step)
    if folder is None:
        folder = group_dir / _folder_name_for_stem(src.stem)
    suffix = src.suffix.lower()
    language = "python" if suffix == ".py" else ("bash" if suffix == ".bash" else "shell")
    dest = folder / packet_script_name(language)
    if src.resolve() == dest.resolve():
        return None
    if dest.is_file():
        _pull_companions(src, dest)
        src.unlink()
    else:
        _rename_beside(src, dest)
    return dest


def _folder_name_for_stem(stem: str) -> str:
    """A step-folder name for a script that has no `Source:` line."""
    import hashlib

    from .step_cache import _fs_slug

    match = re.search(r"_([0-9a-f]{10})$", stem)
    if match:
        digest = match.group(1)
        slug = _fs_slug(stem[: match.start()])[:40].strip("._-") or "step"
    else:
        digest = hashlib.sha256(stem.encode("utf-8")).hexdigest()[:10]
        slug = _fs_slug(stem)[:40].strip("._-") or "step"
    return f"{slug}_{digest}"


def _sweep_legacy_files(group_dir: Path, legacy: Path) -> None:
    """Screenshots left beside an old script folder follow that step's hash."""
    if not legacy.is_dir() or not group_dir.is_dir():
        return
    for path in list(legacy.rglob("*")):
        if not path.is_file() or path.name == ".DS_Store":
            continue
        match = re.search(r"_([0-9a-f]{10})(?:-\d+)?\.", path.name)
        if not match:
            continue
        folders = [
            item
            for item in group_dir.glob(f"*_{match.group(1)}")
            if item.is_dir() and item.name not in {"archived", "archive", "z-data"}
        ]
        if len(folders) != 1:
            continue
        target = folders[0] / path.name
        if target.exists():
            continue
        path.rename(target)


def _fold_orphan_step_dirs(group_dir: Path, legacy: Path) -> None:
    """A step directory left with JSON and screenshots, after its script already moved."""
    from .step_cache import _fs_slug

    steps = legacy / "steps" if (legacy / "steps").is_dir() else legacy
    if not steps.is_dir():
        return
    group_dir.mkdir(parents=True, exist_ok=True)
    prefix = f"{group_dir.name}_"
    for folder in list(steps.iterdir()):
        if not folder.is_dir() or folder.name in {"__pycache__", "archived", "archive"}:
            continue
        match = re.search(r"_([0-9a-f]{10})$", folder.name)
        if not match:
            continue
        body = folder.name[: match.start()]
        if body.startswith(prefix):
            body = body[len(prefix) :]
        slug = _fs_slug(body)[:40].strip("._-") or "step"
        dest = group_dir / f"{slug}_{match.group(1)}"
        stem = folder.name
        if dest.exists() and dest.resolve() != folder.resolve():
            for child in list(folder.iterdir()):
                target = dest / child.name
                if not target.exists():
                    child.rename(target)
            if folder.is_dir() and not any(folder.iterdir()):
                folder.rmdir()
        elif not dest.exists():
            folder.rename(dest)
        fake = dest / "b-compile.py"
        if not dest.is_dir():
            continue
        for child in list(dest.iterdir()):
            if not child.is_file():
                continue
            name = _packet_companion(child.name, stem, fake)
            target = dest / name
            if name != child.name and not target.exists():
                child.rename(target)


def _legacy_scripts(root: Path) -> list[Path]:
    found: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".py", ".sh", ".bash"}:
            continue
        if "__pycache__" in path.parts or "archived" in path.parts or "archive" in path.parts:
            continue
        found.append(path)
    return sorted(found)


def _pull_companions(src: Path, dest: Path) -> None:
    """Move JSON, crop, and prompt next to a script that is already in the step folder."""
    folder = _artifact_folder(src)
    if folder is None or not folder.is_dir():
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    for child in list(folder.iterdir()):
        if not child.is_file() or child.resolve() == src.resolve():
            continue
        name = _packet_companion(child.name, src.stem, dest)
        target = dest.parent / name
        if target.exists():
            continue
        child.rename(target)
    if folder.is_dir() and folder != dest.parent and not any(folder.iterdir()):
        folder.rmdir()


def _remove_empty_dirs(root: Path) -> None:
    if not root.is_dir():
        return
    for child in list(root.iterdir()):
        if child.name == ".DS_Store":
            child.unlink()
            continue
        if child.is_dir() and child.name != "__pycache__":
            _remove_empty_dirs(child)
        elif child.is_dir() and child.name == "__pycache__":
            shutil_rmtree(child)
    if root.is_dir() and not any(root.iterdir()):
        root.rmdir()


def relocate_compiled_by_text(workflow: Workflow, env: dict[str, str] | None = None) -> None:
    """Move a position-named script onto the text name when its source still matches."""
    adopt_legacy_compiled(workflow, env)
    for index, step in compiled_indexes(workflow):
        if step.auto:
            continue
        if step.kind not in COMPILED_KINDS and not is_browser_script(step) and not is_python_script(step) and not is_cua_script(step):
            continue
        path = compiled_step_path(workflow, step, index=index, env=env)
        if path.is_file():
            continue
        _adopt_compiled_script(path, step)


def _adopt_compiled_script(path: Path, step: Step) -> bool:
    """Rename an older script whose stored source is this step's text."""
    wanted = _step_source(step)
    if not wanted:
        return False
    for candidate in _compiled_py_candidates(path):
        if candidate.resolve() == path.resolve():
            continue
        try:
            text = candidate.read_text(encoding="utf-8")
        except OSError:
            continue
        if _stored_source(text) != wanted:
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        _rename_beside(candidate, path)
        return True
    return False


def _compiled_py_candidates(path: Path) -> list[Path]:
    """Scripts in this workflow folder, including one still under `compiled/`."""
    group = path.parent.parent if is_packet_script(path) or path.parent.name == path.stem else path.parent
    if path.name == "b-compile.py" and not is_packet_script(path):
        group = path.parent
    found: list[Path] = []
    if group.is_dir():
        for child in group.iterdir():
            if child.name in {"archived", "z-data", "archive", "compiled"}:
                continue
            if child.is_file() and child.suffix == ".py":
                found.append(child)
            elif child.is_dir():
                found.extend(child.glob("*.py"))
    legacy = group.parent / "compiled" / group.name
    if legacy.is_dir():
        found.extend(_legacy_scripts(legacy))
    if group.name == "main":
        compiled_root = group.parent / "compiled"
        steps = compiled_root / "steps"
        if steps.is_dir():
            found.extend(_legacy_scripts(steps))
    return sorted(set(found))


def _artifact_folder(path: Path) -> Path | None:
    """Directory that holds a step's script, JSON, and screenshots."""
    from .browser_helper import artifact_dir

    if path.suffix.lower() in {".py", ".sh", ".bash"}:
        return artifact_dir(path)
    if path.name.startswith(("a-", "a_", "b-", "b_", "c-", "c_", "z-data_")) and _STEP_DIR_RE_LOCAL.match(path.parent.name):
        return path.parent
    if path.suffix.lower() == ".json" and path.parent.name == path.stem:
        return path.parent
    if path.name.endswith(".prompt.md"):
        stem = path.name[: -len(".prompt.md")]
        if path.parent.name == stem:
            return path.parent
        return path.parent / stem
    return None


_STEP_DIR_RE_LOCAL = re.compile(r"^.+_[0-9a-f]{10}$")


def _remove_empty_artifact(path: Path) -> None:
    folder = _artifact_folder(path)
    if folder is not None and folder.is_dir() and not any(folder.iterdir()):
        folder.rmdir()


def _packet_companion(name: str, src_stem: str, dest: Path) -> str:
    """Map an old sidecar onto the packet name when the destination is `b-compile`."""
    if is_packet_script(dest):
        if name == f"{src_stem}.json":
            return "b_01-context.json"
        if name == f"{src_stem}.prompt.md":
            return "a-prompt.md"
        if name == f"{src_stem}.crop.png":
            return "b-crop.png"
        return name
    if name == f"{src_stem}.json":
        return f"{dest.stem}.json"
    if name == f"{src_stem}.prompt.md":
        return f"{dest.stem}.prompt.md"
    return name


def _rename_stem_files(folder: Path, old_stem: str, new_stem: str) -> None:
    if not folder.is_dir() or old_stem == new_stem:
        return
    json_path = folder / f"{old_stem}.json"
    if json_path.is_file():
        json_path.rename(folder / f"{new_stem}.json")
    prompt = folder / f"{old_stem}.prompt.md"
    if prompt.is_file():
        prompt.rename(folder / f"{new_stem}.prompt.md")


def _rename_beside(src: Path, dest: Path) -> None:
    """Move a compiled script and the JSON and screenshots that belong with it."""
    src_folder = _artifact_folder(src)
    dest_folder = _artifact_folder(dest)
    if src_folder is None or dest_folder is None:
        dest.parent.mkdir(parents=True, exist_ok=True)
        src.rename(dest)
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    same = src_folder == dest_folder
    script_in_folder = src.parent.name == src.stem
    if script_in_folder and src_folder.is_dir() and not same and not dest_folder.exists():
        src_folder.rename(dest_folder)
        moved = dest_folder / src.name
        if moved.is_file() and moved != dest:
            moved.rename(dest)
        for child in list(dest_folder.iterdir()):
            if child.resolve() == dest.resolve():
                continue
            name = _packet_companion(child.name, src.stem, dest)
            target = dest_folder / name
            if name != child.name and not target.exists():
                child.rename(target)
        return
    src.rename(dest)
    if not same and src_folder.is_dir():
        dest_folder.mkdir(parents=True, exist_ok=True)
        for child in list(src_folder.iterdir()):
            name = _packet_companion(child.name, src.stem, dest)
            target = dest_folder / name
            if target.exists():
                continue
            child.rename(target)
        if src_folder.is_dir() and not any(src_folder.iterdir()):
            src_folder.rmdir()
    else:
        _rename_stem_files(dest_folder, src.stem, dest.stem)
    outside_json = src.with_suffix(".json")
    if outside_json.is_file() and outside_json.parent != dest_folder:
        dest_folder.mkdir(parents=True, exist_ok=True)
        outside_json.rename(dest_folder / _packet_companion(outside_json.name, src.stem, dest))
    prompt = src.with_name(f"{src.stem}.prompt.md")
    if prompt.is_file() and prompt.parent != dest_folder:
        dest_folder.mkdir(parents=True, exist_ok=True)
        prompt.rename(dest_folder / _packet_companion(prompt.name, src.stem, dest))


def _logged_step_text(path: Path) -> str | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    step = payload.get("step")
    if not isinstance(step, str) or not step.strip():
        return None
    return step


def ensure_compiled(
    workflow: Workflow,
    step: Step,
    *,
    index: int,
    env: dict[str, str] | None = None,
    force: bool = False,
    error: str = "",
    page: dict[str, Any] | None = None,
    step_json: str = "",
    browser: Any = None,
    variables: dict[str, Any] | None = None,
    dry_run: bool = False,
) -> CompileResult:
    """Write the step script once. Reuse it when validation still passes.

    A step that already names a URL or command is compiled directly. Anything
    else is written by the model, which may correct the call or mark it as a goal.
    """
    path = compiled_step_path(workflow, step, index=index, env=env)
    if not path.is_file():
        _adopt_compiled_script(path, step)
    started = time.perf_counter()
    existed = path.is_file()
    problem = ""
    if existed and not force:
        problem = validate_compiled(path, step)
        if not problem:
            elapsed = _elapsed_ms(started)
            prompt_path, helper = _ensure_compile_record(path, step, only_helper=True)
            _log_compile(
                workflow,
                step,
                index=index,
                mode="reuse",
                status="reused",
                path=path,
                elapsed_ms=elapsed,
                result=f"reused {path}",
                prompt_path=prompt_path,
                helper=helper,
            )
            return CompileResult(path, "reused", elapsed_ms=elapsed)
    from .browser_helper import artifact_dir
    from .model import logging_api_calls

    with logging_api_calls(artifact_dir(path)):
        return _compile_fresh(
            workflow,
            step,
            index=index,
            error=error,
            page=page,
            step_json=step_json,
            browser=browser,
            variables=variables,
            dry_run=dry_run,
            path=path,
            started=started,
            existed=existed,
            problem=problem,
        )


def _compile_fresh(
    workflow: Workflow,
    step: Step,
    *,
    index: int,
    error: str,
    page: dict[str, Any] | None,
    step_json: str,
    browser: Any,
    variables: dict[str, Any] | None,
    dry_run: bool,
    path: Path,
    started: float,
    existed: bool,
    problem: str,
) -> CompileResult:
    """Write this step's script. A model call during this write is saved as `a-request.py`."""
    reply = None
    mode = "direct"
    body = ""
    reason = error or problem
    # A text edit is a new step. Do not ask the model to repair the old script.
    compile_error = "" if problem in _COMPILE_FRESH and not error else reason
    if is_python_script(step):
        body, reply = _python_script(
            step,
            path=path,
            env=workflow.env,
            error=compile_error,
            step_json=step_json,
            variables=variables,
        )
        mode = "model" if reply is not None and reply.messages else "direct"
        if not body:
            elapsed = _elapsed_ms(started)
            detail = (reply.error if reply else "") or "python compile returned no script"
            _log_compile(
                workflow,
                step,
                index=index,
                mode="model",
                status="failed",
                path=path,
                elapsed_ms=elapsed,
                messages=getattr(reply, "messages", None),
                options=getattr(reply, "options", None),
                thinking=getattr(reply, "thinking", "") or "",
                model_result=getattr(reply, "text", "") or "",
                result="",
                error=detail,
                model_name=getattr(reply, "model", "") or "",
                reason=reason,
                message_fields=getattr(reply, "message_fields", "") or "",
                llm_ms=int(getattr(reply, "latency_ms", 0) or 0),
            )
            return CompileResult(path, "failed", error=detail, elapsed_ms=elapsed)
    elif is_browser_script(step):
        body, reply = _browser_script(
            step,
            path=path,
            env=workflow.env,
            error=compile_error,
            page=page,
            reference=workflow.reference,
            workflow_path=workflow.path,
            step_json=step_json,
            browser=browser,
            variables=variables,
        )
        mode = "model" if reply is not None and reply.messages else "direct"
        if not body:
            elapsed = _elapsed_ms(started)
            detail = (reply.error if reply else "") or "browser compile returned no script"
            _log_compile(
                workflow,
                step,
                index=index,
                mode="model",
                status="failed",
                path=path,
                elapsed_ms=elapsed,
                messages=getattr(reply, "messages", None),
                options=getattr(reply, "options", None),
                thinking=getattr(reply, "thinking", "") or "",
                model_result=getattr(reply, "text", "") or "",
                result="",
                error=detail,
                model_name=getattr(reply, "model", "") or "",
                reason=reason,
                message_fields=getattr(reply, "message_fields", "") or "",
                llm_ms=int(getattr(reply, "latency_ms", 0) or 0),
            )
            return CompileResult(path, "failed", error=detail, elapsed_ms=elapsed)
    elif is_cua_script(step):
        body, reply = _cua_script(step, path=path, env=workflow.env, step_json=step_json)
        mode = "model" if reply is not None and reply.messages else "direct"
        if not body:
            elapsed = _elapsed_ms(started)
            detail = (reply.error if reply else "") or "cua compile returned no script"
            _log_compile(
                workflow,
                step,
                index=index,
                mode="model",
                status="failed",
                path=path,
                elapsed_ms=elapsed,
                messages=getattr(reply, "messages", None),
                options=getattr(reply, "options", None),
                thinking=getattr(reply, "thinking", "") or "",
                model_result=getattr(reply, "text", "") or "",
                result="",
                error=detail,
                model_name=getattr(reply, "model", "") or "",
                reason=reason,
                message_fields=getattr(reply, "message_fields", "") or "",
                llm_ms=int(getattr(reply, "latency_ms", 0) or 0),
            )
            return CompileResult(path, "failed", error=detail, elapsed_ms=elapsed)
    elif is_cua_click(step):
        body, reply = _cua_click_script(
            step,
            path=path,
            env=workflow.env,
            step_json=step_json,
            dry_run=dry_run,
        )
        mode = "direct"
        if not body:
            elapsed = _elapsed_ms(started)
            detail = (reply.error if reply else "") or "cua click compile returned no location"
            _log_compile(
                workflow,
                step,
                index=index,
                mode="direct",
                status="failed",
                path=path,
                elapsed_ms=elapsed,
                messages=getattr(reply, "messages", None),
                options=getattr(reply, "options", None),
                thinking=getattr(reply, "thinking", "") or "",
                model_result=getattr(reply, "text", "") or "",
                result="",
                error=detail,
                model_name=getattr(reply, "model", "") or "",
                reason=reason,
                message_fields=getattr(reply, "message_fields", "") or "",
                llm_ms=int(getattr(reply, "latency_ms", 0) or 0),
            )
            return CompileResult(path, "failed", error=detail, elapsed_ms=elapsed)
    elif step.kind == "browser_js" and step.params.get("generate_js"):
        body, reply = _generated_js_script(
            step,
            path=path,
            env=workflow.env,
            page=page,
            step_json=step_json,
            browser=browser,
        )
        mode = "model" if reply is not None and reply.messages else "direct"
        if not body:
            elapsed = _elapsed_ms(started)
            detail = (reply.error if reply else "") or "js compile returned no script"
            _log_compile(
                workflow,
                step,
                index=index,
                mode="model",
                status="failed",
                path=path,
                elapsed_ms=elapsed,
                messages=getattr(reply, "messages", None),
                options=getattr(reply, "options", None),
                thinking=getattr(reply, "thinking", "") or "",
                model_result=getattr(reply, "text", "") or "",
                result="",
                error=detail,
                model_name=getattr(reply, "model", "") or "",
                reason=reason,
                message_fields=getattr(reply, "message_fields", "") or "",
                llm_ms=int(getattr(reply, "latency_ms", 0) or 0),
            )
            return CompileResult(path, "failed", error=detail, elapsed_ms=elapsed)
    elif step.kind == "extract":
        mode = "model"
        body, reply = _generate_extract_script(
            step,
            path=path,
            env=workflow.env,
            error=compile_error,
            page=page,
            variables=variables,
            step_json=step_json,
        )
        if not body:
            elapsed = _elapsed_ms(started)
            detail = (reply.error if reply else "") or "extract compile returned no script"
            _log_compile(
                workflow,
                step,
                index=index,
                mode="model",
                status="failed",
                path=path,
                elapsed_ms=elapsed,
                messages=getattr(reply, "messages", None),
                options=getattr(reply, "options", None),
                thinking=getattr(reply, "thinking", "") or "",
                model_result=getattr(reply, "text", "") or "",
                result="",
                error=detail,
                model_name=getattr(reply, "model", "") or "",
                reason=reason,
                message_fields=getattr(reply, "message_fields", "") or "",
                llm_ms=int(getattr(reply, "latency_ms", 0) or 0),
            )
            return CompileResult(path, "failed", error=detail, elapsed_ms=elapsed)
    elif _needs_model(step):
        mode = "model"
        body, reply = _model_script(step, path=path, env=workflow.env, error=compile_error)
    if not body:
        if _needs_model(step):
            mode = "model-fallback"
            log_compile(f"COMPILE goal {path}", folder=path.parent)
            body = render_step(
                step,
                path=path,
                env=workflow.env,
                call=f"run_goal(ctx, {step.raw!r})",
                runner="run_goal",
            )
        else:
            body = render_step(step, path=path, env=workflow.env)
    write_step_script(path, body, language="python")
    prompt_path, helper = _write_compile_record(path, step, body, reply)
    problem = validate_compiled(path, step)
    elapsed = _elapsed_ms(started)
    status = "failed" if problem else ("recompiled" if existed else "compiled")
    written = path.read_text(encoding="utf-8") if path.is_file() else body
    model_error = (reply.error if reply else "") or ""
    detail = "\n".join(item for item in (model_error, problem) if item)
    _log_compile(
        workflow,
        step,
        index=index,
        mode=mode,
        status=status,
        path=path,
        elapsed_ms=elapsed,
        messages=getattr(reply, "messages", None),
        options=getattr(reply, "options", None),
        thinking=getattr(reply, "thinking", "") or "",
        model_result=getattr(reply, "text", "") or "",
        result=written,
        error=detail,
        model_name=getattr(reply, "model", "") or "",
        reason=reason,
        message_fields=getattr(reply, "message_fields", "") or "",
        llm_ms=int(getattr(reply, "latency_ms", 0) or 0),
        prompt_path=prompt_path,
        helper=helper,
    )
    if problem:
        return CompileResult(path, "failed", error=problem, elapsed_ms=elapsed)
    return CompileResult(path, status, elapsed_ms=elapsed)


# These are a different step, not a broken script. Compile again and do not run the old file.
_COMPILE_FRESH = frozenset({"step text changed", "compiled json does not match"})


def validate_compiled(path: Path, step: Step) -> str:
    """Return an error when the script cannot be run for this step."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        return str(exc)
    stored = _stored_source(text)
    if stored is not None and not _same_step_text(stored, step):
        return "step text changed"
    json_problem = _json_source_problem(path, text, step)
    if json_problem:
        return json_problem
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        return f"syntax error: {exc.msg} line {exc.lineno}"
    has_run = any(isinstance(node, ast.FunctionDef) and node.name == "run" for node in ast.walk(tree))
    if not has_run:
        return "missing def run"
    if step.kind == "extract":
        return _extract_script_error(text, step)
    if is_python_script(step):
        if "run_goal" in text or "run_term" in text or "python_helper" in text:
            return "python script must be generated code"
        if _env_browser_lookup(text):
            return "ctx['env'] has no 'browser'. $rootProject is ctx['env']['rootProject']."
        return ""
    if is_cua_click(step):
        if "replay_cua_click" not in text:
            return "cua click must replay the saved location"
        return ""
    if not any(name in text for name in _RUNNERS):
        return "missing a cg_loop runner"
    if re.search(r"\bRUNNER\b", text):
        return "model script must call a real runner, not RUNNER"
    if is_browser_script(step):
        if "run_goal" in text or "run_term" in text:
            return "browser script must not call run_goal or run_term"
        if "browser_helper(" in text:
            return "browser step still asks Jev at run time"
        if "browser_helper" in text or "replay_browser_actions" in text:
            return ""
        if "browser_page" not in text:
            return "browser script must call browser_page or browser_helper"
        if re.search(
            r"\bpage\.(click|fill|press|check|locator|get_by_role|get_by_text|get_by_placeholder)\s*\(",
            text,
        ) and 'ctx["browser"].page' not in text and "ctx['browser'].page" not in text:
            return "browser_page returns a dict; click and fill on ctx['browser'].page"
        return ""
    if is_cua_script(step):
        if "replay_cua_actions" not in text:
            return "cua command must replay saved actions"
        if "run_goal" in text:
            return "cua command must not call run_goal"
        return ""
    if "run_goal" in text:
        return ""
    if step.kind == "browser_js" and step.params.get("generate_js"):
        if "run_browser_js" not in text:
            return "missing run_browser_js"
        return ""
    if _needs_model(step):
        match = _GOTO_URL_RE.search(text)
        if match and match.group(2).startswith(("http://", "https://", "$")):
            return ""
        if "run_goto" in text and _HTTP_IN_TEXT.search(text):
            return ""
        return "model script must call run_goal or run_goto with an http URL"
    call = _call_expr(step)
    if call not in text:
        return f"missing {call}"
    return ""


def _elapsed_ms(started: float) -> int:
    return round((time.perf_counter() - started) * 1000)


def _step_source(step: Step) -> str:
    return (step.raw or "").replace('"""', "'").strip()


def _same_step_text(stored: str, step: Step) -> bool:
    """The compiled note and the workflow step are the same text."""
    wanted = {_step_source(step), (step.raw or "").strip()}
    return stored.strip() in wanted


def _json_source_problem(path: Path, text: str, step: Step) -> str:
    """The actions JSON is part of the compiled step. A different command is not this step."""
    from .browser_helper import compiled_json_path

    json_path = compiled_json_path(path)
    replay = "replay_browser_actions" in text
    if not json_path.is_file():
        return ""
    try:
        payload = json.loads(json_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return "compiled json does not match" if replay else ""
    if not isinstance(payload, dict) or "command" not in payload:
        return "compiled json does not match" if replay else ""
    command = payload.get("command")
    if not isinstance(command, str) or not _same_step_text(command, step):
        return "compiled json does not match"
    actions = payload.get("actions")
    if replay and isinstance(actions, list) and not actions:
        return "compiled browser actions are missing"
    return ""


def _stored_source(text: str) -> str | None:
    match = re.search(r"(?m)^Source: (.*)$", text)
    if not match:
        return None
    return match.group(1).strip()


def _page_url(page: dict[str, Any] | None) -> str:
    if not isinstance(page, dict):
        return ""
    return str(page.get("url") or "").strip()


def _compile_variables(variables: dict[str, Any] | None) -> dict[str, Any]:
    """Values earlier steps stored, trimmed so the compile prompt stays small."""
    if not variables:
        return {}
    public: dict[str, Any] = {}
    for key, value in variables.items():
        if str(key) in {"workflow_run_command"}:
            continue
        if isinstance(value, dict):
            public[str(key)] = {
                str(item): (text[:500] if isinstance(text, str) and len(text) > 500 else text)
                for item, text in value.items()
            }
        elif isinstance(value, str):
            public[str(key)] = value[:500]
        else:
            public[str(key)] = value
    return public


_GOTO_URL_RE = re.compile(r"run_goto\(\s*ctx\s*,\s*(['\"])(.*?)\1", re.DOTALL)
_HTTP_IN_TEXT = re.compile(r"https?://\S+")
_VAR_IN_TEXT = re.compile(r"\$[A-Za-z_][A-Za-z0-9_]*")
_RUNNERS = (
    "run_load",
    "run_goto",
    "run_reuse_tab",
    "run_browser_js",
    "run_browser_gemma",
    "run_openrouter",
    "run_extract",
    "run_term",
    "run_llm_call",
    "run_generate",
    "run_workflow_step",
    "run_goal",
    "browser_page",
    "browser_helper",
    "python_helper",
    "run_locate",
    "run_clef",
    "run_cua",
    "run_hug",
    "replay_cua_actions",
)


def _extract_script_error(text: str, step: Step) -> str:
    """Extract steps carry their own code. The shared extract helper is not that code."""
    if re.search(r"\brun_extract\b|\barticle_from_page\b|cg_loop\.extract", text):
        return "extract script must not call the extract library"
    if ".evaluate(" not in text and "browser_page" not in text:
        return "extract script must read the page with page.evaluate or browser_page"
    var = step.var or "article"
    if var not in text:
        return f"extract script must store {var}"
    return ""


def is_browser_script(step: Step) -> bool:
    """A /browser goal is compiled once. Run time replays the saved actions and does not call Jev."""
    return step.tool == "browser" and step.kind == "goal"


def is_cua_script(step: Step) -> bool:
    """A `/cua` sentence is compiled once. Laya chooses the actions. Run time replays them."""
    return step.tool == "cua" and step.kind == "goal"


def _cua_script(
    step: Step,
    *,
    path: Path,
    env: dict[str, str],
    step_json: str,
) -> tuple[str, Any]:
    """Ask Laya once, when this step is compiling, and store that reply beside the script."""
    import json

    from . import model
    from .browser_helper import artifact_dir
    from .cua import compile_cua_actions

    log_compile(f"COMPILE cua {path}", step_json)
    run_src = (
        "def run(ctx):\n"
        "    import json\n"
        "    from pathlib import Path\n"
        "    from cg_loop.cua import replay_cua_actions\n"
        "    _script = Path(__file__)\n"
        "    if _script.name.startswith('b-compile.'):\n"
        "        _folder = _script.parent\n"
        "        _json_name = 'b_01-context.json'\n"
        "    elif _script.parent.name == _script.stem:\n"
        "        _folder = _script.parent\n"
        "        _json_name = _script.stem + '.json'\n"
        "    else:\n"
        "        _folder = _script.parent / _script.stem\n"
        "        _json_name = _script.stem + '.json'\n"
        "    saved = json.loads((_folder / _json_name).read_text(encoding='utf-8'))\n"
        "    return replay_cua_actions(\n"
        "        saved.get('command') or '',\n"
        "        saved.get('actions') or [],\n"
        "        dry_run=bool(ctx.get('dry_run')),\n"
        "        env=ctx.get('env') or {},\n"
        "        variables=ctx.get('variables') or {},\n"
        "    )\n"
    )
    reply = model.CompileReply(text=run_src, model="laya")
    try:
        compiled = compile_cua_actions(step.raw or step.extra)
    except Exception as exc:
        reply.error = str(exc)
        return "", reply
    questions = compiled.get("questions") or {}
    state = compiled.get("state") or {}
    reply.messages = [
        {"role": "system", "content": "laya"},
        {"role": "user", "content": json.dumps({"state": state, "questions": questions}, default=str)},
    ]
    detail = str(compiled.get("error") or "")
    saved = {
        "command": step.raw,
        "actions": compiled.get("actions") or [],
        "model": "laya",
    }
    if detail:
        saved["error"] = detail
        reply.error = detail
    json_path = artifact_dir(path) / "b_01-context.json" if is_packet_script(path) else artifact_dir(path) / f"{path.stem}.json"
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(saved, indent=2) + "\n", encoding="utf-8")
    if detail:
        return "", reply
    return _wrap_run(step, path=path, env=env, run_src=run_src), reply


def is_cua_click(step: Step) -> bool:
    """A `/cua click` compiles the located point. Later runs try that point, then verify it."""
    return step.tool == "cua" and step.kind == "cua" and step.extra == "click"


def _cua_click_script(
    step: Step,
    *,
    path: Path,
    env: dict[str, str],
    step_json: str,
    dry_run: bool,
) -> tuple[str, Any]:
    """Locate the label once and store the point beside this script."""
    import json

    from . import model
    from .browser_helper import artifact_dir
    from .cua import compile_click_location, save_click_crop

    log_compile(f"COMPILE cua click {path}", step_json)
    reply = model.CompileReply(text="", model="locate")
    label = str(step.params.get("label") or "")
    app = str(step.params.get("app") or "")
    locate_env = dict(env)
    if step_json:
        locate_env["CG_LOOP_STEP_JSON"] = step_json
    point: dict[str, Any] = {"label": label, "app": app}
    if not dry_run:
        try:
            point = compile_click_location(label, app, locate_env)
        except Exception as exc:
            reply.error = str(exc)
            return "", reply
    saved = {
        "command": step.raw,
        "label": label,
        "app": app,
        "x": point.get("x"),
        "y": point.get("y"),
        "width": point.get("width") or 0,
        "height": point.get("height") or 0,
        "box": point.get("box") or {},
        "method": point.get("method") or "",
    }
    folder = artifact_dir(path)
    folder.mkdir(parents=True, exist_ok=True)
    image = str(point.get("image") or "")
    box = saved["box"] if isinstance(saved["box"], dict) else {}
    if image and box and not dry_run:
        from .browser_helper import compile_crop_path

        save_click_crop(image, box, compile_crop_path(path))
    json_path = folder / ("b_01-context.json" if is_packet_script(path) else f"{path.stem}.json")
    json_path.write_text(json.dumps(saved, indent=2) + "\n", encoding="utf-8")
    run_src = (
        "def run(ctx):\n"
        "    from pathlib import Path\n"
        "    from cg_loop.cua import replay_cua_click\n"
        "    return replay_cua_click(ctx, Path(__file__))\n"
    )
    reply.text = run_src
    return _wrap_run(step, path=path, env=env, run_src=run_src), reply


def is_python_script(step: Step) -> bool:
    """A /python goal is compiled once into its own run(ctx) function."""
    return step.tool == "python" and step.kind == "goal"


def _goto_target(step: Step) -> str:
    """The http URL or $variable inside a goto step, without a site label or trailing words."""
    text = (step.url or step.raw or "").strip()
    if text.startswith(("http://", "https://", "$")):
        return text.split()[0]
    http = _HTTP_IN_TEXT.search(text)
    if http:
        return http.group(0)
    var = _VAR_IN_TEXT.search(text)
    if var:
        return var.group(0)
    return ""


def _waits_for_document(step: Step) -> bool:
    text = (step.raw or "").lower()
    return "wait" in text and ("ready" in text or "document" in text or "load" in text)


def _needs_model(step: Step) -> bool:
    """True when a goto step does not already contain an http URL or $variable."""
    if step.kind != "goto":
        return False
    return not _goto_target(step)


def _python_script(
    step: Step,
    *,
    path: Path,
    env: dict[str, str],
    error: str,
    step_json: str = "",
    variables: dict[str, Any] | None = None,
) -> tuple[str, Any]:
    """Ask the compile model for this /python step. A bare wait sleeps and does not ask."""
    from .browser_helper import _only_duration_wait

    pause = _only_duration_wait(python_body(step))
    if pause is not None:
        from . import model

        log_compile(f"COMPILE python {path}", step_json)
        run_src = _duration_sleep_source(pause)
        reply = model.CompileReply(text=run_src, model="")
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    return _generate_python_script(
        step,
        path=path,
        env=env,
        error=error,
        variables=variables,
        step_json=step_json,
    )


def _generate_python_script(
    step: Step,
    *,
    path: Path,
    env: dict[str, str],
    error: str,
    variables: dict[str, Any] | None,
    step_json: str,
) -> tuple[str, Any]:
    """Ask the compile model for this /python step. The script is the step."""
    from . import model

    context: dict[str, Any] = {
        "step": _compile_step_text(step, env, variables),
        "kind": step.kind,
        "tool": step.tool,
        "error": error,
    }
    names = _compile_variables(variables)
    if names:
        context["variables"] = names
    log_compile(f"COMPILE python {path}", step_json)
    try:
        with model.bind_python_step(python_step_slot(step)):
            reply = model.compile_python_step(context)
    except Exception as exc:
        print(f"COMPILE python failed: {exc}")
        return "", model.CompileReply(text="", error=str(exc), model=model.MODEL)
    if not reply.messages:
        reply.messages = model.compile_python_messages(context)
    run_src = _extract_run(reply.text)
    if not run_src or not _generated_python_run(run_src):
        reply.error = reply.error or "model did not return a python script"
        print(f"COMPILE python failed: {reply.error}")
        return "", reply
    return _wrap_run(step, path=path, env=env, run_src=run_src), reply


def _compile_step_text(step: Step, env: dict[str, str], variables: dict[str, Any] | None) -> str:
    """The task the compiler sees. `$rootProject` is already a real folder."""
    from .terminal import expand_command

    return expand_command(python_sentence(step), {**os.environ, **(env or {})}, variables or {})


def _env_browser_lookup(text: str) -> bool:
    """True when a script reads a browser path out of ctx['env']. That key is not there."""
    return re.search(
        r"""\[\s*["']env["']\s*\]\s*[\.\[]\s*(?:get\s*\(\s*)?["']browser["']""",
        text or "",
    ) is not None


def _generated_python_run(run_src: str) -> bool:
    if "def run" not in run_src:
        return False
    if "python_helper" in run_src or "run_goal" in run_src or "run_term" in run_src:
        return False
    return True


_HELPER_VERBS = frozenset(
    {
        "click",
        "type",
        "select",
        "tick",
        "search",
        "wait",
        "verify",
        "go",
        "open",
        "reload",
        "press",
        "upload",
        "extract",
        "scroll",
        "back",
        "forward",
    }
)


def _schedule_variable(step: Step) -> str:
    """`$name` in `Set Schedule the date and time to $name`."""
    match = re.search(
        r"set\s+schedule\s+the\s+date\s+and\s+time\s+to\s+\$([A-Za-z_]\w*)\b",
        step.raw or "",
        re.IGNORECASE,
    )
    return match.group(1) if match else ""


def _sets_local_file(step: Step) -> bool:
    """A local file input step is generated. Chrome reads the path itself."""
    text = (step.raw or "").lower()
    return "set_input_files" in text or "set_local_input_files" in text


def _helper_owned(step: Step) -> bool:
    """A click, type, upload, wait, or navigation stays on browser_helper."""
    body = step_body(step)
    if body.lower().startswith("local "):
        body = body.split(None, 1)[1] if " " in body else ""
    first = body.split(None, 1)[0].lower().strip(".,") if body else ""
    return first in _HELPER_VERBS


def _browser_helper_source(step: Step) -> str:
    """Run time loads the actions JSON written at compile. It does not call Jev."""
    del step
    return (
        "def run(ctx):\n"
        "    import json\n"
        "    from pathlib import Path\n"
        "    from cg_loop.browser_helper import replay_browser_actions\n"
        "    _script = Path(__file__)\n"
        "    if _script.name.startswith('b-compile.'):\n"
        "        _folder = _script.parent\n"
        "        _json_name = 'b_01-context.json'\n"
        "    elif _script.parent.name == _script.stem:\n"
        "        _folder = _script.parent\n"
        "        _json_name = _script.stem + '.json'\n"
        "    else:\n"
        "        _folder = _script.parent / _script.stem\n"
        "        _json_name = _script.stem + '.json'\n"
        "    saved = json.loads((_folder / _json_name).read_text(encoding='utf-8'))\n"
        "    return replay_browser_actions(\n"
        "        saved.get('command') or '',\n"
        "        ctx.get('browser'),\n"
        "        saved.get('actions') or [],\n"
        "        dry_run=bool(ctx.get('dry_run')),\n"
        "        env=ctx.get('env') or {},\n"
        "        variables=ctx.get('variables') or {},\n"
        "        screenshot_path=str(Path(__file__)),\n"
        "    )\n"
    )


def _compile_replay_browser(
    step: Step,
    *,
    path: Path,
    env: dict[str, str],
    step_json: str,
    browser: Any = None,
    variables: dict[str, Any] | None = None,
    error: str = "",
) -> tuple[str, Any]:
    """Ask Jev once, when this step is compiling, and store that reply beside the script."""
    import json

    from . import model

    log_compile(f"COMPILE browser {path}", step_json)
    run_src = _browser_helper_source(step)
    reply = model.CompileReply(text=run_src, model=model.browser_model_name(), error=error)
    if browser is None:
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    from .browser_helper import compile_browser_actions

    try:
        compiled = compile_browser_actions(step.raw, browser, env=env, variables=variables)
    except Exception as exc:
        reply.error = str(exc)
        return "", reply
    reply.messages = compiled.get("messages") or None
    reply.model = str(compiled.get("model") or reply.model)
    detail = str(compiled.get("error") or "")
    saved_actions = compiled.get("actions") or []
    if not saved_actions and not detail:
        detail = "Jev returned no browser actions."
    path.parent.mkdir(parents=True, exist_ok=True)
    from .browser_helper import artifact_dir, compile_screenshot

    saved: dict[str, Any] = {
        "command": step.raw,
        "actions": saved_actions,
        "elements": compiled.get("elements") or [],
    }
    seen = compiled.get("page")
    if isinstance(seen, dict) and (seen.get("url") or seen.get("title")):
        saved["page"] = {"url": seen.get("url") or "", "title": seen.get("title") or ""}
    shot = compile_screenshot(
        browser,
        path,
        1,
        name=step_body(step) or step.raw,
        actions=saved["actions"],
    )
    if shot:
        saved["screenshots"] = [shot]
    if detail:
        saved["error"] = detail
        reply.error = detail
    json_path = artifact_dir(path) / "b_01-context.json" if is_packet_script(path) else artifact_dir(path) / f"{path.stem}.json"
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(
        json.dumps(saved, indent=2) + "\n",
        encoding="utf-8",
    )
    sibling = path.with_suffix(".json")
    if sibling.is_file() and sibling.resolve() != json_path.resolve():
        sibling.unlink()
    if detail:
        return "", reply
    seen_url = ""
    if isinstance(saved.get("page"), dict):
        seen_url = str(saved["page"].get("url") or "")
    return _wrap_run(step, path=path, env=env, run_src=run_src, page_url=seen_url), reply


def _browser_script(
    step: Step,
    *,
    path: Path,
    env: dict[str, str],
    error: str,
    page: dict[str, Any] | None = None,
    reference: str = "",
    workflow_path: Path | None = None,
    step_json: str = "",
    browser: Any = None,
    variables: dict[str, Any] | None = None,
) -> tuple[str, Any]:
    """Compile one browser goal. Scroll and plain page actions call a helper. Generate writes the script."""
    from . import model
    from .browser_helper import (
        _only_duration_wait,
        _scroll_phrase,
        click_if_exists_command,
        enabled_click_command,
        click_locator_command,
        locate_click_command,
        sendkeys_command,
    )

    pause = _only_duration_wait(step.raw or "")
    if pause is not None:
        log_compile(f"COMPILE browser {path}", step_json)
        run_src = _duration_wait_source(step.raw or "")
        reply = model.CompileReply(text=run_src, model="")
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    if enabled_click_command(step.raw or ""):
        log_compile(f"COMPILE browser {path}", step_json)
        run_src = _enabled_wait_source(step.raw or "")
        reply = model.CompileReply(text=run_src, model="")
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    if click_if_exists_command(step.raw or ""):
        log_compile(f"COMPILE browser {path}", step_json)
        run_src = _click_if_exists_source(step.raw or "")
        reply = model.CompileReply(text=run_src, model="")
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    if locate_click_command(step.raw or ""):
        log_compile(f"COMPILE browser {path}", step_json)
        run_src = _locate_click_source(step.raw or "")
        reply = model.CompileReply(text=run_src, model="")
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    locator = click_locator_command(step.raw or "")
    if locator:
        log_compile(f"COMPILE browser {path}", step_json)
        run_src = _click_locator_source(step.raw or "")
        reply = model.CompileReply(text=run_src, model="")
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    if sendkeys_command(step.raw or "") is not None:
        log_compile(f"COMPILE browser {path}", step_json)
        run_src = _sendkeys_source(step.raw or "")
        reply = model.CompileReply(text=run_src, model="")
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    schedule_var = _schedule_variable(step)
    if schedule_var:
        log_compile(f"COMPILE browser {path}", step_json)
        run_src = (
            "def run(ctx):\n"
            "    from cg_loop.browser_helper import set_schedule_datetime\n"
            f"    return set_schedule_datetime(ctx, {schedule_var!r})\n"
        )
        reply = model.CompileReply(text=run_src, model="")
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    phrase = _scroll_phrase(step.raw or "")
    if phrase:
        log_compile(f"COMPILE browser {path}", step_json)
        run_src = _scroll_run_source(phrase)
        reply = model.CompileReply(text=run_src, model=model.browser_model_name())
        return _wrap_run(step, path=path, env=env, run_src=run_src), reply
    if not _sets_local_file(step) and (_helper_owned(step) or model.choose_compile_action(step) != "generate"):
        return _compile_replay_browser(
            step,
            path=path,
            env=env,
            step_json=step_json,
            browser=browser,
            variables=variables,
        )
    body, reply = _generate_browser_script(
        step,
        path=path,
        env=env,
        error=error,
        page=page,
        variables=variables,
        reference=reference,
        workflow_path=workflow_path,
        step_json=step_json,
    )
    if body:
        return body, reply
    print(f"COMPILE generate fell back to saved actions: {getattr(reply, 'error', '') or 'empty script'}")
    return _compile_replay_browser(
        step,
        path=path,
        env=env,
        step_json=step_json,
        browser=browser,
        variables=variables,
        error=getattr(reply, "error", "") or "",
    )


def _generate_browser_script(
    step: Step,
    *,
    path: Path,
    env: dict[str, str],
    error: str,
    page: dict[str, Any] | None,
    variables: dict[str, Any] | None,
    reference: str,
    workflow_path: Path | None,
    step_json: str,
) -> tuple[str, Any]:
    """Ask the compile model for run(ctx). The script runs at the workflow level."""
    from . import model

    context: dict[str, Any] = {"step": step.raw, "kind": step.kind, "tool": step.tool, "error": error}
    if isinstance(page, dict) and page:
        context["page"] = {
            "url": page.get("url"),
            "title": page.get("title"),
            "text": str(page.get("text") or "")[:6000],
        }
    names = _compile_variables(variables)
    if names:
        context["variables"] = names
    if reference:
        try:
            context["reference"] = _reference_source(reference, workflow_path=workflow_path)
        except RuntimeError as exc:
            print(f"COMPILE generate failed: {exc}")
            return "", model.CompileReply(text="", error=str(exc), model=model.MODEL)
    log_compile(f"COMPILE generate {path}", step_json)
    try:
        reply = model.compile_browser_step(context)
    except Exception as exc:
        print(f"COMPILE generate failed: {exc}")
        return "", model.CompileReply(text="", error=str(exc), model=model.MODEL)
    if not reply.messages:
        reply.messages = model.compile_browser_messages(context)
    run_src = _extract_run(reply.text)
    if not run_src or not _generated_browser_run(run_src):
        reply.error = reply.error or "model did not return a browser script"
        print(f"COMPILE generate failed: {reply.error}")
        return "", reply
    return _wrap_run(step, path=path, env=env, run_src=run_src, page_url=_page_url(page)), reply


def _generated_browser_run(run_src: str) -> bool:
    if "browser_page" not in run_src:
        return False
    if "browser_helper" in run_src or "run_goal" in run_src or "run_term" in run_src:
        return False
    return True


def _generate_extract_script(
    step: Step,
    *,
    path: Path,
    env: dict[str, str],
    error: str,
    page: dict[str, Any] | None,
    variables: dict[str, Any] | None,
    step_json: str,
) -> tuple[str, Any]:
    """Ask the compile model for this extract. The script holds the extraction."""
    from . import model

    context: dict[str, Any] = {
        "step": step.raw,
        "kind": step.kind,
        "tool": step.tool,
        "var": step.var or "article",
        "phrase": step.extra,
        "error": error,
    }
    if isinstance(page, dict) and page:
        context["page"] = {
            "url": page.get("url"),
            "title": page.get("title"),
            "text": str(page.get("text") or "")[:6000],
            "links": list(page.get("links") or [])[:20],
        }
    names = _compile_variables(variables)
    if names:
        context["variables"] = names
    log_compile(f"COMPILE extract {path}", step_json)
    try:
        reply = model.compile_extract_step(context)
    except Exception as exc:
        print(f"COMPILE extract failed: {exc}")
        return "", model.CompileReply(text="", error=str(exc), model=model.MODEL)
    if not reply.messages:
        reply.messages = model.compile_extract_messages(context)
    run_src = _extract_run(reply.text)
    if not run_src or _extract_script_error(run_src, step):
        reply.error = reply.error or _extract_script_error(run_src, step) or "model did not return an extract script"
        print(f"COMPILE extract failed: {reply.error}")
        return "", reply
    return _wrap_run(step, path=path, env=env, run_src=run_src, page_url=_page_url(page)), reply


def _duration_sleep_source(seconds: float) -> str:
    """Sleep for a bare `/python wait 10s`. The compile model is not asked."""
    return (
        "def run(ctx):\n"
        "    import time\n"
        f"    seconds = {seconds!r}\n"
        "    if ctx.get('dry_run'):\n"
        "        print(f'DRY-RUN WAIT {seconds:g}s')\n"
        "        return {'inputs': {'seconds': seconds}, 'outputs': {'status': 'proposed'}}\n"
        "    print(f'Waiting {seconds:g}s.', flush=True)\n"
        "    time.sleep(seconds)\n"
        "    return {'inputs': {'seconds': seconds}, 'outputs': {'status': 'ok', 'message': f'Waited {seconds:g}s.'}}\n"
    )


def _duration_wait_source(command: str) -> str:
    """Sleep for a bare `/browser wait 10s`. No tab and no model."""
    return (
        "def run(ctx):\n"
        "    from cg_loop.browser_helper import replay_browser_actions\n"
        "    return replay_browser_actions(\n"
        f"        {command!r},\n"
        "        ctx.get('browser'),\n"
        "        [],\n"
        "        dry_run=bool(ctx.get('dry_run')),\n"
        "        env=ctx.get('env') or {},\n"
        "        variables=ctx.get('variables') or {},\n"
        "    )\n"
    )


def _enabled_wait_source(command: str) -> str:
    """Wait until the named control is enabled, then click it. This does not ask Jev."""
    return (
        "def run(ctx):\n"
        "    from cg_loop.browser_helper import wait_until_enabled_then_click\n"
        "    return wait_until_enabled_then_click(\n"
        f"        {command!r},\n"
        "        ctx.get('browser'),\n"
        "        dry_run=bool(ctx.get('dry_run')),\n"
        "    )\n"
    )


def _click_if_exists_source(command: str) -> str:
    """Wait, then click the named control when it is on the page. This does not ask Jev."""
    return (
        "def run(ctx):\n"
        "    from cg_loop.browser_helper import click_if_exists\n"
        "    return click_if_exists(\n"
        f"        {command!r},\n"
        "        ctx.get('browser'),\n"
        "        dry_run=bool(ctx.get('dry_run')),\n"
        "    )\n"
    )


def _click_locator_source(command: str) -> str:
    """Click a Playwright locator. This does not look up a visible name."""
    return (
        "def run(ctx):\n"
        "    from cg_loop.browser_helper import run_click_locator\n"
        f"    return run_click_locator(ctx, {command!r})\n"
    )


def _sendkeys_source(command: str) -> str:
    """Type into the focused field. This does not look up a textbox."""
    return (
        "def run(ctx):\n"
        "    from cg_loop.browser_helper import run_sendkeys\n"
        f"    return run_sendkeys(ctx, {command!r})\n"
    )


def _locate_click_source(command: str) -> str:
    """Run time screenshots and runs LocateAnything, or clicks a saved point. It does not ask Jev."""
    return (
        "def run(ctx):\n"
        "    from cg_loop.browser_helper import click_located\n"
        "    return click_located(\n"
        f"        {command!r},\n"
        "        ctx.get('browser'),\n"
        "        dry_run=bool(ctx.get('dry_run')),\n"
        "        env=ctx.get('env') or {},\n"
        "        variables=ctx.get('variables') or {},\n"
        "    )\n"
    )


def _scroll_run_source(phrase: str) -> str:
    """The scroll step itself: page down, then check the visible text, and repeat."""
    shown = phrase.replace("\\", "\\\\").replace('"', '\\"')
    return f'''def run(ctx):
    from cg_loop.browser_helper import page_down, phrase_visible, read_tab

    phrase = "{shown}"
    dry_run = bool(ctx.get("dry_run"))
    tab = ctx.get("browser")
    steps = []
    actions = []
    page = read_tab(tab)
    status = "ready"
    message = ""
    executed = False
    for _ in range(8):
        found = phrase_visible(page, phrase)
        verdict = f"{{phrase}} is in view." if found else f"{{phrase}} is not in view."
        actions.append({{"operation": "CHECK", "kind": "check", "label": phrase, "message": verdict}})
        steps.append(f"Verify {{verdict}}")
        if found:
            status = "done"
            message = verdict
            break
        actions.append({{"operation": "PAGE_DOWN", "kind": "scroll", "label": "Page down", "message": ""}})
        steps.append("Page down")
        if dry_run:
            status = "dry-run"
            message = f"{{phrase}} is not in view."
            break
        scroll = page.get("scroll") if isinstance(page.get("scroll"), dict) else {{}}
        before = (scroll.get("top"), scroll.get("y"), page.get("text"))
        page_down(tab, page)
        executed = True
        page = read_tab(tab)
        scroll = page.get("scroll") if isinstance(page.get("scroll"), dict) else {{}}
        if (scroll.get("top"), scroll.get("y"), page.get("text")) == before:
            found = phrase_visible(page, phrase)
            verdict = f"{{phrase}} is in view." if found else f"{{phrase}} is not in view."
            actions.append({{"operation": "CHECK", "kind": "check", "label": phrase, "message": verdict}})
            steps.append(f"Verify {{verdict}}")
            status = "done" if found else "blocked"
            message = verdict if found else f"{{phrase}} is not in view."
            break
    else:
        found = phrase_visible(page, phrase)
        verdict = f"{{phrase}} is in view." if found else f"{{phrase}} is not in view."
        actions.append({{"operation": "CHECK", "kind": "check", "label": phrase, "message": verdict}})
        steps.append(f"Verify {{verdict}}")
        status = "done" if found else "blocked"
        message = verdict if found else f"{{phrase}} is not in view."
    if dry_run and status != "blocked":
        status = "dry-run"
    print("actions")
    for index, action in enumerate(actions, 1):
        print(f"{{index}}. {{action['operation']}}  {{action.get('message') or action.get('label')}}")
    if status == "blocked" and message:
        print(message)
    return {{
        "status": status,
        "blocked": status == "blocked",
        "message": message,
        "executed": executed,
        "outputs": {{
            "status": status,
            "steps": steps,
            "actions": actions,
            "message": message,
            "searched": {{}},
            "llm_call": None,
        }},
    }}
'''


def _reference_source(reference: str, *, workflow_path: Path | None) -> dict[str, str] | None:
    """Read an example script for the compiler. The run never executes this file."""
    text = (reference or "").strip()
    if not text:
        return None
    path = Path(text).expanduser()
    if not path.is_absolute() and workflow_path is not None:
        path = (workflow_path.parent / path).resolve()
    if not path.is_file():
        raise RuntimeError(f"reference script not found: {path}")
    return {
        "path": str(path),
        "note": "Example only. Do not import, run, or call this file. Copy the Playwright calls that match this step.",
        "source": path.read_text(encoding="utf-8")[:24000],
    }


def _public_env(env: dict[str, str]) -> dict[str, str]:
    hidden = ("KEY", "TOKEN", "SECRET", "PASSWORD")
    return {key: value for key, value in env.items() if not any(part in key.upper() for part in hidden)}


def _model_script(step: Step, *, path: Path, env: dict[str, str], error: str) -> tuple[str, Any]:
    from . import model

    context = {
        "step": step.raw,
        "kind": step.kind,
        "url": step.url,
        "error": error,
    }
    messages = model.compile_messages(context)
    log_compile(f"COMPILE llm {path}", folder=path.parent)
    try:
        reply = model.compile_step(context)
    except Exception as exc:
        print(f"COMPILE llm failed: {exc}")
        return "", model.CompileReply(text="", messages=messages, error=str(exc), model=model.MODEL)
    if isinstance(reply, str):
        reply = model.CompileReply(text=reply, messages=messages, model=model.MODEL)
    if not reply.messages:
        reply.messages = messages
    if reply.error or not (reply.text or "").strip():
        print(f"COMPILE llm failed: {reply.error or 'empty script'}")
        return "", reply
    run_src = _extract_run(reply.text)
    if not run_src:
        print("COMPILE llm failed: model did not return def run")
        reply.error = reply.error or "model did not return def run"
        return "", reply
    return _wrap_run(step, path=path, env=env, run_src=run_src), reply


def _log_compile(workflow: Workflow, step: Step, **kwargs: Any) -> None:
    try:
        note_compile_attempt(workflow, step, **kwargs)
    except Exception as exc:
        print(f"COMPILE log failed: {exc}")


_HELPER_MODULES = frozenset({"cg_loop.browser_helper", "cg_loop.compiled", "cg_loop.python_helper"})


def compile_record_path(script: Path) -> Path:
    """Prompt or helper note kept beside a compiled script."""
    from .browser_helper import artifact_dir

    folder = artifact_dir(script)
    if is_packet_script(script):
        return folder / "a-prompt.md"
    return folder / f"{script.stem}.prompt.md"


def _ensure_compile_record(script: Path, step: Step, *, only_helper: bool) -> tuple[str, str]:
    """Keep an existing note. A reused helper script with none gets one."""
    if is_packet_script(script):
        write_stage_context(script.parent, step)
    path = compile_record_path(script)
    if path.is_file():
        return _summarize_compile_record(path)
    try:
        source = script.read_text(encoding="utf-8")
    except OSError:
        return "", ""
    return _write_compile_record(script, step, source, None, only_helper=only_helper)


def _write_compile_record(
    script: Path,
    step: Step,
    source: str,
    reply: Any,
    *,
    only_helper: bool = False,
) -> tuple[str, str]:
    """Write the prompt that generated this Python, or the helper when none did."""
    if is_packet_script(script):
        write_stage_context(script.parent, step)
    messages = getattr(reply, "messages", None) if reply is not None else None
    text = _compile_record_text(step.raw or "", source, messages, only_helper=only_helper)
    if not text:
        return "", ""
    path = compile_record_path(script)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        same = path.is_file() and path.read_text(encoding="utf-8") == text
    except OSError:
        same = False
    if not same:
        path.write_text(text, encoding="utf-8")
    prompt_path, helper = _summarize_compile_record(path)
    return prompt_path, helper


def _summarize_compile_record(path: Path) -> tuple[str, str]:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return "", ""
    match = re.search(r"(?m)^helper: (.+)$", text)
    if match and "## " not in text:
        return "", match.group(1).strip()
    return str(path), ""


def _compile_record_text(
    step_text: str,
    source: str,
    messages: list[dict[str, Any]] | None,
    *,
    only_helper: bool,
) -> str:
    title = (step_text or "").strip() or "step"
    if not only_helper and _messages_generated_python(messages):
        prompt = prompt_markdown(title, {"llm_call": {"messages": messages}})
        if prompt:
            return prompt
    if _is_thin_helper(source):
        return f"# {title}\n\nhelper: {_returned_helper(source)}\n"
    if not only_helper and messages:
        prompt = prompt_markdown(title, {"llm_call": {"messages": messages}})
        if prompt:
            return prompt
    if only_helper:
        return ""
    names = _helpers_in_run(source)
    if names:
        return f"# {title}\n\nhelper: {', '.join(names)}\n"
    return ""


def _messages_generated_python(messages: list[dict[str, Any]] | None) -> bool:
    """True when these messages are the prompt that writes run(ctx)."""
    for message in messages or []:
        if not isinstance(message, dict):
            continue
        content = str(message.get("content") or "")
        if "Write the run(ctx)" in content:
            return True
    return False


def _run_function(source: str) -> ast.FunctionDef | None:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None
    return next((node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "run"), None)


def _helpers_in_run(source: str) -> list[str]:
    """cg-loop helpers imported inside run. browser_page is a page read, not the step helper."""
    run = _run_function(source)
    if run is None:
        return []
    names: list[str] = []
    for stmt in run.body:
        if not isinstance(stmt, ast.ImportFrom) or stmt.module not in _HELPER_MODULES:
            continue
        for alias in stmt.names:
            name = alias.asname or alias.name
            if name in {"*", "browser_page"} or name in names:
                continue
            names.append(name)
    return names


def _returned_helper(source: str) -> str:
    run = _run_function(source)
    if run is None:
        return ""
    for stmt in run.body:
        if isinstance(stmt, ast.Return) and isinstance(stmt.value, ast.Call) and isinstance(stmt.value.func, ast.Name):
            return stmt.value.func.id
    return ""


def _is_thin_helper(source: str) -> bool:
    """True when run only imports, assigns, and returns one cg-loop helper."""
    run = _run_function(source)
    if run is None:
        return False
    imported = set(_helpers_in_run(source))
    returned = ""
    for stmt in run.body:
        if isinstance(stmt, (ast.Import, ast.ImportFrom, ast.Assign, ast.AnnAssign, ast.Pass)):
            continue
        if (
            isinstance(stmt, ast.Return)
            and isinstance(stmt.value, ast.Call)
            and isinstance(stmt.value.func, ast.Name)
        ):
            if returned:
                return False
            returned = stmt.value.func.id
            continue
        return False
    return bool(returned) and returned in imported


def _extract_run(text: str) -> str:
    cleaned = (text or "").strip()
    fence = re.match(r"^```(?:python)?\s*([\s\S]*?)\s*```$", cleaned, re.IGNORECASE)
    if fence:
        cleaned = fence.group(1).strip()
    start = cleaned.find("def run")
    if start < 0:
        return ""
    body = cleaned[start:]
    main_at = body.find("\nif __name__")
    if main_at >= 0:
        body = body[:main_at]
    return body.strip()


def _wrap_run(step: Step, *, path: Path, env: dict[str, str], run_src: str, page_url: str = "") -> str:
    source = (step.raw or "").replace('"""', "'")
    example = _example_block(step, path, env or {}).replace('"""', "'")
    recorded = f"Page: {page_url}\n" if page_url else ""
    return f'''"""Compiled cg-loop step.

Source: {source}
{recorded}
{example}
"""
import sys
from pathlib import Path

_LIB = Path({str(_LIB)!r})
if str(_LIB) not in sys.path:
    sys.path.insert(0, str(_LIB))


{run_src}


if __name__ == "__main__":
    from cg_loop.compiled import main_standalone
    main_standalone(run)
'''


def render_step(
    step: Step,
    *,
    path: Path | None = None,
    env: dict[str, str] | None = None,
    call: str = "",
    runner: str = "",
) -> str:
    source = (step.raw or "").replace('"""', "'")
    call = call or _call_expr(step)
    runner = runner or _runner_name(step.kind)
    example = _example_block(step, path, env or {}).replace('"""', "'")
    return f'''"""Compiled cg-loop step.

Source: {source}

{example}
"""
import sys
from pathlib import Path

_LIB = Path({str(_LIB)!r})
if str(_LIB) not in sys.path:
    sys.path.insert(0, str(_LIB))


def run(ctx):
    from cg_loop.compiled import {runner}
    return {call}


if __name__ == "__main__":
    from cg_loop.compiled import main_standalone
    main_standalone(run)
'''


def execute_compiled(path: Path, ctx: dict[str, Any], *, capture_stdout: bool = False) -> dict[str, Any]:
    module_name = f"cg_compiled_{path.stem}"
    sys.modules.pop(module_name, None)
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load compiled step {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    from .data_numbers import numbered_data

    printed = ""
    with numbered_data(ctx):
        if capture_stdout:
            import contextlib
            import io

            buffer = io.StringIO()
            with contextlib.redirect_stdout(buffer):
                result = module.run(ctx)
            printed = buffer.getvalue()
            if printed:
                sys.stdout.write(printed)
                if not printed.endswith("\n"):
                    sys.stdout.write("\n")
        else:
            result = module.run(ctx)
    if not isinstance(result, dict):
        raise RuntimeError(f"compiled step {path} returned {type(result).__name__}")
    if printed:
        outputs = result.get("outputs")
        if isinstance(outputs, dict):
            outputs.setdefault("stdout", printed)
        else:
            result["stdout"] = printed
    return result


def check_python_verify(
    result: dict[str, Any],
    expected: str,
    *,
    files: list[Path] | None = None,
) -> dict[str, Any]:
    """Block the step when the result does not contain `expected`.

    A printed answer is enough when the step names no file. A step that names
    an `.html` or other file must put the text in that file. An HTML file also
    has to be a document with a heading and a list. A short word, such as `3`,
    matches that word and not a longer one.
    """
    phrase = (expected or "").strip()
    named = [Path(path) for path in (files or [])]
    if not phrase:
        return result
    if named:
        return _check_python_files(result, phrase, named)
    if _python_verify_matches(phrase, _python_printed(result)):
        return result
    printed = _python_printed(result).strip()
    shown = printed.splitlines()[0][:200] if printed else ""
    if shown:
        message = f"verify failed: printed {shown!r}, which did not contain {phrase!r}"
    else:
        message = f"verify failed: printed output did not contain {phrase!r}"
    return _block_python_verify(result, phrase, message)


def python_named_files(step: Step, env: dict[str, str] | None, variables: dict[str, Any] | None) -> list[Path]:
    """File paths the `/python` task names, such as `$rootProject/data/slide.html`."""
    from .terminal import expand_command
    from .workflow import python_sentence

    merged = {**os.environ, **(env or {})}
    text = expand_command(python_sentence(step), merged, variables or {})
    root = Path(str(merged.get("rootProject") or ".")).expanduser()
    found: list[Path] = []
    for match in _NAMED_FILE_RE.finditer(text):
        raw = match.group(1).rstrip(".,)")
        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = root / path
        if path not in found:
            found.append(path)
    return found


_NAMED_FILE_RE = re.compile(
    r"(?<!\S)([^\s\"']*?/[^\s\"']+\.(?:html|htm|yaml|yml|md|css))(?!\w)",
    re.IGNORECASE,
)


def _check_python_files(result: dict[str, Any], phrase: str, files: list[Path]) -> dict[str, Any]:
    missing = [path for path in files if not path.is_file()]
    if missing:
        return _block_python_verify(result, phrase, f"verify failed: {missing[0]} was not written")
    blobs: list[str] = []
    for path in files:
        blobs.append(path.read_text(encoding="utf-8", errors="replace")[:200_000])
    blob = "\n".join(blobs)
    if not _python_verify_matches(phrase, blob):
        return _block_python_verify(result, phrase, f"verify failed: {files[0].name} did not contain {phrase!r}")
    html = [path for path in files if path.suffix.lower() in {".html", ".htm"}]
    if html and not _presentation_html(blob):
        return _block_python_verify(
            result,
            phrase,
            f"verify failed: {html[0].name} is not a presentation",
        )
    return result


def _presentation_html(text: str) -> bool:
    """A presentation is an HTML document with a heading and a list."""
    lowered = text.lower()
    document = "<html" in lowered or "<!doctype html" in lowered
    heading = any(tag in lowered for tag in ("<h1", "<h2", "<h3"))
    bullets = "<li" in lowered and ("<ul" in lowered or "<ol" in lowered)
    return document and heading and bullets


def _block_python_verify(result: dict[str, Any], phrase: str, message: str) -> dict[str, Any]:
    print(message, flush=True)
    outputs = dict(result.get("outputs") or {})
    outputs["status"] = "blocked"
    outputs["verify"] = phrase
    outputs["message"] = message
    updated = dict(result)
    updated["outputs"] = outputs
    updated["blocked"] = True
    return updated


def _python_printed(result: dict[str, Any]) -> str:
    parts: list[str] = []
    outputs = result.get("outputs")
    if isinstance(outputs, dict):
        for key in ("printed", "stdout"):
            value = outputs.get(key)
            if value is not None:
                parts.append(str(value))
    if result.get("stdout"):
        parts.append(str(result["stdout"]))
    variables = result.get("variables")
    if isinstance(variables, dict):
        for value in variables.values():
            if isinstance(value, (str, int, float)) and not isinstance(value, bool):
                parts.append(str(value))
    return "\n".join(parts)


def _python_verify_matches(phrase: str, text: str) -> bool:
    if len(phrase) <= 2 and phrase.isalnum():
        return re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", text) is not None
    return phrase in text


def describe_inputs(
    step: Step,
    env: dict[str, str],
    variables: dict[str, Any],
    workflow_path: Path | None = None,
) -> dict[str, Any]:
    """Inputs a step will see, expanded before it runs."""
    from .terminal import expand_command

    merged = {**os.environ, **env}

    def expand(value: str) -> str:
        return expand_command(value, merged, variables)

    if step.kind == "load":
        return {
            "filter": step.extra,
            "var": step.var or "seen",
            "roots": {token: expand(token) for token in step.roots},
        }
    if step.kind == "goto":
        return {"url": step.url}
    if step.kind == "reuse_tab":
        return {"site": step.extra}
    if step.kind == "browser_js":
        return {"js": step.extra, "var": step.var}
    if step.kind == "browser_gemma":
        return {"model": step.command, "instruction": step.extra, "var": step.var}
    if step.kind == "openrouter":
        return {"model": step.command, "instruction": step.extra, "var": step.var}
    if step.kind == "extract":
        return {"phrase": step.extra, "var": step.var or "article"}
    if step.kind == "term":
        return {"command": expand(step.command)}
    if step.kind == "llm_call":
        return {"template": step.template, "var": step.var or "article"}
    if step.kind == "generate":
        return {"var": step.var or "article", "extra": step.extra}
    if step.kind == "condition":
        return {
            "condition": step.condition,
            "checks": [sub.raw for sub in step.checks],
            "steps": [sub.raw for sub in step.steps],
        }
    if step.kind == "workflow":
        params = {
            key: expand(value) if isinstance(value, str) else value
            for key, value in step.params.items()
        }
        return {
            "workflow": expand(step.workflow_name) if step.workflow_name else "",
            "ref": step.workflow_ref,
            "params": params,
        }
    if step.kind == "code":
        return {"script": step.workflow_name or step.raw, "params": dict(step.params)}
    if step.kind == "locate":
        return {"query": expand(step.extra), "image": expand(step.command), "var": step.var or "loc"}
    if step.kind == "clef":
        return {
            "question": expand(step.extra),
            "options": [expand(str(item)) for item in (step.params.get("options") or [])],
            "verify": expand(str(step.params.get("verify") or "")),
            "image": str(step.params.get("image") or "") or "/browser",
            "var": step.var,
        }
    if step.kind == "hug":
        from .hug import load_prompt

        written = expand(step.extra)
        base = workflow_path.expanduser().parent if workflow_path else None
        try:
            message, prompt_file = load_prompt(written, base=base, env=merged, variables=variables)
        except (OSError, ValueError, FileNotFoundError):
            message, prompt_file = written, ""
        return {
            "model": expand(step.command) if step.command else expand(str((env or {}).get("HUG_MODEL") or "")),
            "message": message,
            "prompt_file": prompt_file,
            "files": [expand(str(item)) for item in (step.params.get("files") or [])],
            "out": expand(str(step.params.get("out") or "")),
            "var": step.var,
            "print": bool(step.params.get("print")),
        }
    if step.kind == "cua":
        return {
            "action": step.extra,
            "app": expand(str(step.params.get("app") or "")),
            "url": expand(step.url),
            "label": expand(str(step.params.get("label") or "")),
            "text": expand(str(step.params.get("text") or "")),
            "var": step.var,
        }
    return {"step": step.raw}


def main_standalone(run: Callable[[dict[str, Any]], dict[str, Any]]) -> None:
    payload, dry_flag = _standalone_args(sys.argv[1:], script=Path(sys.argv[0]))
    ctx: dict[str, Any] = {
        "env": dict(os.environ),
        "variables": json.loads(os.environ.get("CG_LOOP_VARIABLES") or "{}"),
        "dry_run": dry_flag or os.environ.get("CG_LOOP_DRY_RUN") == "1",
        "browser": None,
        "cdp_url": os.environ.get("CDP_URL") or os.environ.get("CG_LOOP_CDP_URL") or "",
        "run_dir": os.environ.get("CG_LOOP_RUN_DIR") or "",
        "data": os.environ.get("DATA") or os.environ.get("CG_LOOP_DATA") or "",
        "timeout": None,
        "cwd": os.environ.get("CG_LOOP_CWD") or os.getcwd(),
        "workflow_path": os.environ.get("CG_LOOP_WORKFLOW") or "",
    }
    if isinstance(payload.get("env"), dict):
        ctx["env"].update({str(key): "" if value is None else str(value) for key, value in payload["env"].items()})
    if isinstance(payload.get("variables"), dict):
        ctx["variables"].update(payload["variables"])
    if payload.get("dry_run"):
        ctx["dry_run"] = True
    if payload.get("cdp_url"):
        ctx["cdp_url"] = str(payload["cdp_url"])
    if payload.get("run_dir"):
        ctx["run_dir"] = str(payload["run_dir"])
    if payload.get("data"):
        ctx["data"] = str(payload["data"])
    if payload.get("cwd"):
        ctx["cwd"] = str(payload["cwd"])
    if payload.get("workflow_path"):
        ctx["workflow_path"] = str(payload["workflow_path"])
    if "timeout" in payload:
        from .terminal import command_timeout

        ctx["timeout"] = command_timeout(payload.get("timeout"))
    opened = False
    if ctx["cdp_url"] and not ctx["dry_run"]:
        from .browser import Browser

        ctx["browser"] = Browser(
            ctx["cdp_url"],
            profile=str((ctx.get("env") or {}).get("PROFILE") or ""),
        )
        ctx["browser"].open()
        opened = True
    from .data_numbers import data_numbers_enabled, numbered_data

    ctx["data_numbers"] = data_numbers_enabled(True, "", ctx.get("env") or {})
    try:
        with numbered_data(ctx):
            result = run(ctx)
    finally:
        browser = ctx.get("browser")
        if opened and browser is not None:
            browser.close()
    print(json.dumps(result.get("outputs") or {}, indent=2, default=str))


def run_load(
    ctx: dict[str, Any],
    *,
    filter_text: str,
    var: str,
    roots: list[str],
) -> dict[str, Any]:
    from .extract import load_previous_titles, load_previous_urls
    from .terminal import expand_command

    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}
    expanded = [expand_command(token, env, variables) for token in roots]
    ideas = "idea" in (filter_text or "").lower()
    found = load_previous_titles(expanded) if ideas else load_previous_urls(expanded, filter_text=filter_text)
    name = var or "seen"
    kind = "titles" if ideas else "urls"
    print(f"LOAD ${name} {len(found)} {kind} from {expanded}")
    return {
        "inputs": {"filter": filter_text, "var": name, "roots": dict(zip(roots, expanded))},
        "outputs": {name: found},
        "variables": {name: found},
    }


def read_browser(browser: Any) -> dict[str, Any]:
    """Observe the open page, waiting briefly if the text has not been painted yet."""
    page = browser.observe()
    for _ in range(4):
        if str(page.get("text") or "").strip():
            return page
        waiter = getattr(browser, "page", None)
        if waiter is not None and hasattr(waiter, "wait_for_timeout"):
            waiter.wait_for_timeout(500)
        page = browser.observe()
    return page


def set_local_input_files(page: Any, path: str) -> None:
    """Set a file input from a path on this machine. Chrome reads the file itself."""
    from .browser import set_local_input_files as apply

    apply(page, path)


def browser_page(ctx: dict[str, Any]) -> dict[str, Any]:
    """Read the page that is already open. Does not navigate and does not start another step."""
    if ctx.get("dry_run"):
        return {"url": "", "title": "(dry-run)", "text": "(dry-run)"}
    browser = ctx.get("browser")
    if browser is None:
        raise RuntimeError(f"browser step needs a CDP session ({ctx.get('cdp_url') or 'no cdp-url'})")
    page = read_browser(browser)
    return {
        "url": str(page.get("url") or ""),
        "title": str(page.get("title") or ""),
        "text": str(page.get("text") or ""),
    }


def run_goal(ctx: dict[str, Any], text: str) -> dict[str, Any]:
    """Hand the step to the agent goal loop. `$NAME` is filled from variables and env."""
    from .terminal import expand_command

    env = {**os.environ, **(ctx.get("env") or {})}
    text = expand_command(text, env, ctx.get("variables") or {})
    print(f"GOAL {text}")
    return {
        "inputs": {"goal": text},
        "outputs": {"mode": "goal", "goal": text},
        "delegate": "goal",
    }


def _strip_js(source: str) -> str:
    text = (source or "").strip()
    fenced = re.match(r"^```(?:javascript|js)?\s*(.*?)\s*```$", text, re.DOTALL | re.IGNORECASE)
    if fenced:
        text = fenced.group(1).strip()
    return text


def _generated_js_script(
    step: Step,
    *,
    path: Path,
    env: dict[str, str],
    page: dict[str, Any] | None,
    step_json: str,
    browser: Any = None,
) -> tuple[str, Any]:
    """Compile `/browser +js <instruction>` into run_browser_js with the generated function."""
    from . import model

    log_compile(f"COMPILE js {path}", step_json)
    seen = dict(page or {})
    if browser is not None and not seen.get("url"):
        from .browser_helper import read_tab

        try:
            live = read_tab(browser)
        except Exception:
            live = {}
        if isinstance(live, dict):
            seen = live
    reply = model.generate_browser_js(step.raw or step.extra, seen)
    script = _strip_js(reply.text)
    if reply.error or not script or ("function" not in script and "=>" not in script):
        reply.error = reply.error or "JS was not a function."
        return "", reply
    verify = str(step.params.get("verify") or "").strip()
    try:
        seconds = max(0.0, float(step.params.get("verify_seconds") if step.params.get("verify_seconds") is not None else 5))
    except (TypeError, ValueError):
        seconds = 5.0
    lines = [
        "def run(ctx):",
        "    from cg_loop.compiled import run_browser_js",
        f"    result = run_browser_js(ctx, {script!r}, {step.var!r})",
    ]
    if verify:
        lines.extend(
            [
                "    from cg_loop.browser_helper import replay_browser_actions",
                "    waited = replay_browser_actions(",
                f"        {('verify ' + verify)!r},",
                "        ctx.get('browser'),",
                "        [{",
                "            'operation': 'WAIT',",
                f"            'phrase': {verify!r},",
                f"            'target': {verify!r},",
                f"            'label': {verify!r},",
                "            'kind': 'wait',",
                f"            'seconds': {seconds!r},",
                "            'selector': '',",
                "        }],",
                "        dry_run=bool(ctx.get('dry_run')),",
                "        env=ctx.get('env') or {},",
                "        variables=ctx.get('variables') or {},",
                "    )",
                "    if waited.get('blocked') or waited.get('status') == 'blocked':",
                "        return waited",
                "    outputs = dict(result.get('outputs') or {})",
                "    outputs['verify'] = waited.get('message') or ''",
                "    result['outputs'] = outputs",
            ]
        )
    lines.append("    return result")
    run_src = "\n".join(lines) + "\n"
    reply.text = run_src
    return _wrap_run(step, path=path, env=env, run_src=run_src), reply


def run_browser_js(ctx: dict[str, Any], source: str, var: str) -> dict[str, Any]:
    """Run JavaScript on the open page and store the return value."""
    name = var or "value"
    expression = _js_expression(source)
    print(f"JS ${name}", flush=True)
    inputs = {"js": source, "var": name}
    if ctx.get("dry_run"):
        return {"inputs": inputs, "outputs": {"status": "dry-run", name: ""}, "variables": {name: ""}}
    browser = ctx.get("browser")
    if browser is None:
        raise RuntimeError(f"browser js needs a browser CDP session ({ctx.get('cdp_url') or 'no cdp-url'})")
    page = getattr(browser, "page", None)
    if page is None or not hasattr(page, "evaluate"):
        raise RuntimeError("browser js needs an open page")
    value = page.evaluate(expression)
    print(f"JS ${name} = {_js_shown(value)}", flush=True)
    return {"inputs": inputs, "outputs": {name: value, "status": "ok"}, "variables": {name: value}}


def run_browser_gemma(ctx: dict[str, Any], model: str, instruction: str, var: str) -> dict[str, Any]:
    """Screenshot the open page, ask the model, and store the JSON value."""
    from .gemma import accepts_value, extract_image, extraction_prompt
    from .terminal import expand_command

    name = var or "value"
    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}
    task = expand_command(instruction, env, variables)
    prompt = extraction_prompt(task)
    inputs = {"model": model, "instruction": task, "prompt": prompt, "var": name}
    lower_model = (model or "").lower()
    if lower_model.startswith("openrouter-"):
        label = "OPENROUTER"
    elif lower_model.startswith("local/"):
        label = "LOCAL"
    else:
        label = "LMSTUDIO"
    if ctx.get("dry_run"):
        print(f"DRY-RUN {label} /{model} ${name}")
        found = {"status": "proposed", "text": "", "value": "", "model": model}
        return {"inputs": inputs, "outputs": {"status": "dry-run", "prompt": prompt, name: found}, "variables": {name: found}}
    browser = ctx.get("browser")
    page = getattr(browser, "page", None) if browser is not None else None
    if page is None or not hasattr(page, "screenshot"):
        raise RuntimeError(f"{label.lower()} extract needs an open page ({ctx.get('cdp_url') or 'no cdp-url'})")
    shot = _gemma_shot_path(ctx)
    shot.write_bytes(page.screenshot(type="jpeg", quality=80))
    logged = _gemma_log_shot(ctx, shot)
    print(f"{label} /{model} ${name}", flush=True)
    try:
        found = extract_image(model, task, str(shot), env)
    except Exception as exc:
        print(f"BLOCKED {exc}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {"status": "blocked", "message": str(exc), "prompt": prompt, "screenshots": [str(logged)]},
            "blocked": True,
        }
    value = str(found.get("value") or "").strip()
    if not accepts_value(task, value):
        raw = str(found.get("raw") or "").strip()
        message = f"model did not return a value for ${name}"
        if raw:
            message = f"{message}: {raw[:500]}"
        print(f"BLOCKED {message}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {
                name: found,
                "status": "blocked",
                "message": message,
                "prompt": prompt,
                "screenshots": [str(logged)],
            },
            "variables": {name: found},
            "blocked": True,
        }
    print(f"{label} ${name} = {value}", flush=True)
    return {
        "inputs": inputs,
        "outputs": {name: found, "status": "ok", "prompt": prompt, "screenshots": [str(logged)]},
        "variables": {name: found},
    }


def read_template(
    source: str | Path,
    ctx: dict[str, Any] | None = None,
    *,
    env: dict[str, str] | None = None,
    variables: dict[str, Any] | None = None,
    base: Path | None = None,
) -> str:
    """Read an `.md` or `.json` prompt and fill `$name` from context.

    ``{{name}}``, ``${name}``, and ``$name`` come from variables, then config.
    A missing name stays as written. The file is the prompt.
    """
    from .hug import read_template as _read_template

    if base is None and isinstance(ctx, dict):
        base = _workflow_dir(ctx)
    return _read_template(source, ctx, env=env, variables=variables, base=base)


def _model_instruction(
    ctx: dict[str, Any],
    instruction: str,
    env: dict[str, str],
    variables: dict[str, Any],
) -> tuple[str, str]:
    """The prompt text, and the markdown or JSON file it was read from."""
    from .hug import is_template_file
    from .terminal import expand_command

    task = expand_command(instruction, env, variables).strip()
    if not is_template_file(task):
        return task, ""
    return read_template(task, ctx, env=env, variables=variables), task


def run_openrouter(ctx: dict[str, Any], model: str, instruction: str, var: str) -> dict[str, Any]:
    """Ask an OpenRouter model and store the reply. No screenshot."""
    from .gemma import complete_text

    name = var or "value"
    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}
    try:
        task, prompt_file = _model_instruction(ctx, instruction, env, variables)
    except (OSError, ValueError, FileNotFoundError) as exc:
        print(f"BLOCKED {exc}", flush=True)
        return {
            "inputs": {"model": model, "instruction": instruction, "var": name},
            "outputs": {"status": "blocked", "message": str(exc)},
            "blocked": True,
        }
    inputs = {"model": model, "instruction": task, "prompt": task, "prompt_file": prompt_file, "var": name}
    if task == "DONE" and not ctx.get("dry_run"):
        found = {"status": "ok", "text": "DONE", "value": "DONE", "model": model}
        print(f"OPENROUTER ${name} = DONE", flush=True)
        return {
            "inputs": inputs,
            "outputs": {name: found, "status": "ok", "prompt": task},
            "variables": {name: found},
        }
    if ctx.get("dry_run"):
        print(f"DRY-RUN OPENROUTER /{model} ${name}")
        found = {"status": "proposed", "text": "", "value": "", "model": model}
        return {"inputs": inputs, "outputs": {"status": "dry-run", "prompt": task, name: found}, "variables": {name: found}}
    print(f"OPENROUTER /{model} ${name}", flush=True)
    try:
        found = complete_text(model, task, env)
    except Exception as exc:
        print(f"BLOCKED {exc}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {"status": "blocked", "message": str(exc), "prompt": task},
            "blocked": True,
        }
    value = str(found.get("value") or "").strip()
    if not value:
        message = f"openrouter returned nothing for ${name}"
        print(f"BLOCKED {message}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {name: found, "status": "blocked", "message": message, "prompt": task},
            "variables": {name: found},
            "blocked": True,
        }
    print(f"OPENROUTER ${name} = {value.splitlines()[0][:200]}", flush=True)
    return {
        "inputs": inputs,
        "outputs": {name: found, "status": "ok", "prompt": task},
        "variables": {name: found},
    }


def run_lmstudio(ctx: dict[str, Any], model: str, instruction: str, var: str) -> dict[str, Any]:
    """Ask a local LM Studio model and store the reply. No screenshot."""
    from .gemma import complete_lmstudio_text

    name = var or "value"
    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}
    try:
        task, prompt_file = _model_instruction(ctx, instruction, env, variables)
    except (OSError, ValueError, FileNotFoundError) as exc:
        print(f"BLOCKED {exc}", flush=True)
        return {
            "inputs": {"model": model, "instruction": instruction, "var": name},
            "outputs": {"status": "blocked", "message": str(exc)},
            "blocked": True,
        }
    inputs = {"model": model, "instruction": task, "prompt": task, "prompt_file": prompt_file, "var": name}
    if ctx.get("dry_run"):
        print(f"DRY-RUN LMSTUDIO /{model} ${name}")
        found = {"status": "proposed", "text": "", "value": "", "model": model}
        return {"inputs": inputs, "outputs": {"status": "dry-run", "prompt": task, name: found}, "variables": {name: found}}
    print(f"LMSTUDIO /{model} ${name}", flush=True)
    try:
        found = complete_lmstudio_text(model, task, env)
    except Exception as exc:
        print(f"BLOCKED {exc}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {"status": "blocked", "message": str(exc), "prompt": task},
            "blocked": True,
        }
    value = str(found.get("value") or "").strip()
    if not value:
        message = f"lmstudio returned nothing for ${name}"
        print(f"BLOCKED {message}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {name: found, "status": "blocked", "message": message, "prompt": task},
            "variables": {name: found},
            "blocked": True,
        }
    print(f"LMSTUDIO ${name} = {value.splitlines()[0][:200]}", flush=True)
    return {
        "inputs": inputs,
        "outputs": {name: found, "status": "ok", "prompt": task},
        "variables": {name: found},
    }


def _gemma_shot_path(ctx: dict[str, Any]) -> Path:
    import tempfile

    data = str(ctx.get("data") or "").strip()
    folder = Path(data).expanduser() if data else Path(tempfile.mkdtemp(prefix="cg-gemma-"))
    folder.mkdir(parents=True, exist_ok=True)
    return folder / f"gemma-{time.time_ns()}.jpg"


def _gemma_log_shot(ctx: dict[str, Any], shot: Path) -> Path:
    """Copy the screenshot beside the step JSON so the log keeps the image that was sent."""
    raw = str((ctx.get("env") or {}).get("CG_LOOP_STEP_JSON") or "").strip()
    if not raw:
        return shot
    dest = Path(raw).expanduser().with_suffix(".jpg")
    if dest.resolve() == shot.resolve():
        return shot
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(shot.read_bytes())
    return dest


def _js_expression(source: str) -> str:
    """Playwright evaluates a function. An expression is returned from one."""
    text = (source or "").strip()
    head = text[:80]
    if text.startswith(("(", "function", "async ")) or "=>" in head:
        return text
    return f"() => ({text})"


def _js_shown(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, default=str)


def run_reuse_tab(ctx: dict[str, Any], site: str) -> dict[str, Any]:
    """Attach later browser steps to a matching open tab, or a new one."""
    print(f"REUSE_TAB {site}")
    browser = ctx.get("browser")
    if browser is None:
        if ctx.get("dry_run"):
            return {"inputs": {"site": site}, "outputs": {"status": "dry-run", "site": site, "reused": False}}
        raise RuntimeError(f"reuseTab needs a browser CDP session ({ctx.get('cdp_url') or 'no cdp-url'})")
    page = browser.reuse_tab(site)
    return {
        "inputs": {"site": site},
        "outputs": {
            "url": page.get("url"),
            "title": page.get("title"),
            "reused": bool(page.get("reused")),
        },
        "page": page,
    }


def run_goto(ctx: dict[str, Any], url: str, wait_until: str = "domcontentloaded") -> dict[str, Any]:
    from .terminal import expand_url

    env = {**os.environ, **(ctx.get("env") or {})}
    url = expand_url(url, env, ctx.get("variables") or {})
    print(f"GOTO {url}" if wait_until == "domcontentloaded" else f"GOTO {url}  wait={wait_until}")
    if ctx.get("dry_run"):
        return {"inputs": {"url": url}, "outputs": {"status": "dry-run", "url": url, "wait_until": wait_until}}
    browser = ctx.get("browser")
    if browser is None:
        raise RuntimeError(f"goto needs a browser CDP session ({ctx.get('cdp_url') or 'no cdp-url'})")
    page = browser.goto(url, wait_until=wait_until)
    return {
        "inputs": {"url": url},
        "outputs": {"url": page.get("url"), "title": page.get("title")},
        "page": page,
    }


def run_extract(ctx: dict[str, Any], *, phrase: str, var: str) -> dict[str, Any]:
    name = var or "article"
    inputs = {"phrase": phrase, "var": name}
    if not ctx.get("browser"):
        if ctx.get("dry_run"):
            article = {
                "title": "(dry-run)",
                "url": "https://example.com/dry-run",
                "text": "(dry-run)",
            }
            print("DRY-RUN EXTRACT (no browser)")
            return {"inputs": inputs, "outputs": {name: article}, "variables": {name: article}}
        raise RuntimeError("extract needs a browser CDP session")
    from .extract import article_from_page, skip_url_set

    page = ctx["browser"].observe()
    article = article_from_page(
        page,
        phrase=phrase,
        skip_urls=skip_url_set(ctx.get("variables") or {}, phrase),
    )
    if not article:
        print("EXTRACT: no unused URL in the observed list")
        return {"inputs": inputs, "outputs": {"status": "blocked"}, "blocked": True, "page": page}
    return {
        "inputs": inputs,
        "outputs": {name: {"title": article.get("title"), "url": article.get("url")}},
        "article": article,
        "store_article": name,
        "page": page,
    }


def _json_object(stdout: str) -> dict[str, Any]:
    """A JSON object in a command's output.

    A pick record (story_folder, short_folder, or stop) wins over an earlier
    object. Otherwise the first object is used.
    """
    text = stdout or ""
    found: list[dict[str, Any]] = []
    start = 0
    while True:
        at = text.find("{", start)
        if at < 0:
            break
        try:
            value, _end = json.JSONDecoder().raw_decode(text[at:])
        except json.JSONDecodeError:
            start = at + 1
            continue
        if isinstance(value, dict):
            found.append(value)
        start = at + 1
    for value in reversed(found):
        if "story_folder" in value or "short_folder" in value or value.get("stop") is True:
            return value
    return found[0] if found else {}


def keep_picked_story(variables: dict[str, Any], stdout: str) -> None:
    """Store the story or short a pick command returned. none means nothing was found."""
    fields = _json_object(stdout)
    has_story = "story_folder" in fields
    has_short = "short_folder" in fields
    stopped = fields.get("stop") is True
    if not has_story and not has_short and not stopped:
        return

    def store(key: str) -> None:
        folder = fields.get(key)
        if stopped or not str(folder or "").strip() or str(folder).strip().lower() == "none":
            variables[key] = "none"
        else:
            variables[key] = str(folder)

    if has_story or (stopped and not has_short):
        store("story_folder")
    if has_short or (stopped and not has_story):
        store("short_folder")
    for source, target in (("title", "post_title"), ("description", "post_description")):
        if fields.get(source) and not fields.get(target):
            fields[target] = fields[source]
    for key in ("post_title", "post_description", "title", "description", "youtube_video", "story_video", "video"):
        if fields.get(key):
            variables[key] = fields[key]
    if "story_folder" in variables and (has_story or (stopped and not has_short)):
        print(f"RETURN story_folder={variables['story_folder']}", flush=True)
    if "short_folder" in variables and (has_short or (stopped and not has_story)):
        print(f"RETURN short_folder={variables['short_folder']}", flush=True)


def run_cua(
    ctx: dict[str, Any],
    *,
    action: str,
    app: str = "",
    url: str = "",
    label: str = "",
    text: str = "",
    var: str = "",
) -> dict[str, Any]:
    """Launch an app, click a label, or type into a field."""
    from .cua import perform
    from .terminal import expand_command

    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}

    def expand(value: str) -> str:
        return expand_command(value, env, variables) if value else ""

    action_text = expand(action)
    app_text = expand(app)
    url_text = expand(url)
    label_text = expand(label)
    typed = expand(text)
    inputs = {"action": action_text, "app": app_text, "url": url_text, "label": label_text, "text": typed}
    if ctx.get("dry_run"):
        from .cua import _action_text, cua_target

        target = cua_target(env)
        where = "local" if target["mode"] == "local" else f"space {target['space'] or target['url']}"
        shown = _action_text(action_text, app_text, url_text, label_text, typed)
        print(f"DRY-RUN CUA {shown} [{where}]")
        found = {"status": "proposed", **inputs}
        outputs: dict[str, Any] = {"status": "proposed", "cua": found}
        result: dict[str, Any] = {"inputs": inputs, "outputs": outputs}
        if var:
            result["variables"] = {var: found}
            outputs[var] = found
        return result
    try:
        found = perform(action_text, app=app_text, url=url_text, label=label_text, text=typed, env=env)
    except Exception as exc:
        print(f"BLOCKED {exc}", flush=True)
        outputs = {"status": "blocked", "message": str(exc)}
        shots = [str(item) for item in (getattr(exc, "screenshots", None) or []) if item]
        if shots:
            outputs["screenshots"] = shots
        return {
            "inputs": inputs,
            "outputs": outputs,
            "blocked": True,
        }
    from .trace import detail

    detail(f"CUA {found.get('text') or action_text}")
    outputs = {"status": "ok", "cua": found}
    shots = [str(item) for item in (found.get("screenshots") or []) if item]
    if shots:
        outputs["screenshots"] = shots
    result = {"inputs": inputs, "outputs": outputs}
    if var:
        result["variables"] = {var: found}
        outputs[var] = found
    return result


def run_clef(
    ctx: dict[str, Any],
    *,
    question: str,
    options: list[str] | None = None,
    verify: str = "",
    image: str = "",
    var: str = "",
) -> dict[str, Any]:
    """Ask Clef about an image, and fail when `+verify` does not match.

    With no `+image`, or with `+image /browser`, the image is the open page.
    `+image /cua` is the window from the last `/cua` step.
    `+image $shot` or `+image /path/shot.jpg` reads that file.
    """
    from .clef import ask_clef, expected_answer, is_browser_image, is_cua_image, same_answer
    from .terminal import expand_command

    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}
    choices = [expand_command(str(item), env, variables) for item in (options or [])]
    task = expand_command(question, env, variables).strip()
    expected = expand_command(verify, env, variables).strip()
    if expected:
        expected = expected_answer(expected, choices)
    source = (image or "").strip()
    name = var or "answer"
    inputs = {"question": task, "options": choices, "verify": expected, "image": source or "/browser", "var": var}
    if ctx.get("dry_run"):
        shown = task
        if choices:
            shown += " +options " + ",".join(choices)
        if source:
            shown += f" +image {source}"
        if expected:
            shown += f" +verify {expected}"
        print(f"DRY-RUN CLEF {shown}")
        return {
            "inputs": inputs,
            "outputs": {"status": "proposed", name: "", "verify": expected},
            "variables": {name: ""} if var else {},
        }
    if is_cua_image(source):
        loaded = _clef_cua_image(ctx)
    elif is_browser_image(source):
        loaded = _clef_browser_image(ctx)
    else:
        loaded = _clef_file_image(ctx, source, env, variables)
    if loaded is None:
        message = str(ctx.pop("_clef_error", "") or "clef image failed")
        return {
            "inputs": inputs,
            "outputs": {"status": "blocked", "message": message},
            "blocked": True,
        }
    image_bytes, logged, state = loaded
    from .trace import detail

    label = task if not expected else f"{task} +verify {expected}"
    detail(f"CLEF {label}")
    try:
        value, probability = ask_clef(
            task,
            choices,
            image_bytes,
            state=state,
            env=env,
        )
    except Exception as exc:
        print(f"BLOCKED {exc}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {
                "status": "blocked",
                "message": str(exc),
                "screenshots": [str(logged)],
            },
            "blocked": True,
        }
    outputs: dict[str, Any] = {
        name: value,
        "status": "ok",
        "probability": probability,
        "screenshots": [str(logged)],
    }
    detail(f"CLEF {value}")
    if expected and not same_answer(value, expected):
        message = f"clef verify failed: got {value!r}, expected {expected!r}"
        print(f"BLOCKED {message}", flush=True)
        outputs["status"] = "blocked"
        outputs["message"] = message
        outputs["verify"] = expected
        result = {"inputs": inputs, "outputs": outputs, "blocked": True}
        if var:
            result["variables"] = {name: value}
        return result
    result = {"inputs": inputs, "outputs": outputs}
    if var:
        result["variables"] = {name: value}
    return result


def run_hug(
    ctx: dict[str, Any],
    *,
    model: str,
    message: str,
    files: list[str] | None = None,
    out: str = "",
    var: str = "",
    printed: bool = False,
    extra: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Ask one Hugging Face model. The model comes from `+model` or `hug-model`.

    Text models take `+m`. Image models take `+files`. A generate model takes
    `+m` and writes the image to `+out`. `into $var` stores that path. A missing
    required param fails before the weights load. A `+param` the definition does
    not list is kept.
    """
    from pathlib import Path

    from .hug import (
        ask_hug,
        check_params,
        hug_download_enabled,
        load_prompt,
        resolve_generate_output,
        runtime_spec,
        resolve_hug_file,
        resolve_model,
    )
    from .terminal import expand_command

    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}
    model_id = resolve_model(expand_command(model, env, variables), env)
    written = expand_command(message, env, variables).strip()
    out_text = expand_command(out, env, variables).strip()
    prompt = written
    prompt_file = ""
    destination = ""
    try:
        paths = [resolve_hug_file(str(item), env, variables) for item in (files or [])]
        prompt, prompt_file = load_prompt(
            written, base=_workflow_dir(ctx), env=env, variables=variables
        )
        spec = runtime_spec(model_id)
        dynamic = {
            key: expand_command(str(value), env, variables)
            for key, value in (extra or {}).items()
        }
        check_params(spec, message=prompt, files=paths, out=out_text, extra=dynamic)
        if spec.kind == "generate":
            destination = resolve_generate_output(
                out_text,
                prompt=prompt,
                folder=_output_folder(ctx),
                base=_workflow_dir(ctx),
            )
    except (ValueError, FileNotFoundError) as exc:
        print(f"BLOCKED {exc}", flush=True)
        return {
            "inputs": {
                "model": model_id,
                "message": prompt,
                "prompt_file": prompt_file,
                "files": list(files or []),
                "out": out_text,
                "var": var,
            },
            "outputs": {"status": "blocked", "message": str(exc), "model": model_id},
            "blocked": True,
        }
    name = var or "value"
    inputs = {
        "model": model_id,
        "message": prompt,
        "prompt_file": prompt_file,
        "files": paths,
        "out": destination or out_text,
        "var": var,
        "print": printed,
    }
    if ctx.get("dry_run"):
        shown = model_id
        if prompt_file:
            shown += f" +m {prompt_file}"
        elif prompt:
            shown += f" +m {prompt}"
        if paths:
            shown += " +files " + " ".join(paths)
        if destination:
            shown += f" +out {destination}"
        if printed:
            shown += " +print"
        print(f"DRY-RUN HUG {shown}")
        return {
            "inputs": inputs,
            "outputs": {"status": "proposed", "model": model_id, name: ""},
            "variables": {var: ""} if var else {},
        }
    missing = [path for path in paths if not Path(path).expanduser().is_file()]
    if missing:
        message_text = f"hug file not found: {missing[0]}"
        print(f"BLOCKED {message_text}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {"status": "blocked", "message": message_text, "model": model_id},
            "blocked": True,
        }
    from .trace import detail

    detail(f"HUG {model_id}")
    try:
        hug_kwargs: dict[str, Any] = {}
        if dynamic:
            hug_kwargs["extra"] = dynamic
        text = ask_hug(
            model_id,
            prompt,
            [str(Path(path).expanduser()) for path in paths],
            out=destination,
            download=hug_download_enabled(env),
            **hug_kwargs,
        )
    except Exception as exc:
        print(f"BLOCKED {exc}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {"status": "blocked", "message": str(exc), "model": model_id},
            "blocked": True,
        }
    outputs: dict[str, Any] = {"status": "ok", "model": model_id, "text": text, "hug": text, name: text}
    result: dict[str, Any] = {"inputs": inputs, "outputs": outputs}
    if var:
        result["variables"] = {var: text}
    return result


def _output_folder(ctx: dict[str, Any]) -> Path:
    """Where a generate model writes when the step omits `+out`."""
    raw = str(ctx.get("data") or "").strip()
    if raw:
        return Path(raw).expanduser()
    base = _workflow_dir(ctx)
    if base is not None:
        return base
    return Path.cwd()


def _workflow_dir(ctx: dict[str, Any]) -> Path | None:
    """The folder of the workflow file. A relative `+m` path is read from there."""
    raw = str(ctx.get("workflow_path") or "").strip()
    if not raw:
        return None
    path = Path(raw).expanduser()
    if path.is_dir():
        return path
    return path.parent


def _clef_cua_image(ctx: dict[str, Any]) -> tuple[bytes, str, str] | None:
    """Screenshot the window the last `/cua` step left open."""
    from .cua import open_driver

    try:
        driver = open_driver(ctx.get("env"))
        if int(getattr(driver, "last_pid", 0) or 0) and int(getattr(driver, "last_window_id", 0) or 0):
            state = driver.get_window_state()
        else:
            window = driver.target_window("")
            state = driver.get_window_state(pid=window["pid"], window_id=window["window_id"])
        path = Path(str(getattr(state, "image", "") or ""))
        if not path.is_file():
            raise FileNotFoundError(f"clef window shot not found: {path}")
        data = path.read_bytes()
    except Exception as exc:
        print(f"BLOCKED {exc}", flush=True)
        ctx["_clef_error"] = str(exc)
        return None
    logged = _clef_log_bytes(ctx, data, path)
    app = str(getattr(driver, "last_app", "") or "").strip()
    shown = f"The attached image is the {app} window." if app else "The attached image is the open application window."
    return data, str(logged), shown


def _clef_browser_image(ctx: dict[str, Any]) -> tuple[bytes, str, str] | None:
    """Screenshot the page the browser tool has open."""
    browser = ctx.get("browser")
    page = getattr(browser, "page", None) if browser is not None else None
    if page is None or not hasattr(page, "screenshot"):
        message = f"clef needs an open page ({ctx.get('cdp_url') or 'no cdp-url'})"
        print(f"BLOCKED {message}", flush=True)
        ctx["_clef_error"] = message
        return None
    shot = _clef_shot_path(ctx)
    data = page.screenshot(type="jpeg", quality=80)
    shot.write_bytes(data)
    logged = _gemma_log_shot(ctx, shot)
    page_url = str(getattr(page, "url", "") or "")
    state = "The attached image is the open browser page."
    if page_url:
        state = f"The attached image is the open browser page at {page_url}."
    return data, str(logged), state


def _clef_file_image(
    ctx: dict[str, Any],
    source: str,
    env: dict[str, Any],
    variables: dict[str, Any],
) -> tuple[bytes, str, str] | None:
    """Read the file named by `+image`."""
    from .clef import resolve_image_path

    try:
        path = Path(resolve_image_path(source, env, variables)).expanduser()
    except FileNotFoundError as exc:
        print(f"BLOCKED {exc}", flush=True)
        ctx["_clef_error"] = str(exc)
        return None
    if not path.is_file():
        message = f"clef image not found: {path}"
        print(f"BLOCKED {message}", flush=True)
        ctx["_clef_error"] = message
        return None
    data = path.read_bytes()
    logged = _clef_log_bytes(ctx, data, path)
    return data, str(logged), f"The attached image is the file {path}."


def _clef_log_bytes(ctx: dict[str, Any], data: bytes, source: Path) -> Path:
    """Keep a copy beside the step JSON. The original file stays where it is."""
    raw = str((ctx.get("env") or {}).get("CG_LOOP_STEP_JSON") or "").strip()
    if not raw:
        return source
    dest = Path(raw).expanduser().with_suffix(".jpg")
    if dest.resolve() == source.resolve():
        return source
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return dest


def _clef_shot_path(ctx: dict[str, Any]) -> Path:
    import tempfile

    data = str(ctx.get("data") or "").strip()
    folder = Path(data).expanduser() if data else Path(tempfile.mkdtemp(prefix="cg-clef-"))
    folder.mkdir(parents=True, exist_ok=True)
    return folder / f"clef-{time.time_ns()}.jpg"


def run_locate(ctx: dict[str, Any], *, query: str, image: str, var: str) -> dict[str, Any]:
    """Locate `query` in `image` and store the pixel position in `var`."""
    from .locate import locate_image
    from .terminal import expand_command

    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}
    query_text = expand_command(query, env, variables)
    image_text = expand_command(image, env, variables)
    name = var or "loc"
    inputs = {"query": query_text, "image": image_text, "var": name}
    if ctx.get("dry_run"):
        print(f"DRY-RUN LOCATE {query_text} {image_text}")
        found = {"status": "proposed", "query": query_text, "image": image_text, "text": ""}
        return {"inputs": inputs, "outputs": {name: found, "status": "proposed"}, "variables": {name: found}}
    path = Path(image_text).expanduser()
    if not path.is_file():
        message = f"locate image not found: {path}"
        print(f"BLOCKED {message}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {"status": "blocked", "message": message},
            "blocked": True,
        }
    try:
        found = locate_image(query_text, str(path), env)
    except Exception as exc:
        print(f"BLOCKED {exc}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {"status": "blocked", "message": str(exc)},
            "blocked": True,
        }
    if not found.get("box"):
        message = f"no position for {query_text!r}"
        raw = str(found.get("raw") or "").strip()
        if raw:
            message = f"{message}: {raw}"
        print(f"BLOCKED {message}", flush=True)
        return {
            "inputs": inputs,
            "outputs": {name: found, "status": "blocked", "message": message},
            "variables": {name: found},
            "blocked": True,
        }
    print(f"LOCATE {query_text} -> {found.get('text')}", flush=True)
    outputs: dict[str, Any] = {name: found, "status": "ok"}
    marked = str(found.get("marked") or "")
    if marked:
        outputs["screenshots"] = [marked]
    return {
        "inputs": inputs,
        "outputs": outputs,
        "variables": {name: found},
    }


def run_term(ctx: dict[str, Any], command: str) -> dict[str, Any]:
    from .step_cache import cache_env
    from .terminal import command_timeout, expand_command, run_command
    from .workflow import Step

    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}
    expanded = expand_command(command, env, variables)
    if ctx.get("dry_run"):
        print(f"DRY-RUN TERM {expanded}")
        result = {"status": "proposed", "command": expanded}
        return {
            "inputs": {"command": expanded},
            "outputs": result,
            "variables": {"last_command": result},
        }
    extra = cache_env(Step(kind="term", raw=""), variables, dict(ctx.get("env") or {}))
    article = variables.get("article")
    if isinstance(article, dict) and article.get("title"):
        extra.setdefault("TOPIC", str(article["title"]))
    result = run_command(
        expanded,
        timeout=command_timeout(ctx.get("timeout")),
        cwd=ctx.get("cwd") or None,
        env=extra,
    )
    saved: dict[str, Any] = {"last_command": result}
    if result.get("status") == "completed":
        keep_picked_story(saved, str(result.get("stdout") or ""))
    payload = {
        "inputs": {"command": expanded},
        "outputs": {
            "status": result.get("status"),
            "exit_code": result.get("exit_code"),
            "command": result.get("command") or expanded,
            "stdout": result.get("stdout") or "",
            "stderr": result.get("stderr") or "",
        },
        "variables": saved,
    }
    if result.get("status") not in {"completed", "proposed"}:
        payload["blocked"] = True
    return payload


def run_llm_call(
    ctx: dict[str, Any],
    *,
    template: str,
    var: str,
    extra: str,
) -> dict[str, Any]:
    from .agent import STORY_PROMPT, _template_prompt
    from .extract import format_article
    from . import model

    name = var or "article"
    article = (ctx.get("variables") or {}).get(name)
    source = format_article(article if isinstance(article, dict) else {"text": str(article or "")})
    workflow_path = Path(ctx.get("workflow_path") or "") if ctx.get("workflow_path") else None
    prompt = _template_prompt(template or "story.md", workflow_path) or STORY_PROMPT.format(article=source)
    if "{article}" in prompt:
        prompt = prompt.format(article=source)
    elif source and source not in prompt:
        prompt = prompt.rstrip() + "\n\nArticle:\n" + source
    template_name = template or "story.md"
    print(f"LLM_CALL {template_name}")
    run_dir = Path(ctx.get("run_dir") or ".")
    out = run_dir / Path(template_name).name
    if ctx.get("dry_run"):
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(f"(dry-run prompt)\n{prompt[:1000]}\n", encoding="utf-8")
    else:
        out.write_text(model.llm_write(prompt) + "\n", encoding="utf-8")
    return {
        "inputs": {"template": template_name, "var": name, "extra": extra},
        "outputs": {"path": str(out)},
        "variables": {"story_md": str(out), Path(template_name).stem: str(out)},
    }


def _idea_request(extra: str) -> bool:
    """A generate step that writes a new value, rather than remixing an article into a story."""
    return not (extra or "").lower().startswith("story")


def _sleep_brief(text: str) -> bool:
    return "sleep story" in (text or "").lower()


def _calendar_brief(text: str) -> bool:
    low = (text or "").lower()
    return any(token in low for token in ("today", "year", "current event", "history"))


def idea_prompt(
    extra: str,
    *,
    avoid: list[str] | None = None,
    today: Any = None,
) -> str:
    """One-line brief. The step text names the themes. Existing titles stay out."""
    from datetime import date

    brief = (extra or "").strip() or "one creative sleep story title"
    sleep = _sleep_brief(brief)
    lines = [
        "Write one sleep story title only." if sleep else "Write one idea only.",
        "One line. No label, no quotes, no list.",
        brief,
    ]
    head = brief.split("\n\nNews:", 1)[0]
    if not sleep and _calendar_brief(head):
        day = today or date.today()
        lines.append(f"Today is {day.strftime('%B')} {day.day}, {day.year}.")
    names: list[str] = []
    seen_names: set[str] = set()
    for item in avoid or []:
        name = str(item).strip()
        key = name.casefold()
        if not name or key in seen_names:
            continue
        seen_names.add(key)
        names.append(name)
    if names:
        lines.append("Do not repeat: " + "; ".join(names[:200]))
    return "\n".join(lines)


def _folder_titles(
    env: dict[str, Any],
    keys: tuple[str, ...],
    *,
    newest_first: bool = False,
) -> list[str]:
    titles: list[str] = []
    for key in keys:
        raw = env.get(key)
        if not raw:
            continue
        root = Path(str(raw))
        if not root.is_dir():
            continue
        children = [
            child
            for child in root.iterdir()
            if child.is_dir() and not child.name.startswith(".")
        ]
        if newest_first:
            children.sort(key=lambda child: child.stat().st_mtime, reverse=True)
        else:
            children.sort(key=lambda child: child.name)
        titles.extend(child.name.replace("-", " ") for child in children)
    return titles


def _existing_story_titles(env: dict[str, Any]) -> list[str]:
    return _folder_titles(env, ("DRAFT_STORIES", "APPROVED_STORIES"))


def _avoid_titles(env: dict[str, Any], brief: str) -> list[str]:
    if _sleep_brief(brief):
        return _existing_story_titles(env)
    return _folder_titles(env, ("DRAFT_ROOT", "APPROVED_ROOT"), newest_first=True)


def _idea_brief(extra: str, variables: dict[str, Any], output_var: str) -> str:
    """Fill `$news` and other inputs. An article becomes a News block the idea is written from."""
    from .extract import format_article
    from .terminal import _VAR_RE

    sources: list[str] = []

    def repl(match: re.Match[str]) -> str:
        name = match.group(1) or match.group(2)
        if name == output_var:
            return ""
        if name not in variables:
            return match.group(0)
        value = variables[name]
        if isinstance(value, dict) and (value.get("url") or value.get("title") or value.get("text")):
            sources.append(format_article(value)[:1500])
            return ""
        if isinstance(value, (list, tuple)):
            return ""
        return str(value)

    text = _VAR_RE.sub(repl, extra or "").strip()
    if sources:
        text = text.rstrip() + "\n\nNews:\n" + "\n\n".join(sources)
    return text


def _loaded_titles(extra: str, variables: dict[str, Any], output_var: str) -> list[str]:
    """Titles a load step stored, named by `$seen` or another list in the idea step."""
    from .terminal import _VAR_RE

    titles: list[str] = []
    for match in _VAR_RE.finditer(extra or ""):
        name = match.group(1) or match.group(2)
        if name == output_var or name not in variables:
            continue
        value = variables[name]
        if not isinstance(value, (list, tuple)):
            continue
        for item in value:
            text = str(item).strip()
            if text and not text.startswith("http"):
                titles.append(text)
    return titles


def _generate_idea(ctx: dict[str, Any], *, var: str, extra: str) -> dict[str, Any]:
    from . import model

    name = var or "idea"
    variables = ctx.get("variables") or {}
    prompt = _idea_brief(extra, variables, name)
    avoid = [*_loaded_titles(extra, variables, name), *_avoid_titles(ctx.get("env") or {}, prompt)]
    if ctx.get("dry_run"):
        text = "(dry-run idea)"
    else:
        written = model.llm_write(idea_prompt(prompt, avoid=avoid))
        text = written.strip().strip('"').splitlines()[0].strip()
        if not text:
            raise ValueError(f"generate produced no {name}")
    print(f"GENERATE ${name} {text}")
    return {
        "inputs": {"var": name, "extra": extra},
        "outputs": {name: text},
        "variables": {name: text},
    }


def run_generate(ctx: dict[str, Any], *, var: str, extra: str) -> dict[str, Any]:
    import shlex

    from .agent import REMIX_RUN, _output_folder

    if _idea_request(extra):
        return _generate_idea(ctx, var=var, extra=extra)
    name = var or "article"
    article = (ctx.get("variables") or {}).get(name) or {}
    if not isinstance(article, dict):
        article = {"text": str(article)}
    args = [str(REMIX_RUN)]
    if article.get("url"):
        args.append(str(article["url"]))
    elif article.get("text"):
        args.extend(["--text", str(article["text"])])
    elif ctx.get("dry_run"):
        print("DRY-RUN GENERATE (no article yet)")
        return {"inputs": {"var": name, "extra": extra}, "outputs": {"status": "dry-run"}}
    else:
        raise ValueError("generate story needs $article url or text")
    args.append("--story-only")
    command = " ".join(shlex.quote(part) for part in args)
    print(f"GENERATE {command}")
    result = run_term(ctx, command)
    status = ((result.get("variables") or {}).get("last_command") or {}).get("status")
    if status not in {"completed", "proposed"}:
        result["blocked"] = True
    else:
        stdout = ((result.get("variables") or {}).get("last_command") or {}).get("stdout") or ""
        story_dir = _output_folder(stdout)
        result.setdefault("variables", {})["story_dir"] = story_dir
        result.setdefault("outputs", {})["story_dir"] = story_dir
    result.setdefault("inputs", {})["extra"] = extra
    return result


def run_workflow_step(
    ctx: dict[str, Any],
    *,
    name: str,
    ref: str,
    params: dict[str, Any],
) -> dict[str, Any]:
    from .terminal import expand_command

    env = {**os.environ, **(ctx.get("env") or {})}
    variables = ctx.get("variables") or {}

    def expand(value: str) -> str:
        return expand_command(value, env, variables)

    expanded = {
        key: expand(value) if isinstance(value, str) else value for key, value in params.items()
    }
    return {
        "inputs": {
            "workflow": expand(name) if name else "",
            "ref": ref,
            "params": expanded,
        },
        "outputs": {"mode": "in-process"},
        "delegate": "workflow",
    }


def _example_log_dir(path: Path | None) -> Path:
    """Folder a compiled script can read to replay one run.

    A packet script reads `c-*-context.json` in its own step folder.
    """
    if path is None:
        return Path("logs")
    if is_packet_script(path):
        return path.parent
    steps = path.parent
    if steps.name != "steps" and steps.parent.name == "steps":
        steps = steps.parent
    if steps.name == "steps":
        group_dir = steps.parent
        compiled = group_dir.parent
        if compiled.name == "compiled":
            return compiled.parent / "logs" / group_dir.name
    if path.parent.name == "compiled":
        return path.parent.parent / "logs"
    return path.parent / "logs"


def _example_block(step: Step, path: Path | None, env: dict[str, str]) -> str:
    script = str(path or "STEP.py")
    names: list[str] = []
    for name in re.findall(r"\$(\w+)", step.raw or ""):
        if name == step.var or name in names:
            continue
        names.append(name)
    env_part = {name: env.get(name, "") for name in names if name in env}
    var_part = {name: "" for name in names if name not in env}
    sample: dict[str, Any] = {}
    if var_part:
        sample["variables"] = var_part
    if env_part:
        sample["env"] = env_part
    log_dir = str(_example_log_dir(path))
    lines = [
        "Example:",
        f"  python3 {script} {log_dir}",
        "  # reads c-*-context.json in this step folder and uses the record for this script",
        "",
        f"  python3 {script} step.json",
    ]
    if not sample:
        lines.append('  # step.json optional, e.g. {"dry_run": true}')
        return "\n".join(lines)
    lines.append("  # step.json:")
    lines.extend(f"  {line}" for line in json.dumps(sample, indent=2).splitlines())
    return "\n".join(lines)


def _standalone_args(argv: list[str], *, script: Path | None = None) -> tuple[dict[str, Any], bool]:
    dry_run = False
    source = ""
    for arg in argv:
        if arg == "--dry-run":
            dry_run = True
            continue
        if arg in {"-h", "--help"}:
            print("usage: python3 STEP.py [RUN_DIR|step.json] [--dry-run]", file=sys.stderr)
            raise SystemExit(0)
        if arg.startswith("-"):
            raise SystemExit(f"unknown option {arg}")
        if source:
            raise SystemExit("usage: python3 STEP.py [RUN_DIR|step.json] [--dry-run]")
        source = arg
    if not source:
        return {}, dry_run
    path = Path(source).expanduser()
    if path.is_dir():
        payload = payload_from_run(path, script or Path(sys.argv[0]))
        return payload, dry_run
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise SystemExit(f"step json must be an object: {path}")
    if _is_step_record(payload):
        payload = _payload_from_records([payload], payload)
    return payload, dry_run


def payload_from_run(run_dir: Path, script: Path) -> dict[str, Any]:
    """Build step inputs from a run folder by matching this compiled script."""
    folder = run_dir.expanduser()
    if folder.name == "steps":
        folder = folder.parent
    records = _read_step_records(folder)
    script_resolved = script.expanduser().resolve()
    matched = [record for record in records if _same_file(record.get("script"), script_resolved)]
    if not matched:
        known = ", ".join(str(record.get("step") or record.get("script") or "?") for record in records) or "(none)"
        raise SystemExit(f"no step in {folder} matches {script_resolved.name}; have: {known}")
    current = max(matched, key=lambda record: int(record.get("seq") or 0))
    print(
        f"using step {current.get('seq') or current.get('index')} {current.get('step')} from {folder}",
        file=sys.stderr,
    )
    return _payload_from_records(records, current, workflow=_workflow_config(folder))


_OUTPUT_META = frozenset({"status", "command", "exit_code", "stdout", "stderr", "mode"})


def _payload_from_records(
    records: list[dict[str, Any]],
    current: dict[str, Any],
    *,
    workflow: dict[str, Any] | None = None,
) -> dict[str, Any]:
    config = workflow or {}
    env: dict[str, str] = {}
    raw_env = config.get("env") or {}
    if isinstance(raw_env, dict):
        env.update({str(key): "" if value is None else str(value) for key, value in raw_env.items()})
    seq = int(current.get("seq") or 0)
    variables: dict[str, Any] = {}
    ordered = sorted(records, key=lambda record: int(record.get("seq") or 0))
    for record in ordered:
        record_seq = int(record.get("seq") or 0)
        if seq and record_seq > seq:
            continue
        _apply_roots(env, record.get("inputs") or {})
        if record is current or (seq and record_seq == seq):
            continue
        outputs = record.get("outputs") or {}
        if isinstance(outputs, dict):
            for key, value in outputs.items():
                if key not in _OUTPUT_META:
                    variables[key] = value
    payload: dict[str, Any] = {}
    if env:
        payload["env"] = env
    if variables:
        payload["variables"] = variables
    cdp = str(config.get("cdp-url") or config.get("cdp_url") or "")
    if cdp:
        payload["cdp_url"] = cdp
    return payload


def _apply_roots(env: dict[str, str], inputs: Any) -> None:
    if not isinstance(inputs, dict):
        return
    roots = inputs.get("roots")
    if not isinstance(roots, dict):
        return
    for key, value in roots.items():
        env[str(key).lstrip("$")] = "" if value is None else str(value)


def _read_step_records(run_dir: Path) -> list[dict[str, Any]]:
    paths = _step_record_paths(run_dir)
    if not paths:
        raise SystemExit(f"run folder has no step records: {run_dir}")
    records: list[dict[str, Any]] = []
    for path in paths:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            records.append(payload)
    records.sort(key=lambda record: int(record.get("seq") or 0))
    return records


def _step_record_paths(run_dir: Path) -> list[Path]:
    """Legacy `steps/*.json`, or `c-*-context.json` in a step folder and its sibling steps."""
    paths: list[Path] = []
    steps_dir = run_dir / "steps"
    if steps_dir.is_dir():
        paths.extend(steps_dir.glob("*.json"))
        paths.extend(steps_dir.glob("*/*.json"))
    paths.extend(_context_jsons(run_dir, nested=False))
    if not paths:
        paths.extend(_context_jsons(run_dir, nested=True))
    return paths


def _context_jsons(run_dir: Path, *, nested: bool) -> list[Path]:
    """Run records. `c-NN-context.json` is current; `c_NN-context.json` is the older name."""
    patterns = ("*/c-*-context.json", "*/c_*-context.json") if nested else ("c-*-context.json", "c_*-context.json")
    found: list[Path] = []
    for pattern in patterns:
        for path in run_dir.glob(pattern):
            if not path.is_file():
                continue
            if nested and ("archived" in path.parts or "archive" in path.parts):
                continue
            found.append(path)
    return found


def _run_log_file(run_dir: Path) -> Path | None:
    for candidate in (
        run_dir / "c-run.log",
        run_dir / "run.log",
        run_dir.parent / "c-run.log",
        run_dir.parent / "run.log",
    ):
        if candidate.is_file():
            return candidate
    return None


def _workflow_config(run_dir: Path) -> dict[str, Any]:
    log = _run_log_file(run_dir)
    if log is None:
        return {}
    workflow_path = ""
    for line in log.read_text(encoding="utf-8").splitlines():
        if line.startswith("# workflow: "):
            workflow_path = line.split(": ", 1)[1].strip()
            break
    path = Path(workflow_path) if workflow_path and workflow_path != "-" else None
    if path is None or not path.is_file():
        return {}
    import yaml

    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    config = data.get("config") if isinstance(data, dict) else {}
    return config if isinstance(config, dict) else {}


def _is_step_record(payload: dict[str, Any]) -> bool:
    return "inputs" in payload and ("script" in payload or "step" in payload) and "variables" not in payload


def _same_file(recorded: Any, script: Path) -> bool:
    text = str(recorded or "").strip()
    if not text:
        return False
    candidate = Path(text).expanduser()
    try:
        return candidate.resolve() == script
    except OSError:
        return candidate.name == script.name


def _call_expr(step: Step) -> str:
    if step.kind == "load":
        return (
            f"run_load(ctx, filter_text={step.extra!r}, var={step.var!r}, roots={step.roots!r})"
        )
    if step.kind == "goto":
        target = _goto_target(step) or step.url
        if _waits_for_document(step):
            return f"run_goto(ctx, {target!r}, wait_until='load')"
        return f"run_goto(ctx, {target!r})"
    if step.kind == "reuse_tab":
        return f"run_reuse_tab(ctx, {step.extra!r})"
    if step.kind == "browser_js":
        return f"run_browser_js(ctx, {step.extra!r}, {step.var!r})"
    if step.kind == "browser_gemma":
        return f"run_browser_gemma(ctx, {step.command!r}, {step.extra!r}, {step.var!r})"
    if step.kind == "openrouter":
        return f"run_openrouter(ctx, {step.command!r}, {step.extra!r}, {step.var!r})"
    if step.kind == "extract":
        return f"run_extract(ctx, phrase={step.extra!r}, var={step.var!r})"
    if step.kind == "term":
        return f"run_term(ctx, {step.command!r})"
    if step.kind == "llm_call":
        return (
            f"run_llm_call(ctx, template={step.template!r}, var={step.var!r}, extra={step.extra!r})"
        )
    if step.kind == "generate":
        return f"run_generate(ctx, var={step.var!r}, extra={step.extra!r})"
    if step.kind == "locate":
        return f"run_locate(ctx, query={step.extra!r}, image={step.command!r}, var={step.var!r})"
    if step.kind == "clef":
        options = list(step.params.get("options") or [])
        verify = str(step.params.get("verify") or "")
        image = str(step.params.get("image") or "")
        return (
            "run_clef(ctx, "
            f"question={step.extra!r}, options={options!r}, verify={verify!r}, "
            f"image={image!r}, var={step.var!r})"
        )
    if step.kind == "hug":
        files = list(step.params.get("files") or [])
        out = str(step.params.get("out") or "")
        extra = {
            key: value
            for key, value in step.params.items()
            if key not in {"files", "out", "print"}
        }
        return (
            "run_hug(ctx, "
            f"model={step.command!r}, message={step.extra!r}, "
            f"files={files!r}, out={out!r}, var={step.var!r}, "
            f"printed={bool(step.params.get('print'))!r}, extra={extra!r})"
        )
    if step.kind == "cua":
        return (
            "run_cua(ctx, "
            f"action={step.extra!r}, app={str(step.params.get('app') or '')!r}, "
            f"url={step.url!r}, label={str(step.params.get('label') or '')!r}, "
            f"text={str(step.params.get('text') or '')!r}, var={step.var!r})"
        )
    if step.kind == "workflow":
        return (
            "run_workflow_step(ctx, "
            f"name={step.workflow_name!r}, ref={step.workflow_ref!r}, params={step.params!r})"
        )
    raise ValueError(f"cannot compile step kind {step.kind!r}")


def _runner_name(kind: str) -> str:
    return {
        "load": "run_load",
        "goto": "run_goto",
        "reuse_tab": "run_reuse_tab",
        "browser_js": "run_browser_js",
        "browser_gemma": "run_browser_gemma",
        "openrouter": "run_openrouter",
        "extract": "run_extract",
        "term": "run_term",
        "llm_call": "run_llm_call",
        "generate": "run_generate",
        "locate": "run_locate",
        "clef": "run_clef",
        "cua": "run_cua",
        "hug": "run_hug",
        "workflow": "run_workflow_step",
    }[kind]


def _slug(value: str) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "_" for ch in (value or "").strip())
    return text.strip("_") or "step"
