"""Find a named thing in an image with LocateAnything.

`/locate close button, 'shot.jpg' into $loc` stores the pixel position in `$loc`
and writes `shot.locate.jpg` with a box around the match.
Coordinates come back from the model on a 0–1000 grid and are projected onto
the image. `$loc` prints as `x,y box=x1,y1,x2,y2` plus the marked image path.

The model id is `tool-details` `locate.model`. `LOCATE_MODEL` replaces it.
Jobs keep the weights in the shared local-models process. The first locate
loads them there. A later run uses them when they are already loaded.
Without that process, weights load in ~/.cache/cg-loop/venv-mlx and stay loaded.
`openrouter/<vendor>/<name>` sends the image to that OpenRouter vision model
instead. The reply must contain one `<box><xmin><ymin><xmax><ymax></box>`
on a 0–1000 grid.
"""

from __future__ import annotations

import fcntl
import json
import os
import re
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

SKILL_ROOT = Path(__file__).resolve().parents[2]
# tool-details locate.model replaces this when a workflow sets LOCATE_MODEL.
MODEL_ID = "andai-labs/LocateAnything-3B-MLX"
_BOX_RE = re.compile(
    r"<box>\s*<(\d+)>\s*<(\d+)>\s*<(\d+)>\s*<(\d+)>\s*</box>",
    re.IGNORECASE,
)
_MODEL: tuple[Any, Any] | None = None
_IN_SERVER = False
_DAEMON_READY = False
_PING_TIMEOUT = 2.0
_LOCATE_TIMEOUT = 600.0


def locate_prompt(query: str) -> str:
    """The sentence LocateAnything expects, such as `Locate the close button.`"""
    text = (query or "").strip().rstrip(".")
    if not text:
        raise ValueError("locate needs something to find")
    if text.lower().startswith("locate "):
        return text + "."
    return f"Locate the {text}."


def parse_boxes(raw: str) -> list[tuple[int, int, int, int]]:
    """`<box><xmin><ymin><xmax><ymax></box>` values, each 0–1000.

    This checkpoint puts x first. Reading the numbers as y-first lands beside the control.
    """
    found: list[tuple[int, int, int, int]] = []
    for match in _BOX_RE.finditer(raw or ""):
        xmin, ymin, xmax, ymax = (int(group) for group in match.groups())
        found.append((xmin, ymin, xmax, ymax))
    return found


def project_box(
    xmin: int,
    ymin: int,
    xmax: int,
    ymax: int,
    *,
    width: int,
    height: int,
) -> dict[str, int]:
    """Map a 0–1000 box onto pixel edges and its center."""
    x1 = int(xmin * width / 1000)
    y1 = int(ymin * height / 1000)
    x2 = int(xmax * width / 1000)
    y2 = int(ymax * height / 1000)
    return {
        "x1": x1,
        "y1": y1,
        "x2": x2,
        "y2": y2,
        "x": (x1 + x2) // 2,
        "y": (y1 + y2) // 2,
    }


def marked_path(image: str | Path) -> Path:
    """`shot.jpg` becomes `shot.locate.jpg` beside the original."""
    path = Path(image)
    return path.with_name(f"{path.stem}.locate.jpg")


def mark_image(image: str | Path, boxes: list[dict[str, int]]) -> str:
    """Draw every box on a copy of `image` and return that file."""
    from PIL import Image, ImageDraw

    source = Path(image)
    picture = Image.open(source).convert("RGB")
    draw = ImageDraw.Draw(picture)
    width, height = picture.size
    stroke = max(4, min(width, height) // 150)
    for box in boxes:
        x1 = int(box["x1"])
        y1 = int(box["y1"])
        x2 = max(int(box["x2"]), x1 + 1)
        y2 = max(int(box["y2"]), y1 + 1)
        draw.rectangle([x1, y1, x2, y2], outline=(255, 40, 40), width=stroke)
    out = marked_path(source)
    picture.save(out, quality=95)
    return str(out)


def position_from_output(
    raw: str,
    *,
    width: int,
    height: int,
    query: str,
    image: str,
) -> dict[str, Any]:
    """Turn model text into the value stored in the workflow variable."""
    boxes = [
        project_box(*norm, width=width, height=height) for norm in parse_boxes(raw)
    ]
    primary = boxes[0] if boxes else None
    text = ""
    if primary:
        text = (
            f"{primary['x']},{primary['y']} "
            f"box={primary['x1']},{primary['y1']},{primary['x2']},{primary['y2']}"
        )
        if len(boxes) > 1:
            text += f" (+{len(boxes) - 1} more)"
    return {
        "query": query,
        "image": image,
        "width": width,
        "height": height,
        "x": None if primary is None else primary["x"],
        "y": None if primary is None else primary["y"],
        "box": None
        if primary is None
        else {"x1": primary["x1"], "y1": primary["y1"], "x2": primary["x2"], "y2": primary["y2"]},
        "boxes": boxes,
        "raw": raw,
        "text": text,
    }


def locate_image(query: str, image: str, env: dict[str, Any] | None = None) -> dict[str, Any]:
    """Locate `query` in `image`. Raises FileNotFoundError when the file is missing.

    A local model id loads the weights in the shared models process the first
    time a job asks. Later jobs reuse that process. `CG_LOOP_RESIDENT` off
    keeps the older locate process. `openrouter/<vendor>/<name>` asks that
    model over OpenRouter.
    """
    path = Path(image).expanduser()
    if not path.is_file():
        raise FileNotFoundError(f"locate image not found: {path}")
    if _IN_SERVER:
        return _locate_local(query, path)
    merged = _merged_env(env)
    from .gemma import openrouter_checkpoint

    checkpoint = openrouter_checkpoint((merged.get("LOCATE_MODEL") or MODEL_ID).strip())
    if checkpoint:
        return _locate_openrouter(query, path, checkpoint, merged)
    from .resident import announce, call, serving, use_resident

    if serving():
        return _locate_local(query, path)
    if use_resident():
        payload = call("locate", {"query": query, "image": str(path)})
        model_id = (merged.get("LOCATE_MODEL") or MODEL_ID).strip() or MODEL_ID
        announce(payload, model_id)
        found = payload.get("result")
        if not isinstance(found, dict):
            raise RuntimeError("locate returned no result")
        return found
    return _locate_via_daemon(query, path)


def _merged_env(env: dict[str, Any] | None) -> dict[str, str]:
    merged = dict(os.environ)
    if env:
        merged.update({str(key): "" if value is None else str(value) for key, value in env.items()})
    return merged


def _locate_openrouter(query: str, path: Path, checkpoint: str, env: dict[str, str]) -> dict[str, Any]:
    """Ask an OpenRouter vision model for one 0–1000 box."""
    from PIL import Image

    from .gemma import chat_completion, openrouter_url

    print(f"LOCATE openrouter {checkpoint}", flush=True)
    prompt = (
        f"{locate_prompt(query)} "
        "Answer with one box only, x first, on a 0 to 1000 grid, as "
        "<box><xmin><ymin><xmax><ymax></box>."
    )
    raw = chat_completion(
        openrouter_url(env),
        checkpoint,
        prompt,
        path.read_bytes(),
        env=env,
        provider="openrouter",
    )
    with Image.open(path) as picture:
        width, height = picture.size
    found = position_from_output(raw, width=width, height=height, query=query, image=str(path))
    if found.get("boxes"):
        marked = mark_image(path, found["boxes"])
        found["marked"] = marked
        found["text"] = f"{found['text']} {marked}".strip()
    return found


def locate_python() -> Path:
    """Interpreter that has mlx-vlm. This process is used when it already does."""
    override = (os.environ.get("LOCATE_PYTHON") or os.environ.get("CG_LOOP_LOCATE_PYTHON") or "").strip()
    if override:
        return Path(override).expanduser()
    for folder in (SKILL_ROOT / "venv-mlx", Path.home() / ".cache" / "cg-loop" / "venv-mlx"):
        for name in ("python3", "python"):
            candidate = folder / "bin" / name
            if candidate.is_file():
                return candidate
    raise RuntimeError(
        "LocateAnything needs mlx-vlm on Python 3.10 or newer. "
        "Install it with python3.12 -m venv ~/.cache/cg-loop/venv-mlx "
        "&& ~/.cache/cg-loop/venv-mlx/bin/pip install mlx-vlm pillow, "
        "or set LOCATE_PYTHON."
    )


def _runtime_dir() -> Path:
    override = (os.environ.get("CG_LOOP_LOCATE_DIR") or "").strip()
    if override:
        return Path(override).expanduser()
    return Path.home() / ".cache" / "cg-loop"


def _socket_path() -> Path:
    return _runtime_dir() / "locate.sock"


def _pid_path() -> Path:
    return _runtime_dir() / "locate.pid"


def _patch_projector_names() -> None:
    """The MLX conversion names the projector mlp1_0/1/3. mlx-vlm expects layer_norm and linear_*."""
    from mlx_vlm.models.locateanything.locateanything import Model

    if getattr(Model, "_cg_locate_patched", False):
        return
    original = Model.sanitize
    renamed_prefix = (
        ("multi_modal_projector.mlp1_0.", "multi_modal_projector.layer_norm."),
        ("multi_modal_projector.mlp1_1.", "multi_modal_projector.linear_1."),
        ("multi_modal_projector.mlp1_3.", "multi_modal_projector.linear_2."),
    )

    def sanitize(self: Any, weights: dict[str, Any]) -> dict[str, Any]:
        renamed: dict[str, Any] = {}
        for key, value in weights.items():
            for old, new in renamed_prefix:
                if key.startswith(old):
                    key = new + key[len(old) :]
                    break
            renamed[key] = value
        return original(self, renamed)

    Model.sanitize = sanitize  # type: ignore[method-assign]
    Model._cg_locate_patched = True


def _model() -> tuple[Any, Any]:
    global _MODEL
    if _MODEL is None:
        from mlx_vlm import load

        _patch_projector_names()
        model_id = (os.environ.get("LOCATE_MODEL") or MODEL_ID).strip()
        print(f"LOCATE load {model_id}", file=sys.stderr, flush=True)
        _MODEL = load(model_id, trust_remote_code=True)
    return _MODEL


def _format_prompt(processor: Any, prompt: str) -> str:
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image"},
                {"type": "text", "text": prompt},
            ],
        }
    ]
    apply = getattr(processor, "apply_chat_template", None)
    if apply is None:
        raise RuntimeError("LocateAnything processor has no chat template")
    return apply(messages, tokenize=False, add_generation_prompt=True)


def _response_text(response: Any) -> str:
    if isinstance(response, str):
        return response
    text = getattr(response, "text", None)
    if isinstance(text, str):
        return text
    if isinstance(response, (tuple, list)) and response:
        return _response_text(response[0])
    return str(response)


def _generate(model: Any, processor: Any, prompt: str, image: str) -> str:
    from mlx_vlm import generate

    try:
        response = generate(model, processor, prompt, image=image, max_tokens=200, verbose=False)
    except TypeError:
        response = generate(model, processor, prompt, image, max_tokens=200)
    return _response_text(response)


def _locate_local(query: str, path: Path) -> dict[str, Any]:
    from PIL import Image

    model, processor = _model()
    with Image.open(path) as image:
        width, height = image.size
    formatted = _format_prompt(processor, locate_prompt(query))
    raw = _generate(model, processor, formatted, str(path))
    found = position_from_output(raw, width=width, height=height, query=query, image=str(path))
    if found.get("boxes"):
        marked = mark_image(path, found["boxes"])
        found["marked"] = marked
        found["text"] = f"{found['text']} {marked}".strip()
    return found


def _locate_via_daemon(query: str, path: Path) -> dict[str, Any]:
    started = _ensure_daemon()
    if started:
        model_id = (os.environ.get("LOCATE_MODEL") or MODEL_ID).strip()
        print(f"LOCATE load {model_id}", file=sys.stderr, flush=True)
    payload = _rpc({"query": query, "image": str(path)}, timeout=_LOCATE_TIMEOUT)
    if payload.get("error"):
        raise RuntimeError(str(payload["error"]))
    return payload


def _ensure_daemon() -> bool:
    """Start the model process on first use. A live process is left running."""
    global _DAEMON_READY
    if _DAEMON_READY and _pid_alive():
        return False
    if _ping() is not None:
        _DAEMON_READY = True
        return False
    if _pid_alive():
        _DAEMON_READY = True
        return False
    with _daemon_lock():
        if _ping() is not None or _pid_alive():
            _DAEMON_READY = True
            return False
        _spawn()
        if not _wait_ping(30):
            raise RuntimeError("locate model did not start")
        _DAEMON_READY = True
        return True


def _spawn() -> None:
    python = locate_python()
    script = Path(__file__).resolve()
    runtime = _runtime_dir()
    runtime.mkdir(parents=True, exist_ok=True)
    sock = _socket_path()
    if sock.exists():
        sock.unlink()
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["CG_LOOP_LOCATE_DIR"] = str(runtime)
    log = open(runtime / "locate.log", "ab", buffering=0)
    # Run the file directly. Importing the cg_loop package pulls in the agent,
    # and this interpreter only has mlx-vlm. The process outlives this run.
    subprocess.Popen(
        [str(python), str(script), "--serve"],
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=log,
        start_new_session=True,
        close_fds=True,
        env=env,
    )
    log.close()


def _wait_ping(seconds: float) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        if _ping() is not None:
            return True
        time.sleep(0.1)
    return False


def _ping() -> dict[str, Any] | None:
    try:
        payload = _rpc({"cmd": "ping"}, timeout=_PING_TIMEOUT)
    except OSError:
        return None
    if payload.get("ok"):
        return payload
    return None


def _pid_alive() -> bool:
    try:
        pid = int(_pid_path().read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _daemon_lock() -> Any:
    runtime = _runtime_dir()
    runtime.mkdir(parents=True, exist_ok=True)
    handle = open(runtime / "locate.lock", "a", encoding="utf-8")
    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
    return _Lock(handle)


class _Lock:
    def __init__(self, handle: Any) -> None:
        self._handle = handle

    def __enter__(self) -> "_Lock":
        return self

    def __exit__(self, *exc: object) -> None:
        fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
        self._handle.close()


def _rpc(message: dict[str, Any], *, timeout: float) -> dict[str, Any]:
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect(str(_socket_path()))
        sock.sendall((json.dumps(message) + "\n").encode("utf-8"))
        buf = b""
        while b"\n" not in buf:
            chunk = sock.recv(65536)
            if not chunk:
                break
            buf += chunk
    finally:
        sock.close()
    line = buf.decode("utf-8").strip()
    if not line.startswith("LOCATE_JSON "):
        raise RuntimeError(f"locate worker returned {line[:200]!r}")
    payload = json.loads(line[len("LOCATE_JSON ") :])
    if not isinstance(payload, dict):
        raise RuntimeError("locate worker returned a non-object")
    return payload


def _serve() -> None:
    """Answer locates on a socket. The model loads on the first request and stays."""
    global _IN_SERVER
    _IN_SERVER = True
    runtime = _runtime_dir()
    runtime.mkdir(parents=True, exist_ok=True)
    sock_path = _socket_path()
    if sock_path.exists():
        sock_path.unlink()
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(str(sock_path))
    server.listen(16)
    _pid_path().write_text(str(os.getpid()), encoding="utf-8")
    print(f"LOCATE serve {sock_path}", file=sys.stderr, flush=True)
    try:
        while True:
            conn, _addr = server.accept()
            with conn:
                raw = _read_line(conn)
                if not raw:
                    continue
                try:
                    request = json.loads(raw)
                except json.JSONDecodeError as exc:
                    _send(conn, {"error": f"locate request was not json: {exc}"})
                    continue
                if not isinstance(request, dict):
                    _send(conn, {"error": "locate request was not an object"})
                    continue
                if request.get("cmd") == "stop":
                    _send(conn, {"ok": True})
                    break
                if request.get("cmd") == "ping":
                    _send(conn, {"ok": True, "loaded": _MODEL is not None})
                    continue
                try:
                    query = str(request.get("query") or "")
                    image = str(request.get("image") or "")
                    _send(conn, _locate_local(query, Path(image)))
                except Exception as exc:
                    _send(conn, {"error": str(exc)})
    finally:
        _IN_SERVER = False
        server.close()
        sock_path.unlink(missing_ok=True)
        _pid_path().unlink(missing_ok=True)


def _read_line(conn: socket.socket) -> str:
    buf = b""
    while b"\n" not in buf:
        chunk = conn.recv(65536)
        if not chunk:
            break
        buf += chunk
        if len(buf) > 1_000_000:
            break
    return buf.split(b"\n", 1)[0].decode("utf-8").strip()


def _send(conn: socket.socket, payload: dict[str, Any]) -> None:
    conn.sendall(("LOCATE_JSON " + json.dumps(payload) + "\n").encode("utf-8"))


def main(argv: list[str] | None = None) -> None:
    args = list(sys.argv[1:] if argv is None else argv)
    if "--serve" in args:
        _serve()
        return
    if len(args) != 2:
        raise SystemExit("usage: python -m cg_loop.locate QUERY IMAGE")
    print(json.dumps(locate_image(args[0], args[1]), indent=2))


if __name__ == "__main__":
    main()
