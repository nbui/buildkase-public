"""Parse cg-loop workflow YAML into typed steps."""

from __future__ import annotations

import os
import re
import shlex
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

import yaml

from .quoting import finditer_outside, mask_quoted, search_outside, unquote_param

SKILL_ROOT = Path(__file__).resolve().parents[2]
# `$rootProject` and `.$rootProject`. The optional dot is the form used in a step path.
_ROOT_PROJECT_RE = re.compile(r"\.?\$\{rootProject\}|\.?\$rootProject\b")
_ROUTINE_SUFFIX = "_routine"
_ROUTINE_CONFIG_SUFFIX = "_routine_setup"
WORKFLOW_PATH_KEYS = ("WORKFLOW_PATH", "CG_LOOP_WORKFLOW_PATH")
YAML_SUFFIXES = {".yaml", ".yml"}
# Run output and tool trees are not workflow catalogs.
_SKIP_WORKFLOW_DIRS = {"cache", "node_modules", "venv", "__pycache__", ".git"}
CODE_STEP_TYPES = frozenset({"code", "python", "py", "shell", "sh", "bash", "script"})
PYTHON_TYPES = frozenset({"python", "py"})
_NORM_RE = re.compile(r"[^a-z0-9]+")
_TOOL_RE = re.compile(r"^/(?P<tool>[A-Za-z][\w-]*)(?:\s+(?P<body>[\s\S]+))?$")
# A term starts with `/`. An action param starts with `+`, as in `/browser +click subscribe box`.
# `+verify` on `/clef` or `/cua` is a flag. On `/browser` it is an action param.
# `+options` and `+image` stay flags.
_ACTION_PLUS_RE = re.compile(
    r"(?<!\S)\+(?P<action>sendkeys|reusetab|launch|extract|scroll|select|press|click|goto|open|type|wait|js|go)\b",
    re.IGNORECASE,
)
# +model and +verify on /python. Other plus signs stay in the task, as in `print 2 + 1`.
_PYTHON_FLAG_RE = re.compile(r"(?<!\S)\+(model|verify)\b", re.IGNORECASE)
_PYTHON_MODEL_KINDS = {
    "local": "local",
    "hug": "local",
    "openrouter": "openrouter",
    "open-router": "openrouter",
}
_RETURN_RE = re.compile(r"\breturn\s+(?:true|false)\b", re.IGNORECASE)
BROWSER_TOOL = "browser"
PYTHON_TOOL = "python"
TERM_TOOL = "term"
LOCATE_TOOL = "locate"
CUA_TOOL = "cua"
CLEF_TOOL = "clef"
HUG_TOOL = "hug"
LOOP_TOOLS = frozenset({BROWSER_TOOL, PYTHON_TOOL, TERM_TOOL, LOCATE_TOOL, CUA_TOOL, CLEF_TOOL, HUG_TOOL})
_LOCATE_RE = re.compile(
    r"^(?P<query>.+?)\s*,\s*(?P<image>'[^']*'|\"[^\"]*\"|\S+)\s+into\s+\$(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*$",
    re.IGNORECASE | re.DOTALL,
)
_JS_RE = re.compile(
    r"^js\s+(?P<code>[\s\S]+?)\s+in\s+\$(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*$",
    re.IGNORECASE,
)
_GEMMA_RE = re.compile(
    r"^/(?P<model>openrouter-\S+|lmstudio-\S+|local/\S+)\s+(?P<prompt>[\s\S]+)"
    r"\s+into\s+\$(?P<var>[A-Za-z_][A-Za-z0-9_]*)"
    r"(?:\s+print\s+\$(?P<shown>[A-Za-z_][A-Za-z0-9_]*))?\s*$",
    re.IGNORECASE,
)


@dataclass
class Step:
    kind: str
    raw: str
    url: str = ""
    var: str = ""
    template: str = ""
    command: str = ""
    extra: str = ""
    roots: list[str] = field(default_factory=list)
    params: dict[str, Any] = field(default_factory=dict)
    workflow_name: str = ""
    workflow_ref: str = ""
    tool: str = ""
    nested: Workflow | None = None
    auto: bool = False
    condition: str = ""
    checks: list[Step] = field(default_factory=list)
    steps: list[Step] = field(default_factory=list)
    line: int = 0
    end_line: int = 0

    def label(self) -> str:
        return self.raw.strip()


@dataclass(frozen=True)
class CompileOverride:
    """A workflow file's python or browser compile section. Unset fields keep the app default."""

    llm: str = ""
    model: str = ""
    timeout: float | None = None
    fallbacks: list[tuple[str, str, float | None]] | None = None


@dataclass
class Workflow:
    name: str
    profile: str = ""
    cdp_url: str = ""
    env: dict[str, str] = field(default_factory=dict)
    steps: list[Step] = field(default_factory=list)
    # Steps from config, or from <name>_routine_setup when that block sets steps.
    # They run before this routine's own steps.
    before: list[Step] = field(default_factory=list)
    # Five-field cron. Empty means this routine is not scheduled.
    scheduler: str = ""
    extras: list["Workflow"] = field(default_factory=list)
    path: Path | None = None
    goal: str = ""
    group: str = ""
    loop_count: int = 1
    loop_delay: float = 0.0
    log_keep: int = 5
    data_numbers: bool = True
    llm: str = ""
    model: str = ""
    browser_tool_model: str = ""
    llm_timeout: float = 30.0
    command_timeout: int = 0
    recompile: bool = False
    browser_recompile: bool = False
    browser_reusetab: str = ""
    config_locks: set[str] = field(default_factory=set)
    recompile_on_error: bool = False
    fallbacks: list[tuple[str, str, float | None]] = field(default_factory=list)
    python_compile: CompileOverride | None = None
    browser_compile: CompileOverride | None = None
    owns_loop: bool = False
    reference: str = ""
    catalog: dict[str, "Workflow"] = field(default_factory=dict)

    def plan_text(self) -> str:
        if self.goal and not self.steps and not self.before and not self.extras:
            return self.goal
        lines = [f"Workflow: {self.name}", f"group: {self.group}"]
        if self.scheduler:
            lines.append(f"scheduler: {self.scheduler}")
        for i, step in enumerate(runnable_steps(self), 1):
            lines.extend(_plan_step_lines(step, f"{i}", ""))
        for extra in self.extras:
            lines.append(f"+ {extra.group} ({extra.name})")
            if extra.scheduler:
                lines.append(f"  scheduler: {extra.scheduler}")
            for i, step in enumerate(runnable_steps(extra), 1):
                lines.extend(_plan_step_lines(step, f"{i}", "  "))
            for nested in extra.extras:
                lines.append(f"  + {nested.group} ({nested.name})")
        return "\n".join(lines)

    def all_steps(self) -> list[Step]:
        found: list[Step] = []
        for step in runnable_steps(self):
            found.extend(_step_tree(step))
        for extra in self.extras:
            found.extend(extra.all_steps())
        return found

    def named_groups(self) -> dict[str, "Workflow"]:
        groups: dict[str, "Workflow"] = {}
        if self.group:
            groups.setdefault(self.group, self)
            short = _routine_label(self.group)
            if short and short != self.group:
                groups.setdefault(short, self)
        for extra in self.extras:
            for key, group in extra.named_groups().items():
                groups.setdefault(key, group)
        return groups


def runnable_steps(workflow: Workflow) -> list[Step]:
    """Config steps first, then the routine's own steps."""
    return [*workflow.before, *workflow.steps]


def condition_reads_steps(text: str) -> bool:
    """True when the condition is decided from steps that already ran, not folder counts."""
    return bool(_RETURN_RE.search(text or ""))


def _plan_step_lines(step: Step, number: str, indent: str) -> list[str]:
    lines = [f"{indent}{number}. {step.raw}{' [auto]' if step.auto else ''}"]
    for j, check in enumerate(step.checks, 1):
        lines.extend(_plan_step_lines(check, f"{number}.c{j}", indent + "  "))
    for j, sub in enumerate(step.steps, 1):
        lines.extend(_plan_step_lines(sub, f"{number}.{j}", indent + "  "))
    if step.kind == "workflow" and step.nested:
        for j, nested_step in enumerate(step.nested.steps, 1):
            lines.extend(_plan_step_lines(nested_step, str(j), indent + "   "))
        for nested_extra in step.nested.extras:
            lines.append(f"{indent}   + {nested_extra.group} ({nested_extra.name})")
    return lines


def _step_tree(step: Step) -> list[Step]:
    found = [step]
    for sub in [*step.checks, *step.steps]:
        found.extend(_step_tree(sub))
    if step.nested:
        found.extend(step.nested.all_steps())
    return found


def _flatten_steps(steps: list[Step]) -> list[Step]:
    found: list[Step] = []
    for step in steps:
        found.append(step)
        if step.checks:
            found.extend(_flatten_steps(step.checks))
        if step.steps:
            found.extend(_flatten_steps(step.steps))
    return found


def parse_steps(raw: Any) -> list[Step]:
    """Parse one YAML item into the steps it runs. One item is one step."""
    return [parse_step(raw)]


def _parse_step_list(items: list[Any]) -> list[Step]:
    steps: list[Step] = []
    for item in items:
        steps.extend(parse_steps(item))
    return steps


def parse_step(raw: Any) -> Step:
    if isinstance(raw, dict):
        return _parse_mapping_step(raw)
    text = str(raw or "").strip()
    if not text:
        raise ValueError("empty workflow step")
    recognized = strip_action_plus(text)
    lowered_text = recognized.lower()
    clef = _parse_clef_step(recognized)
    if clef is not None:
        clef.raw = text
        return clef
    if lowered_text.startswith("/openrouter-") or lowered_text.startswith("/lmstudio-"):
        parsed = _parse_model_command(recognized)
        kind = "lmstudio" if lowered_text.startswith("/lmstudio-") else "openrouter"
        if parsed is None:
            raise ValueError(f"{kind} needs: /{kind}-<model> <instruction> into $<name>")
        model, prompt, var = parsed
        return Step(kind=kind, raw=text, extra=prompt, command=model, var=var, tool=kind)
    tool, body = _split_tool(recognized)
    python_model = ""
    python_verify = ""
    if tool == PYTHON_TOOL:
        body, python_model, python_verify = split_python_flags(body)
    if tool == LOCATE_TOOL:
        step = _parse_locate(body)
        step.tool = tool
        step.raw = text
        return step
    if tool == CUA_TOOL:
        step = _parse_cua(body)
        step.tool = tool
        step.raw = text
        return step
    if tool == HUG_TOOL:
        step = _parse_hug(body)
        step.tool = tool
        step.raw = text
        return step
    if tool == BROWSER_TOOL and (body.lower().startswith("js ") or body.lower() == "js"):
        generated = _parse_generated_js(body)
        if generated is not None:
            instruction, verify, seconds = generated
            return Step(
                kind="browser_js",
                raw=text,
                extra=instruction,
                command=instruction,
                tool=tool,
                params={"generate_js": True, "verify": verify, "verify_seconds": seconds},
            )
        source, var = _parse_browser_js(body)
        return Step(kind="browser_js", raw=text, extra=source, command=source, var=var, tool=tool)
    if tool == BROWSER_TOOL:
        gemma = _parse_browser_gemma(body)
        if gemma is not None:
            model, prompt, var = gemma
            return Step(kind="browser_gemma", raw=text, extra=prompt, command=model, var=var, tool=tool)
        if body.lower().startswith("/openrouter-"):
            raise ValueError(
                "openrouter needs: /browser /openrouter-<model> <instruction> into $<name>"
            )
    step = _parse_step_text(body)
    if tool == PYTHON_TOOL and step.kind == "extract":
        # `to $name` is an input on a python step, not a page extract.
        step = Step(kind="goal", raw=body, extra=body)
    if (
        tool == BROWSER_TOOL
        and step.kind == "extract"
        and not body.lower().startswith(("get ", "extract ", "save ", "read ", "fetch "))
    ):
        step = Step(kind="goal", raw=body, extra=body)
    if not tool:
        return step
    if tool not in LOOP_TOOLS:
        raise ValueError(f"unknown tool /{tool}")
    if tool != TERM_TOOL and step.kind in {"term", "code"}:
        raise ValueError(f"/{tool} cannot run a shell step: {text}")
    step.tool = tool
    step.raw = text
    if tool == PYTHON_TOOL and (python_model or python_verify):
        llm_name, model_id = python_model_ref(python_model) if python_model else ("", "")
        step.params = {
            **step.params,
            "model": python_model,
            "llm": llm_name,
            "compile_model": model_id,
            "verify": python_verify,
        }
    return step


def _parse_clef_step(text: str) -> Step | None:
    """`/clef`, `/browser /clef`, or `/cua /clef`, with `+options`, `+image`, and `+verify`.

    `/cua <question> +verify yes` is the same check. The `/clef` word can be left off
    when the step carries `+verify`, `+options`, or `+image`.
    """
    from .clef import BROWSER_IMAGE, CUA_IMAGE, parse_clef_command

    lowered = text.lower()
    prefix = ""
    if lowered.startswith("/clef"):
        body = text.split(None, 1)[1].strip() if " " in text else ""
        prefix = "clef"
    elif lowered.startswith("/browser") or lowered.startswith("/cua"):
        rest = text.split(None, 1)[1].strip() if " " in text else ""
        prefix = "browser" if lowered.startswith("/browser") else "cua"
        if rest.lower().startswith("/clef"):
            body = rest.split(None, 1)[1].strip() if " " in rest else ""
        elif _clef_flags_without_verb(rest, prefix):
            body = rest
        else:
            return None
    else:
        return None
    question, options, verify, image, var = parse_clef_command(body)
    if not image and prefix == "browser":
        image = BROWSER_IMAGE
    if not image and prefix == "cua":
        image = CUA_IMAGE
    return Step(
        kind="clef",
        raw=text,
        extra=question,
        var=var,
        tool=CLEF_TOOL,
        params={"options": options, "verify": verify, "image": image},
    )


_CUA_ACTION_VERBS = frozenset({"launch", "open", "click", "type", "sendkeys", "wait"})
# `/browser +verify <phrase>` is a page check. `/browser <question> +verify yes` stays Clef.
_BROWSER_ACTION_VERBS = _CUA_ACTION_VERBS | frozenset(
    {"reusetab", "extract", "scroll", "select", "press", "goto", "js", "go", "verify"}
)


def _clef_flags_without_verb(body: str, tool: str = "") -> bool:
    """A question plus `+verify`, `+options`, or `+image`, and not a tool action.

    A browser step that starts with `+click`, `+go`, `+wait`, or `+verify` stays on
    the browser tool. Clef still owns `/cua <question> +verify yes`.
    """
    if search_outside(re.compile(r"(?:^|\s)\+(?:options|verify|image)\b", re.IGNORECASE), body or "") is None:
        return False
    tokens = _cua_tokens(body)
    if not tokens:
        return False
    first = tokens[0]
    name = first.lower().lstrip("+")
    if tool == "browser" and (first.startswith("+") or name in _BROWSER_ACTION_VERBS):
        return False
    return name not in _CUA_ACTION_VERBS


def strip_action_plus(text: str) -> str:
    """Drop `+` on an action param. `/browser +click subscribe box` reads as `click subscribe box`.

    The action name is lowercase. `+options` and `+image` stay, because those are
    flags on a Clef question. `+verify` stays here too: Clef reads it as a flag,
    and the browser helper drops it when the step is a page check.
    """
    raw = text or ""
    masked = mask_quoted(raw)
    matches = list(_ACTION_PLUS_RE.finditer(masked))
    for match in reversed(matches):
        raw = raw[: match.start()] + match.group("action").lower() + raw[match.end() :]
    return raw


def _parse_hug(body: str) -> Step:
    """`/hug +model <id> +m <prompt> +files <path> +out <path> into $var`."""
    from .hug import parse_hug_command

    call = parse_hug_command(body)
    return Step(
        kind="hug",
        raw="",
        extra=call.message,
        command=call.model,
        var=call.var,
        params={"files": list(call.files), "out": call.out, "print": call.printed, **(call.extra or {})},
    )


def step_body(step: Step) -> str:
    """Step text without a leading `/browser`, `/python`, `/term`, `/locate`, `/clef`, `/hug`, or `/cua` prefix."""
    raw = (step.raw or "").strip()
    if step.tool and raw.lower().startswith(f"/{step.tool}"):
        return raw.split(None, 1)[1].strip() if " " in raw else ""
    return raw


def split_python_flags(body: str) -> tuple[str, str, str]:
    """Pull `+model` and `+verify` off a `/python` task. Other plus signs stay.

    `print 2 + 1` and `print "something" + today` keep the plus. `+model` is
    `local/<id>` or `openrouter/<id>`. `+verify` is text the printed result
    must contain. A quoted `+model` stays in the task.
    """
    raw = body or ""
    matches = finditer_outside(_PYTHON_FLAG_RE, raw)
    if not matches:
        return raw.strip(), "", ""
    model = ""
    verify = ""
    seen_verify = False
    spans: list[tuple[int, int]] = []
    for index, match in enumerate(matches):
        name = match.group(1).lower()
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(raw)
        value = unquote_param(raw[start:end].strip())
        spans.append((match.start(), end))
        if name == "model":
            if model:
                raise ValueError("python +model is repeated")
            if not value:
                raise ValueError("python +model needs local/<model> or openrouter/<model>")
            model = value
        else:
            if seen_verify:
                raise ValueError("python +verify is repeated")
            seen_verify = True
            if not value:
                raise ValueError("python +verify needs the text to find")
            verify = value
    kept: list[str] = []
    cursor = 0
    for start, end in spans:
        kept.append(raw[cursor:start])
        cursor = end
    kept.append(raw[cursor:])
    instruction = " ".join("".join(kept).split())
    if not instruction:
        raise ValueError("python needs a task before +model or +verify")
    if model:
        python_model_ref(model)
    return instruction, model, verify


def python_model_ref(token: str) -> tuple[str, str]:
    """`local/<id>` or `openrouter/<id>`. The id itself may contain slashes."""
    text = (token or "").strip()
    prefix, sep, rest = text.partition("/")
    kind = _PYTHON_MODEL_KINDS.get(prefix.strip().lower())
    model_id = rest.strip()
    if not sep or kind is None or not model_id:
        raise ValueError(f"python +model needs local/<model> or openrouter/<model>: {text}")
    return kind, model_id


def python_sentence(step: Step) -> str:
    """The `/python` task. `+model` and `+verify` are not part of it."""
    if step.tool != "python" or not (step.params.get("model") or step.params.get("verify")):
        return step.raw or ""
    extra = (step.extra or "").strip()
    if not extra:
        return "/python"
    if extra.lower().startswith("/python"):
        return extra
    return f"/python {extra}"


def python_body(step: Step) -> str:
    """`python_sentence` without the `/python` prefix."""
    sentence = python_sentence(step)
    if sentence.lower().startswith("/python"):
        return sentence.split(None, 1)[1].strip() if " " in sentence else ""
    return sentence


def python_step_slot(step: Step) -> CompileOverride | None:
    """The `+model` on this step. None keeps the workflow or app python section."""
    if not str(step.params.get("model") or "").strip():
        return None
    return CompileOverride(
        llm=str(step.params.get("llm") or "").strip(),
        model=str(step.params.get("compile_model") or "").strip(),
    )


def _split_tool(text: str) -> tuple[str, str]:
    match = _TOOL_RE.match(text)
    if not match:
        return "", text
    return match.group("tool").lower(), (match.group("body") or "").strip()


def _split_config_pairs(body: str) -> list[str]:
    """Split `KEY=VALUE, KEY2=VALUE2`. A comma inside quotes stays in the value."""
    parts: list[str] = []
    buf: list[str] = []
    quote = ""
    for ch in body:
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = ""
            continue
        if ch in {"'", '"'}:
            quote = ch
            buf.append(ch)
            continue
        if ch == ",":
            parts.append("".join(buf).strip())
            buf.clear()
            continue
        buf.append(ch)
    if quote:
        raise ValueError(f"set_config has an unclosed quote: {body}")
    parts.append("".join(buf).strip())
    if parts and parts[-1] == "":
        parts.pop()
    if not parts or any(not part for part in parts):
        raise ValueError(f"set_config needs KEY=VALUE: {body}")
    return parts


def config_alias_key(key: str) -> str:
    """A config field written with a hyphen, such as `cdp-url`.

    Identifier names stay environment variables. `cdp-url` is the same field
    `--param cdp-url=` sets.
    """
    text = (key or "").strip()
    if not text or re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", text):
        return ""
    if text in CONFIG_ALIASES:
        return text
    swapped = text.replace("_", "-")
    if swapped in CONFIG_ALIASES:
        return swapped
    return ""


def _normalize_set_config_key(key: str, source: str) -> str:
    alias = config_alias_key(key)
    if alias:
        return alias
    text = key.strip()
    if not text or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", text):
        raise ValueError(f"set_config key must be a name: {source}")
    return text.upper()


def _parse_one_config_pair(body: str, source: str) -> tuple[str, str]:
    if "=" not in body:
        raise ValueError(f"set_config needs KEY=VALUE: {source}")
    key, _, value = body.partition("=")
    key = key.strip()
    value = value.strip()
    value = unquote_param(value)
    return _normalize_set_config_key(key, source), value


def parse_set_config_items(text: str) -> list[tuple[str, str]]:
    """Parse one or more `KEY=VALUE` pairs.

    Commas separate pairs. A comma inside quotes stays in the value.
    `set_config A=1, B=2` and `A=1, B=2` both yield two pairs.
    """
    body = (text or "").strip()
    lower = body.lower()
    if lower.startswith("set_config ") or lower.startswith("set-config "):
        body = body.split(None, 1)[1].strip()
    return [_parse_one_config_pair(part, text) for part in _split_config_pairs(body)]


def parse_set_config_item(text: str) -> tuple[str, str]:
    """Parse one `set_config KEY=VALUE` or `KEY=VALUE`. The value is everything after the first `=`."""
    pairs = parse_set_config_items(text)
    if len(pairs) != 1:
        raise ValueError(f"set_config needs one KEY=VALUE: {text}")
    return pairs[0]


def _config_value_text(value: str) -> str:
    """Write a value so a later `parse_step` reads the same text.

    A comma separates config pairs. A quote mark starts a quoted value.
    Either one in the text is wrapped so it stays part of this value.
    """
    if any(ch in value for ch in ",\"'\\"):
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    return value


def set_config_pairs(step: Step) -> list[tuple[str, str]]:
    """Every KEY=VALUE on a `set_config` step. One YAML line can set several."""
    raw_items = step.params.get("items") if step.kind == "set_config" else None
    if isinstance(raw_items, list) and raw_items:
        pairs: list[tuple[str, str]] = []
        for item in raw_items:
            if isinstance(item, (list, tuple)) and len(item) >= 2:
                pairs.append((str(item[0]), str(item[1])))
        if pairs:
            return pairs
    if step.kind == "set_config" and step.var:
        return [(step.var, step.extra)]
    return []


def _set_config_step(key: str, value: str) -> Step:
    return _set_config_pairs_step([(key, value)])


def _set_config_pairs_step(pairs: list[tuple[str, str]]) -> Step:
    shown = ", ".join(f"{key}={_config_value_text(value)}" for key, value in pairs)
    key, value = pairs[0]
    params: dict[str, Any] = {}
    if len(pairs) > 1:
        params["items"] = [[item_key, item_value] for item_key, item_value in pairs]
    return Step(
        kind="set_config",
        raw=f"set_config {shown}",
        var=key,
        extra=value,
        command=value,
        params=params,
    )


def _store_set_config_pairs(step: Step, pairs: list[tuple[str, str]]) -> None:
    """Write resolved values back onto a step. The printed line stays as parsed."""
    if not pairs:
        return
    step.var, step.extra = pairs[0]
    step.command = pairs[0][1]
    if len(pairs) > 1 or "items" in step.params:
        step.params["items"] = [[key, value] for key, value in pairs]


_CUA_INTO_RE = re.compile(r"\s+into\s+\$(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*$", re.IGNORECASE)
_CUA_USAGE = (
    'cua needs: /cua +launch <app> [url], /cua +click "<label>", '
    '/cua +type "<text>" into "<label>", /cua +sendkeys clear then "<text>", '
    "/cua +wait <duration>, or /cua /clef <question>"
)
_CUA_WAIT_AMOUNT = re.compile(
    r"^(?P<num>\d+(?:\.\d+)?)\s*(?P<unit>s|sec|secs|second|seconds)$",
    re.IGNORECASE,
)


def _cua_wait_seconds(text: str) -> float | None:
    """`10s` or `10 seconds`. Anything else is not a timed pause."""
    match = _CUA_WAIT_AMOUNT.match((text or "").strip())
    if not match:
        return None
    return float(match.group("num"))


def _parse_cua(body: str) -> Step:
    """`/cua +launch`, `/cua +click`, `/cua +type`, `/cua +sendkeys`, `/cua +wait`, or a sentence Laya turns into those actions."""
    text = (body or "").strip()
    var = ""
    into = search_outside(_CUA_INTO_RE, text)
    if into:
        var = into.group("var")
        text = text[: into.start()].strip()
    tokens = _cua_tokens(text)
    if not tokens:
        raise ValueError(_CUA_USAGE)
    verb = tokens[0].lower()
    if _cua_sentence(text):
        return Step(
            kind="goal",
            raw="",
            extra=text,
            command=text,
            params={"action": "command"},
            var=var,
        )
    if verb in {"launch", "open"}:
        rest = tokens[1:]
        if rest and rest[-1].lower().startswith(("http://", "https://")):
            url = rest[-1]
            app_tokens = rest[:-1]
        else:
            url = ""
            app_tokens = rest
        app = " ".join(app_tokens).strip()
        if not app:
            raise ValueError("cua launch needs an app name")
        return Step(
            kind="cua",
            raw="",
            extra="launch",
            command=app,
            url=url,
            var=var,
            params={"action": "launch", "app": app, "url": url, "label": ""},
        )
    if verb == "click":
        rest = tokens[1:]
        if rest and rest[0].lower() == "on":
            rest = rest[1:]
        app = ""
        if "in" in [token.lower() for token in rest]:
            at = [token.lower() for token in rest].index("in")
            app = " ".join(rest[at + 1 :]).strip()
            rest = rest[:at]
        label = " ".join(rest).strip()
        if not label:
            raise ValueError('cua click needs a label: /cua +click "<label>"')
        return Step(
            kind="cua",
            raw="",
            extra="click",
            command=label,
            url="",
            var=var,
            params={"action": "click", "app": app, "url": "", "label": label, "text": ""},
        )
    if verb == "type":
        rest = tokens[1:]
        lowers = [token.lower() for token in rest]
        app = ""
        label = ""
        if "into" in lowers:
            at = lowers.index("into")
            typed = rest[:at]
            label_tokens = rest[at + 1 :]
            label_lowers = [token.lower() for token in label_tokens]
            if "in" in label_lowers:
                app_at = label_lowers.index("in")
                app = " ".join(label_tokens[app_at + 1 :]).strip()
                label_tokens = label_tokens[:app_at]
            label = " ".join(label_tokens).strip()
        else:
            typed = rest
        typed_text = " ".join(typed).strip()
        if not typed_text:
            raise ValueError('cua type needs text: /cua +type "<text>" into "<label>"')
        return Step(
            kind="cua",
            raw="",
            extra="type",
            command=typed_text,
            url="",
            var=var,
            params={"action": "type", "app": app, "url": "", "label": label, "text": typed_text},
        )
    if verb == "sendkeys":
        rest = tokens[1:]
        clear = False
        if rest and rest[0].lower() == "clear":
            clear = True
            rest = rest[1:]
            if rest and rest[0].lower() == "then":
                rest = rest[1:]
        typed_text = " ".join(rest).strip()
        if not clear and not typed_text:
            raise ValueError('cua sendkeys needs clear, text, or clear then "<text>"')
        return Step(
            kind="cua",
            raw="",
            extra="sendkeys",
            command=typed_text,
            url="",
            var=var,
            params={
                "action": "sendkeys",
                "app": "",
                "url": "",
                "label": "clear" if clear else "",
                "text": typed_text,
            },
        )
    if verb == "wait":
        duration = " ".join(tokens[1:]).strip()
        seconds = _cua_wait_seconds(duration)
        if seconds is None:
            raise ValueError('cua wait needs a duration: /cua +wait 10s')
        return Step(
            kind="cua",
            raw="",
            extra="wait",
            command=duration,
            url="",
            var=var,
            params={"action": "wait", "app": "", "url": "", "label": "", "text": duration, "seconds": seconds},
        )
    raise ValueError(_CUA_USAGE)


def _cua_sentence(text: str) -> bool:
    """A command with more than one action. Laya plans it. A single launch or click does not."""
    lower = (text or "").lower()
    if " and " in lower or "," in text:
        return True
    verbs = re.findall(r"\b(launch|open|click|type|press)\b", lower)
    return len(verbs) > 1


def _cua_tokens(text: str) -> list[str]:
    """Words outside quotes, and each quoted string with its escapes applied."""
    raw = text or ""
    found: list[str] = []
    index = 0
    while index < len(raw):
        if raw[index].isspace():
            index += 1
            continue
        if raw[index] in {'"', "'"} and (index == 0 or raw[index - 1].isspace()):
            value, index = _read_cua_quoted(raw, index)
            found.append(value)
            continue
        start = index
        while index < len(raw) and not raw[index].isspace():
            if raw[index] == "\\" and index + 1 < len(raw):
                index += 2
                continue
            index += 1
        found.append(unquote_param(raw[start:index]))
    return found


def _read_cua_quoted(text: str, start: int) -> tuple[str, int]:
    quote = text[start]
    index = start + 1
    buf: list[str] = []
    while index < len(text):
        char = text[index]
        if char == "\\" and index + 1 < len(text):
            buf.append(text[index + 1])
            index += 2
            continue
        if char == quote:
            return "".join(buf), index + 1
        buf.append(char)
        index += 1
    raise ValueError("unclosed quote")


def _parse_locate(body: str) -> Step:
    """`/locate close button, 'shot.jpg' into $loc`."""
    text = (body or "").strip()
    match = _LOCATE_RE.match(mask_quoted(text))
    if not match:
        raise ValueError("locate needs: /locate <what>, '<image>' into $<name>")
    query = unquote_param(text[match.start("query") : match.end("query")])
    image = unquote_param(text[match.start("image") : match.end("image")])
    if not query or not image:
        raise ValueError("locate needs a description and an image path")
    return Step(kind="locate", raw="", extra=query, command=image, var=match.group("var"))


def _parse_set_config(text: str) -> Step:
    """One step, including `set_config A=1, B=2`. Every pair is applied when it runs."""
    return _set_config_pairs_step(parse_set_config_items(text))


def _parse_step_text(text: str) -> Step:
    if not text:
        raise ValueError("empty workflow step")
    lower = text.lower()

    if lower.startswith("workflow "):
        name = text.split(None, 1)[1].strip()
        return Step(kind="workflow", raw=text, extra=name, workflow_name=name)

    if lower == "reusetab" or lower.startswith("reusetab "):
        parts = text.split()
        site = parts[1] if len(parts) > 1 else ""
        if not site:
            raise ValueError(f"reuseTab needs a site: {text}")
        return Step(kind="reuse_tab", raw=text, extra=site)

    if lower.startswith("goto ") or lower.startswith("open "):
        url = text.split(None, 1)[1].strip()
        return Step(kind="goto", raw=text, url=url)

    if lower.startswith("set_config ") or lower.startswith("set-config "):
        return _parse_set_config(text)

    if lower.startswith("term ") or lower.startswith("sh ") or lower.startswith("shell "):
        command = text.split(None, 1)[1].strip()
        return Step(kind="term", raw=text, command=command)

    if lower.startswith("llm-call ") or lower.startswith("llm_call "):
        rest = text.split(None, 1)[1].strip()
        parts = rest.split()
        template = parts[0] if parts else ""
        extra = " ".join(parts[1:])
        var = _first_var(extra)
        return Step(kind="llm_call", raw=text, template=template, extra=extra, var=var)

    if lower.startswith("generate"):
        extra = text.split(None, 1)[1].strip() if " " in text else ""
        return Step(kind="generate", raw=text, extra=extra, var=_first_var(extra))

    load_match = _match_load(text)
    if load_match:
        extra, var, roots = load_match
        return Step(kind="load", raw=text, extra=extra, var=var, roots=roots)

    get_match = _match_extract(text)
    if get_match:
        phrase, var = get_match
        return Step(kind="extract", raw=text, extra=phrase, var=var)

    return Step(kind="goal", raw=text, extra=text)


def _parse_mapping_step(raw: dict[str, Any]) -> Step:
    if "condition" in raw or (set(raw) <= {"condition", "steps"} and "steps" in raw):
        return _parse_condition_step(raw)
    step_type = str(raw.get("type") or "").strip().lower()
    workflow_key = raw.get("workflow")
    has_workflow_fields = (
        step_type == "workflow"
        or workflow_key is not None
        or ("msg" in raw and "params" in raw)
    )
    if has_workflow_fields and step_type in {"", "workflow"}:
        if "msg" in raw:
            msg = raw.get("msg")
        else:
            msg = ""
        params = raw.get("params") or {}
        if params is None:
            params = {}
        if not isinstance(params, dict):
            raise ValueError(f"workflow params must be a mapping: {params!r}")
        unknown = set(raw) - {"msg", "type", "params", "workflow"}
        if unknown:
            raise ValueError(f"unknown workflow step keys: {sorted(unknown)}")
        name = str(msg or "").strip()
        ref = str(workflow_key or "").strip()
        label_parts = ["workflow"]
        if ref:
            label_parts.append(ref)
        if name:
            label_parts.append(name)
        return Step(
            kind="workflow",
            raw=" ".join(label_parts),
            extra=name or ref,
            workflow_name=name,
            workflow_ref=ref,
            params=dict(params),
        )
    if step_type in CODE_STEP_TYPES:
        params = raw.get("params") or {}
        if params is None:
            params = {}
        if not isinstance(params, dict):
            raise ValueError(f"code step params must be a mapping: {params!r}")
        unknown = set(raw) - {"msg", "type", "params", "workflow"}
        if unknown:
            raise ValueError(f"unknown code step keys: {sorted(unknown)}")
        if "msg" in raw:
            msg = raw.get("msg")
        elif workflow_key is not None:
            msg = workflow_key
        else:
            msg = ""
        name = str(msg or "").strip()
        language = "python" if step_type in PYTHON_TYPES else "shell"
        label = f"{language} {name}".strip()
        return Step(
            kind="code",
            raw=label,
            extra=language,
            workflow_name=name,
            params=dict(params),
        )
    if step_type and step_type != "workflow":
        raise ValueError(f"unknown step type {step_type!r}")
    if len(raw) != 1:
        raise ValueError(f"step mapping must have one key: {raw!r}")
    kind, value = next(iter(raw.items()))
    return parse_step(f"{kind} {value}".strip())


def _split_condition(raw: Any) -> tuple[str, list[Any]]:
    """A condition is a sentence, or steps plus a final `return true` or `return false` line."""
    if isinstance(raw, list):
        items = [item for item in raw if not (isinstance(item, str) and not str(item).strip())]
        if not items:
            raise ValueError("condition list is empty")
        last = items[-1]
        if not isinstance(last, str) or not _RETURN_RE.search(last):
            raise ValueError(
                "a condition with steps must end with 'return true' or 'return false': "
                f"{last!r}"
            )
        return str(last).strip(), items[:-1]
    text = str(raw or "").strip()
    if "\n" not in text:
        return text, []
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) > 1 and _RETURN_RE.search(lines[-1]):
        return lines[-1], lines[:-1]
    return text, []


def _parse_condition_step(raw: dict[str, Any]) -> Step:
    unknown = set(raw) - {"condition", "steps"}
    if unknown:
        raise ValueError(f"unknown condition step keys: {sorted(unknown)}")
    condition, check_items = _split_condition(raw.get("condition"))
    checks = _parse_step_list(check_items)
    raw_steps = raw.get("steps")
    if not isinstance(raw_steps, list) or not raw_steps:
        raise ValueError(f"condition step needs a steps list: {condition or raw!r}")
    steps = _parse_step_list(raw_steps)
    label = f"condition: {condition}" if condition else "steps"
    return Step(
        kind="condition",
        raw=label,
        condition=condition,
        extra=condition,
        checks=checks,
        steps=steps,
    )


_JS_LOOKS_RE = re.compile(
    r"(=>|\bfunction\b|\bdocument\b|\blocation\b|\bwindow\b|\bquerySelector\b|\breturn\b|\bconst\b|\blet\b)"
)
_JS_VERIFY_RE = re.compile(
    r"^(?P<instruction>.*?)\s+\+?verify\s+(?P<phrase>.+?)(?:\s+max\s+(?P<seconds>\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?)?\s*$",
    re.IGNORECASE | re.DOTALL,
)


def _parse_generated_js(body: str) -> tuple[str, str, float] | None:
    """`/browser +js <instruction>` is generated. A JavaScript expression stays literal."""
    text = (body or "").strip()
    if _JS_RE.match(mask_quoted(text)):
        return None
    instruction = text[2:].strip() if text.lower().startswith("js") else ""
    verify = ""
    seconds = 5.0
    found = _JS_VERIFY_RE.match(instruction)
    if found and found.group("instruction").strip():
        instruction = found.group("instruction").strip()
        verify = found.group("phrase").strip().strip(".")
        raw_seconds = found.group("seconds")
        if raw_seconds:
            seconds = max(0.0, float(raw_seconds))
    if not instruction or _JS_LOOKS_RE.search(instruction):
        return None
    return instruction, verify, seconds


def _parse_browser_js(body: str) -> tuple[str, str]:
    """`/browser +js <expression> in $name` runs that JavaScript on the open page."""
    text = (body or "").strip()
    match = _JS_RE.match(mask_quoted(text))
    if not match or not text[match.start("code") : match.end("code")].strip():
        raise ValueError("browser js needs: /browser +js <javascript> in $<name>")
    code = unquote_param(text[match.start("code") : match.end("code")])
    return code, match.group("var")


def _parse_browser_gemma(body: str) -> tuple[str, str, str] | None:
    """`/browser /lmstudio-<model>`, `/browser /openrouter-<model>`, or `/browser /local/<model>` reads a screenshot.

    Other `/browser /...` lines stay browser goals. `/locate` is one of those.
    """
    return _parse_model_command(body)


def _parse_model_command(body: str) -> tuple[str, str, str] | None:
    """`/<model> <instruction> into $name`. The model id after the prefix keeps its case."""
    text = (body or "").strip()
    match = _GEMMA_RE.match(mask_quoted(text))
    if not match:
        return None
    prompt = unquote_param(text[match.start("prompt") : match.end("prompt")])
    if not prompt:
        raise ValueError("model command needs an instruction and into $<name>")
    return _model_slug(match.group("model")), prompt, match.group("var")


def _model_slug(model: str) -> str:
    from .gemma import model_id, openrouter_model

    if model.lower().startswith("lmstudio-"):
        slug = "lmstudio-" + model[len("lmstudio-") :]
        model_id(slug)
        return slug
    if model.lower().startswith("openrouter-"):
        slug = "openrouter-" + model[len("openrouter-") :]
        openrouter_model(slug)
        return slug
    if model.lower().startswith("local/"):
        name = model[len("local/") :].strip()
        if "/" not in name or name.startswith("/") or name.endswith("/") or any(char.isspace() for char in name):
            raise ValueError(f"local model needs vendor/name: /local/<model>, got /local/{name}")
        return "local/" + name
    return model.lower()


def _first_var(text: str) -> str:
    for token in text.split():
        if token.startswith("$") and len(token) > 1:
            return token[1:].strip(".,;:")
    return ""


def _match_extract(text: str) -> tuple[str, str] | None:
    lowered = text.strip()
    prefixes = ("get ", "extract ", "save ", "read ", "fetch ")
    if not lowered.lower().startswith(prefixes):
        if " to $" not in lowered.lower():
            return None
    if " to $" not in lowered.lower():
        return None
    head, _, tail = lowered.rpartition(" to $")
    var = tail.split()[0].strip(".,;:")
    phrase = head.split(None, 1)[1] if " " in head else head
    return phrase, var


def _match_load(text: str) -> tuple[str, str, list[str]] | None:
    lowered = text.strip()
    if not lowered.lower().startswith("load "):
        return None
    if " to $" not in lowered.lower() or " from " not in lowered.lower():
        return None
    to_at = lowered.lower().rfind(" to $")
    from_at = lowered.lower().find(" from ")
    if from_at < 0 or to_at < 0:
        return None
    if from_at < to_at:
        extra = lowered[5:from_at].strip()
        roots = lowered[from_at + 6 : to_at].split()
        var = lowered[to_at + 5 :].split()[0].strip(".,;:")
    else:
        extra = lowered[5:to_at].strip()
        after = lowered[to_at + 5 :]
        var, _, rest = after.partition(" from ")
        var = var.split()[0].strip(".,;:")
        roots = rest.split()
    extra = extra.removeprefix("load ").strip() if extra.lower().startswith("load ") else extra
    return extra, var, roots


def load_workflow(path: str | Path, *, _stack: tuple[Path, ...] = ()) -> Workflow:
    file_path = Path(path).expanduser().resolve()
    if file_path in _stack:
        cycle = " -> ".join(str(p) for p in _stack + (file_path,))
        raise ValueError(f"workflow cycle: {cycle}")
    payload = _load_yaml(file_path)
    if not isinstance(payload, dict):
        raise ValueError(f"workflow YAML must be a mapping: {file_path}")
    config = _with_app_defaults(payload.get("config") or {})
    env_raw = config.get("env") or {}
    env = _coerce_env(env_raw)
    profile = str(config.get("profile") or "")
    if profile and "PROFILE" not in env:
        env["PROFILE"] = profile
    env = _with_models(config, _with_lmstudio(config, _with_venv(config, env)))
    env.setdefault("rootProject", str(project_root()))
    stack = _stack + (file_path,)
    name = str(config.get("name") or file_path.stem)
    routine_configs = _routine_config_map(payload)
    groups = [
        _load_group(
            str(key),
            value,
            parent_path=file_path,
            config=config,
            env=env,
            stack=stack,
            routine_config=routine_configs.get(str(key)),
        )
        for key, value in payload.items()
        if _is_routine_key(str(key))
    ]
    if not groups:
        raise ValueError(f"workflow YAML needs a <name>_routine group: {file_path}")
    workflow = Workflow(
        name=name,
        profile=str(config.get("profile") or ""),
        cdp_url=str(config.get("cdp-url") or config.get("cdp_url") or ""),
        env=env,
        extras=groups,
        path=file_path,
        loop_count=_as_int(config.get("loop-count") or config.get("loop_count"), 1),
        loop_delay=_as_float(config.get("loop-delay") or config.get("loop_delay"), 0.0),
        log_keep=_as_int(config.get("log-keep") or config.get("log_keep"), 5),
        data_numbers=_data_numbers(config),
        llm=_llm_name(config),
        model=_model_name(config),
        browser_tool_model=_browser_tool_model(config),
        llm_timeout=_llm_timeout(config),
        command_timeout=_config_command_timeout(config),
        recompile=_as_bool(config.get("recompile")),
        browser_recompile=_as_bool(config.get("browser-recompile") or config.get("browser_recompile")),
        browser_reusetab=_browser_reuse_site(config),
        recompile_on_error=_as_bool(
            config.get("recompile-on-error") or config.get("recompile_on_error")
        ),
        fallbacks=_fallbacks(config),
        python_compile=_compile_override(config, "python"),
        browser_compile=_compile_override(config, "browser"),
        reference=_reference_script(config),
    )
    _bind_subworkflows(workflow, stack=stack)
    _install_set_config(workflow, _set_config_items(payload.get("set_config")))
    _resolve_workflow_paths(workflow)
    _annotate_workflow_lines(workflow, file_path)
    return workflow


class _UniqueKeyLoader(yaml.SafeLoader):
    """Safe YAML loader that rejects a mapping key written twice."""


def _construct_unique_mapping(loader: yaml.SafeLoader, node: yaml.Node) -> dict[Any, Any]:
    loader.flatten_mapping(node)
    mapping: dict[Any, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=True)
        if key in mapping:
            raise ValueError(f"duplicate key {key!r}")
        mapping[key] = loader.construct_object(value_node, deep=True)
    return mapping


_UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    _construct_unique_mapping,
)


def _load_yaml(path: Path) -> Any:
    try:
        payload = yaml.load(path.read_text(encoding="utf-8"), Loader=_UniqueKeyLoader)
    except ValueError as exc:
        raise ValueError(f"{path}: {exc}") from exc
    except yaml.YAMLError as exc:
        raise ValueError(f"{path}: {exc}") from exc
    return {} if payload is None else payload


def _annotate_workflow_lines(workflow: Workflow, path: Path) -> None:
    """Record the source lines of each step in this file.

    A group loaded from another file already has its own lines. A cursor on a
    line can then run that step alone.
    """
    try:
        loader = _UniqueKeyLoader(path.read_text(encoding="utf-8"))
        node = loader.get_single_node()
    except yaml.YAMLError as exc:
        raise ValueError(f"{path}: {exc}") from exc
    if not isinstance(node, yaml.MappingNode):
        return
    group_nodes = [
        value
        for key, value in node.value
        if isinstance(key, yaml.ScalarNode) and _is_routine_key(str(key.value))
    ]
    if len(group_nodes) != len(workflow.extras):
        raise ValueError(
            f"{path}: step line map has {len(group_nodes)} groups, loaded {len(workflow.extras)}"
        )
    source = path.resolve()
    setup_nodes = {
        str(key.value)[: -len("_setup")]: value
        for key, value in node.value
        if isinstance(key, yaml.ScalarNode) and _is_routine_config_key(str(key.value))
    }
    for value, group in zip(group_nodes, workflow.extras):
        if group.path is None or group.path.resolve() != source:
            continue
        _annotate_group_node(group, value, loader)
        _annotate_setup_steps(group, setup_nodes.get(group.group), loader)


def _annotate_group_node(group: Workflow, node: yaml.Node, loader: yaml.SafeLoader) -> None:
    if isinstance(node, yaml.ScalarNode):
        return
    if isinstance(node, yaml.SequenceNode):
        _annotate_step_list(group.steps, node, loader)
        return
    if not isinstance(node, yaml.MappingNode):
        return
    items = _node_map(node)
    if "auto" not in items and "steps" not in items:
        return
    raw_auto = items.get("auto")
    raw_steps = items.get("steps")
    if isinstance(raw_auto, yaml.ScalarNode):
        if isinstance(raw_steps, yaml.SequenceNode):
            _annotate_step_list(group.steps, raw_steps, loader)
        return
    compiled = [step for step in group.steps if not step.auto]
    auto_steps = [step for step in group.steps if step.auto]
    if isinstance(raw_auto, yaml.SequenceNode):
        if isinstance(raw_steps, yaml.SequenceNode):
            _annotate_step_list(compiled, raw_steps, loader)
        _annotate_step_list(auto_steps, raw_auto, loader)
        return
    if isinstance(raw_steps, yaml.SequenceNode):
        _annotate_step_list(group.steps, raw_steps, loader)


def _annotate_setup_steps(group: Workflow, node: yaml.Node | None, loader: yaml.SafeLoader) -> None:
    """Line numbers for `<routine>_routine_setup` steps. They run before the routine."""
    if not group.before or not isinstance(node, yaml.MappingNode):
        return
    raw_steps = _node_map(node).get("steps")
    if isinstance(raw_steps, yaml.SequenceNode):
        _annotate_step_list(group.before, raw_steps, loader)


def _annotate_step_list(steps: list[Step], node: yaml.SequenceNode, loader: yaml.SafeLoader) -> None:
    offset = 0
    for item in node.value:
        raw = loader.construct_object(item, deep=True)
        produced = parse_steps(raw)
        chunk = steps[offset : offset + len(produced)]
        if len(chunk) != len(produced):
            raise ValueError(f"step line map mismatch at line {item.start_mark.line + 1}")
        start, end = _node_span(item)
        for step in chunk:
            step.line = start
            step.end_line = end
        if len(produced) == 1:
            _annotate_step_children(chunk[0], item, loader)
        offset += len(produced)
    if offset != len(steps):
        raise ValueError(f"step line map left {len(steps) - offset} steps")


def _annotate_step_children(step: Step, node: yaml.Node, loader: yaml.SafeLoader) -> None:
    if isinstance(node, yaml.ScalarNode):
        if step.checks:
            _annotate_scalar_checks(step, node)
        return
    if not isinstance(node, yaml.MappingNode):
        return
    items = _node_map(node)
    condition = items.get("condition")
    nested = items.get("steps")
    if isinstance(condition, yaml.SequenceNode) and step.checks:
        check_nodes = condition.value[:-1]
        if len(check_nodes) != len(step.checks):
            raise ValueError(f"step line map mismatch at line {condition.start_mark.line + 1}")
        for check, check_node in zip(step.checks, check_nodes):
            check.line, check.end_line = _node_span(check_node)
            _annotate_step_children(check, check_node, loader)
    elif isinstance(condition, yaml.ScalarNode) and step.checks:
        _annotate_scalar_checks(step, condition)
    if isinstance(nested, yaml.SequenceNode) and step.steps:
        _annotate_step_list(step.steps, nested, loader)


def _annotate_scalar_checks(step: Step, node: yaml.ScalarNode) -> None:
    start = node.start_mark.line + 1
    if node.style in {"|", ">"}:
        start += 1
    for index, check in enumerate(step.checks):
        check.line = start + index
        check.end_line = check.line


def _node_map(node: yaml.MappingNode) -> dict[str, yaml.Node]:
    found: dict[str, yaml.Node] = {}
    for key, value in node.value:
        if isinstance(key, yaml.ScalarNode):
            found[str(key.value)] = value
    return found


def _node_span(node: yaml.Node) -> tuple[int, int]:
    """Inclusive 1-based lines. The end mark is the first position after the node."""
    start = node.start_mark.line + 1
    end_mark = node.end_mark
    if isinstance(node, yaml.ScalarNode) and end_mark.column != 0:
        end = end_mark.line + 1
    else:
        end = end_mark.line
    if end < start:
        end = start
    return start, end


def _skipped_workflow_dir(name: str) -> bool:
    return name in _SKIP_WORKFLOW_DIRS or name.startswith(".")


def workflow_yaml_files(folder: Path) -> list[Path]:
    """YAML files in a workflow folder and its subfolders.

    Cache copies and hidden directories are not workflows.
    """
    root = Path(folder).expanduser().resolve()
    if not root.is_dir():
        raise ValueError(f"workflow folder not found: {root}")
    files: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(name for name in dirnames if not _skipped_workflow_dir(name))
        for name in filenames:
            if Path(name).suffix.lower() not in YAML_SUFFIXES:
                continue
            files.append(Path(dirpath) / name)
    files.sort()
    return files


def _is_routine_key(key: str) -> bool:
    """A routine is a top-level key ending in `_routine`, or the older `wf_` prefix."""
    text = str(key).strip()
    if _is_routine_config_key(text):
        return False
    if text.startswith("wf_") and len(text) > 3:
        return True
    return text.endswith(_ROUTINE_SUFFIX) and len(text) > len(_ROUTINE_SUFFIX)


def _is_routine_config_key(key: str) -> bool:
    """`<name>_routine_setup` overrides `config` for that one routine."""
    text = str(key).strip()
    return text.endswith(_ROUTINE_CONFIG_SUFFIX) and len(text) > len(_ROUTINE_CONFIG_SUFFIX)


def _routine_config_map(payload: dict[Any, Any]) -> dict[str, Any]:
    """Map a routine key to its `<name>_routine_setup` block."""
    routines = {str(key) for key in payload if _is_routine_key(str(key))}
    found: dict[str, Any] = {}
    for key, value in payload.items():
        text = str(key)
        if not _is_routine_config_key(text):
            continue
        routine = text[: -len("_setup")]
        if routine not in routines:
            raise ValueError(f"{text} has no {routine} routine")
        if not isinstance(value, dict):
            raise ValueError(f"{text} must be a mapping")
        found[routine] = value
    return found


def _overlay_routine_config(
    config: dict[str, Any],
    env: dict[str, str],
    routine_config: Any,
    group: str,
) -> tuple[dict[str, Any], dict[str, str], bool]:
    """Keys in `<group>_setup` replace the same keys from the file config."""
    return _overlay_group_config(
        config,
        env,
        {"config": routine_config},
        group=f"{group}_setup",
    )


def _apply_routine_config_tree(workflow: Workflow, routine_config: dict[str, Any]) -> None:
    """Push scalar routine-config overrides onto a workflow loaded from another file."""
    overrides: dict[str, str] = {}
    for key, item in routine_config.items():
        if key in {"steps", "scheduler", "env"} or isinstance(item, (dict, list)):
            continue
        overrides[str(key)] = "" if item is None else str(item)
    if overrides:
        apply_overrides(workflow, overrides)


def _finish_scheduled_group(workflow: Workflow, config: dict[str, Any], group: str) -> Workflow:
    workflow.before = _prelude_steps(config, group)
    workflow.scheduler = _scheduler_text(config, group)
    return workflow


def _prelude_steps(config: dict[str, Any], group: str) -> list[Step]:
    """Steps named on config. They always run before the routine's own steps.

    A routine setup that sets `steps` replaces the file config's steps.
    """
    if "steps" not in config:
        return []
    raw = config.get("steps")
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ValueError(f"{group} config steps must be a list")
    return _parse_step_list(raw)


_CRON_OFF = frozenset({"", "false", "off", "none", "no"})
_CRON_LIMITS = (
    ("minute", 0, 59),
    ("hour", 0, 23),
    ("day", 1, 31),
    ("month", 1, 12),
    ("weekday", 0, 7),
)


def _scheduler_text(config: dict[str, Any], group: str) -> str:
    """Five-field cron. `false` or a blank value clears a scheduler inherited from config."""
    if "scheduler" not in config:
        return ""
    raw = config.get("scheduler")
    if raw is False or raw is None:
        return ""
    if isinstance(raw, bool):
        raise ValueError(f"{group} scheduler must be a cron expression")
    text = " ".join(str(raw).split())
    if text.lower() in _CRON_OFF:
        return ""
    _check_cron(text, group)
    return text


def _check_cron(text: str, group: str) -> None:
    fields = text.split(" ")
    if len(fields) != 5:
        raise ValueError(f"{group} scheduler must be five cron fields: minute hour day month weekday")
    for field, (name, lo, hi) in zip(fields, _CRON_LIMITS):
        _check_cron_field(field, name, lo, hi, group)


def _check_cron_field(field: str, name: str, lo: int, hi: int, group: str) -> None:
    if not field:
        raise ValueError(f"{group} scheduler {name} is empty")
    for part in field.split(","):
        body, step = part, 1
        if "/" in part:
            body, step_text = part.split("/", 1)
            if not step_text.isdigit() or int(step_text) < 1:
                raise ValueError(f"{group} scheduler {name} has a bad step: {part}")
            step = int(step_text)
        if body in {"", "*"}:
            continue
        if "-" in body:
            start_text, end_text = body.split("-", 1)
            if not start_text.isdigit() or not end_text.isdigit():
                raise ValueError(f"{group} scheduler {name} has a bad range: {part}")
            start, end = int(start_text), int(end_text)
            if start > end or start < lo or end > hi:
                raise ValueError(f"{group} scheduler {name} is outside {lo}-{hi}: {part}")
            continue
        if not body.isdigit() or not lo <= int(body) <= hi:
            raise ValueError(f"{group} scheduler {name} is outside {lo}-{hi}: {part}")
        if step < 1:
            raise ValueError(f"{group} scheduler {name} has a bad step: {part}")


def _routine_label(key: str) -> str:
    """Short name for a routine key. `open_chrome_routine` and `wf_open_chrome` are both `open_chrome`."""
    text = str(key).strip()
    if text.startswith("wf_"):
        text = text[3:]
    if text.endswith(_ROUTINE_SUFFIX):
        text = text[: -len(_ROUTINE_SUFFIX)]
    return text or str(key)


def _is_group_token(name: str) -> bool:
    """True when a step names a routine rather than a workflow file."""
    text = (name or "").strip().lower()
    return text.startswith("wf_") or text.endswith(_ROUTINE_SUFFIX)


def _has_workflow_group(payload: Any) -> bool:
    return isinstance(payload, dict) and any(_is_routine_key(str(key)) for key in payload)


def check_workflow_conflicts(files: list[Path]) -> None:
    """Fail when a routine key is defined in more than one file, or a file repeats a key."""
    owners: dict[str, Path] = {}
    problems: list[str] = []
    for path in files:
        payload = _load_yaml(path)
        if not isinstance(payload, dict):
            raise ValueError(f"workflow YAML must be a mapping: {path}")
        for key in payload:
            if not _is_routine_key(str(key)):
                continue
            name = str(key)
            previous = owners.get(name)
            if previous is not None and previous != path:
                problems.append(f"{name} in {previous} and {path}")
            else:
                owners[name] = path
    if problems:
        details = "\n".join(problems)
        raise ValueError(f"workflow key conflict:\n{details}")


def load_workflow_dir(folder: str | Path) -> Workflow:
    """Load every workflow in a folder as one catalog.

    wf_* names are global across the folder. The same name in two files is an
    error and nothing runs.
    """
    root = Path(folder).expanduser().resolve()
    files = workflow_yaml_files(root)
    check_workflow_conflicts(files)
    group_files = [path for path in files if _has_workflow_group(_load_yaml(path))]
    if not group_files:
        raise ValueError(f"no workflow YAML in {root}")
    loaded = [load_workflow(path) for path in group_files]
    catalog: dict[str, Workflow] = {}
    groups: list[Workflow] = []
    for workflow in loaded:
        for extra in workflow.extras:
            if extra.group in catalog:
                other = catalog[extra.group]
                raise ValueError(
                    f"workflow key conflict:\n{extra.group} in {other.path} and {extra.path}"
                )
            catalog[extra.group] = extra
            groups.append(extra)
    container = Workflow(name=root.name, extras=groups, path=root, catalog=catalog)
    _assign_catalog(container, catalog)
    _bind_unresolved(container)
    return container


def attach_folder_catalog(workflow: Workflow, folder: str | Path) -> None:
    """Index sibling workflows so a step can call any wf_* name in the folder.

    Raises when two files use the same wf_* key. Groups from `workflow` stay
    the objects already loaded from its file.
    """
    root = Path(folder).expanduser().resolve()
    files = workflow_yaml_files(root)
    check_workflow_conflicts(files)
    catalog: dict[str, Workflow] = {}
    for extra in workflow.extras:
        catalog[extra.group] = extra
    own = workflow.path.resolve() if workflow.path else None
    for path in files:
        if own and path.resolve() == own:
            continue
        if not _has_workflow_group(_load_yaml(path)):
            continue
        loaded = load_workflow(path)
        for extra in loaded.extras:
            if extra.group in catalog and catalog[extra.group].path != extra.path:
                raise ValueError(
                    f"workflow key conflict:\n{extra.group} in {catalog[extra.group].path} and {extra.path}"
                )
            catalog.setdefault(extra.group, extra)
    _assign_catalog(workflow, catalog)
    _bind_unresolved(workflow)


def _set_config_items(raw: Any) -> list[tuple[str, str]]:
    if raw is None:
        return []
    if isinstance(raw, str):
        raw = [raw]
    if isinstance(raw, dict):
        return [
            (_normalize_set_config_key(str(key), str(key)), "" if value is None else str(value))
            for key, value in raw.items()
        ]
    if not isinstance(raw, list):
        raise ValueError("set_config must be a list of KEY=VALUE")
    found: list[tuple[str, str]] = []
    for item in raw:
        if isinstance(item, dict):
            if len(item) != 1:
                raise ValueError(f"set_config item must be one KEY=VALUE: {item!r}")
            key, value = next(iter(item.items()))
            found.append(
                (_normalize_set_config_key(str(key), str(key)), "" if value is None else str(value))
            )
            continue
        found.extend(parse_set_config_items(str(item)))
    return found


def _env_set_config(key: str) -> bool:
    """Environment names propagate to every group. Config fields do not."""
    return not config_alias_key(key)


def _collect_set_config(workflow: Workflow, assigned: dict[str, str]) -> None:
    for step in _flatten_steps(runnable_steps(workflow)):
        for key, value in set_config_pairs(step):
            if _env_set_config(key):
                assigned[key] = value
    for extra in workflow.extras:
        _collect_set_config(extra, assigned)


def _apply_set_config(workflow: Workflow, assigned: dict[str, str]) -> None:
    workflow.env.update(assigned)
    local: dict[str, str] = {}
    for step in _flatten_steps(runnable_steps(workflow)):
        for key, value in set_config_pairs(step):
            if _env_set_config(key):
                local[key] = value
    workflow.env.update(local)
    for extra in workflow.extras:
        _apply_set_config(extra, {**assigned, **local})


def _group_config_assignments(workflow: Workflow) -> dict[str, str]:
    found: dict[str, str] = {}
    for step in _flatten_steps(runnable_steps(workflow)):
        for key, value in set_config_pairs(step):
            alias = config_alias_key(key)
            if alias and CONFIG_ALIASES.get(alias) != "browser_reusetab":
                found[alias] = value
    return found


def _apply_group_config_steps(workflow: Workflow) -> None:
    """A group's `set-config cdp-url=` applies to that group, then its children."""
    found = _group_config_assignments(workflow)
    if found:
        apply_overrides(workflow, found)
    for extra in workflow.extras:
        _apply_group_config_steps(extra)


def _install_set_config(workflow: Workflow, items: list[tuple[str, str]]) -> None:
    """Apply set_config onto this workflow and every group. A later entry wins.

    A group's own `set_config` step replaces the shared value for that group.
    Config fields (`cdp-url`, `loop-count`) on a step apply to that group only.
    The same fields in the top-level `set_config` list apply to every group.
    `--param` is applied after load, so a run override still replaces these values.
    """
    assigned: dict[str, str] = {}
    shared_config: dict[str, str] = {}
    for key, value in items:
        if config_alias_key(key):
            shared_config[key] = value
        else:
            assigned[key] = value
    _collect_set_config(workflow, assigned)
    if shared_config:
        apply_overrides(workflow, shared_config)
    _apply_set_config(workflow, assigned)
    _apply_group_config_steps(workflow)


def _load_group(
    key: str,
    value: Any,
    *,
    parent_path: Path,
    config: dict[str, Any],
    env: dict[str, str],
    stack: tuple[Path, ...],
    routine_config: Any = None,
) -> Workflow:
    group = str(key)
    name = _routine_label(group)
    if isinstance(value, str):
        nested_path = _resolve_extra_path(value, parent_path=parent_path, env=env)
        nested = load_workflow(nested_path, _stack=stack)
        nested.group = group
        nested.name = f"{nested.name} [{name}]"
        _inherit_env_tree(nested, env)
        parent_cdp = str(config.get("cdp-url") or config.get("cdp_url") or "")
        parent_profile = str(config.get("profile") or "")
        _fill_attr_tree(nested, "cdp_url", parent_cdp)
        _fill_attr_tree(nested, "profile", parent_profile)
        _fill_attr_tree(nested, "llm", _llm_name(config))
        _fill_attr_tree(nested, "model", _model_name(config))
        _fill_attr_tree(nested, "browser_tool_model", _browser_tool_model(config))
        parent_timeout = _config_llm_timeout(config)
        if parent_timeout is not None:
            _set_attr_tree(nested, "llm_timeout", parent_timeout)
        if "fallbacks" in config or "llm-fallbacks" in config:
            _set_attr_tree(nested, "fallbacks", _fallbacks(config))
        _fill_attr_tree(nested, "python_compile", _compile_override(config, "python"))
        _fill_attr_tree(nested, "browser_compile", _compile_override(config, "browser"))
        if "data-numbers" in config or "data_numbers" in config:
            _set_attr_tree(nested, "data_numbers", _data_numbers(config))
        effective = config
        if routine_config is not None:
            effective, group_env, owns_loop = _overlay_routine_config(config, env, routine_config, group)
            _apply_routine_config_tree(nested, routine_config)
            for env_key, env_value in group_env.items():
                if env.get(env_key) != env_value:
                    _set_env_tree(nested, env_key, env_value)
            if owns_loop:
                nested.owns_loop = True
                nested.loop_count = _as_int(effective.get("loop-count") or effective.get("loop_count"), 1)
                nested.loop_delay = _as_float(effective.get("loop-delay") or effective.get("loop_delay"), 0.0)
        return _finish_scheduled_group(nested, effective, group)
    if isinstance(value, dict):
        merged, group_env, owns_loop = _overlay_group_config(config, env, value, group=group)
        if routine_config is not None:
            merged, group_env, owns_more = _overlay_routine_config(merged, group_env, routine_config, group)
            owns_loop = owns_loop or owns_more
        steps = _group_object_steps(value, group)
        return _finish_scheduled_group(
            _workflow_from_config(
                name,
                steps,
                parent_path=parent_path,
                config=merged,
                env=group_env,
                group=group,
                owns_loop=owns_loop,
            ),
            merged,
            group,
        )
    if not isinstance(value, list):
        raise ValueError(f"{group} must be a step list, an auto/config object, or a YAML path")
    merged = config
    group_env = env
    owns_loop = False
    if routine_config is not None:
        merged, group_env, owns_loop = _overlay_routine_config(config, env, routine_config, group)
    return _finish_scheduled_group(
        _workflow_from_config(
            name,
            _parse_step_list(value),
            parent_path=parent_path,
            config=merged,
            env=group_env,
            group=group,
            owns_loop=owns_loop,
        ),
        merged,
        group,
    )


_GROUP_OBJECT_KEYS = frozenset({"auto", "steps", "config"})


def _overlay_group_config(
    config: dict[str, Any],
    env: dict[str, str],
    value: dict[str, Any],
    *,
    group: str,
) -> tuple[dict[str, Any], dict[str, str], bool]:
    unknown = set(value) - _GROUP_OBJECT_KEYS
    if unknown:
        raise ValueError(f"{group} object keys must be auto, steps, or config: {sorted(unknown)}")
    raw_overlay = value.get("config") if "config" in value else {}
    if raw_overlay is None:
        raw_overlay = {}
    if not isinstance(raw_overlay, dict):
        raise ValueError(f"{group} config must be a mapping")
    overlay = raw_overlay
    merged = dict(config)
    owns_loop = "loop-count" in overlay or "loop_count" in overlay
    group_env_raw = overlay.get("env")
    for key, item in overlay.items():
        if key == "env":
            continue
        merged[key] = item
    group_env = dict(env)
    if group_env_raw is not None:
        if not isinstance(group_env_raw, dict):
            raise ValueError(f"{group} config.env must be a mapping")
        group_env.update(_coerce_env(group_env_raw))
    if "profile" in overlay and str(overlay.get("profile") or ""):
        group_env["PROFILE"] = str(overlay["profile"])
    return merged, group_env, owns_loop


def _group_object_steps(value: dict[str, Any], group: str) -> list[Step]:
    if "auto" not in value and "steps" not in value:
        raise ValueError(f"{group} object needs auto: or steps:")
    raw_auto = value.get("auto")
    if "auto" in value and raw_auto is None:
        raise ValueError(f"{group} auto must be a step list or true")
    raw_steps = value.get("steps")
    compiled: list[Step] = []
    auto_steps: list[Step] = []
    if isinstance(raw_auto, bool):
        if not isinstance(raw_steps, list):
            raise ValueError(f"{group} auto: {str(raw_auto).lower()} needs a steps: list")
        parsed = _parse_step_list(raw_steps)
        if raw_auto:
            auto_steps = [_as_auto(step) for step in parsed]
        else:
            compiled = parsed
    elif isinstance(raw_auto, list):
        auto_steps = [_as_auto(step) for step in _parse_step_list(raw_auto)]
        if raw_steps is not None:
            if not isinstance(raw_steps, list):
                raise ValueError(f"{group} steps must be a list")
            compiled = _parse_step_list(raw_steps)
    elif raw_auto is None:
        if not isinstance(raw_steps, list):
            raise ValueError(f"{group} steps must be a list")
        compiled = _parse_step_list(raw_steps)
    else:
        raise ValueError(f"{group} auto must be a step list or true")
    steps = [*compiled, *auto_steps]
    if not steps:
        raise ValueError(f"{group} has no steps")
    return steps


def _as_auto(step: Step) -> Step:
    step.auto = True
    return step


def _workflow_from_config(
    name: str,
    steps: list[Step],
    *,
    parent_path: Path,
    config: dict[str, Any],
    env: dict[str, str],
    group: str,
    owns_loop: bool = False,
) -> Workflow:
    return Workflow(
        name=name,
        profile=str(config.get("profile") or ""),
        cdp_url=str(config.get("cdp-url") or config.get("cdp_url") or ""),
        env=_with_models(config, _with_lmstudio(config, _with_venv(config, env))),
        steps=steps,
        path=parent_path,
        group=group,
        loop_count=_as_int(config.get("loop-count") or config.get("loop_count"), 1),
        loop_delay=_as_float(config.get("loop-delay") or config.get("loop_delay"), 0.0),
        log_keep=_as_int(config.get("log-keep") or config.get("log_keep"), 5),
        data_numbers=_data_numbers(config),
        llm=_llm_name(config),
        model=_model_name(config),
        browser_tool_model=_browser_tool_model(config),
        llm_timeout=_llm_timeout(config),
        command_timeout=_config_command_timeout(config),
        recompile=_as_bool(config.get("recompile")),
        browser_recompile=_as_bool(config.get("browser-recompile") or config.get("browser_recompile")),
        browser_reusetab=_browser_reuse_site(config),
        recompile_on_error=_as_bool(
            config.get("recompile-on-error") or config.get("recompile_on_error")
        ),
        fallbacks=_fallbacks(config),
        python_compile=_compile_override(config, "python"),
        browser_compile=_compile_override(config, "browser"),
        owns_loop=owns_loop,
        reference=_reference_script(config),
    )


def workflow_from_goal(goal: str, *, url: str = "", cdp_url: str = "", profile: str = "") -> Workflow:
    steps: list[Step] = []
    if url:
        steps.append(Step(kind="goto", raw=f"goto {url}", url=url))
    steps.append(Step(kind="goal", raw=goal, extra=goal))
    return Workflow(
        name="goal",
        profile=profile,
        cdp_url=cdp_url,
        steps=steps,
        goal=goal,
        group="wf_goal",
    )


def select_step_at_line(workflow: Workflow, line: int, *, only: str = "") -> Workflow:
    """The group step that contains this 1-based source line, as its own run.

    A nested step wins over the condition that contains it. Several steps that
    share one YAML item run together. A step inside `<routine>_routine_setup`
    runs by itself. The rest of that setup list does not run.
    `only` must name that step's group when it is set.
    """
    if workflow.path is None or workflow.path.is_dir():
        raise ValueError("--line needs a workflow file")
    source = workflow.path.resolve()
    if line < 1:
        raise ValueError(f"line {line} is not a step in {source.name}")
    found: list[tuple[tuple[int, int, int], Workflow, Step]] = []

    def visit(group: Workflow, step: Step, depth: int) -> None:
        if group.path is None or group.path.resolve() != source:
            return
        end = step.end_line or step.line
        if step.line and step.line <= line <= end:
            found.append(((end - step.line, -depth, step.line), group, step))
        for child in (*step.checks, *step.steps):
            visit(group, child, depth + 1)

    for group in _walk_groups(workflow):
        for step in (*group.before, *group.steps):
            visit(group, step, 0)
    if not found:
        raise ValueError(f"line {line} is not a step in {source.name}")
    best = min(item[0] for item in found)
    chosen = [(group, step) for score, group, step in found if score == best]
    group = chosen[0][0]
    if any(other is not group for other, _step in chosen[1:]):
        raise ValueError(f"line {line} matches steps in more than one group")
    if only.strip() and not _is_all_groups(only):
        if _group_needle(group.group) != _group_needle(only):
            raise ValueError(f"line {line} is in {group.group}, not {only}")
    return _selected_run(group, [step for _group, step in chosen])


def select_steps_between(workflow: Workflow, start: int, end: int, *, only: str = "") -> Workflow:
    """Steps the highlight covers, from `start` through `end`, as one run.

    A parent runs instead of its children when the highlight includes the
    parent's first line. A highlight that stays inside the parent runs the
    children it covers. A highlight inside `<routine>_routine_setup` runs
    those setup steps only, not the rest of the setup list. Every chosen
    step belongs to one group.
    """
    if workflow.path is None or workflow.path.is_dir():
        raise ValueError("--end needs a workflow file")
    source = workflow.path.resolve()
    if end < start:
        start, end = end, start
    if start < 1:
        raise ValueError(f"lines {start}-{end} are not steps in {source.name}")
    found: list[tuple[Workflow, Step, Step | None]] = []

    def visit(group: Workflow, step: Step, parent: Step | None) -> None:
        if group.path is None or group.path.resolve() != source:
            return
        span_end = step.end_line or step.line
        if step.line and step.line <= end and span_end >= start:
            found.append((group, step, parent))
        for child in (*step.checks, *step.steps):
            visit(group, child, step)

    for group in _walk_groups(workflow):
        for step in (*group.before, *group.steps):
            visit(group, step, None)

    parents = {id(step): parent for _group, step, parent in found}
    overlapping = {id(step) for _group, step, _parent in found}

    def under(ancestor: Step, step: Step) -> bool:
        parent = parents.get(id(step))
        while parent is not None:
            if parent is ancestor:
                return True
            parent = parents.get(id(parent))
        return False

    def ancestor_selected(step: Step) -> bool:
        parent = parents.get(id(step))
        while parent is not None:
            if id(parent) in overlapping and parent.line >= start:
                return True
            parent = parents.get(id(parent))
        return False

    chosen: list[tuple[Workflow, Step]] = []
    for group, step, _parent in found:
        if ancestor_selected(step):
            continue
        if step.line < start and any(under(step, other) for _group, other, _parent in found):
            continue
        chosen.append((group, step))
    if not chosen:
        raise ValueError(f"lines {start}-{end} are not steps in {source.name}")
    group = chosen[0][0]
    if any(other is not group for other, _step in chosen[1:]):
        raise ValueError(f"lines {start}-{end} match steps in more than one group")
    if only.strip() and not _is_all_groups(only):
        if _group_needle(group.group) != _group_needle(only):
            raise ValueError(f"lines {start}-{end} are in {group.group}, not {only}")
    return _selected_run(group, [step for _group, step in chosen])


def _selected_run(group: Workflow, steps: list[Step]) -> Workflow:
    """One group's chosen steps. A setup step does not bring the rest of setup."""
    fields: dict[str, Any] = {
        "steps": steps,
        "extras": [],
        "loop_count": 1,
        "owns_loop": False,
    }
    if steps and all(_in_setup(group, step) for step in steps):
        fields["before"] = []
    return replace(group, **fields)


def _in_setup(group: Workflow, step: Step) -> bool:
    """True when `step` is one of the routine setup steps, or nested inside one."""
    if any(item is step for item in group.before):
        return True
    for item in group.before:
        start = item.line
        end = item.end_line or item.line
        if start and step.line and start <= step.line <= end:
            return True
    return False


def _walk_groups(workflow: Workflow) -> list[Workflow]:
    found: list[Workflow] = []

    def walk(item: Workflow) -> None:
        found.append(item)
        for extra in item.extras:
            walk(extra)

    walk(workflow)
    return found


def select_workflows(workflow: Workflow, only: str = "") -> list[Workflow]:
    """Return the workflow units to run.

    No --only: one group runs as itself. Two or more groups do not run until
    the user passes `--only wf_all` or names the groups.
    --only slides / wf_slides: just that group.
    --only wf_all: every wf_<name> group, in file order.
    Pipe or comma lists run those groups in order: wf_research|wf_slides.
    """
    spec = only.strip()
    if not spec:
        return _select_default(workflow)
    names = [part.strip() for part in re.split(r"[|,]", spec) if part.strip()]
    if not names:
        return _select_default(workflow)
    if any(_is_all_groups(name) for name in names):
        if len(names) != 1:
            raise ValueError("wf_all runs every group; do not combine it with other groups")
        return [workflow]
    units = [_select_one_group(workflow, name) for name in names]
    if len(units) == 1:
        return [units[0]]
    return [
        Workflow(
            name=workflow.name,
            profile=workflow.profile,
            cdp_url=workflow.cdp_url,
            env=dict(workflow.env),
            extras=units,
            path=workflow.path,
            catalog=dict(workflow.catalog),
            loop_count=workflow.loop_count,
            loop_delay=workflow.loop_delay,
            log_keep=workflow.log_keep,
            data_numbers=workflow.data_numbers,
            llm=workflow.llm,
            model=workflow.model,
            browser_tool_model=workflow.browser_tool_model,
            llm_timeout=workflow.llm_timeout,
            command_timeout=workflow.command_timeout,
            recompile=workflow.recompile,
            browser_recompile=workflow.browser_recompile,
            browser_reusetab=workflow.browser_reusetab,
            config_locks=set(workflow.config_locks),
            recompile_on_error=workflow.recompile_on_error,
            fallbacks=list(workflow.fallbacks),
            python_compile=workflow.python_compile,
            browser_compile=workflow.browser_compile,
        )
    ]


def _select_default(workflow: Workflow) -> list[Workflow]:
    """Run a lone group. Refuse to run every group until the user passes wf_all."""
    groups = list(workflow.extras)
    if not groups:
        return [workflow]
    if len(groups) == 1 and not workflow.steps:
        return [groups[0]]
    if len(groups) == 1:
        return [workflow]
    names = ", ".join(group.group for group in groups)
    raise ValueError(f"pass --only <group> or --only wf_all; groups: {names}")


def _is_all_groups(value: str) -> bool:
    return (value or "").strip().lower() in {"wf_all", "all"}


def _select_one_group(workflow: Workflow, only: str) -> Workflow:
    needle = _group_needle(only)
    groups = workflow.named_groups()
    for key, group in groups.items():
        if _group_needle(key) == needle:
            return group
    have = ", ".join(sorted(groups)) or "(none)"
    raise ValueError(f"unknown wf group {only!r}; have: {have}")


def _group_needle(value: str) -> str:
    text = (value or "").strip().lower()
    if text.startswith("wf_"):
        text = text[3:]
    if text.endswith(_ROUTINE_SUFFIX):
        text = text[: -len(_ROUTINE_SUFFIX)]
    return text


CONFIG_ALIASES = {
    "cdp-url": "cdp_url",
    "cdp_url": "cdp_url",
    "profile": "profile",
    "name": "name",
    "loop-count": "loop_count",
    "loop_count": "loop_count",
    "loop-delay": "loop_delay",
    "loop_delay": "loop_delay",
    "log-keep": "log_keep",
    "log_keep": "log_keep",
    "data-numbers": "data_numbers",
    "data_numbers": "data_numbers",
    "llm": "llm",
    "provider": "llm",
    "model-provider": "llm",
    "model_provider": "llm",
    "model": "model",
    "llm-model": "model",
    "llm_model": "model",
    "browser-tool-model": "browser_tool_model",
    "browser_tool_model": "browser_tool_model",
    "llm-timeout": "llm_timeout",
    "llm_timeout": "llm_timeout",
    "command-timeout": "command_timeout",
    "command_timeout": "command_timeout",
    "recompile": "recompile",
    "browser-recompile": "browser_recompile",
    "browser_recompile": "browser_recompile",
    "browser-reusetab": "browser_reusetab",
    "browser_reusetab": "browser_reusetab",
    "recompile-on-error": "recompile_on_error",
    "recompile_on_error": "recompile_on_error",
    "lmstudio": "lmstudio",
    "lmstudio-path": "lmstudio",
    "lmstudio_path": "lmstudio",
    "clef": "clef",
    "clef-model": "clef",
    "clef_model": "clef",
    "locate": "locate",
    "locate-model": "locate",
    "locate_model": "locate",
    "hug": "hug",
    "hug-model": "hug",
    "hug_model": "hug",
    "hug-download": "hug_download",
    "hug_download": "hug_download",
    "cua": "cua",
    "cua-space": "cua_space",
    "cua_space": "cua_space",
    "cua-url": "cua_url",
    "cua_url": "cua_url",
    "cua-token": "cua_token",
    "cua_token": "cua_token",
    "venv": "venv",
}


def parse_override(raw: str) -> tuple[str, str]:
    if "=" not in raw:
        raise ValueError(f"override must be KEY=VALUE, got {raw!r}")
    key, _, value = raw.partition("=")
    key = key.strip()
    if not key:
        raise ValueError(f"override missing key: {raw!r}")
    return key, value.strip()


def apply_overrides(
    workflow: Workflow,
    overrides: dict[str, str],
    *,
    env: dict[str, str] | None = None,
    lock: bool = False,
) -> None:
    """CLI/config overrides. Known keys patch the workflow; anything else is env.

    `lock` keeps a `--param` value in place when a later `set-config` step names that field.
    """
    for raw_key, value in overrides.items():
        field = CONFIG_ALIASES.get(raw_key) or CONFIG_ALIASES.get(raw_key.replace("_", "-"))
        if field == "cdp_url":
            _set_attr_tree(workflow, "cdp_url", value)
        elif field == "profile":
            _set_attr_tree(workflow, "profile", value)
            _set_env_tree(workflow, "PROFILE", value)
        elif field == "name":
            workflow.name = value
        elif field == "loop_count":
            _set_attr_tree(workflow, "loop_count", max(1, _as_int(value, 1)))
        elif field == "loop_delay":
            _set_attr_tree(workflow, "loop_delay", max(0.0, _as_float(value, 0.0)))
        elif field == "log_keep":
            _set_attr_tree(workflow, "log_keep", max(1, _as_int(value, 5)))
        elif field == "data_numbers":
            _set_attr_tree(workflow, "data_numbers", _as_bool(value))
        elif field == "llm":
            _set_attr_tree(workflow, "llm", value.strip().lower())
        elif field == "model":
            _set_attr_tree(workflow, "model", value.strip())
        elif field == "browser_tool_model":
            _set_attr_tree(workflow, "browser_tool_model", value.strip())
        elif field == "llm_timeout":
            _set_attr_tree(workflow, "llm_timeout", _llm_timeout_value(value))
        elif field == "command_timeout":
            _set_attr_tree(workflow, "command_timeout", _config_command_timeout({"command-timeout": value}))
        elif field == "recompile":
            _set_attr_tree(workflow, "recompile", _as_bool(value))
        elif field == "browser_recompile":
            _set_attr_tree(workflow, "browser_recompile", _as_bool(value))
        elif field == "browser_reusetab":
            _set_attr_tree(workflow, "browser_reusetab", _browser_reuse_site({"browser-reusetab": value}))
            if lock:
                _lock_config_tree(workflow, "browser_reusetab")
        elif field == "recompile_on_error":
            _set_attr_tree(workflow, "recompile_on_error", _as_bool(value))
        elif field == "lmstudio":
            _set_env_tree(workflow, "LM_STUDIO_BASE_URL", value.strip())
        elif field == "clef":
            _set_env_tree(workflow, "CLEF_MODEL", value.strip())
        elif field == "locate":
            _set_env_tree(workflow, "LOCATE_MODEL", value.strip())
        elif field == "hug":
            _set_env_tree(workflow, "HUG_MODEL", value.strip())
        elif field == "hug_download":
            _set_env_tree(workflow, "HUG_DOWNLOAD", "true" if _as_bool(value) else "false")
        elif field == "cua":
            _set_env_tree(workflow, "CUA", value.strip().lower())
        elif field == "cua_space":
            _set_env_tree(workflow, "CUA_SPACE", value.strip())
        elif field == "cua_url":
            _set_env_tree(workflow, "CUA_URL", value.strip())
        elif field == "cua_token":
            _set_env_tree(workflow, "CUA_TOKEN", value.strip())
        elif field == "venv":
            _apply_venv_tree(workflow, value.strip())
        else:
            _set_env_tree(workflow, raw_key, expand_root_project(value))
    for key, value in (env or {}).items():
        _set_env_tree(workflow, key, expand_root_project(value))


def live_config_value(workflow: Workflow, key: str, *, cdp_url: str = "") -> str:
    """The value a config field has after load and `--param`. Empty when unset."""
    alias = config_alias_key(key)
    if not alias:
        return ""
    field = CONFIG_ALIASES[alias]
    if field == "cdp_url":
        return (cdp_url or workflow.cdp_url or "").rstrip("/")
    env_keys = {
        "lmstudio": "LM_STUDIO_BASE_URL",
        "clef": "CLEF_MODEL",
        "locate": "LOCATE_MODEL",
        "hug": "HUG_MODEL",
        "hug_download": "HUG_DOWNLOAD",
        "cua": "CUA",
        "cua_space": "CUA_SPACE",
        "cua_url": "CUA_URL",
        "cua_token": "CUA_TOKEN",
    }
    if field in env_keys:
        return workflow.env.get(env_keys[field], "")
    value = getattr(workflow, field, "")
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return ""
    return str(value)


def _lock_config_tree(workflow: Workflow, field: str) -> None:
    workflow.config_locks.add(field)
    for extra in workflow.extras:
        _lock_config_tree(extra, field)


def _set_attr_tree(workflow: Workflow, attr: str, value: Any) -> None:
    setattr(workflow, attr, value)
    for extra in workflow.extras:
        _set_attr_tree(extra, attr, value)


def _set_env_tree(workflow: Workflow, key: str, value: str) -> None:
    workflow.env[key] = value
    for extra in workflow.extras:
        _set_env_tree(extra, key, value)


def _inherit_env_tree(workflow: Workflow, parent_env: dict[str, str]) -> None:
    merged = dict(parent_env)
    merged.update(workflow.env)
    workflow.env = merged
    for extra in workflow.extras:
        _inherit_env_tree(extra, parent_env)


def _fill_attr_tree(workflow: Workflow, attr: str, value: Any) -> None:
    if value and not getattr(workflow, attr):
        setattr(workflow, attr, value)
    for extra in workflow.extras:
        _fill_attr_tree(extra, attr, value)


def _with_app_defaults(config: dict[str, Any]) -> dict[str, Any]:
    """Start from workflows-app.yaml config. Keys in the workflow file replace them."""
    from .app_config import app_env, workflow_defaults

    if not isinstance(config, dict):
        config = {}
    base = workflow_defaults()
    overlay = dict(config)
    base_env = base.get("env") if isinstance(base.get("env"), dict) else {}
    file_env = overlay.get("env") if isinstance(overlay.get("env"), dict) else None
    merged = dict(base)
    merged.update(overlay)
    env = app_env()
    if isinstance(base_env, dict):
        env.update(_coerce_env(base_env))
    if isinstance(file_env, dict):
        env.update(_coerce_env(file_env))
    if env or isinstance(file_env, dict) or base_env:
        merged["env"] = env
    return merged


def _reference_script(config: dict[str, Any]) -> str:
    """Path of an example script. The compiler reads it. The run does not call it."""
    return str(config.get("reference") or "").strip()


def _llm_name(config: dict[str, Any]) -> str:
    return str(
        config.get("llm") or config.get("provider") or config.get("model-provider") or config.get("model_provider") or ""
    ).strip().lower()


def _model_name(config: dict[str, Any]) -> str:
    return str(config.get("model") or config.get("llm-model") or config.get("llm_model") or "").strip()


def _browser_tool_model(config: dict[str, Any]) -> str:
    return str(config.get("browser-tool-model") or config.get("browser_tool_model") or "").strip()


def _compile_override(config: dict[str, Any], tool: str) -> CompileOverride | None:
    """python or browser under a workflow config. Missing means the app section."""
    raw = config.get(tool)
    if not isinstance(raw, dict):
        return None
    names = {"llm", "provider", "model", "llm-timeout", "llm_timeout", "fallbacks", "llm-fallbacks"}
    if not names.intersection(raw):
        return None
    fallbacks = _fallbacks(raw) if "fallbacks" in raw or "llm-fallbacks" in raw else None
    return CompileOverride(
        llm=str(raw.get("llm") or raw.get("provider") or "").strip().lower(),
        model=str(raw.get("model") or "").strip(),
        timeout=_config_llm_timeout(raw),
        fallbacks=fallbacks,
    )


def _browser_reuse_site(config: dict[str, Any]) -> str:
    """Site whose open tab later browser steps use. Blank keeps the active tab.

    A workflow file or `--param browser-reusetab=` replaces the app value.
    A `set-config browser-reusetab=` step replaces it again when that step runs.
    """
    if "browser-reusetab" in config:
        raw = config.get("browser-reusetab")
    elif "browser_reusetab" in config:
        raw = config.get("browser_reusetab")
    else:
        return ""
    if raw is None or raw is False:
        return ""
    text = str(raw).strip()
    if text.lower() in {"false", "none", "off", "0"}:
        return ""
    return text


def _lmstudio_url(config: dict[str, Any]) -> str:
    """The LM Studio server in config. Empty means the step uses the default."""
    return str(config.get("lmstudio") or config.get("lmstudio-path") or config.get("lmstudio_path") or "").strip()


def _with_venv(config: dict[str, Any], env: dict[str, str]) -> dict[str, str]:
    """Put the shared interpreter first on PATH. A file's venv replaces the app one.

    A workflow env with no PATH starts from the process PATH, so commands such
    as bash stay reachable after the venv bin is prepended.
    """
    folder = str(config.get("venv") or "").strip()
    if not folder:
        return env
    root = Path(folder).expanduser()
    bin_dir = str(root / "bin")
    merged = dict(env)
    previous = merged.get("VIRTUAL_ENV", "")
    inherited = merged.get("PATH") or os.environ.get("PATH", "")
    parts = [part for part in inherited.split(os.pathsep) if part]
    if previous:
        previous_bin = str(Path(previous) / "bin")
        parts = [part for part in parts if part != previous_bin]
    parts = [bin_dir, *[part for part in parts if part != bin_dir]]
    merged["PATH"] = os.pathsep.join(parts)
    merged["VIRTUAL_ENV"] = str(root)
    return merged


def _apply_venv_tree(workflow: Workflow, folder: str) -> None:
    workflow.env = _with_venv({"venv": folder}, workflow.env)
    for extra in workflow.extras:
        _apply_venv_tree(extra, folder)


def _with_lmstudio(config: dict[str, Any], env: dict[str, str]) -> dict[str, str]:
    url = _lmstudio_url(config)
    if not url:
        return env
    merged = dict(env)
    merged["LM_STUDIO_BASE_URL"] = url
    return merged


def _with_models(config: dict[str, Any], env: dict[str, str]) -> dict[str, str]:
    """Locate, Clef, and Hug model ids, then Cua settings.

    `tool-details` supplies each id. A `locate`, `clef`, or `hug-model` key
    in this file's config replaces that id.
    """
    env = _with_tool_model(config, env, "locate", "LOCATE_MODEL")
    env = _with_tool_model(config, env, "clef", "CLEF_MODEL")
    env = _with_tool_model(config, env, "hug", "HUG_MODEL")
    env = _with_hug_download(config, env)
    return _with_cua(config, env)


def _with_hug_download(config: dict[str, Any], env: dict[str, str]) -> dict[str, str]:
    """Copy `hug-download` into env. Missing means download the model and its packages."""
    if "hug-download" in config:
        raw = config.get("hug-download")
    elif "hug_download" in config:
        raw = config.get("hug_download")
    else:
        raw = True
    merged = dict(env)
    merged["HUG_DOWNLOAD"] = "true" if _as_bool(raw) else "false"
    return merged


def _with_tool_model(config: dict[str, Any], env: dict[str, str], tool: str, env_key: str) -> dict[str, str]:
    """One tool's Hugging Face id. A workflow `config` key replaces tool-details."""
    name = _config_text(config, tool, f"{tool}-model", f"{tool}_model")
    if not name:
        from .app_config import tool_model

        name = tool_model(tool)
    if not name:
        return env
    merged = dict(env)
    merged[env_key] = name
    return merged


def _config_text(config: dict[str, Any], *keys: str) -> str:
    for key in keys:
        if key not in config:
            continue
        value = config.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def _with_cua(config: dict[str, Any], env: dict[str, str]) -> dict[str, str]:
    """Copy cua target settings into env. local is this machine. space is a Cua Space."""
    merged = dict(env)
    target = _config_text(config, "cua")
    space = _config_text(config, "cua-space", "cua_space")
    url = _config_text(config, "cua-url", "cua_url")
    token = _config_text(config, "cua-token", "cua_token")
    if target:
        merged["CUA"] = target.lower()
    if space:
        merged["CUA_SPACE"] = space
    if url:
        merged["CUA_URL"] = url
    if token:
        merged["CUA_TOKEN"] = token
    workflow_name = _config_text(config, "name")
    if workflow_name:
        merged["CUA_WORKFLOW"] = workflow_name
    return merged


def _config_command_timeout(config: dict[str, Any]) -> int:
    """Seconds for one terminal command. 0 means no limit."""
    if "command-timeout" in config:
        raw = config.get("command-timeout")
    elif "command_timeout" in config:
        raw = config.get("command_timeout")
    else:
        return 0
    if raw is None or raw == "":
        return 0
    return max(0, _as_int(raw, 0))


def _config_llm_timeout(config: dict[str, Any]) -> float | None:
    if "llm-timeout" in config:
        raw = config.get("llm-timeout")
    elif "llm_timeout" in config:
        raw = config.get("llm_timeout")
    else:
        return None
    return _llm_timeout_value(raw)


def _fallbacks(config: dict[str, Any]) -> list[tuple[str, str, float | None]]:
    raw = config.get("fallbacks")
    if raw is None:
        raw = config.get("llm-fallbacks")
    if raw is None:
        raw = []
    if isinstance(raw, str):
        raw = [part.strip() for part in raw.split("|") if part.strip()]
    if not isinstance(raw, list):
        raise ValueError(f"fallbacks must be a list, got {raw!r}")
    parsed: list[tuple[str, str, float | None]] = []
    for item in raw:
        if isinstance(item, str):
            llm, _, model_name = item.partition(":")
            parsed.append(_fallback_slot(llm, model_name, None))
            continue
        if not isinstance(item, dict):
            raise ValueError(f"fallback must be a mapping or llm:model string, got {item!r}")
        llm = str(item.get("llm") or item.get("provider") or "local")
        model_name = str(item.get("model") or "")
        timeout = item.get("timeout", item.get("llm-timeout"))
        parsed.append(_fallback_slot(llm, model_name, timeout))
    return parsed


def _fallback_slot(llm: Any, model_name: Any, timeout: Any) -> tuple[str, str, float | None]:
    name = str(llm or "local").strip().lower()
    if timeout is None and name == "local":
        slot_timeout: float | None = 120.0
    elif timeout is None:
        slot_timeout = None
    else:
        slot_timeout = _llm_timeout_value(timeout)
    return name, str(model_name or "").strip(), slot_timeout


def _llm_timeout(config: dict[str, Any]) -> float:
    found = _config_llm_timeout(config)
    return 30.0 if found is None else found


def _llm_timeout_value(value: Any) -> float:
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return 30.0
    if seconds <= 0:
        return 30.0
    return seconds


def _data_numbers(config: dict[str, Any]) -> bool:
    """Number files in the run data folder unless config turns that off."""
    if "data-numbers" in config:
        return _as_bool(config.get("data-numbers"))
    if "data_numbers" in config:
        return _as_bool(config.get("data_numbers"))
    return True


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _as_int(value: Any, default: int) -> int:
    if value is None or value == "":
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _as_float(value: Any, default: float) -> float:
    if value is None or value == "":
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _coerce_env(env_raw: Any) -> dict[str, str]:
    if not isinstance(env_raw, dict):
        return {}
    return {str(key): _env_to_str(value) for key, value in env_raw.items()}


def project_root() -> Path:
    """The workflow project. It holds ``workflows-app.yaml``.

    The skill ships with the app, so this is not the skill's parent.
    ``CG_LOOP_PROJECT`` names the folder. ``CG_LOOP_APP`` names the yaml.
    Otherwise the search starts at the working directory.
    """
    named = os.environ.get("CG_LOOP_PROJECT", "").strip()
    if named:
        return Path(named).expanduser().resolve()
    app = os.environ.get("CG_LOOP_APP", "").strip()
    if app:
        return Path(app).expanduser().resolve().parent
    start = Path.cwd()
    for folder in (start, *start.parents):
        if (folder / "workflows-app.yaml").is_file():
            return folder.resolve()
    legacy = SKILL_ROOT.parents[1]
    if (legacy / "workflows-app.yaml").is_file():
        return legacy.resolve()
    return start.resolve()


def expand_root_project(value: str) -> str:
    """Replace ``$rootProject`` with the project folder.

    ``.$rootProject`` is the same token. A step writes it as
    ``set_config UPLOAD_SCRIPT=.$rootProject/skills/...``.
    """
    if "rootProject" not in value:
        return value
    return _ROOT_PROJECT_RE.sub(str(project_root()), value)


def _resolve_config_path(value: str, base: Path) -> str:
    """Turn a workflow file path into an absolute path.

    Flags, URLs, and values with spaces stay as written. A path that is
    already absolute stays absolute. A model id such as
    ``mlx-community/clef-flash-4bit`` has a slash but is not a file, so it
    stays as written. ``$rootProject`` is the project folder.
    """
    value = expand_root_project(value)
    text = value.strip()
    if not text or any(ch.isspace() for ch in text):
        return value
    if text.startswith(("-", "/")) or "://" in text:
        return value
    rooted = text.startswith(("~", ".", "..", "skills/"))
    if not rooted and "/" not in text:
        return value
    path = Path(text).expanduser()
    if not path.is_absolute():
        path = base / path
    if not rooted and not path.exists():
        return value
    # Keep the last name. A venv python is often a symlink, and following it
    # drops the virtualenv.
    return str(path.parent.resolve() / path.name)


def _resolve_workflow_paths(workflow: Workflow) -> None:
    """Resolve env and set_config paths against the workflow file's folder."""
    base = workflow.path.parent if workflow.path is not None else None
    if base is not None:
        for key, value in list(workflow.env.items()):
            workflow.env[key] = _resolve_config_path(value, base)
        for step in _flatten_steps(workflow.steps):
            pairs = set_config_pairs(step)
            if not pairs:
                continue
            _store_set_config_pairs(
                step,
                [(key, _resolve_config_path(value, base)) for key, value in pairs],
            )
    for extra in workflow.extras:
        if extra.path is None and workflow.path is not None:
            extra.path = workflow.path
        _resolve_workflow_paths(extra)


def _env_to_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return os.pathsep.join(
            _env_to_str(item) for item in value if item is not None and str(item) != ""
        )
    return str(value)


def _stringify_params(params: dict[str, Any]) -> dict[str, str]:
    return {str(key): _env_to_str(value) for key, value in params.items()}


def _bind_subworkflows(
    workflow: Workflow,
    *,
    stack: tuple[Path, ...],
    scope: Workflow | None = None,
) -> None:
    scope = scope or workflow
    for step in _flatten_steps(workflow.steps):
        if step.kind != "workflow" or step.nested is not None or _needs_runtime_lookup(step):
            continue
        lookup, _groups = _step_ref(step)
        if _loaded_group(scope, lookup) is None and _defer_group(lookup):
            continue
        step.nested = resolve_subworkflow(
            step,
            env=workflow.env,
            parent=workflow,
            stack=stack,
            scope=scope,
        )
    for extra in workflow.extras:
        _bind_subworkflows(extra, stack=stack, scope=scope)


def _assign_catalog(
    workflow: Workflow,
    catalog: dict[str, Workflow],
    seen: set[int] | None = None,
) -> None:
    seen = seen if seen is not None else set()
    if id(workflow) in seen:
        return
    seen.add(id(workflow))
    workflow.catalog = catalog
    for step in _flatten_steps(workflow.steps):
        if step.nested is not None:
            _assign_catalog(step.nested, catalog, seen)
    for extra in workflow.extras:
        _assign_catalog(extra, catalog, seen)


def _bind_unresolved(workflow: Workflow, *, stack: tuple[Path, ...] = ()) -> None:
    for step in _flatten_steps(workflow.steps):
        if step.kind != "workflow" or step.nested is not None or _needs_runtime_lookup(step):
            continue
        step.nested = resolve_subworkflow(
            step,
            env=workflow.env,
            parent=workflow,
            stack=stack,
            scope=workflow,
        )
    for extra in workflow.extras:
        _bind_unresolved(extra, stack=stack)


def _step_ref(step: Step) -> tuple[str, str]:
    return split_workflow_msg(step.workflow_name, explicit=step.workflow_ref)


def _defer_group(name: str) -> bool:
    """A routine name may be a group in another file, bound once the folder is loaded."""
    return _is_group_token(name)


def _loaded_group(scope: Workflow | None, name: str) -> Workflow | None:
    if scope is None or not (name or "").strip():
        return None
    needle = _group_needle(name)
    found: list[Workflow] = []
    seen: set[int] = set()
    pools: list[dict[str, Workflow]] = []
    if scope.catalog:
        pools.append(scope.catalog)
    pools.append(scope.named_groups())
    for pool in pools:
        for key, group in pool.items():
            if _group_needle(key) != needle:
                continue
            if id(group) in seen:
                continue
            seen.add(id(group))
            found.append(group)
    if not found:
        return None
    if len(found) > 1:
        names = ", ".join(sorted({group.group or group.name for group in found}))
        raise ValueError(f"ambiguous workflow group {name!r}: {names}")
    return found[0]


def _clone_workflow(workflow: Workflow) -> Workflow:
    return replace(
        workflow,
        env=dict(workflow.env),
        steps=list(workflow.steps),
        extras=[_clone_workflow(extra) for extra in workflow.extras],
        fallbacks=list(workflow.fallbacks),
        catalog=workflow.catalog,
    )


def _needs_runtime_lookup(step: Step) -> bool:
    if "$" in (step.workflow_name or "") or "$" in (step.workflow_ref or ""):
        return True
    return any("$" in str(value) for value in step.params.values())


def _resolve_extra_path(value: str, *, parent_path: Path, env: dict[str, str]) -> Path:
    nested_path = Path(value).expanduser()
    if not nested_path.is_absolute():
        nested_path = parent_path.parent / nested_path
    if nested_path.is_file() and nested_path.suffix.lower() in YAML_SUFFIXES:
        return nested_path.resolve()
    return find_workflow(value, workflow_search_paths(env, parent_path))


def workflow_search_paths(
    env: dict[str, str] | None = None,
    parent_path: Path | None = None,
) -> list[Path]:
    """Directories (or files) to search for named workflows.

    `WORKFLOW_PATH` may be one directory, or several joined with `os.pathsep`
    (YAML lists in config.env are joined the same way). Each directory is
    searched with its subfolders. If unset, the parent workflow directory and
    the workflows folder from workflows-app.yaml are used.
    """
    merged = dict(os.environ)
    if env:
        merged.update({str(k): str(v) for k, v in env.items() if v is not None})
    raw = ""
    for key in WORKFLOW_PATH_KEYS:
        if merged.get(key):
            raw = merged[key]
            break
    paths: list[Path] = []
    seen: set[Path] = set()

    def add(path: Path) -> None:
        resolved = path.expanduser()
        try:
            resolved = resolved.resolve()
        except OSError:
            pass
        if resolved in seen:
            return
        seen.add(resolved)
        paths.append(resolved)

    if raw:
        for part in raw.split(os.pathsep):
            part = part.strip()
            if part:
                add(Path(part))
        return paths
    if parent_path:
        base = parent_path.parent if parent_path.suffix.lower() in YAML_SUFFIXES else parent_path
        add(base)
    catalog = _configured_workflows_dir()
    if catalog is not None and catalog.is_dir():
        add(catalog)
    return paths


def find_workflow(msg: str, roots: list[Path] | None = None) -> Path:
    text = (msg or "").strip()
    if not text:
        raise ValueError("workflow step missing workflow name")
    direct = Path(text).expanduser()
    if direct.is_file() and direct.suffix.lower() in YAML_SUFFIXES:
        return direct.resolve()
    search_roots = list(roots or workflow_search_paths())
    if not direct.is_absolute():
        for root in search_roots:
            if not root.is_dir():
                continue
            for candidate in (root / text, root / f"{text}.yaml", root / f"{text}.yml"):
                if candidate.is_file() and candidate.suffix.lower() in YAML_SUFFIXES:
                    return candidate.resolve()
    refs = _index_workflows(search_roots)
    hits = _match_workflow_refs(text, refs)
    unique: list[_WorkflowRef] = []
    seen: set[Path] = set()
    for ref in hits:
        if ref.path in seen:
            continue
        seen.add(ref.path)
        unique.append(ref)
    if len(unique) == 1:
        return unique[0].path
    searched = ", ".join(str(root) for root in search_roots) or "(none)"
    known = ", ".join(sorted({ref.stem for ref in refs} | {ref.name for ref in refs})) or "(none)"
    if unique:
        found = ", ".join(str(ref.path) for ref in unique)
        raise ValueError(f"ambiguous workflow {text!r}; matches: {found}")
    raise ValueError(f"unknown workflow {text!r}; searched: {searched}; have: {known}")


@dataclass
class _WorkflowRef:
    path: Path
    stem: str
    name: str


def _index_workflows(roots: list[Path]) -> list[_WorkflowRef]:
    files: list[Path] = []
    seen: set[Path] = set()
    for root in roots:
        try:
            root = root.expanduser().resolve()
        except OSError:
            continue
        candidates: list[Path] = []
        if root.is_file() and root.suffix.lower() in YAML_SUFFIXES:
            candidates.append(root)
        elif root.is_dir():
            try:
                candidates.extend(workflow_yaml_files(root))
            except ValueError:
                continue
        for path in candidates:
            resolved = path.resolve()
            if resolved in seen:
                continue
            if any(part == "cache" for part in resolved.parts):
                continue
            seen.add(resolved)
            files.append(resolved)
    refs: list[_WorkflowRef] = []
    for path in files:
        name = path.stem
        try:
            payload = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            if isinstance(payload, dict):
                config = payload.get("config") or {}
                if isinstance(config, dict) and config.get("name"):
                    name = str(config["name"])
        except (OSError, yaml.YAMLError):
            pass
        refs.append(_WorkflowRef(path=path, stem=path.stem, name=name))
    return refs


def _norm_name(value: str) -> str:
    return _NORM_RE.sub("", (value or "").strip().lower())


def _name_aliases(value: str) -> set[str]:
    text = (value or "").strip().lower()
    stem = Path(text).stem.lower()
    filename = Path(text).name.lower()
    stripped = stem.removeprefix("wf-").removeprefix("wf_")
    aliases = {
        text,
        stem,
        filename,
        stripped,
        _norm_name(text),
        _norm_name(stem),
        _norm_name(filename),
        _norm_name(stripped),
    }
    return {item for item in aliases if item}


def _match_workflow_refs(msg: str, refs: list[_WorkflowRef]) -> list[_WorkflowRef]:
    needles = _name_aliases(msg)
    hits: list[_WorkflowRef] = []
    for ref in refs:
        aliases = _name_aliases(ref.stem) | _name_aliases(ref.name) | _name_aliases(ref.path.name)
        if needles & aliases:
            hits.append(ref)
    return hits


def _configured_workflows_dir() -> Path | None:
    """The workflows folder from workflows-app.yaml, or the project root."""
    from .app_config import workflows_root

    try:
        configured = workflows_root()
    except (OSError, ValueError):
        configured = None
    if configured is not None:
        return configured
    default_repo = project_root()
    if default_repo.is_dir():
        return default_repo
    return None


def _under_workflows_root(path: Path) -> bool:
    """True when `path` lives in the workflows folder from workflows-app.yaml."""
    from .app_config import workflows_root

    root = workflows_root()
    if root is None:
        return False
    try:
        path.resolve().relative_to(root.resolve())
    except (OSError, ValueError):
        return False
    return True


def cg_loop_location() -> Path:
    """The cg-loop script that ships with this skill. A `cg-loop` key replaces it."""
    from .app_config import load_app_config

    configured = load_app_config().cg_loop
    if configured is not None:
        return configured
    bkase = SKILL_ROOT / "scripts" / "bkase"
    if bkase.is_file():
        return bkase
    return SKILL_ROOT / "scripts" / "cg_loop.sh"


def workflow_call_name(workflow: Workflow) -> str:
    """Name passed to cg-loop. A file in the workflows folder is its stem.

    A file in a subfolder is the path under that folder, without the suffix.
    A file anywhere else is the path, so the loop can open it.
    """
    path = workflow.path
    if path is None:
        return workflow.name or ""
    if _under_workflows_root(path):
        try:
            from .app_config import workflows_root

            root = workflows_root()
            relative = path.resolve().relative_to(root.resolve()) if root else path
        except (OSError, ValueError):
            return str(path)
        if len(relative.parts) == 1:
            return path.stem
        return relative.with_suffix("").as_posix()
    return str(path)


def format_workflow_run_command(argv: list[str]) -> str:
    """The `bkase` line that started this process, quoted so a shell can run it again."""
    return " ".join(shlex.quote(part) for part in ["bkase", *argv])


def workflow_bash_command(workflow: Workflow, params: dict[str, Any] | None = None) -> str:
    """One cg-loop line that runs this group, named, with the step's params.

    The script is the one that ships with this skill. A workflows-app.yaml
    `cg-loop` key replaces it. A workflow file in the workflows folder is
    passed by name. The loop finds the file there.
    """
    script = cg_loop_location()
    args = ["bkase"] if script.name == "bkase" else ["bash", str(script)]
    if workflow.group:
        args.extend(["--only", workflow.group])
    name = workflow_call_name(workflow)
    if name:
        args.append(name)
    for key, value in (params or {}).items():
        args.extend(["--param", f"{key}={value}"])
    return " ".join(shlex.quote(str(part)) for part in args)


def resolve_subworkflow(
    step: Step,
    *,
    env: dict[str, str] | None = None,
    parent: Workflow | None = None,
    stack: tuple[Path, ...] = (),
    name: str | None = None,
    params: dict[str, Any] | None = None,
    scope: Workflow | None = None,
) -> Workflow:
    """Load a named workflow and overlay params, inheriting parent env/config.

    `msg` defaults to the workflow name. One group runs as itself. Several
    groups need `wf_all` or a group list. A trailing `wf_*` token (or
    `workflow:` + `msg` as the group) selects groups.
    """
    search_env = dict(parent.env) if parent else {}
    if env:
        search_env.update(env)
    raw_params = dict(step.params if params is None else params)
    explicit = str(
        raw_params.pop("workflow", "")
        or (step.workflow_ref or "")
    ).strip()
    msg = str(name if name is not None else step.workflow_name or "").strip()
    lookup, groups = split_workflow_msg(msg, explicit=explicit)
    param_only = str(raw_params.pop("only", "") or "").strip()
    only = groups or param_only
    if not lookup:
        raise ValueError(
            "workflow step missing workflow name; set workflow: or msg to a YAML in WORKFLOW_PATH"
        )
    found = _loaded_group(scope or parent, lookup)
    if found is not None and _defer_group(lookup):
        cloned = _clone_workflow(found)
        if parent:
            _inherit_env_tree(cloned, parent.env)
            _fill_attr_tree(cloned, "cdp_url", parent.cdp_url)
            _fill_attr_tree(cloned, "profile", parent.profile)
        apply_overrides(cloned, _stringify_params(raw_params))
        if only:
            cloned = select_workflows(cloned, only)[0]
        return cloned
    parent_path = parent.path if parent else None
    path = find_workflow(lookup, workflow_search_paths(search_env, parent_path))
    nested = load_workflow(path, _stack=stack)
    if parent:
        _inherit_env_tree(nested, parent.env)
        _fill_attr_tree(nested, "cdp_url", parent.cdp_url)
        _fill_attr_tree(nested, "profile", parent.profile)
    apply_overrides(nested, _stringify_params(raw_params))
    nested = select_workflows(nested, only)[0]
    return nested


def split_workflow_msg(msg: str, *, explicit: str = "") -> tuple[str, str]:
    """Split msg into (workflow lookup, wf groups).

    msg is the workflow name and groups are empty (one group, or wf_all to run every group).
    `workflow:` / `params.workflow` makes msg the group filter instead.
    """
    ref = (explicit or "").strip()
    text = (msg or "").strip()
    if ref:
        return ref, text
    if not text:
        return "", ""
    parts = text.split(None, 1)
    if len(parts) == 2 and _looks_like_group(parts[1]):
        return parts[0], parts[1]
    return text, ""


def _looks_like_group(value: str) -> bool:
    text = (value or "").strip().lower()
    if not text:
        return False
    if "|" in text or "," in text:
        parts = [part.strip() for part in re.split(r"[|,]", text) if part.strip()]
        return bool(parts) and all(_looks_like_group(part) for part in parts)
    return _is_group_token(text)
