"""The browser tool model chooses actions. The chat model writes text, commands, and python or term scripts."""

from __future__ import annotations

import contextvars
import json
import math
import os
import pprint
import re
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterator, TypeVar

import httpx
from openai import OpenAI

from .extract import canonical_url, parse_rss_items, skip_url_set
from .questions import (
    BROWSER_JS,
    COMPILE_ACTION,
    COMPILE_BROWSER,
    COMPILE_EXTRACT,
    COMPILE_PYTHON,
    COMPILE_STEP,
    NEXT_ACTION,
    SECOND_ACTION,
    STEP_CODE,
    TARGET,
    TERM_VALUE,
    TEXT_VALUE,
)
from .workflow import Step, Workflow

OPENROUTER_URL = "https://openrouter.ai/api/v1"
OPENROUTER_FREE_MODEL = "deepseek/deepseek-v3.2"
OPENROUTER_SYSTEMONE_URL = OPENROUTER_URL + "/systemone"
JEV_MODEL = "jev-latest"
DEFAULT_BROWSER_TOOL_MODEL = "von"
LOCAL_URL = "http://127.0.0.1:1234/v1"
LOCAL_MODEL = "qwen3.8-27b-mlx"

LM_STUDIO_URL = os.environ.get("LM_STUDIO_BASE_URL", LOCAL_URL)
MODEL = os.environ.get("LM_STUDIO_MODEL", LOCAL_MODEL)
API_KEY = os.environ.get("LM_STUDIO_API_KEY", "lm-studio")
PROVIDER = "local"
# "model" is the on-machine chat model. "lmstudio" is the LM Studio server.
# "openrouter" is the hosted API. A local Hugging Face text model stays on "model".
_CHAT = "lmstudio"
DEFAULT_LLM_TIMEOUT = 30.0
LOCAL_FALLBACK_TIMEOUT = 120.0
CONNECT_TIMEOUT = 5.0
# One extra attempt after a timeout or connection failure, before that model is skipped.
LLM_TRANSPORT_RETRIES = 1
LLM_TIMEOUT = DEFAULT_LLM_TIMEOUT
# A Hug answer stays short. Python and browser compile need a full script.
_HUG_CHAT_MAX_TOKENS = 4096
BROWSER_TOOL_MODEL = DEFAULT_BROWSER_TOOL_MODEL
_LAYA_ROUTER: Any = None
FALLBACKS: list[tuple[str, str, float | None]] = []
_CONFIG_ENV: dict[str, str] = {}
_PRIMARY: tuple[str, str, str, str, str, str] = ("local", LOCAL_URL, LOCAL_MODEL, "lm-studio", "local", "lmstudio")
_DOWN: set[tuple[str, str]] = set()
_T = TypeVar("_T")

_JSON_RE = re.compile(r"\{.*\}", re.DOTALL)
_SPECIAL_TOKEN_RE = re.compile(r"<\|[^|>]+\|>")
# GPT-2 byte-level BPE spells whitespace as these letters. DeepSeek sometimes returns them raw.
_GPT2_WS = str.maketrans({"\u0120": " ", "\u010a": "\n", "\u0109": "\t", "\u010d": "\r"})
_SECRET_RE = re.compile(r"sk-or-v1-[A-Za-z0-9]+|sk-[A-Za-z0-9_-]{12,}")
_THINK_RE = re.compile(r"<think(?:ing)?>([\s\S]*?)</think(?:ing)?>", re.IGNORECASE)
_FENCE_RE = re.compile(r"^```(?:python)?\s*([\s\S]*?)\s*```$", re.IGNORECASE)
_llm_ms = 0.0
_exchange_log: Any = None


@dataclass
class _ApiLog:
    folder: Path
    started: bool = False


_api_log_dir: contextvars.ContextVar[_ApiLog | None] = contextvars.ContextVar("cg_loop_api_log", default=None)
_COMPILE_WORKFLOW: contextvars.ContextVar[Any] = contextvars.ContextVar("cg_loop_compile_workflow", default=None)
_COMPILE_PYTHON_STEP: contextvars.ContextVar[Any] = contextvars.ContextVar("cg_loop_compile_python_step", default=None)
_JSON_KEYS = {"operation", "text", "command", "confidence", "click_target", "term_target", "selector"}

_REASON_KEYS = ("reasoning", "reasoning_content", "reasoning_details", "thinking")
_TEXT_KEYS = ("text", "summary", "content", "reasoning", "thinking")


def reset_llm_time() -> None:
    global _llm_ms
    _llm_ms = 0.0


def llm_time_ms() -> float:
    return _llm_ms


def set_exchange_log(callback: Any) -> None:
    """Record each JSON model call: messages, thinking, raw reply, and parse error."""
    global _exchange_log
    _exchange_log = callback


class ChatError(Exception):
    """The model reply could not be used. The exchange is already in the compile log."""

    def __init__(self, message: str, *, text: str = "", transport: bool = False) -> None:
        super().__init__(message)
        self.text = text
        self.transport = transport


def _charge_llm(started: float) -> None:
    global _llm_ms
    _llm_ms += (time.perf_counter() - started) * 1000


KIND_TO_OP = {
    "click": "CLICK",
    "fill": "TYPE_TEXT",
    "select": "SELECT",
}

CONTROL_OPS = {
    "scroll_up": "SCROLL_UP",
    "scroll_down": "SCROLL_DOWN",
    "wait": "WAIT",
}


def load_env_file(path: Path | str) -> None:
    """Fill unset process env vars from a dotenv file. Values already set win."""
    file = Path(path)
    if not file.is_file():
        return
    for line in file.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#") or "=" not in text:
            continue
        if text.startswith("export "):
            text = text[len("export ") :].strip()
        key, value = text.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'\"")
        if key:
            os.environ.setdefault(key, value)


def configure(
    llm: str = "",
    model: str = "",
    env: dict[str, str] | None = None,
    *,
    timeout: float | None = None,
    fallbacks: list[tuple[str, str]] | None = None,
    browser_tool_model: str = "",
) -> None:
    """Point chat calls at the local model, LM Studio, or OpenRouter. Empty llm keeps local.

    A local model listed as text under tool-details `hug.models` runs on this
    machine. It does not call LM Studio. LM Studio is used only for a local
    name that is not one of those models.
    `env` is the workflow config.env. It overrides the process environment for
    the key, base URL, and model. `timeout` is the chat-call deadline in seconds.
    `fallbacks` are tried, in order, when the primary chat model call fails.
    `browser_tool_model` chooses browser actions and tool routing.
    `von` and `layla` run locally. Any other name, including `jev-latest`,
    calls Jev on OpenRouter. Python and browser compile use their own sections.
    `llm: local` with a listed text model, such as Bonsai, runs on this machine.
    Term compile stays on the chat model.
    """
    global LLM_TIMEOUT, FALLBACKS, _CONFIG_ENV, _PRIMARY, _DOWN, BROWSER_TOOL_MODEL
    LLM_TIMEOUT = _timeout_seconds(timeout)
    _DOWN = set()
    merged = dict(os.environ)
    if env:
        merged.update({str(key): "" if value is None else str(value) for key, value in env.items()})
    _CONFIG_ENV = merged
    if fallbacks is not None:
        FALLBACKS = [_normalize_fallback(item) for item in fallbacks]
    _apply_provider(llm, model, merged)
    BROWSER_TOOL_MODEL = _browser_model_name(browser_tool_model, merged)
    _PRIMARY = _snapshot()


def activate(llm: str, model_name: str = "") -> None:
    """Switch the current chat endpoint without changing the primary or the fallback list."""
    _apply_provider(llm, model_name, _CONFIG_ENV)


def restore() -> None:
    """Return chat calls to the primary endpoint from the last configure()."""
    _apply_snapshot(_PRIMARY)


def fallback_chain() -> list[tuple[str, str, float | None]]:
    """Primary first, then configured fallbacks, without duplicates. Down models are omitted."""
    primary = (_PRIMARY[0], _PRIMARY[2], None)
    chain = []
    seen: set[tuple[str, str]] = set()
    for llm_name, model_name, slot_timeout in [primary, *FALLBACKS]:
        key = (llm_name, model_name)
        if not llm_name or key in seen or key in _DOWN:
            continue
        seen.add(key)
        chain.append((llm_name, model_name, slot_timeout))
    return chain


def describe() -> str:
    if _CHAT == "model":
        label = "local"
        endpoint = MODEL
        key = "local"
    elif PROVIDER == "openrouter":
        label = "OpenRouter"
        endpoint = LM_STUDIO_URL
        key = "set" if API_KEY else "missing"
    else:
        label = "LM Studio"
        endpoint = LM_STUDIO_URL
        key = repr(API_KEY)
    text = (
        f"{label}: {endpoint}  model={MODEL}  key={key}  "
        f"llm-timeout={LLM_TIMEOUT:g}s  browser-tool-model={browser_model_name()}"
    )
    if FALLBACKS:
        shown = ", ".join(
            f"{name}:{model_name or 'default'}" + (f"@{slot_timeout:g}s" if slot_timeout else "")
            for name, model_name, slot_timeout in FALLBACKS
        )
        text += f"  fallbacks={shown}"
    return text


def _snapshot() -> tuple[str, str, str, str, str, str]:
    return (PROVIDER, LM_STUDIO_URL, MODEL, API_KEY, PROVIDER, _CHAT)


def _apply_snapshot(slot: tuple[str, str, str, str, str, str]) -> None:
    global PROVIDER, LM_STUDIO_URL, MODEL, API_KEY, _CHAT
    PROVIDER, LM_STUDIO_URL, MODEL, API_KEY, _provider, _CHAT = slot
    PROVIDER = _provider


def browser_model_name() -> str:
    """Model for the browser tool, browser compile, and unprefixed tool routing."""
    return BROWSER_TOOL_MODEL or DEFAULT_BROWSER_TOOL_MODEL


def resolve_browser_tool_model(name: str = "", env: dict[str, str] | None = None) -> str:
    """The model configure() will use. An empty name falls through to env, then Von."""
    merged = dict(os.environ)
    if env:
        merged.update({str(key): "" if value is None else str(value) for key, value in env.items()})
    return _browser_model_name(name, merged)


def browser_tool_backend(name: str = "") -> str:
    """`von` and `layla` run on this machine. Every other name is Jev on OpenRouter."""
    key = (name or browser_model_name()).strip().lower()
    if key in {"von", "von-latest"} or key.startswith(("von-", "wfzyx/von")):
        return "von"
    if key in {"layla", "laya", "layla-latest", "laya-latest"} or key.startswith(("layla-", "laya-")):
        return "laya"
    return "jev"


def workflow_needs_von(workflow: Workflow) -> bool:
    """True when the decision model is Von and a step in this run will call it."""
    from .app_config import load_app_config

    decision = browser_tool_backend(load_app_config().decision_model or "")
    if decision != "von":
        return False
    steps = workflow.all_steps()
    browser = browser_tool_backend(resolve_browser_tool_model(workflow.browser_tool_model, workflow.env))
    if browser == "von" and any(step.tool == "browser" and step.kind == "goal" for step in steps):
        return True
    return any(_asks_decision_model(step) for step in steps)


def load_von_if_needed(workflow: Workflow) -> None:
    """Load Von once, before the first step, when the decision model is Von.

    A job asks the shared models process. The weights stay there for the next run.
    """
    if not workflow_needs_von(workflow):
        return
    from .resident import call, use_resident

    if use_resident():
        call("load", {"id": "von"}, timeout=900)
        return
    _load_von_weights()


def workflow_needs_laya(workflow: Workflow) -> bool:
    """True when a step in this run will ask local Laya."""
    from .app_config import load_app_config

    decision = browser_tool_backend(load_app_config().decision_model or "")
    browser = browser_tool_backend(resolve_browser_tool_model(workflow.browser_tool_model, workflow.env))
    steps = workflow.all_steps()
    if browser == "laya" and any(step.tool == "browser" and step.kind == "goal" for step in steps):
        return True
    return decision == "laya" and any(_asks_decision_model(step) for step in steps)


def _asks_decision_model(step: Any) -> bool:
    """A step with no tool, or a condition check the loop cannot decide itself."""
    if step.kind == "goal" and not step.tool:
        return True
    if step.kind != "condition":
        return False
    text = (step.condition or "").lower()
    if not text:
        return False
    if "found" in text and ("story_folder" in text or "short_folder" in text):
        return False
    return True


def _is_hug_text_model(name: str) -> bool:
    """True when `name` is a text model listed under tool-details `hug.models`."""
    model_id = (name or "").strip()
    if not model_id or "/" not in model_id:
        return False
    try:
        from .app_config import tool_models
    except Exception:
        return False
    spec = tool_models("hug").get(model_id)
    if spec is None:
        return False
    return (spec.kind or "text") == "text"


def hug_models_for_run(workflow: Workflow) -> list[str]:
    """Local text models this run will ask. Chat, python compile, and browser compile."""
    found: list[str] = []

    def add(name: str) -> None:
        model_id = (name or "").strip()
        if model_id and model_id not in found and _is_hug_text_model(model_id):
            found.append(model_id)

    for node in _workflow_nodes(workflow):
        steps = _own_steps(node)
        if any(step.kind in {"generate", "llm_call"} for step in steps):
            add(node.model)
        python_steps = [step for step in steps if _step_asks_python_model(step)]
        if any(_step_python_hug_model(step) is None for step in python_steps):
            add(_compile_hug_model("python", node))
        for step in python_steps:
            named = _step_python_hug_model(step)
            if named:
                add(named)
        if any(_step_asks_browser_model(step) for step in steps):
            add(_compile_hug_model("browser", node))
    return found


def _workflow_nodes(workflow: Workflow) -> list[Workflow]:
    """This workflow, its groups, and workflows nested inside a step."""
    found: list[Workflow] = []
    seen: set[int] = set()

    def walk(node: Workflow | None) -> None:
        if node is None or id(node) in seen:
            return
        seen.add(id(node))
        found.append(node)
        for extra in node.extras:
            walk(extra)
        for step in _own_steps(node):
            nested = getattr(step, "nested", None)
            if isinstance(nested, Workflow):
                walk(nested)

    walk(workflow)
    return found


def _own_steps(workflow: Workflow) -> list[Any]:
    """Steps on this workflow. Nested workflows are separate nodes."""
    from .workflow import runnable_steps

    found: list[Any] = []

    def walk(step: Any) -> None:
        found.append(step)
        for child in (*getattr(step, "checks", ()), *getattr(step, "steps", ())):
            walk(child)

    for step in runnable_steps(workflow):
        walk(step)
    return found


def workflow_needs_hug_chat(workflow: Workflow) -> bool:
    """True when this run will ask a Hugging Face text model."""
    return bool(hug_models_for_run(workflow))


def load_hug_chat_if_needed(workflow: Workflow) -> None:
    """Load each Hugging Face text model once, before the first step.

    A job asks the shared models process. The weights stay there for the next run.
    A load failure is printed and left for the step, which can use a fallback.
    """
    models = hug_models_for_run(workflow)
    if not models:
        return
    from .hug import hug_download_enabled
    from .resident import call, use_resident

    download = hug_download_enabled(workflow.env)
    for model_id in models:
        try:
            if use_resident():
                call("load", {"id": model_id, "download": download}, timeout=900)
                continue
            _load_hug_text(model_id, download=download)
        except Exception as exc:
            print(f"hug model={model_id} is not loaded: {exc}", flush=True)


def _step_asks_python_model(step: Any) -> bool:
    """A /python goal or an extract is written by the python compile model."""
    if step.kind == "extract":
        return True
    return getattr(step, "tool", "") == "python" and step.kind == "goal"


def _step_python_hug_model(step: Any) -> str | None:
    """A local id from `+model`. None uses the python section. Blank is hosted."""
    params = getattr(step, "params", None) or {}
    if not str(params.get("model") or "").strip():
        return None
    llm_name = str(params.get("llm") or "").strip().lower()
    if llm_name in {"local", "hug"}:
        return str(params.get("compile_model") or "").strip()
    return ""


def _step_asks_browser_model(step: Any) -> bool:
    """A /browser goal or generated page script is written by the browser compile model."""
    return getattr(step, "tool", "") == "browser" and step.kind in {"goal", "browser_js"}


def _compile_hug_model(tool: str, workflow: Workflow) -> str:
    """The local text model one compile section will call. Empty for a hosted provider."""
    llm_name, model_name, _timeout, _fallbacks = resolve_compile(tool, workflow)
    provider = (llm_name or "").strip().lower()
    if provider in {"openrouter", "open-router", "lmstudio"}:
        return ""
    if not provider:
        return (workflow.model or "").strip()
    if provider in {"local", "hug", "model"}:
        return (model_name or "").strip()
    return ""


def _load_hug_text(model_id: str, *, download: bool) -> None:
    from .hug import _cached, _load_text_backend

    _generate, load = _load_text_backend(model_id, download=download)
    _cached("text", model_id, load)


def load_laya_if_needed(workflow: Workflow) -> None:
    """Install Laya if it is missing, then load it once before the first step.

    A job asks the shared models process. A model that is already loaded is reused.
    """
    if not workflow_needs_laya(workflow):
        return
    from .resident import call, use_resident

    if use_resident():
        call("load", {"id": "laya"}, timeout=900)
        return
    ensure_laya_router()


def _quiet_von_logs() -> None:
    """Von’s tokenizer warns once on the first call. That is not a step action."""
    import logging

    logging.getLogger("transformers").setLevel(logging.ERROR)
    logging.getLogger("huggingface_hub").setLevel(logging.ERROR)
    try:
        from transformers.utils import logging as transformers_logging
    except ImportError:
        return
    transformers_logging.set_verbosity_error()


def _load_von_weights() -> None:
    _quiet_von_logs()
    try:
        from von.engine import VonEngine
    except ImportError as exc:
        raise ChatError("von-sdk is not installed. Install it with: pip install von-sdk") from exc
    engine = VonEngine.get_instance()
    loader = getattr(engine.backend, "_get_model", None)
    if not callable(loader):
        raise ChatError("von-sdk is installed but its model could not be loaded")
    loader()


def _browser_model_name(name: str, env: dict[str, str]) -> str:
    picked = (name or env.get("BROWSER_TOOL_MODEL") or env.get("TYPESAFE_MODEL") or DEFAULT_BROWSER_TOOL_MODEL).strip()
    return picked or DEFAULT_BROWSER_TOOL_MODEL


def _apply_provider(llm: str, model_name: str, env: dict[str, str]) -> None:
    global LM_STUDIO_URL, MODEL, API_KEY, PROVIDER, _CHAT
    provider = (llm or env.get("CG_LOOP_LLM") or "local").strip().lower()
    if provider in {"openrouter", "open-router"}:
        PROVIDER = "openrouter"
        _CHAT = "openrouter"
        LM_STUDIO_URL = (env.get("OPENROUTER_BASE_URL") or OPENROUTER_URL).strip()
        MODEL = (model_name or env.get("OPENROUTER_MODEL") or OPENROUTER_FREE_MODEL).strip()
        API_KEY = (env.get("OPENROUTER_API_KEY") or "").strip()
        return
    picked = (model_name or env.get("LM_STUDIO_MODEL") or LOCAL_MODEL).strip()
    if provider in {"local", "hug", ""} and (provider == "hug" or _is_hug_text_model(picked)):
        PROVIDER = "local"
        _CHAT = "model"
        LM_STUDIO_URL = ""
        MODEL = picked
        API_KEY = ""
        return
    PROVIDER = "local"
    _CHAT = "lmstudio"
    LM_STUDIO_URL = (env.get("LM_STUDIO_BASE_URL") or LOCAL_URL).strip()
    MODEL = picked
    API_KEY = (env.get("LM_STUDIO_API_KEY") or "lm-studio").strip()


def _timeout_seconds(value: Any) -> float:
    if value is None or value == "":
        return DEFAULT_LLM_TIMEOUT
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return DEFAULT_LLM_TIMEOUT
    if seconds <= 0:
        return DEFAULT_LLM_TIMEOUT
    return seconds


def client() -> OpenAI:
    if PROVIDER == "openrouter" and not API_KEY:
        raise ChatError("OPENROUTER_API_KEY is not set", transport=True)
    kwargs: dict[str, Any] = {
        "base_url": LM_STUDIO_URL,
        "api_key": API_KEY,
        "timeout": httpx.Timeout(LLM_TIMEOUT, connect=CONNECT_TIMEOUT),
        "max_retries": 0,
    }
    if PROVIDER == "openrouter":
        kwargs["default_headers"] = {"X-OpenRouter-Title": "cg-loop"}
    return OpenAI(**kwargs)


def _normalize_fallback(item: tuple[Any, ...]) -> tuple[str, str, float | None]:
    name = str(item[0] or "").strip().lower()
    model_name = str(item[1] or "").strip() if len(item) > 1 else ""
    if len(item) > 2 and item[2] is not None and item[2] != "":
        slot_timeout: float | None = _timeout_seconds(item[2])
    elif name == "local":
        slot_timeout = LOCAL_FALLBACK_TIMEOUT
    else:
        slot_timeout = None
    return name, model_name, slot_timeout


def _is_transport(exc: BaseException) -> bool:
    """A timeout, a dropped connection, or a local server with no model loaded.

    A reply that arrived and could not be used is not a transport failure.
    """
    if getattr(exc, "transport", False):
        return True
    if isinstance(exc, (TimeoutError, ConnectionError, OSError)):
        return True
    if type(exc).__name__ in {
        "APITimeoutError",
        "APIConnectionError",
        "ConnectError",
        "ConnectTimeout",
        "ReadTimeout",
    }:
        return True
    return "no models loaded" in str(exc).lower()


def _first_success(run: Callable[[], _T]) -> _T:
    """Try the primary, then each fallback after a timeout.

    A timeout or connection failure is sent once more to the same model.
    A bad reply stays on the primary and is not retried.
    """
    global LLM_TIMEOUT
    saved = _snapshot()
    saved_timeout = LLM_TIMEOUT
    last: BaseException | None = None
    try:
        chain = fallback_chain()
        if not chain:
            raise ChatError("every configured model already failed in this run", transport=True)
        primary_key = (_PRIMARY[0], _PRIMARY[2])
        for llm_name, model_name, slot_timeout in chain:
            if (llm_name, model_name) != primary_key:
                limit = f"{slot_timeout:g}s" if slot_timeout else f"{saved_timeout:g}s"
                print(f"FALLBACK {llm_name} model={model_name or 'default'} timeout={limit}")
                _apply_provider(llm_name, model_name, _CONFIG_ENV)
            LLM_TIMEOUT = slot_timeout if slot_timeout is not None else saved_timeout
            for attempt in range(LLM_TRANSPORT_RETRIES + 1):
                try:
                    return run()
                except Exception as exc:
                    last = exc
                    print(f"LLM failed model={MODEL}: {exc}")
                    if not _is_transport(exc):
                        raise
                    if attempt < LLM_TRANSPORT_RETRIES:
                        print(f"RETRY model={MODEL}")
                        continue
                    _DOWN.add((llm_name, model_name))
                    print(f"skipping {llm_name} model={model_name or MODEL} for the rest of this run")
                    break
        if last is None:
            raise RuntimeError("LLM request was not sent")
        raise last
    finally:
        LLM_TIMEOUT = saved_timeout
        _apply_snapshot(saved)


def _completion(**kwargs: Any) -> Any:
    """One chat completion. On failure, try each configured fallback, then restore the primary."""

    def run() -> Any:
        call = dict(kwargs)
        if "model" in call:
            call["model"] = MODEL
        return _completion_once(**call)

    return _first_success(run)


def _bounded(run: Callable[[], _T]) -> _T:
    """Run `run` and stop it at LLM_TIMEOUT. A still-running call is abandoned."""
    box: dict[str, Any] = {}
    error: list[BaseException] = []

    def work() -> None:
        try:
            box["response"] = run()
        except BaseException as exc:
            error.append(exc)

    thread = threading.Thread(target=work, daemon=True)
    thread.start()
    thread.join(LLM_TIMEOUT)
    if thread.is_alive():
        raise TimeoutError(f"LLM request timed out after {LLM_TIMEOUT:g}s")
    if error:
        raise error[0]
    return box["response"]


def _close_client(api: OpenAI) -> None:
    """Drop a timed-out client. A stuck close must not hold the next attempt."""
    try:
        api.close()
    except Exception:
        return


def _hug_chat_prompt(messages: Any) -> str:
    """One instruction for a Hugging Face text model. System and user text are both kept."""
    parts: list[str] = []
    if isinstance(messages, list):
        for message in messages:
            if not isinstance(message, dict):
                continue
            content = message.get("content")
            text = content.strip() if isinstance(content, str) else ""
            if text:
                parts.append(text)
    prompt = "\n\n".join(parts).strip()
    if not prompt:
        raise ChatError("hug chat has no prompt")
    return prompt


@dataclass
class _ReplyMessage:
    content: str

    def model_dump(self) -> dict[str, str]:
        return {"content": self.content}


@dataclass
class _Reply:
    model: str
    choices: list[Any]


def _text_reply(content: str, model_name: str) -> _Reply:
    return _Reply(model=model_name, choices=[type("Choice", (), {"message": _ReplyMessage(content)})()])


def _hug_completion(kwargs: dict[str, Any]) -> _Reply:
    """One chat completion on the configured Hugging Face text model."""
    from .hug import ask_hug, hug_download_enabled

    messages = kwargs.get("messages")
    prompt = _hug_chat_prompt(messages)
    _note_api_call(
        f"hug://{MODEL}",
        {"Content-Type": "application/json"},
        {"model": MODEL, "messages": messages or []},
    )
    try:
        text = ask_hug(
            MODEL,
            prompt,
            [],
            download=hug_download_enabled(_CONFIG_ENV),
            messages=messages if isinstance(messages, list) else None,
            max_tokens=_HUG_CHAT_MAX_TOKENS,
        )
    except ValueError as exc:
        raise ChatError(str(exc)) from exc
    except ChatError:
        raise
    except Exception as exc:
        raise ChatError(str(exc), transport=True) from exc
    return _text_reply(text, MODEL)


def _completion_once(**kwargs: Any) -> Any:
    """One chat completion, stopped at LLM_TIMEOUT even if the socket stays open.

    A Hugging Face chat model is asked in this same call, so the same deadline applies.
    The HTTP read timeout resets whenever any bytes arrive, including HTTP/2
    keepalive frames, so a stuck model can hold the connection past that limit.
    Closing the client unblocks the read. That close runs aside so a socket
    that ignores the close cannot add another full timeout.
    """
    if _CHAT == "model":
        return _bounded(lambda: _hug_completion(kwargs))
    _note_api_call(*_chat_completion_request(kwargs))
    api = client()
    box: dict[str, Any] = {}
    error: list[BaseException] = []

    def run() -> None:
        try:
            box["response"] = api.chat.completions.create(**kwargs)
        except BaseException as exc:
            error.append(exc)

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    thread.join(LLM_TIMEOUT)
    if thread.is_alive():
        closer = threading.Thread(target=_close_client, args=(api,), daemon=True)
        closer.start()
        closer.join(0.2)
        raise TimeoutError(f"LLM request timed out after {LLM_TIMEOUT:g}s")
    if error:
        raise error[0]
    return box["response"]


def _accessible_name(action: dict[str, Any]) -> str:
    named = action.get("name")
    if isinstance(named, str) and named.strip():
        return named.strip()
    label = str(action.get("label") or "")
    kind = action.get("kind")
    if kind == "select" and " → " in label:
        label = label.split(" → ", 1)[0]
    if kind == "click" and label.startswith("Open "):
        label = label[len("Open ") :]
    return label.strip()


def _option_label(action: dict[str, Any]) -> str:
    label = str(action.get("label") or "")
    if " → " in label:
        return label.split(" → ", 1)[1].strip()
    return str(action.get("value") or "").strip()


def _role_selector(role: str, name: str, nth: int | None = None) -> str:
    """Playwright role selector. `s` requires the accessible name to match exactly."""
    base = f"role={role or 'generic'}[name={json.dumps(name)}s]"
    if nth is None:
        return base
    return f"{base} >> nth={nth}"


def _nth_for_nodes(actions: list[dict[str, Any]]) -> dict[tuple[str, str, Any], int | None]:
    """nth is set only when two controls share a role and accessible name."""
    order: dict[tuple[str, str], list[Any]] = {}
    for action in actions:
        if action.get("kind") not in KIND_TO_OP:
            continue
        ident = (str(action.get("role") or ""), _accessible_name(action))
        nodes = order.setdefault(ident, [])
        node = action.get("node")
        if node not in nodes:
            nodes.append(node)
    nth: dict[tuple[str, str, Any], int | None] = {}
    for ident, nodes in order.items():
        for position, node in enumerate(nodes):
            nth[(*ident, node)] = position if len(nodes) > 1 else None
    return nth


def _with_selector(action: dict[str, Any], nth: int | None) -> dict[str, Any]:
    stored = dict(action)
    option = _option_label(action) if action.get("kind") == "select" else None
    element = _role_selector(str(action.get("role") or ""), _accessible_name(action), nth)
    stored["selector"] = element
    if option is None:
        stored["selector_key"] = element
    else:
        stored["selector_key"] = f"{element} >> option={json.dumps(option)}"
    return stored


def action_space(
    page: dict[str, Any] | None,
    step: Step | None,
    variables: dict[str, Any],
    *,
    command_catalog: str = "",
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    """One index per observed element; each operation has its own valid targets.

    Every element action also gets a role selector. Browser steps offer that
    selector instead of the index.
    """
    elements: list[dict[str, Any]] = []
    indices: dict[Any, str] = {}
    targets: dict[str, dict[str, Any]] = {}
    controls: dict[str, dict[str, Any]] = {}
    actions = list((page or {}).get("actions") or [])
    nth_for = _nth_for_nodes(actions)
    for action in actions:
        kind = action.get("kind")
        if kind not in KIND_TO_OP:
            controls[CONTROL_OPS.get(action.get("id"), str(action.get("id") or "").upper())] = action
            continue
        node = action.get("node")
        if node not in indices:
            index = str(len(elements) + 1)
            indices[node] = index
            element = {
                k: action[k]
                for k in ("role", "value", "checked", "selected", "expanded", "href", "view")
                if k in action
            }
            element.update(index=index, label=str(action.get("label") or "").split(" → ")[0], operations=[])
            if kind == "select":
                element["value"] = action.get("current_value", "")
                element["options"] = []
            elements.append(element)
        index = indices[node]
        operation = KIND_TO_OP[kind]
        group = targets.setdefault(operation, {})
        element = elements[int(index) - 1]
        if operation not in element["operations"]:
            element["operations"].append(operation)
        nth = nth_for.get((str(action.get("role") or ""), _accessible_name(action), node))
        stored = _with_selector(action, nth)
        element["selector"] = stored["selector"]
        target = index
        if kind == "select":
            target = f"{index}:{len(element['options']) + 1}"
            element["options"].append(
                {
                    "index": target,
                    "selector": stored["selector_key"],
                    "label": action.get("label"),
                    "value": action.get("value"),
                }
            )
        group[target] = stored

    rss_items = parse_rss_items(str((page or {}).get("html") or ""), base_url=str((page or {}).get("url") or ""))
    skip = skip_url_set(variables, (step.extra if step else "") or "")
    if rss_items:
        extract_targets: dict[str, Any] = {}
        for i, item in enumerate(rss_items, 1):
            if canonical_url(str(item.get("url") or "")) in skip:
                continue
            index = str(len(extract_targets) + 1)
            extract_targets[index] = {
                "id": f"rss{i}",
                "kind": "extract",
                "label": f"RSS [{index}] {item.get('title')}",
                "article": item,
            }
        if extract_targets:
            targets["EXTRACT"] = extract_targets

    if step:
        _add_step_controls(controls, targets, step, variables, command_catalog)

    controls.setdefault(
        "DONE",
        {"id": "DONE", "kind": "done", "label": "This step is satisfied."},
    )
    controls.setdefault(
        "BLOCKED",
        {"id": "BLOCKED", "kind": "blocked", "label": "No supported operation can progress."},
    )
    return elements, targets, controls


_CLICK_ROLE = r"button|radio|link|checkbox|tab|switch"
_NAMED_ROLE_CLICK = re.compile(
    rf"click\s+(?:the\s+)?(?P<name>.+?)\s+(?P<role>{_CLICK_ROLE})\b",
    re.IGNORECASE,
)
_WAIT_MAX_UNTIL = re.compile(
    r"\bwait\s+max\s+(?P<seconds>\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?\s+until\b",
    re.IGNORECASE,
)
_WAIT_UNTIL_CLICK = re.compile(
    rf"\bwait\s+max\s+\d+(?:\.\d+)?\s*s(?:ec(?:ond)?s?)?\s+until\s+"
    rf"click\s+(?:the\s+)?"
    rf"(?P<name>\"[^\"]+\"|'[^']+'|[^.\n]+?)"
    rf"(?:\s+(?P<role>{_CLICK_ROLE}))?"
    rf"\s*(?:[.]|$)",
    re.IGNORECASE,
)
_INTO_FIELD = re.compile(
    r"\binto\s+(?:the\s+)?(?P<name>.+?)(?:\s+(?:input\s+)?(?:box|field))?(?=\s*(?:[.]|$|\bwait\b|\bverify\b))",
    re.IGNORECASE,
)
_PLAIN_CLICK = re.compile(
    rf"\bclick\s+(?:the\s+)?(?P<name>\"[^\"]+\"|'[^']+'|[^.\n]{{1,80}}?)"
    rf"(?:\s+(?P<role>{_CLICK_ROLE}))?(?=\s*(?:[.]|$|,\s+then\b|\bthen\b|\+?(?:wait|verify)\b))",
    re.IGNORECASE,
)
_WAIT_UNTIL_ROLE = re.compile(
    rf"\bwait\s+max\s+\d+(?:\.\d+)?\s*s(?:ec(?:ond)?s?)?\s+until\s+"
    rf"(?:the\s+)?(?P<name>\"[^\"]+\"|'[^']+'|(?:(?!\b(?:click|go)\b)[^.\n])+?)\s+(?P<role>{_CLICK_ROLE})\b",
    re.IGNORECASE,
)


_CLICK_PLACE = re.compile(
    r"\s+(?:in|on|from)\s+(?:the\s+)?(?:left\s+)?(?:nav|navigation|menu|sidebar)\s*$",
    re.IGNORECASE,
)


def _click_name(raw: str) -> str:
    """The control label. `Content in left nav` is the control named Content."""
    name = (raw or "").strip().strip("\"'")
    name = re.sub(r"^the\s+", "", name, flags=re.IGNORECASE).strip()
    name = re.sub(r"\s*\+\s*$", "", name).strip()
    return _CLICK_PLACE.sub("", name).strip()


def _wait_until_click(command: str) -> tuple[str, str] | None:
    """`Wait max Ns until Click Close` names a button when no role word is given."""
    from .browser_helper import _verify_as_wait

    match = _WAIT_UNTIL_CLICK.search(_verify_as_wait(command or ""))
    if not match:
        return None
    name = _click_name(match.group("name"))
    if not name:
        return None
    return (match.group("role") or "button").lower(), name


def _wait_until_role(command: str) -> tuple[str, str] | None:
    """`Wait max Ns until Close button` names that control. The page text is just Close."""
    from .browser_helper import _verify_as_wait

    match = _WAIT_UNTIL_ROLE.search(_verify_as_wait(command or ""))
    if not match:
        return None
    name = _click_name(match.group("name"))
    if not name or re.match(r"click\b", name, re.IGNORECASE):
        return None
    return match.group("role").lower(), name


def _named_clicks(command: str) -> list[tuple[str, str]]:
    named: list[tuple[str, str]] = []
    for click in _NAMED_ROLE_CLICK.finditer(command):
        name = _click_name(click.group("name"))
        if name:
            named.append((click.group("role").lower(), name))
    until_click = _wait_until_click(command)
    if until_click and until_click not in named:
        named.append(until_click)
    return named


def _named_controls(command: str) -> list[tuple[str, str]]:
    """Clicks, plus `until Close button`, which is a button named Close."""
    named = _named_clicks(command)
    role_wait = _wait_until_role(command)
    if role_wait and role_wait not in named:
        named.append(role_wait)
    return named


def _priority_names(command: str) -> list[tuple[str, str]]:
    """Role clicks, plus a bare `Click Create`, which is a button."""
    named = _named_controls(command)
    known = {name.casefold() for _role, name in named}
    for click in _PLAIN_CLICK.finditer(command or ""):
        name = _click_name(click.group("name"))
        if not name or name.casefold() in known:
            continue
        named.append(((click.group("role") or "").lower(), name))
        known.add(name.casefold())
    for field in _INTO_FIELD.finditer(command or ""):
        name = _click_name(field.group("name"))
        if not name or name.casefold() in known:
            continue
        named.append(("", name))
        known.add(name.casefold())
    return named


def _locator_priority(action: dict[str, Any], named: list[tuple[str, str]]) -> str:
    """`likely` when this control is the click the step is waiting for.

    A click that names no role matches the label on any role. `view` then
    prefers the one on screen.
    """
    label = _accessible_name(action).casefold()
    role = str(action.get("role") or "").casefold()
    for wanted_role, name in named:
        wanted = name.casefold().strip()
        same_role = not wanted_role or not role or role == wanted_role
        if label == wanted and same_role:
            return "likely"
        # "Schedule content" is the visible label in "click schedule content toggle".
        if (
            not wanted_role
            and len(label.split()) >= 2
            and (wanted == label or wanted.startswith(label + " "))
        ):
            return "likely"
    return "other"


def _wait_locator(
    action: dict[str, Any],
    selector: str,
    seconds: float,
    priority: str,
) -> dict[str, Any]:
    return {
        "id": action.get("id") or "wait_for_locator",
        "kind": "wait_for_locator",
        "label": action.get("label") or selector,
        "selector": action.get("selector") or selector,
        "selector_key": selector,
        "seconds": seconds,
        "role": action.get("role") or "",
        "node": action.get("node"),
        "priority": priority,
    }


def _mark_locator_priority(targets: dict[str, dict[str, Any]], command: str) -> None:
    """Mark every click, type, and select locator. `likely` is the named control."""
    named = _priority_names(command)
    for operation in ("CLICK", "TYPE_TEXT", "SELECT"):
        for action in (targets.get(operation) or {}).values():
            if isinstance(action, dict) and (action.get("selector") or action.get("selector_key")):
                action["priority"] = _locator_priority(action, named) if named else "other"


def _offer_wait_locators(targets: dict[str, dict[str, Any]], command: str) -> None:
    """Offer every page locator, and always the one named by the click.

    `priority` is `likely` for that named control and `other` for the rest.
    Jev can return any of them and should prefer `likely`.
    """
    from .browser_helper import _verify_as_wait, _wait_before_page_action

    command = _verify_as_wait(command)
    if _wait_before_page_action(command) and not _wait_until_role(command) and not _wait_until_click(command):
        return
    if not _WAIT_MAX_UNTIL.search(command):
        return
    named = _named_controls(command)
    if not named:
        return
    seconds = 5.0
    for sentence in re.split(r"(?<=[.])\s+", command):
        match = re.search(
            r"\bwait\s+max\s+(\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?\s+until\b",
            sentence,
            re.IGNORECASE,
        )
        if match:
            seconds = max(0.0, float(match.group(1)))
            break
    offered = targets.setdefault("WAIT_FOR_LOCATOR", {})
    for action in (targets.get("CLICK") or {}).values():
        if not isinstance(action, dict):
            continue
        selector = str(action.get("selector_key") or action.get("selector") or "")
        if not selector:
            continue
        offered[selector] = _wait_locator(action, selector, seconds, _locator_priority(action, named))
    for role, name in named:
        selector = _role_selector(role, name)
        if selector in offered:
            offered[selector]["priority"] = "likely"
            continue
        offered[selector] = _wait_locator(
            {"label": name, "role": role, "selector": selector},
            selector,
            seconds,
            "likely",
        )


def _locator_catalog(targets: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Every role locator already offered for click, type, select, or a wait."""
    catalog: dict[str, dict[str, Any]] = {}
    for operation in ("CLICK", "TYPE_TEXT", "SELECT", "WAIT_FOR_LOCATOR"):
        for key, action in (targets.get(operation) or {}).items():
            if not isinstance(action, dict):
                continue
            selector = str(action.get("selector_key") or action.get("selector") or key or "")
            if selector.startswith("role="):
                catalog.setdefault(selector, action)
    return catalog


def _offer_scroll_locators(
    targets: dict[str, dict[str, Any]],
    controls: dict[str, dict[str, Any]],
) -> None:
    """Scroll uses the same locators as click. The chosen one is the scroll target."""
    catalog = _locator_catalog(targets)
    if not catalog:
        return
    for operation, default_delta in (("SCROLL_DOWN", 720), ("SCROLL_UP", -720)):
        base = controls.get(operation) or {}
        delta = base.get("delta")
        if delta is None:
            delta = default_delta
        targets[operation] = {
            selector: {
                "id": base.get("id") or operation.lower(),
                "kind": "scroll",
                "label": action.get("label") or selector,
                "delta": delta,
                "selector": action.get("selector") or selector,
                "selector_key": selector,
                "role": action.get("role") or "",
                "priority": action.get("priority") or "other",
                "node": action.get("node"),
                **({"view": action["view"]} if action.get("view") else {}),
            }
            for selector, action in catalog.items()
        }


def _command_goto_url(command: str) -> str:
    """The address in `go to studio.youtube.com` or `go https://...`, including when a wait follows it."""
    text = command or ""
    if re.search(r"\bgo\b", text, re.IGNORECASE):
        http = re.search(r"https?://\S+", text, re.IGNORECASE)
        if http:
            return http.group(0).rstrip(".,")
    match = re.search(r"\bgo\s+to\s+(\S+)", text, re.IGNORECASE)
    if not match:
        return ""
    token = match.group(1).strip().strip("\"'").rstrip(".,")
    lowered = token.lower()
    if lowered.startswith(("http://", "https://")):
        return token
    if re.fullmatch(r"(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}(?:/[^\s]*)?", token):
        return "https://" + token
    return ""


def _offer_duration_wait(controls: dict[str, dict[str, Any]], command: str) -> None:
    """`wait 1s` is a timed pause. A phrase wait already on WAIT stays."""
    from .browser_helper import _duration_wait

    if (controls.get("WAIT") or {}).get("phrase"):
        return
    seconds = _duration_wait(command)
    if seconds is None:
        return
    controls["WAIT"] = {
        "id": "WAIT",
        "kind": "wait",
        "label": f"Wait {seconds:g}s",
        "seconds": seconds,
    }


def _control_matches_phrase(phrase: str, action: dict[str, Any]) -> bool:
    """The verify phrase names this control, or the words `Close button`."""
    label = _accessible_name(action).casefold()
    wanted = (phrase or "").casefold().strip()
    if not label or not wanted:
        return False
    if label == wanted:
        return True
    role = str(action.get("role") or "").casefold()
    return bool(role) and wanted == f"{label} {role}"


def _offer_verify_locators(targets: dict[str, dict[str, Any]], command: str) -> None:
    """A verify can be a locator. Offer the controls, and mark the named one likely."""
    from .browser_helper import _verify_as_wait, _verify_clause

    found = _verify_clause(command)
    if found is None:
        return
    phrase, seconds = found
    offered = targets.setdefault("WAIT_FOR_LOCATOR", {})
    role_phrase = _wait_until_role(_verify_as_wait(command))
    named = [role_phrase] if role_phrase else []
    for action in (targets.get("CLICK") or {}).values():
        if not isinstance(action, dict):
            continue
        selector = str(action.get("selector_key") or action.get("selector") or "")
        if not selector:
            continue
        matched = _control_matches_phrase(phrase, action) or _locator_priority(action, named) == "likely"
        priority = "likely" if matched else "other"
        current = offered.get(selector)
        if isinstance(current, dict) and current.get("priority") == "likely":
            priority = "likely"
        offered[selector] = _wait_locator(action, selector, seconds, priority)
    if role_phrase:
        role, name = role_phrase
        selector = _role_selector(role, name)
        current = offered.get(selector)
        if isinstance(current, dict):
            current["priority"] = "likely"
            current["seconds"] = seconds
        else:
            offered[selector] = _wait_locator(
                {"label": name, "role": role, "selector": selector},
                selector,
                seconds,
                "likely",
            )
    if not offered:
        targets.pop("WAIT_FOR_LOCATOR", None)


def _offer_text_wait(controls: dict[str, dict[str, Any]], command: str) -> None:
    """Offer WAIT for page text. A verify always offers this, and may also offer a locator."""
    from .browser_helper import _showing_phrase, _text_wait, _verify_clause, _wait_seconds

    verify = _verify_clause(command)
    if verify is not None:
        phrase, seconds = verify
        controls["WAIT"] = {
            "id": "WAIT",
            "kind": "wait",
            "label": f"Verify {phrase} as page text, up to {seconds:g}s",
            "phrase": phrase,
            "seconds": seconds,
        }
        return
    waiting = _text_wait(command)
    if waiting is None:
        phrase = _showing_phrase(command)
        if phrase:
            waiting = (phrase, _wait_seconds(command))
    if waiting is None:
        return
    phrase, seconds = waiting
    controls["WAIT"] = {
        "id": "WAIT",
        "kind": "wait",
        "label": f"Wait until {phrase} is showing, up to {seconds:g}s",
        "phrase": phrase,
        "seconds": seconds,
    }


def _add_step_controls(
    controls: dict[str, dict[str, Any]],
    targets: dict[str, dict[str, Any]],
    step: Step,
    variables: dict[str, Any],
    command_catalog: str,
) -> None:
    if step.kind == "goto" and step.url:
        controls["GOTO"] = {
            "id": "GOTO",
            "kind": "goto",
            "label": f"Navigate to {step.url}",
            "url": step.url,
        }
    if step.kind == "term" and step.command:
        targets["TERM"] = {
            "1": {
                "id": "term1",
                "kind": "term",
                "label": step.command,
                "command": step.command,
            }
        }
    elif step.kind == "goal" and step.tool not in {"browser", "python"}:
        targets["TERM"] = {
            "1": {
                "id": "term1",
                "kind": "term",
                "label": "Write and run a shell command for this step",
                "command": "",
                "catalog": command_catalog[:4000],
            }
        }
    if step.kind == "extract":
        controls["EXTRACT"] = {
            "id": "EXTRACT",
            "kind": "extract",
            "label": f"Store the latest matching article in ${step.var or 'article'}",
            "var": step.var or "article",
            "phrase": step.extra,
        }
    if step.kind == "llm_call":
        controls["LLM_CALL"] = {
            "id": "LLM_CALL",
            "kind": "llm_call",
            "label": f"Write {step.template or 'story.md'} from ${step.var or 'article'}",
            "template": step.template,
            "var": step.var,
        }
    if step.kind == "generate":
        controls["GENERATE"] = {
            "id": "GENERATE",
            "kind": "generate",
            "label": f"Generate story from ${step.var or 'article'}",
            "var": step.var,
        }
    if step.tool == "browser":
        goto_url = _command_goto_url(step.raw or "")
        if goto_url:
            controls["GOTO"] = {
                "id": "GOTO",
                "kind": "goto",
                "label": f"Navigate to {goto_url}",
                "url": goto_url,
            }
        controls.setdefault("RELOAD", {"id": "RELOAD", "kind": "reload", "label": "Reload the page."})
        controls.setdefault("BACK", {"id": "BACK", "kind": "back", "label": "Go back."})
        controls.setdefault("FORWARD", {"id": "FORWARD", "kind": "forward", "label": "Go forward."})
        controls.setdefault("PRESS", {"id": "PRESS", "kind": "press", "label": "Press a key.", "key": ""})
        controls.setdefault(
            "SCROLL_DOWN",
            {"id": "scroll_down", "kind": "scroll", "label": "Page down", "delta": 720},
        )
        controls.setdefault(
            "SCROLL_UP",
            {"id": "scroll_up", "kind": "scroll", "label": "Page up", "delta": -720},
        )
        _mark_locator_priority(targets, step.raw or "")
        _offer_wait_locators(targets, step.raw or "")
        _offer_verify_locators(targets, step.raw or "")
        _offer_scroll_locators(targets, controls)
        _offer_text_wait(controls, step.raw or "")
        _offer_duration_wait(controls, step.raw or "")


def _offer_selectors(
    elements: list[dict[str, Any]],
    targets: dict[str, dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    """Key browser targets by selector so the model does not pick a shifting index."""
    offered: dict[str, dict[str, Any]] = {}
    for operation, group in targets.items():
        keyed: dict[str, Any] = {}
        for action in group.values():
            key = str(action.get("selector_key") or action.get("selector") or "")
            if key:
                keyed[key] = action
            else:
                keyed[str(len(keyed) + 1)] = action
        offered[operation] = keyed
    for element in elements:
        element.pop("index", None)
        for option in element.get("options") or []:
            if isinstance(option, dict):
                option.pop("index", None)
    return elements, offered


def choose_request(
    page: dict[str, Any] | None,
    step: Step,
    history: list[dict[str, Any]],
    variables: dict[str, Any],
    *,
    command_catalog: str = "",
    plan: str = "",
    system: str = "",
    rules: list[str] | None = None,
    selectors: bool = False,
) -> dict[str, Any]:
    """The action-choice LLM call for one page, without sending it."""
    elements, targets, controls = action_space(
        page, step, variables, command_catalog=command_catalog
    )
    if selectors:
        elements, targets = _offer_selectors(elements, targets)
    labels = {
        "CLICK": "Click an element, button, menu option, autocomplete suggestion, or calendar day.",
        "TYPE_TEXT": "Enter or replace text in an editable field. A small LLM will supply the value.",
        "SELECT": "Select an observed dropdown value.",
        "EXTRACT": "Store an observed RSS/article item into the step variable.",
        "TERM": "Run a shell command. A small LLM writes the command only if it is not already complete.",
        "GOTO": "Open a URL. Set url to an http address or a host such as studio.youtube.com.",
        "RELOAD": "Reload the current page.",
        "BACK": "Go back in history.",
        "FORWARD": "Go forward in history.",
        "PRESS": "Press a key. Set key, for example Enter, Escape, or Tab.",
        "SCROLL_UP": "Scroll the page up.",
        "SCROLL_DOWN": "Scroll the page down.",
        "WAIT": "Wait for the page to update.",
        "WAIT_FOR_LOCATOR": (
            "Wait until a Playwright locator exists. "
            "locator.wait_for(state='attached'). Choose the locator named by the click, not page text."
        ),
        "LLM_CALL": "Call the LLM with the template and stored variables.",
        "GENERATE": "Run the story generation pipeline on the stored article.",
    }
    operations: dict[str, str] = {}
    for key in targets:
        operations[key] = labels.get(key, key)
    operations.update({key: value.get("label") or key for key, value in controls.items()})

    payload = {
        "plan": plan,
        "current_step": step.raw,
        "variables": _public_vars(variables),
        "page": {k: (page or {}).get(k) for k in ("url", "title", "text")} if page else {},
        "elements": elements[:80],
        "operations": operations,
        "targets": {
            op: {
                key: {
                    "element": a.get("label") if a.get("selector") else f"[{key}] {a.get('label')}",
                    "selector": a.get("selector_key") or a.get("selector") or "",
                    "current_value": a.get("current_value", a.get("value", "")),
                    **{k: a[k] for k in ("role", "checked", "selected", "expanded", "href", "priority", "view") if k in a},
                }
                if selectors
                else {
                    "element": f"[{key}] {a.get('label')}",
                    "current_value": a.get("current_value", a.get("value", "")),
                    **{k: a[k] for k in ("role", "checked", "selected", "expanded", "href", "priority", "view") if k in a},
                }
                for key, a in group.items()
            }
            for op, group in targets.items()
        },
        "recent_actions": [
            {k: h.get(k) for k in ("action", "selector", "kind", "text", "command", "error", "page_changed")}
            for h in history[-10:]
        ],
        "tool": step.tool,
        "rules": list(rules) if rules is not None else _choose_rules(step),
    }
    prompt = system or (
        NEXT_ACTION
        + "\noperation must be one of the offered operations. "
        "For TERM, command is the code to run."
    )
    return {
        "messages": [
            {"role": "system", "content": prompt},
            {"role": "user", "content": json.dumps(payload, default=str)},
        ],
        "elements": elements,
        "targets": targets,
        "controls": controls,
        "operations": operations,
    }


def decision_from_answer(answer: dict[str, Any], request: dict[str, Any], *, started: float) -> dict[str, Any]:
    """Turn one action-choice reply into the operation and the observed target."""
    elements = request["elements"]
    targets = request["targets"]
    controls = request["controls"]
    operations = request["operations"]
    operation = str(answer.get("operation") or "").upper()
    if not operation and str(answer.get("command") or "").strip():
        operation = "TERM"
    if operation not in operations:
        raise ChatError(f"Model picked unsupported operation {operation!r}")
    target = None
    choice: Any = operation
    probabilities: dict[str, float] = {operation: float(answer.get("confidence") or 1)}
    if operation in targets:
        group = targets[operation]
        if not group:
            raise ChatError(f"Model picked {operation} but no target was offered")
        selector = str(answer.get("selector") or "").strip()
        keyed_by_selector = any(str(key).startswith("role=") for key in group)
        if keyed_by_selector:
            if selector not in group:
                raise ChatError(f"Selector is not offered: {selector or '(missing)'}")
            target = selector
        else:
            key = {
                "CLICK": "click_target",
                "TYPE_TEXT": "type_text_target",
                "SELECT": "select_target",
                "EXTRACT": "extract_target",
                "TERM": "term_target",
            }.get(operation, operation.lower() + "_target")
            target = str(answer.get(key) or next(iter(group)))
            if target not in group:
                target = next(iter(group))
        selected = group[target]
        choice = selected.get("id") or target
        probabilities = {selected.get("id") or target: 1.0}
    elif operation in controls:
        choice = controls[operation]["id"]
    return {
        "choice": choice,
        "operation": operation,
        "target": target,
        "confidence": float(answer.get("confidence") or 1),
        "probabilities": probabilities,
        "raw_answers": answer,
        "command": str(answer.get("command") or ""),
        "message": str(answer.get("message") or ""),
        "url": str(answer.get("url") or ""),
        "key": str(answer.get("key") or ""),
        "locator": str(answer.get("locator") or ""),
        "latency_ms": round((time.perf_counter() - started) * 1000),
        "elements": elements,
        "targets": targets,
        "controls": controls,
        "operations": operations,
    }


def choose(
    page: dict[str, Any] | None,
    step: Step,
    history: list[dict[str, Any]],
    variables: dict[str, Any],
    *,
    command_catalog: str = "",
    plan: str = "",
) -> dict[str, Any]:
    request = choose_request(
        page,
        step,
        history,
        variables,
        command_catalog=command_catalog,
        plan=plan,
    )
    started = time.perf_counter()
    answer = _chat_json(request["messages"])
    return decision_from_answer(answer, request, started=started)


def choose_tool(step: Step) -> str:
    """The local decision model picks a known tool when the step has no /prefix."""
    from .decision import decide_message

    try:
        return decide_message(step.raw, phase="execute").tool
    except ValueError as exc:
        raise ChatError(str(exc)) from exc


@contextmanager
def using_python_provider() -> Iterator[None]:
    """Point one code-generation call at the python tool's provider, model, and timeout."""
    with using_compile_provider("python"):
        yield


@contextmanager
def using_browser_provider() -> Iterator[None]:
    """Point one browser-compile call at the browser tool's provider, model, and timeout."""
    with using_compile_provider("browser"):
        yield


@contextmanager
def bind_compile_workflow(workflow: Any) -> Iterator[None]:
    """Use this workflow's python and browser sections for compile calls inside the block."""
    token = _COMPILE_WORKFLOW.set(workflow)
    try:
        yield
    finally:
        _COMPILE_WORKFLOW.reset(token)


@contextmanager
def bind_python_step(slot: Any) -> Iterator[None]:
    """Use this step's `+model` for python compile calls inside the block."""
    token = _COMPILE_PYTHON_STEP.set(slot)
    try:
        yield
    finally:
        _COMPILE_PYTHON_STEP.reset(token)


def resolve_compile(
    tool: str,
    workflow: Any = None,
) -> tuple[str, str, float, list[tuple[str, str, float | None]] | None]:
    """Provider, model, timeout, and fallbacks for one compile tool.

    The app section is the default. A workflow file's python or browser
    section replaces the fields it sets. An empty provider keeps the chat model.
    """
    from .app_config import compile_llm

    llm_name, model_name, timeout, fallbacks = compile_llm(tool)
    node = workflow if workflow is not None else _COMPILE_WORKFLOW.get()
    tool_name = (tool or "").strip().lower()
    slot = getattr(node, "browser_compile", None) if tool_name == "browser" else getattr(node, "python_compile", None)
    llm_name, model_name, timeout, fallbacks = _overlay_compile(llm_name, model_name, timeout, fallbacks, slot)
    if tool_name == "python":
        llm_name, model_name, timeout, fallbacks = _overlay_compile(
            llm_name, model_name, timeout, fallbacks, _COMPILE_PYTHON_STEP.get()
        )
    return llm_name, model_name, timeout, fallbacks


def _overlay_compile(
    llm_name: str,
    model_name: str,
    timeout: float,
    fallbacks: list[tuple[str, str, float | None]] | None,
    slot: Any,
) -> tuple[str, str, float, list[tuple[str, str, float | None]] | None]:
    """Replace the fields a compile section sets. None leaves the current values."""
    if slot is None:
        return llm_name, model_name, timeout, fallbacks
    if getattr(slot, "llm", ""):
        llm_name = slot.llm
    if getattr(slot, "model", ""):
        model_name = slot.model
    if getattr(slot, "timeout", None) is not None:
        timeout = slot.timeout
    if getattr(slot, "fallbacks", None) is not None:
        fallbacks = slot.fallbacks
    return llm_name, model_name, timeout, fallbacks


@contextmanager
def using_compile_provider(tool: str) -> Iterator[None]:
    """Use the compile section for this call.

    The app section is the default. The bound workflow replaces the fields it sets.
    An empty provider keeps the active chat model. A fallbacks list on that
    section replaces the workflow fallbacks. Omitting the list leaves them.
    """
    global LLM_TIMEOUT, FALLBACKS, _PRIMARY

    llm_name, model_name, timeout, fallbacks = resolve_compile(tool)
    previous = _snapshot()
    saved_timeout = LLM_TIMEOUT
    saved_fallbacks = FALLBACKS
    saved_primary = _PRIMARY
    try:
        if llm_name:
            activate(llm_name, model_name)
            _PRIMARY = _snapshot()
        LLM_TIMEOUT = _timeout_seconds(timeout)
        if fallbacks is not None:
            FALLBACKS = [_normalize_fallback(item) for item in fallbacks]
        yield
    finally:
        FALLBACKS = saved_fallbacks
        _PRIMARY = saved_primary
        LLM_TIMEOUT = saved_timeout
        _apply_snapshot(previous)


_JEV_MAX_CHOICES = 255
_JEV_MAX_BYTES = 150_000


def _cap_choices(criteria: dict[str, Any], limit: int = _JEV_MAX_CHOICES) -> dict[str, Any]:
    """Jev rejects a choice question with more than 255 options.

    Keep likely controls, then ones on screen, then the earlier offscreen ones.
    """
    if len(criteria) <= limit:
        return criteria

    def rank(item: tuple[int, tuple[str, Any]]) -> tuple[int, int, int]:
        index, (_key, value) = item
        priority = "other"
        view = ""
        if isinstance(value, dict):
            priority = str(value.get("priority") or "other")
            view = str(value.get("view") or "")
        return (0 if priority == "likely" else 1, 0 if view == "shown" else 1, index)

    ranked = sorted(enumerate(criteria.items()), key=rank)
    keep = {key for _, (key, _value) in ranked[:limit]}
    return {key: value for key, value in criteria.items() if key in keep}


def _fit_jev_questions(
    body: dict[str, Any],
    targets: dict[str, Any],
    locator_choices: dict[str, Any],
) -> dict[str, Any]:
    """Shrink choice lists until the request fits Jev's input limit.

    255 choices is the count limit. A page of long locators can still exceed
    the token limit below that, which comes back as HTTP 400.
    """
    questions = body.get("questions")
    if not isinstance(questions, dict):
        return locator_choices
    while len(json.dumps(body)) > _JEV_MAX_BYTES:
        largest = ""
        largest_n = 24
        for name, question in questions.items():
            if name != "locator" and not str(name).endswith("_target"):
                continue
            criteria = question.get("criteria") if isinstance(question, dict) else None
            if isinstance(criteria, dict) and len(criteria) > largest_n:
                largest = str(name)
                largest_n = len(criteria)
        if not largest:
            break
        question = questions[largest]
        reduced = _cap_choices(question["criteria"], max(24, largest_n * 3 // 4))
        if len(reduced) >= largest_n:
            reduced = _cap_choices(question["criteria"], largest_n - 1)
        question["criteria"] = reduced
        if largest == "locator":
            locator_choices = {key: value for key, value in locator_choices.items() if key in reduced}
            continue
        operation = largest[: -len("_target")].upper()
        group = targets.get(operation)
        if isinstance(group, dict):
            targets[operation] = {key: value for key, value in group.items() if str(key) in reduced}
    return locator_choices


def ask_jev_browser(request: dict[str, Any], *, goal: str = "") -> dict[str, Any]:
    """Up to two Jev browser actions. A go-to and its wait are one reply."""
    user = _request_user(request)
    operations = {str(key): str(value) for key, value in (request.get("operations") or {}).items()}
    operations.setdefault("DONE", "The command is already satisfied.")
    operations.setdefault("BLOCKED", "A named control is not offered.")
    raw_targets = request.get("targets") if isinstance(request.get("targets"), dict) else {}
    targets = dict(raw_targets)
    locator_waits = targets.get("WAIT_FOR_LOCATOR")
    if isinstance(locator_waits, dict) and locator_waits:
        # The missing click is this wait. BLOCKED would win on "the control is not offered."
        operations.pop("BLOCKED", None)
        operations["WAIT_FOR_LOCATOR"] = (
            "The named click is not on the page yet. Wait for its Playwright role locator."
        )
    step_text = goal or str(user.get("current_step") or "")
    from .browser_helper import (
        _command_mentions_wait,
        _page_action_before_wait,
        _text_wait,
        _verify_clause,
        _wait_before_page_action,
    )

    verify = _verify_clause(step_text)
    if verify and "WAIT_FOR_LOCATOR" in operations:
        phrase, seconds = verify
        operations["WAIT_FOR_LOCATOR"] = (
            f"Verify {phrase} as a locator, up to {seconds:g}s. "
            "Choose this when the phrase names a control. Choose WAIT when it is page text."
        )
    following = dict(operations)
    following["NONE"] = "No second action. The first action is the whole command."
    if verify and _page_action_before_wait(step_text):
        operations.pop("WAIT", None)
        operations.pop("WAIT_FOR_LOCATOR", None)
    elif verify and _wait_before_page_action(step_text):
        operations.pop("CLICK", None)
        operations.pop("GOTO", None)
        following.pop("WAIT", None)
        following.pop("WAIT_FOR_LOCATOR", None)
    elif _text_wait(step_text) and _page_action_before_wait(step_text):
        operations.pop("WAIT", None)
    elif _text_wait(step_text) and _wait_before_page_action(step_text):
        operations.pop("CLICK", None)
        operations.pop("GOTO", None)
        following.pop("WAIT", None)
    if not _command_mentions_wait(step_text):
        following.pop("WAIT", None)
        following.pop("WAIT_FOR_LOCATOR", None)
    page = dict(user.get("page") or {})
    if page.get("text"):
        page["text"] = str(page["text"])[:6000]
    operations = _cap_choices(operations)
    following = _cap_choices(following)
    questions: dict[str, Any] = {
        "operation": {
            "type": "choice",
            "criteria": operations,
            "instructions": {"goal": step_text, "rules": NEXT_ACTION},
        },
        "next_operation": {
            "type": "choice",
            "criteria": following,
            "instructions": {"goal": step_text, "rules": SECOND_ACTION},
        },
    }
    for operation, group in list(targets.items()):
        if not isinstance(group, dict) or not group:
            continue
        group = _cap_choices(group)
        targets[operation] = group
        target_rules = [NEXT_ACTION, TARGET]
        if operation in {"CLICK", "TYPE_TEXT", "SELECT", "WAIT_FOR_LOCATOR", "SCROLL_UP", "SCROLL_DOWN"}:
            complete = len(raw_targets.get(operation) or {}) == len(group)
            offered = (
                "Every locator is offered. "
                if complete and operation in {"WAIT_FOR_LOCATOR", "SCROLL_UP", "SCROLL_DOWN"}
                else ""
            )
            target_rules.append(
                offered + "Prefer priority likely. That is the control named by the step. "
                "When priority is the same, prefer view shown. "
                "view offscreen is still that control when it is the one the step names."
            )
        questions[str(operation).lower() + "_target"] = {
            "type": "choice",
            "criteria": {
                str(key): {
                    "element": str((action or {}).get("label") or key),
                    "current_value": (action or {}).get("current_value", (action or {}).get("value", "")),
                    **{
                        item: action[item]
                        for item in ("role", "checked", "selected", "expanded", "priority", "view")
                        if isinstance(action, dict) and item in action
                    },
                }
                for key, action in group.items()
                if isinstance(action, dict)
            },
            "instructions": {
                "goal": step_text,
                "operation": operation,
                "rules": target_rules,
            },
        }
    locator_choices = _cap_choices(_locator_catalog(targets))
    if locator_choices:
        questions["locator"] = {
            "type": "choice",
            "criteria": {
                selector: {
                    "element": str((action or {}).get("label") or selector),
                    "role": (action or {}).get("role") or "",
                    "priority": (action or {}).get("priority") or "other",
                    **({"view": action["view"]} if isinstance(action, dict) and action.get("view") else {}),
                }
                for selector, action in locator_choices.items()
            },
            "instructions": {
                "goal": step_text,
                "rules": [
                    "Return the locator for this action. Click, scroll, type, and wait all use one.",
                    "Prefer priority likely. That is the control named by the step. "
                    "When priority is the same, prefer view shown. "
                    "view offscreen is still that control when it is the one the step names.",
                ],
            },
        }
    body = {
        "model": browser_model_name(),
        "state": {
            "page": page,
            "elements": (request.get("elements") or user.get("elements") or [])[:80],
            "recent_actions": user.get("recent_actions") or [],
        },
        "questions": questions,
    }
    locator_choices = _fit_jev_questions(body, targets, locator_choices)
    result = _jev_post(body)
    answers = result.get("answers") if isinstance(result.get("answers"), dict) else {}
    model_name = str(result.get("model") or browser_model_name())
    operation_answer = _validate_jev_choice(answers.get("operation"), set(operations))
    first = _jev_action(
        str(operation_answer["choice"]),
        operation_answer,
        answers,
        targets,
        model_name,
        locator_choices,
    )
    actions = [first]
    raw_next = answers.get("next_operation")
    if isinstance(raw_next, dict):
        try:
            next_answer = _validate_jev_choice(raw_next, set(following))
        except ChatError:
            next_answer = None
        if next_answer:
            nxt = str(next_answer["choice"])
            if nxt not in {"NONE"}:
                try:
                    second = _jev_action(nxt, next_answer, answers, targets, model_name, locator_choices)
                except ChatError:
                    second = None
                if second and not _same_jev_action(first, second):
                    actions.append(second)
    from .browser_helper import _duration_wait

    pause = _duration_wait(step_text)
    if pause is not None:
        for action in actions:
            if str(action.get("operation") or "") == "WAIT" and action.get("seconds") in (None, ""):
                action["seconds"] = pause
    return {**first, "actions": actions}


def _same_jev_action(first: dict[str, Any], second: dict[str, Any]) -> bool:
    """True when the follow-up is the same operation on the same control."""
    if str(first.get("operation") or "") != str(second.get("operation") or ""):
        return False
    return str(first.get("selector") or "") == str(second.get("selector") or "")


def _jev_action(
    operation: str,
    operation_answer: dict[str, Any],
    answers: dict[str, Any],
    targets: dict[str, Any],
    model_name: str,
    locator_choices: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """One chosen operation, plus its target when that operation needs one."""
    payload: dict[str, Any] = {
        "operation": operation,
        "confidence": float(operation_answer["confidence"]),
        "model": model_name,
    }
    group = targets.get(operation) if isinstance(targets.get(operation), dict) else None
    if group:
        target_answer = _validate_jev_choice(
            answers.get(str(operation).lower() + "_target"),
            {str(key) for key in group},
        )
        selector = str(target_answer["choice"])
        payload["selector"] = selector
        field = {
            "CLICK": "click_target",
            "TYPE_TEXT": "type_text_target",
            "SELECT": "select_target",
            "EXTRACT": "extract_target",
            "TERM": "term_target",
        }.get(operation, str(operation).lower() + "_target")
        payload[field] = selector
    if locator_choices:
        try:
            picked = _validate_jev_choice(answers.get("locator"), set(locator_choices))
        except ChatError:
            picked = None
        if picked:
            payload["locator"] = str(picked["choice"])
            if not payload.get("selector"):
                payload["selector"] = payload["locator"]
    if operation == "BLOCKED":
        payload["message"] = "The named control is not on the page."
    return payload


def _request_user(request: dict[str, Any]) -> dict[str, Any]:
    for message in request.get("messages") or []:
        if not isinstance(message, dict) or message.get("role") != "user":
            continue
        try:
            payload = json.loads(str(message.get("content") or ""))
        except json.JSONDecodeError:
            return {}
        return payload if isinstance(payload, dict) else {}
    return {}


def _validate_jev_choice(answer: Any, ids: set[str]) -> dict[str, Any]:
    """Same checks as Jev Ultrafast: the choice is offered, and its probability is the highest."""
    try:
        if not isinstance(answer, dict):
            raise TypeError
        probabilities = answer["probabilities"]
        numbers = [*probabilities.values(), answer["confidence"]]
        choice = answer["choice"]
        valid = (
            choice in ids
            and set(probabilities) == set(ids)
            and all(type(number) in (int, float) and math.isfinite(number) and 0 <= number <= 1 for number in numbers)
            and abs(sum(probabilities.values()) - 1) < 0.02
            and probabilities[choice] >= max(probabilities.values()) - 1e-6
        )
    except (KeyError, TypeError, ValueError):
        valid = False
    if not valid or not isinstance(answer, dict):
        raise ChatError("Invalid Jev response; no action executed.")
    return answer


def _openrouter_key() -> str:
    key = (_CONFIG_ENV.get("OPENROUTER_API_KEY") or os.environ.get("OPENROUTER_API_KEY") or "").strip()
    if key:
        return key
    if PROVIDER == "openrouter":
        return (API_KEY or "").strip()
    return ""


def _jev_http_message(response: Any, status: int, label: str = "Jev") -> str:
    """Include the provider detail. A bare status hides why the request was rejected."""
    detail = ""
    if response is not None:
        payload: Any = None
        try:
            payload = response.json()
        except Exception:
            payload = None
        if isinstance(payload, dict):
            err = payload.get("error")
            if isinstance(err, dict):
                detail = str(err.get("message") or err.get("detail") or "")
            elif err:
                detail = str(err)
            elif payload.get("detail"):
                detail = str(payload.get("detail") or "")
        if not detail:
            detail = str(getattr(response, "text", "") or "")
    detail = " ".join(detail.split())[:400]
    if detail:
        return f"{label} returned HTTP {status}: {detail}"
    return f"{label} returned HTTP {status}"


def _criteria_text(value: Any) -> str:
    """One line of text a local decision model can score. Structured fields stay in the line."""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        parts = [f"{key}: {_criteria_text(item)}" for key, item in value.items() if _criteria_text(item)]
        return "; ".join(parts)
    if isinstance(value, list):
        return ", ".join(text for item in value if (text := _criteria_text(item)))
    if value is None:
        return ""
    return str(value).strip()


def _instructions_text(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        parts: list[str] = []
        goal = value.get("goal")
        if goal:
            parts.append(str(goal).strip())
        operation = value.get("operation")
        if operation:
            parts.append(f"operation: {operation}")
        rules = value.get("rules")
        if isinstance(rules, list):
            parts.extend(str(item).strip() for item in rules if str(item).strip())
        elif isinstance(rules, str) and rules.strip():
            parts.append(rules.strip())
        return "\n".join(parts)
    return str(value or "").strip()


def _local_questions(questions: Any) -> tuple[dict[str, Any], dict[str, list[str]]]:
    """System One questions with string instructions and string criteria."""
    prepared: dict[str, Any] = {}
    offered: dict[str, list[str]] = {}
    if not isinstance(questions, dict):
        return prepared, offered
    for name, question in questions.items():
        if not isinstance(question, dict):
            continue
        kind = str(question.get("type") or "choice").strip().lower() or "choice"
        criteria = question.get("criteria")
        flat: dict[str, str] = {}
        if isinstance(criteria, dict):
            for key, value in criteria.items():
                flat[str(key)] = _criteria_text(value) or str(key)
        elif isinstance(criteria, list):
            for item in criteria:
                text = _criteria_text(item)
                if text:
                    flat[text] = text
        payload: dict[str, Any] = {"type": kind, "instructions": _instructions_text(question.get("instructions"))}
        if flat:
            payload["criteria"] = flat
        prepared[str(name)] = payload
        if kind == "choice":
            offered[str(name)] = list(flat)
    return prepared, offered


def _response_answers(resp: Any) -> Any:
    if isinstance(resp, dict):
        return resp.get("answers") or {}
    return getattr(resp, "answers", None) or {}


def _answer_mapping(item: Any) -> dict[str, Any]:
    if isinstance(item, dict):
        return item
    if hasattr(item, "model_dump"):
        try:
            dumped = item.model_dump()
        except Exception:
            dumped = None
        if isinstance(dumped, dict):
            return dumped
    data: dict[str, Any] = {}
    for key in ("choice", "probabilities", "confidence", "noul", "score"):
        if hasattr(item, key):
            data[key] = getattr(item, key)
    return data


def _align_choice(data: dict[str, Any], ids: list[str]) -> dict[str, Any]:
    """A choice answer whose probabilities cover exactly the offered ids and sum to 1."""
    raw = data.get("probabilities") or {}
    if not isinstance(raw, dict):
        raw = {}
    weights: list[float] = []
    for key in ids:
        try:
            number = float(raw.get(key, 0.0))
        except (TypeError, ValueError):
            number = 0.0
        if not math.isfinite(number) or number < 0:
            number = 0.0
        weights.append(number)
    choice = str(data.get("choice") or "")
    total = sum(weights)
    if total <= 0:
        weights = [1.0 if key == choice else 0.0 for key in ids]
        total = sum(weights)
        if total <= 0 and ids:
            weights = [1.0, *[0.0 for _ in ids[1:]]]
            choice = ids[0]
            total = 1.0
    probs = {key: value / total for key, value in zip(ids, weights)} if total else {}
    if choice not in probs or (probs and probs[choice] + 1e-9 < max(probs.values())):
        choice = max(probs, key=probs.get) if probs else choice
    return {"choice": choice, "probabilities": probs, "confidence": float(probs.get(choice, 0.0))}


def _normalize_answers(raw: Any, offered: dict[str, list[str]]) -> dict[str, Any]:
    if hasattr(raw, "model_dump") and not isinstance(raw, dict):
        try:
            dumped = raw.model_dump()
        except Exception:
            dumped = None
        if isinstance(dumped, dict):
            raw = dumped
    if not isinstance(raw, dict):
        try:
            raw = dict(raw)
        except (TypeError, ValueError):
            raw = {}
    answers: dict[str, Any] = {}
    for name, item in raw.items():
        data = _answer_mapping(item)
        keys = offered.get(str(name)) or []
        if keys and ("choice" in data or "probabilities" in data):
            answers[str(name)] = _align_choice(data, keys)
        else:
            answers[str(name)] = data
    return answers


def _install_package(name: str) -> None:
    """Install a missing local model into this interpreter."""
    import subprocess
    import sys

    print(f"{name}: installing", flush=True)
    result = subprocess.run([sys.executable, "-m", "pip", "install", name], check=False)
    if result.returncode != 0:
        raise ChatError(f"{name} could not be installed")


def _von_call(state: Any, questions: dict[str, Any]) -> Any:
    import von

    _quiet_von_logs()
    return von.system_one(state=state if isinstance(state, dict) else {}, questions=questions)


def ensure_laya_router() -> Any:
    """The shared Laya router. The package is installed here when it is missing."""
    global _LAYA_ROUTER
    if _LAYA_ROUTER is not None:
        return _LAYA_ROUTER
    try:
        from laya import Router
    except ImportError:
        _install_package("laya")
        from laya import Router
    print("laya: loading", flush=True)
    _LAYA_ROUTER = Router()
    return _LAYA_ROUTER


def _laya_call(state: Any, questions: dict[str, Any]) -> Any:
    return ensure_laya_router().predict(state if isinstance(state, dict) else {}, questions)


def _local_post(body: dict[str, Any], *, package: str, call: Callable[[Any, dict[str, Any]], Any], missing: str) -> dict[str, Any]:
    prepared, offered = _local_questions(body.get("questions"))
    started = time.perf_counter()
    try:
        resp = call(body.get("state") or {}, prepared)
    except ImportError as exc:
        raise ChatError(missing) from exc
    except Exception as exc:
        raise ChatError(f"{package} failed: {exc}", transport=_is_transport(exc)) from exc
    finally:
        _charge_llm(started)
    label = str(body.get("model") or package).strip() or package
    return {"model": label, "answers": _normalize_answers(_response_answers(resp), offered)}


def _von_post(body: dict[str, Any]) -> dict[str, Any]:
    """One Von decision. A job uses the shared process when Von is already loaded."""
    from .resident import announce, call, use_resident

    if use_resident():
        payload = call(
            "von",
            {"state": body.get("state") or {}, "questions": body.get("questions") or {}},
        )
        announce(payload, "von")
        result = payload.get("result")
        if not isinstance(result, dict):
            raise ChatError("von returned no result")
        return result
    return _local_post(
        body,
        package="Von",
        call=_von_call,
        missing="von-sdk is not installed. Install it with: pip install von-sdk",
    )


def _laya_post(body: dict[str, Any]) -> dict[str, Any]:
    """One Laya decision. `layla` and `laya` both use this.

    A job uses the shared process when Laya is already loaded.
    """
    from .resident import announce, call, use_resident

    if use_resident():
        payload = call(
            "laya",
            {"state": body.get("state") or {}, "questions": body.get("questions") or {}},
        )
        announce(payload, "laya")
        result = payload.get("result")
        if not isinstance(result, dict):
            raise ChatError("laya returned no result")
        return result
    return _local_post(
        body,
        package="Laya",
        call=_laya_call,
        missing="laya could not be installed",
    )


def openrouter_systemone(body: dict[str, Any], env: dict[str, Any] | None = None) -> dict[str, Any]:
    """One System One request on OpenRouter. `body["model"]` is `vendor/name`."""
    merged = dict(os.environ)
    if env:
        merged.update({str(key): "" if value is None else str(value) for key, value in env.items()})
    key = (merged.get("OPENROUTER_API_KEY") or "").strip() or _openrouter_key()
    if not key:
        raise ChatError("OPENROUTER_API_KEY is not set", transport=True)
    return _systemone_http(body, key=key, label="OpenRouter")


def _jev_post(body: dict[str, Any]) -> dict[str, Any]:
    """One browser decision. Von and Layla run locally. Other names call Jev on OpenRouter."""
    backend = browser_tool_backend(str(body.get("model") or ""))
    if backend == "von":
        return _von_post(body)
    if backend == "laya":
        return _laya_post(body)
    key = _openrouter_key()
    if not key:
        raise ChatError("OPENROUTER_API_KEY is not set", transport=True)
    return _systemone_http(body, key=key, label="Jev")


def _systemone_http(body: dict[str, Any], *, key: str, label: str) -> dict[str, Any]:
    """POST `body` to OpenRouter System One and return the JSON object."""
    started = time.perf_counter()
    response: Any = None
    try:
        for attempt in range(3):
            headers = {
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "X-OpenRouter-Title": "cg-loop",
            }
            _note_api_call(OPENROUTER_SYSTEMONE_URL, headers, body)
            try:
                response = httpx.post(
                    OPENROUTER_SYSTEMONE_URL,
                    json=body,
                    headers=headers,
                    timeout=httpx.Timeout(LLM_TIMEOUT, connect=CONNECT_TIMEOUT),
                )
            except httpx.HTTPError as exc:
                if attempt < 2:
                    print(f"{label} connection failed, retrying: {exc}", flush=True)
                    time.sleep(0.5 * 2**attempt)
                    continue
                raise ChatError(f"{label} connection failed: {exc}", transport=True) from exc
            if response.status_code in {429, 529, 503} and attempt < 2:
                time.sleep(0.5 * 2**attempt)
                continue
            break
    finally:
        _charge_llm(started)
    if response is None or response.is_error:
        status = getattr(response, "status_code", 0)
        transport = status >= 500 or status in {408, 429, 529}
        raise ChatError(_jev_http_message(response, status, label), transport=transport)
    try:
        payload = response.json()
    except json.JSONDecodeError as exc:
        raise ChatError(f"{label} returned no answer") from exc
    if not isinstance(payload, dict):
        raise ChatError(f"{label} returned no answer")
    return payload


def ask_json(messages: list[dict[str, str]]) -> dict[str, Any]:
    """Send one JSON chat and return the parsed object."""
    return _chat_json(messages)


def _choose_rules(step: Step) -> list[str]:
    rules = [NEXT_ACTION, TARGET]
    if step.tool == "browser":
        rules.append(
            "Tool: browser. Act only on the current page. "
            "Shell commands are not available. "
            "DONE only when the page shows this step is satisfied."
        )
    return rules


def field_text(context: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    started = time.perf_counter()
    output = _chat_json(
        [
            {"role": "system", "content": TEXT_VALUE},
            {"role": "user", "content": json.dumps(context, default=str)},
        ]
    )
    value = output.get("text")
    if not isinstance(value, str) or not value.strip() or len(value) > 4000:
        raise ValueError("Text helper returned no valid field value; nothing typed.")
    return value, {
        "model": MODEL,
        "latency_ms": round((time.perf_counter() - started) * 1000),
    }


def term_command(context: dict[str, Any], fallback: str = "") -> tuple[str, dict[str, Any]]:
    if fallback.strip():
        return fallback.strip(), {"model": "workflow", "latency_ms": 0}
    started = time.perf_counter()
    output = _chat_json(
        [
            {"role": "system", "content": TERM_VALUE},
            {"role": "user", "content": json.dumps(context, default=str)},
        ]
    )
    value = output.get("command")
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Term helper returned no valid command.")
    return value.strip(), {
        "model": MODEL,
        "latency_ms": round((time.perf_counter() - started) * 1000),
    }


@dataclass
class CompileReply:
    """One compile model call: the script, the thinking, and the request that produced them."""

    text: str
    thinking: str = ""
    messages: list[dict[str, str]] | None = None
    model: str = ""
    latency_ms: int = 0
    error: str = ""
    options: dict[str, Any] = field(default_factory=dict)
    message_fields: str = ""


def compile_messages(context: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": COMPILE_STEP},
        {"role": "user", "content": json.dumps(context, default=str)},
    ]


def compile_step(context: dict[str, Any]) -> CompileReply:
    """Ask the model for a run(ctx) function when a step is not already a tool call.

    OpenRouter requests include reasoning so the thinking can be logged separately
    from the script. A 400 from a model that rejects that option is retried without it.
    """
    return _ask_compile(compile_messages(context))


def compile_browser_messages(context: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": COMPILE_BROWSER},
        {"role": "user", "content": json.dumps(context, default=str)},
    ]


def choose_compile_action(step: Step) -> str:
    """Pick helper or generate for a workflow step the local runners do not already own."""
    messages = [
        {"role": "system", "content": COMPILE_ACTION},
        {"role": "user", "content": json.dumps({"step": step.raw, "tool": step.tool, "kind": step.kind})},
    ]
    try:
        with using_browser_provider():
            output = _chat_json(messages)
    except Exception:
        return "helper"
    action = str(output.get("action") or "").strip().lower()
    if action in {"helper", "generate"}:
        return action
    return "helper"


def compile_browser_step(context: dict[str, Any]) -> CompileReply:
    """Write run(ctx) for one /browser step, using the browser tool's provider."""
    with using_browser_provider():
        return _ask_compile(compile_browser_messages(context))


def generate_browser_js(command: str, page: dict[str, Any] | None = None) -> CompileReply:
    """Write the JavaScript function for a browser step that branches."""
    seen = page or {}
    context = {
        "step": command,
        "page": {key: seen.get(key) for key in ("url", "title", "text")},
    }
    if context["page"].get("text"):
        context["page"]["text"] = str(context["page"]["text"])[:6000]
    messages = [
        {"role": "system", "content": BROWSER_JS},
        {"role": "user", "content": json.dumps(context, default=str)},
    ]
    with using_browser_provider():
        return _ask_compile(messages)


def compile_python_messages(context: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": COMPILE_PYTHON},
        {"role": "user", "content": json.dumps(context, default=str)},
    ]


def compile_python_step(context: dict[str, Any]) -> CompileReply:
    """Write run(ctx) for one /python step, using the python tool's provider."""
    with using_python_provider():
        return _ask_compile(compile_python_messages(context))


def compile_extract_messages(context: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": COMPILE_EXTRACT},
        {"role": "user", "content": json.dumps(context, default=str)},
    ]


def compile_extract_step(context: dict[str, Any]) -> CompileReply:
    """Write run(ctx) that extracts from the open page, using the python tool's provider."""
    with using_python_provider():
        return _ask_compile(compile_extract_messages(context))


def _ask_compile(messages: list[dict[str, str]]) -> CompileReply:
    started = time.perf_counter()
    reasoning = PROVIDER == "openrouter"
    options: dict[str, Any] = {"temperature": 0.1}
    if reasoning:
        options["reasoning"] = "enabled"
    messages = _prompt_for_request(messages)
    try:
        response = _compile_completion(messages, reasoning=reasoning)
        message = response.choices[0].message
        raw = _content_text(getattr(message, "content", ""))
        script, inline = split_model_text(raw)
        payload = message.model_dump() if hasattr(message, "model_dump") else {}
        thinking = _merge_thinking(thinking_from_mapping(payload), inline, _preamble(script))
        fields = ""
        if isinstance(payload, dict):
            fields = ", ".join(key for key, value in payload.items() if value not in (None, "", [], {}))
        error = "" if script.strip() else "Compile helper returned an empty script."
        return CompileReply(
            text=script,
            thinking=thinking,
            messages=messages,
            model=str(getattr(response, "model", "") or MODEL),
            latency_ms=round((time.perf_counter() - started) * 1000),
            error=error,
            options=options,
            message_fields=fields,
        )
    except Exception as exc:
        return CompileReply(
            text="",
            messages=messages,
            model=MODEL,
            latency_ms=round((time.perf_counter() - started) * 1000),
            error=str(exc),
            options=options,
        )
    finally:
        _charge_llm(started)


def split_model_text(content: str) -> tuple[str, str]:
    """Split a model reply into script text and any <think> blocks."""
    text = content or ""
    parts = [part.strip() for part in _THINK_RE.findall(text) if part and part.strip()]
    cleaned = _THINK_RE.sub("", text).strip()
    return cleaned, "\n\n".join(parts)


def thinking_from_mapping(payload: Any) -> str:
    """Pull reasoning fields off a chat message dump. The script stays in content."""
    if hasattr(payload, "model_dump"):
        try:
            payload = payload.model_dump()
        except Exception:
            return ""
    if not isinstance(payload, dict):
        return ""
    return _merge_thinking(*[_as_text(payload.get(key)) for key in _REASON_KEYS])


def _prompt_for_request(messages: list[dict[str, str]]) -> list[dict[str, str]]:
    """Write `a-prompt.json` first. The chat call and `a-request.py` both load it."""
    state = _api_log_dir.get()
    if state is None:
        return messages
    from .runlog import prompt_markdown

    folder = state.folder
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "a-prompt.json"
    path.write_text(json.dumps({"messages": messages}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    saved = json.loads(path.read_text(encoding="utf-8"))
    loaded = saved.get("messages") if isinstance(saved, dict) else None
    if not isinstance(loaded, list) or len(loaded) != len(messages):
        return messages
    text = prompt_markdown(_prompt_title(messages), {"llm_call": {"messages": loaded}})
    if text:
        markdown = folder / "a-prompt.md"
        markdown.write_text(text, encoding="utf-8")
    return loaded


def _prompt_title(messages: list[dict[str, str]]) -> str:
    for message in messages:
        if str(message.get("role") or "") != "user":
            continue
        try:
            payload = json.loads(str(message.get("content") or ""))
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict) and str(payload.get("step") or "").strip():
            return str(payload["step"]).strip()
    return "step"


def _compile_completion(messages: list[dict[str, str]], *, reasoning: bool) -> Any:
    kwargs: dict[str, Any] = {"model": MODEL, "messages": messages, "temperature": 0.1}
    if not reasoning:
        return _completion(**kwargs)
    try:
        return _completion(**kwargs, extra_body={"reasoning": {"enabled": True}})
    except Exception as exc:
        if getattr(exc, "status_code", None) != 400:
            raise
        return _completion(**kwargs)


def _content_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        return "\n".join(_content_text(part) for part in content).strip()
    text = getattr(content, "text", None)
    if isinstance(text, str):
        return text.strip()
    if isinstance(content, dict):
        return str(content.get("text") or content.get("content") or "").strip()
    return str(content).strip()


def _preamble(text: str) -> str:
    cleaned = (text or "").strip()
    fence = _FENCE_RE.match(cleaned)
    if fence:
        cleaned = fence.group(1).strip()
    start = cleaned.find("def run")
    if start <= 0:
        return ""
    return cleaned[:start].strip()


def _as_text(value: Any) -> str:
    if value is None or value == "":
        return ""
    if isinstance(value, str):
        return value.strip()
    if hasattr(value, "model_dump"):
        try:
            return _as_text(value.model_dump())
        except Exception:
            return ""
    if isinstance(value, list):
        return _merge_thinking(*[_as_text(item) for item in value])
    if isinstance(value, dict):
        return _merge_thinking(*[_as_text(value.get(key)) for key in _TEXT_KEYS])
    return ""


def _merge_thinking(*parts: str) -> str:
    seen: list[str] = []
    for part in parts:
        text = (part or "").strip()
        if text and text not in seen:
            seen.append(text)
    return "\n\n".join(seen)


def write_step_script(context: dict[str, Any]) -> str:
    started = time.perf_counter()
    try:
        response = _completion(
            model=MODEL,
            messages=[
                {"role": "system", "content": STEP_CODE},
                {"role": "user", "content": json.dumps(context, default=str)},
            ],
            temperature=0.2,
        )
        text = (response.choices[0].message.content or "").strip()
        if not text:
            raise ValueError("Step-code helper returned an empty script.")
        return text
    finally:
        _charge_llm(started)


def llm_write(prompt: str) -> str:
    started = time.perf_counter()
    try:
        response = _completion(
            model=MODEL,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Write the requested file contents only. No surrounding commentary. "
                        "If the user wants markdown, return markdown."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0.4,
        )
        return (response.choices[0].message.content or "").strip()
    finally:
        _charge_llm(started)


def _chat_json(messages: list[dict[str, str]]) -> dict[str, Any]:
    """One JSON chat. A bad reply or a timeout tries the next configured model in this same call."""
    started = time.perf_counter()

    def run() -> dict[str, Any]:
        thinking = ""
        content = ""
        model_name = MODEL
        try:
            response = _completion_once(model=MODEL, messages=messages, temperature=0.1)
            message = response.choices[0].message
            raw = _content_text(getattr(message, "content", ""))
            content, inline = split_model_text(raw)
            payload = message.model_dump() if hasattr(message, "model_dump") else {}
            thinking = _merge_thinking(thinking_from_mapping(payload), inline)
            model_name = str(getattr(response, "model", "") or MODEL)
            parsed = _parse_json(content)
            _emit_exchange(messages, thinking, content, "", model_name, started, parsed)
            return parsed
        except Exception as exc:
            _emit_exchange(messages, thinking, content, str(exc), model_name, started)
            if _is_transport(exc) or isinstance(exc, ChatError):
                raise
            raise ChatError(str(exc), text=content) from exc

    try:
        return _first_success(run)
    except ChatError:
        raise
    except Exception as exc:
        if _is_transport(exc):
            raise ChatError(str(exc), transport=True) from exc
        raise ChatError(str(exc)) from exc
    finally:
        _charge_llm(started)


def _emit_exchange(
    messages: list[dict[str, str]],
    thinking: str,
    result: str,
    error: str,
    model_name: str,
    started: float,
    parsed: dict[str, Any] | None = None,
) -> None:
    hook = _exchange_log
    if hook is None:
        return
    safe_messages = [
        {"role": str(item.get("role") or ""), "content": _redact(str(item.get("content") or ""))}
        for item in messages
    ]
    parsed_text = _redact(json.dumps(parsed, indent=2, default=str)) if isinstance(parsed, dict) else ""
    try:
        hook(
            {
                "messages": safe_messages,
                "thinking": _redact(thinking),
                "result": _redact(result),
                "parsed": parsed_text,
                "error": error,
                "model": model_name,
                "latency_ms": round((time.perf_counter() - started) * 1000),
            }
        )
    except Exception as exc:
        print(f"model log failed: {exc}")


def _redact(text: str) -> str:
    return _SECRET_RE.sub("[redacted]", text or "")


@contextmanager
def logging_api_calls(folder: Path) -> Iterator[None]:
    """Write each HTTP call made while this is open into `folder` as `a-request.py`."""
    token = _api_log_dir.set(_ApiLog(folder))
    try:
        yield
    finally:
        _api_log_dir.reset(token)


def api_request_files(folder: Path) -> list[Path]:
    """Request scripts written for one compile, `a-request.py` first."""
    if not folder.is_dir():
        return []
    files = [item for item in folder.glob("a-request*.py") if item.is_file()]
    return sorted(files, key=lambda item: (len(item.name), item.name))


def _chat_completion_request(kwargs: dict[str, Any]) -> tuple[str, dict[str, str], dict[str, Any]]:
    """URL, headers, and JSON body for one OpenAI chat completion."""
    body = {key: value for key, value in kwargs.items() if key != "extra_body"}
    extra = kwargs.get("extra_body")
    if isinstance(extra, dict):
        body.update(extra)
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}",
    }
    if PROVIDER == "openrouter":
        headers["X-OpenRouter-Title"] = "cg-loop"
    return f"{LM_STUDIO_URL.rstrip('/')}/chat/completions", headers, body


def _note_api_call(url: str, headers: dict[str, str], body: dict[str, Any]) -> None:
    state = _api_log_dir.get()
    if state is None:
        return
    try:
        state.folder.mkdir(parents=True, exist_ok=True)
        if not state.started:
            for old in state.folder.glob("a-request*.py"):
                old.unlink()
            state.started = True
        path = _next_request_path(state.folder)
        prompt_file = _saved_prompt_name(state.folder, body.get("messages"))
        logged = body
        if prompt_file:
            logged = {key: value for key, value in body.items() if key != "messages"}
        path.write_text(api_request_source(url, headers, logged, prompt_file=prompt_file), encoding="utf-8")
        from .runlog import log_compile

        log_compile(f"api request {path.name}  {path}", folder=path.parent)
    except Exception as exc:
        print(f"API request log failed: {exc}")


def _next_request_path(folder: Path) -> Path:
    first = folder / "a-request.py"
    if not first.exists():
        return first
    number = 2
    while (folder / f"a-request-{number}.py").exists():
        number += 1
    return folder / f"a-request-{number}.py"


def _saved_prompt_name(folder: Path, messages: Any) -> str:
    """`a-prompt.json` when this call's messages are the saved prompt."""
    if not isinstance(messages, list):
        return ""
    path = folder / "a-prompt.json"
    try:
        saved = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ""
    if isinstance(saved, dict) and saved.get("messages") == messages:
        return path.name
    return ""


def api_request_source(
    url: str,
    headers: dict[str, str],
    body: dict[str, Any],
    *,
    prompt_file: str = "",
) -> str:
    """A Python file that sends this HTTP request again.

    Message text stays in `prompt_file`. This script loads that JSON.
    """
    header_lines = ["HEADERS = {"]
    for key, value in headers.items():
        if key.lower() == "authorization" and _SECRET_RE.search(value):
            header_lines.append('    "Authorization": "Bearer " + os.environ.get("OPENROUTER_API_KEY", ""),')
        else:
            header_lines.append(f"    {key!r}: {_redact(value)!r},")
    header_lines.append("}")
    shown = pprint.pformat(_redact_value(body), sort_dicts=False, width=88)
    import_lines = ["import json", "import urllib.request"]
    if any("os.environ" in line for line in header_lines):
        import_lines.insert(1, "import os")
    if prompt_file:
        import_lines.append("from pathlib import Path")
    imports = "\n".join(import_lines) + "\n"
    body_lines = f"BODY = {shown}\n"
    if prompt_file:
        body_lines = (
            f"PROMPT = json.loads(Path(__file__).with_name({prompt_file!r}).read_text(encoding='utf-8'))\n"
            f"BODY = {shown}\n"
            'BODY["messages"] = PROMPT["messages"]\n'
        )
    return (
        "#!/usr/bin/env python3\n"
        '"""The HTTP request sent at compile.\n'
        "\n"
        f"POST {url}\n"
        "\n"
        "Run this file to send the same request again.\n"
        '"""\n'
        f"{imports}\n"
        f"URL = {url!r}\n"
        f"TIMEOUT = {LLM_TIMEOUT!r}\n"
        + "\n".join(header_lines)
        + "\n"
        + body_lines
        + "\n"
        "\n"
        "def main() -> None:\n"
        "    request = urllib.request.Request(\n"
        "        URL,\n"
        "        data=json.dumps(BODY).encode(),\n"
        "        headers=HEADERS,\n"
        "        method=\"POST\",\n"
        "    )\n"
        "    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:\n"
        "        print(response.read().decode())\n"
        "\n"
        "\n"
        "if __name__ == \"__main__\":\n"
        "    main()\n"
    )


def _redact_value(value: Any) -> Any:
    if isinstance(value, str):
        return _redact(value)
    if isinstance(value, dict):
        return {str(key): _redact_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    return value


def _parse_json(content: str) -> dict[str, Any]:
    parsed = _parse_json_body(content)
    if parsed is not None:
        return parsed
    decoded = (content or "").translate(_GPT2_WS)
    if decoded != (content or ""):
        parsed = _parse_json_body(decoded)
        if parsed is not None:
            return parsed
    raise ValueError(f"Model did not return JSON: {content[:400]}")


def _parse_json_body(content: str) -> dict[str, Any] | None:
    cleaned = _SPECIAL_TOKEN_RE.sub("", content or "").strip()
    fence = re.match(r"^```(?:json)?\s*([\s\S]*?)\s*```$", cleaned, re.IGNORECASE)
    if fence:
        cleaned = fence.group(1).strip()
    try:
        payload = json.loads(cleaned)
        if isinstance(payload, dict):
            return payload
    except json.JSONDecodeError:
        pass
    tool = _parse_tool_call(cleaned)
    if tool:
        return tool
    match = _JSON_RE.search(cleaned)
    if match:
        try:
            payload = json.loads(match.group(0))
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, dict) and _JSON_KEYS.intersection(payload):
            return payload
    return _code_reply(cleaned)


def _code_reply(content: str) -> dict[str, Any] | None:
    """A reply that is the program itself, not a JSON envelope."""
    text = (content or "").strip()
    fence = re.match(r"^```(?:python|py|bash|sh|shell)?\s*([\s\S]*?)\s*```$", text, re.IGNORECASE)
    if fence:
        text = fence.group(1).strip()
    if not text:
        return None
    first = text.splitlines()[0].strip()
    if not re.match(
        r"^(?:(?:[\w./~-]+/)?python3?(?:\s+-c)?\b|import |from |echo |cat |jq |bash |sh |#!/)",
        first,
        re.IGNORECASE,
    ):
        return None
    return {"operation": "TERM", "command": text, "confidence": 1}


def _parse_tool_call(content: str) -> dict[str, Any] | None:
    """Read a reply like `[TERM(command='...')]` into the JSON shape choose() expects."""
    text = content.strip()
    if text.startswith("["):
        text = text[1:].strip()
    if text.endswith("]"):
        text = text[:-1].strip()
    paren = text.find("(")
    if paren <= 0 or not text.endswith(")"):
        return None
    operation = text[:paren].strip().upper()
    if not re.fullmatch(r"[A-Z][A-Z0-9_]*", operation):
        return None
    body = text[paren + 1 : -1].strip()
    payload: dict[str, Any] = {"operation": operation, "confidence": 1}
    if not body:
        return payload
    arg = re.match(r"(?P<key>\w+)\s*=\s*(?P<q>['\"])(?P<val>[\s\S]*)(?P=q)\s*$", body)
    if not arg:
        return None
    key = arg.group("key")
    value = arg.group("val")
    if key in {"command", "cmd"}:
        payload["command"] = value
        payload["term_target"] = "1"
    elif key == "selector":
        payload["selector"] = value
    elif key in {"click_target", "type_text_target", "select_target", "extract_target", "term_target", "target"}:
        field = "click_target" if key == "target" and operation == "CLICK" else key
        if field == "target":
            field = operation.lower() + "_target"
        payload[field] = value
    else:
        payload[key] = value
    return payload


_SECRET_ENV = re.compile(r"KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL", re.IGNORECASE)


def public_env(env: dict[str, Any]) -> dict[str, str]:
    """Paths and settings the code generator needs. Secrets stay out of the prompt."""
    public: dict[str, str] = {}
    for key, value in env.items():
        if _SECRET_ENV.search(str(key)):
            continue
        text = str(value)
        if not text or len(text) > 300:
            continue
        public[str(key)] = text
    return public


def _public_vars(variables: dict[str, Any]) -> dict[str, Any]:
    public: dict[str, Any] = {}
    for key, value in variables.items():
        if isinstance(value, dict):
            public[key] = {
                k: (str(v)[:500] if k in {"text", "summary"} else v)
                for k, v in value.items()
                if k in {"title", "url", "text", "summary", "published", "path"}
            }
        else:
            public[key] = str(value)[:500]
    return public
