"""Clef answers a page question in process, the way Layla does."""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "lib"))

import cg_loop.clef as clef  # noqa: E402
from cg_loop.clef import (  # noqa: E402
    ask_clef,
    ensure_clef_model,
    load_clef_if_needed,
    parse_clef_command,
    parse_option_list,
    question_body,
    read_answer,
    workflow_needs_clef,
)
from cg_loop.compiled import run_clef  # noqa: E402
from cg_loop.decision import skips_script  # noqa: E402
from cg_loop.workflow import Workflow, load_workflow, parse_step  # noqa: E402


class ParseTests(unittest.TestCase):
    def test_default_is_yes_no(self) -> None:
        question, options, verify, image, var = parse_clef_command("Subscript text exists?")
        self.assertEqual(question, "Subscript text exists?")
        self.assertEqual(options, [])
        self.assertEqual(verify, "")
        self.assertEqual(image, "")
        self.assertEqual(var, "")
        step = parse_step("/clef Subscript text exists?")
        self.assertEqual(step.kind, "clef")
        self.assertEqual(step.tool, "clef")
        self.assertEqual(step.extra, "Subscript text exists?")
        self.assertEqual(step.params["image"], "")
        self.assertTrue(skips_script(step))

    def test_browser_prefix_is_the_same_tool(self) -> None:
        step = parse_step("/browser /clef Subscript text exists? +verify yes into $seen")
        self.assertEqual(step.tool, "clef")
        self.assertEqual(step.params["verify"], "yes")
        self.assertEqual(step.params["image"], "/browser")
        self.assertEqual(step.var, "seen")

    def test_cua_prefix_uses_the_open_window(self) -> None:
        step = parse_step('/cua /clef Yahoo text exists? +verify yes')
        self.assertEqual(step.kind, "clef")
        self.assertEqual(step.tool, "clef")
        self.assertEqual(step.extra, "Yahoo text exists?")
        self.assertEqual(step.params["verify"], "yes")
        self.assertEqual(step.params["image"], "/cua")
        kept = parse_step('/cua /clef Yahoo text exists? +image $shot +verify yes')
        self.assertEqual(kept.params["image"], "$shot")
        short = parse_step("/cua Yahoo text exists +verify yes")
        self.assertEqual(short.kind, "clef")
        self.assertEqual(short.tool, "clef")
        self.assertEqual(short.extra, "Yahoo text exists")
        self.assertEqual(short.params["verify"], "yes")
        self.assertEqual(short.params["image"], "/cua")
        page = parse_step("/browser Yahoo text exists +verify yes")
        self.assertEqual(page.kind, "clef")
        self.assertEqual(page.params["verify"], "yes")
        self.assertEqual(page.params["image"], "/browser")

    def test_image_can_be_the_browser_a_variable_or_a_path(self) -> None:
        from cg_loop.clef import is_browser_image, is_cua_image, parse_image_source, resolve_image_path

        self.assertEqual(parse_image_source("/browser"), "/browser")
        self.assertEqual(parse_image_source("/cua"), "/cua")
        self.assertTrue(is_browser_image(""))
        self.assertTrue(is_browser_image("/browser"))
        self.assertFalse(is_browser_image("/cua"))
        self.assertTrue(is_cua_image("/cua"))
        question, _options, verify, image, var = parse_clef_command(
            'Subscript text exists? +image $shot +verify yes into $seen'
        )
        self.assertEqual(question, "Subscript text exists?")
        self.assertEqual(image, "$shot")
        self.assertEqual(verify, "yes")
        self.assertEqual(var, "seen")
        self.assertEqual(
            parse_clef_command('Which label? +image "/tmp/my shot.jpg"')[3],
            "/tmp/my shot.jpg",
        )
        self.assertEqual(
            resolve_image_path("$shot", {}, {"shot": "/tmp/page.jpg"}),
            "/tmp/page.jpg",
        )
        self.assertEqual(
            resolve_image_path("$shot", {}, {"shot": {"screenshots": ["/tmp/a.jpg", "/tmp/b.jpg"]}}),
            "/tmp/b.jpg",
        )

    def test_options_keep_a_comma_inside_quotes(self) -> None:
        self.assertEqual(parse_option_list("a,b,c"), ["a", "b", "c"])
        self.assertEqual(parse_option_list('"a", "b,", "c"'), ["a", "b,", "c"])
        question, options, verify, image, var = parse_clef_command(
            'Which label? +options "a", "b,", "c" +verify "b," into $label'
        )
        self.assertEqual(question, "Which label?")
        self.assertEqual(options, ["a", "b,", "c"])
        self.assertEqual(verify, "b,")
        self.assertEqual(image, "")
        self.assertEqual(var, "label")
        question, options, verify, image, var = parse_clef_command(
            '"does +verify yes count?" +verify yes'
        )
        self.assertEqual(question, "does +verify yes count?")
        self.assertEqual(options, [])
        self.assertEqual(verify, "yes")
        self.assertEqual(image, "")
        self.assertEqual(var, "")
        self.assertEqual(parse_option_list(r'"a\"b", c'), ['a"b', "c"])

    def test_verify_must_be_yes_or_no_unless_options_are_set(self) -> None:
        with self.assertRaises(ValueError):
            parse_clef_command("Subscript text exists? +verify maybe")
        with self.assertRaises(ValueError):
            parse_clef_command("Which label? +options a,b,c +verify yes")

    def test_question_body_is_noul_until_options_are_set(self) -> None:
        self.assertEqual(
            question_body("Subscript text exists?", []),
            {"type": "noul", "instructions": "Subscript text exists?"},
        )
        self.assertEqual(
            question_body("Which label?", ["a", "b,"]),
            {
                "type": "choice",
                "instructions": "Which label?",
                "criteria": {"a": "a", "b,": "b,"},
            },
        )


class AnswerTests(unittest.TestCase):
    def test_yes_no_uses_the_true_probability(self) -> None:
        self.assertEqual(read_answer({"answers": {"answer": {"noul": 0.8}}}, []), ("yes", 0.8))
        self.assertEqual(read_answer({"answers": {"answer": {"noul": 0.2}}}, []), ("no", 0.2))

    def test_choice_returns_the_option(self) -> None:
        payload = {"answers": {"answer": {"choice": "b,", "probabilities": {"b,": 0.7}}}}
        self.assertEqual(read_answer(payload, ["a", "b,", "c"]), ("b,", 0.7))


class RunTests(unittest.TestCase):
    def test_verify_blocks_when_the_answer_differs(self) -> None:
        def ask(question: str, options: list[str], image: bytes, *, state: str, env: dict) -> tuple[str, float]:
            self.assertEqual(question, "Subscript text exists?")
            self.assertEqual(options, [])
            self.assertEqual(image, b"jpeg")
            self.assertIn("example.com", state)
            return "no", 0.2

        with tempfile.TemporaryDirectory() as folder:
            ctx = {
                "browser": SimpleNamespace(page=SimpleNamespace(url="https://example.com", screenshot=lambda **_: b"jpeg")),
                "env": {},
                "variables": {},
                "data": folder,
            }
            with patch("cg_loop.clef.ask_clef", ask):
                result = run_clef(ctx, question="Subscript text exists?", verify="yes", var="seen")
        self.assertTrue(result["blocked"])
        self.assertEqual(result["variables"]["seen"], "no")
        self.assertIn("expected 'yes'", result["outputs"]["message"])

    def test_matching_verify_stores_the_answer(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            ctx = {
                "browser": SimpleNamespace(page=SimpleNamespace(url="", screenshot=lambda **_: b"jpeg")),
                "env": {},
                "variables": {},
                "data": folder,
            }
            with patch("cg_loop.clef.ask_clef", lambda *args, **kwargs: ("b,", 0.9)):
                result = run_clef(
                    ctx,
                    question="Which label?",
                    options=["a", "b,", "c"],
                    verify="b,",
                    var="label",
                )
        self.assertFalse(result.get("blocked"))
        self.assertEqual(result["variables"]["label"], "b,")

    def test_image_variable_reads_that_file(self) -> None:
        seen: dict[str, object] = {}

        def ask(question: str, options: list[str], image: bytes, *, state: str, env: dict) -> tuple[str, float]:
            seen["image"] = image
            seen["state"] = state
            return "yes", 0.8

        with tempfile.TemporaryDirectory() as folder:
            shot = Path(folder) / "page.jpg"
            shot.write_bytes(b"from-step")
            ctx = {"env": {}, "variables": {"shot": str(shot)}, "data": folder}
            with patch("cg_loop.clef.ask_clef", ask):
                result = run_clef(ctx, question="Subscript text exists?", image="$shot", verify="yes", var="seen")
        self.assertFalse(result.get("blocked"))
        self.assertEqual(seen["image"], b"from-step")
        self.assertIn(str(shot), seen["state"])
        self.assertEqual(result["variables"]["seen"], "yes")

    def test_cua_image_reads_the_window_shot(self) -> None:
        seen: dict[str, object] = {}

        def ask(question: str, options: list[str], image: bytes, *, state: str, env: dict) -> tuple[str, float]:
            seen["image"] = image
            seen["state"] = state
            return "yes", 0.9

        with tempfile.TemporaryDirectory() as folder:
            shot = Path(folder) / "window.png"
            shot.write_bytes(b"window-png")
            driver = SimpleNamespace(
                last_pid=7,
                last_window_id=9,
                last_app="Chrome",
                get_window_state=lambda **_kwargs: SimpleNamespace(image=str(shot)),
            )
            ctx = {"env": {"CG_LOOP_STEP_JSON": str(Path(folder) / "step.json")}, "variables": {}, "data": folder}
            with patch("cg_loop.cua.open_driver", return_value=driver):
                with patch("cg_loop.clef.ask_clef", ask):
                    result = run_clef(ctx, question="Yahoo text exists?", image="/cua", verify="yes")
        self.assertFalse(result.get("blocked"))
        self.assertEqual(seen["image"], b"window-png")
        self.assertIn("Chrome", seen["state"])
        self.assertEqual(result["outputs"]["answer"], "yes")

    def test_missing_image_file_blocks(self) -> None:
        result = run_clef(
            {"env": {}, "variables": {}},
            question="Subscript text exists?",
            image="/tmp/cg-clef-missing.jpg",
        )
        self.assertTrue(result["blocked"])
        self.assertIn("not found", result["outputs"]["message"])

    def test_dry_run_does_not_ask(self) -> None:
        def refuse(*_args: object, **_kwargs: object) -> tuple[str, float]:
            raise AssertionError("dry-run should not load Clef")

        with patch("cg_loop.clef.ask_clef", refuse):
            result = run_clef(
                {"dry_run": True, "env": {}, "variables": {}},
                question="Subscript text exists?",
                verify="yes",
            )
        self.assertEqual(result["outputs"]["status"], "proposed")


class LoadTests(unittest.TestCase):
    def tearDown(self) -> None:
        clef._MODEL = None
        clef._MODEL_ID = ""

    def test_missing_package_is_installed_and_loaded_once(self) -> None:
        created: list[str] = []

        class Model:
            pass

        def install(name: str) -> None:
            created.append(name)
            if name == "huggingface_hub":
                hub = ModuleType("huggingface_hub")
                hub.__path__ = []
                hub.snapshot_download = lambda repo: f"/models/{repo}"
                utils = ModuleType("huggingface_hub.utils")
                utils.disable_progress_bars = lambda: None
                sys.modules["huggingface_hub"] = hub
                sys.modules["huggingface_hub.utils"] = utils
            else:
                sys.modules["mlx_vlm"] = SimpleNamespace()

        def clef_module(path: str) -> SimpleNamespace:
            created.append(f"module:{path}")
            return SimpleNamespace(load=lambda folder: created.append(folder) or Model())

        clef._MODEL = None
        with patch.dict(sys.modules, {"huggingface_hub": None, "huggingface_hub.utils": None, "mlx_vlm": None}):
            with patch("cg_loop.model._install_package", install):
                with patch("cg_loop.clef._clef_module", clef_module):
                    first = ensure_clef_model("mlx-community/clef-flash-4bit")
                    second = ensure_clef_model("mlx-community/clef-flash-4bit")
        self.assertIs(first, second)
        self.assertEqual(
            created,
            [
                "huggingface_hub",
                "mlx-vlm>=0.7.4,<0.8",
                "module:/models/mlx-community/clef-flash-4bit",
                "/models/mlx-community/clef-flash-4bit",
            ],
        )

    def test_a_clef_step_is_what_triggers_the_load(self) -> None:
        workflow = Workflow(name="demo", steps=[parse_step("/clef Subscript text exists?")])
        self.assertTrue(workflow_needs_clef(workflow))
        self.assertFalse(workflow_needs_clef(Workflow(name="demo", steps=[parse_step("/term echo hi")])))

    def test_config_model_is_passed_through_env(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "wf.yaml"
            path.write_text(
                "config:\n  name: demo\nwf_check:\n  - /clef Subscript text exists?\n",
                encoding="utf-8",
            )
            workflow = load_workflow(path)
        self.assertEqual(workflow.env["CLEF_MODEL"], "mlx-community/clef-flash-4bit")
        self.assertEqual(workflow.env["LOCATE_MODEL"], "andai-labs/LocateAnything-3B-MLX")

    def test_workflow_config_can_select_openrouter(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "wf.yaml"
            path.write_text(
                "config:\n"
                "  name: demo\n"
                "  clef: openrouter/cloudflare/clef\n"
                "  locate: openrouter/google/gemma-3-27b-it\n"
                "wf_check:\n"
                "  - /clef Subscript text exists?\n",
                encoding="utf-8",
            )
            workflow = load_workflow(path)
        self.assertEqual(workflow.env["CLEF_MODEL"], "openrouter/cloudflare/clef")
        self.assertEqual(workflow.env["LOCATE_MODEL"], "openrouter/google/gemma-3-27b-it")

    def test_openrouter_model_skips_the_local_weights(self) -> None:
        workflow = Workflow(name="demo", steps=[parse_step("/clef Subscript text exists?")])
        workflow.env["CLEF_MODEL"] = "openrouter/cloudflare/clef"
        with patch("cg_loop.clef.ensure_clef_model", side_effect=AssertionError("loaded")):
            load_clef_if_needed(workflow)

    def test_openrouter_clef_posts_systemone(self) -> None:
        from io import BytesIO

        from PIL import Image

        from cg_loop.gemma import openrouter_checkpoint

        self.assertEqual(openrouter_checkpoint("mlx-community/clef-flash-4bit"), "")
        self.assertEqual(openrouter_checkpoint("openrouter/cloudflare/clef"), "cloudflare/clef")
        with self.assertRaises(ValueError):
            openrouter_checkpoint("openrouter/clef")
        buf = BytesIO()
        Image.new("RGB", (4, 4), "white").save(buf, format="JPEG")
        seen: dict[str, object] = {}

        def post(body: dict, env: dict) -> dict:
            seen["body"] = body
            seen["key"] = env.get("OPENROUTER_API_KEY")
            return {"answers": {"answer": {"noul": 0.8}}}

        with patch("cg_loop.model.openrouter_systemone", post):
            answer, score = ask_clef(
                "Subscript text exists?",
                [],
                buf.getvalue(),
                state="page",
                env={"CLEF_MODEL": "openrouter/cloudflare/clef", "OPENROUTER_API_KEY": "sk"},
            )
        self.assertEqual(answer, "yes")
        self.assertGreater(score, 0.5)
        body = seen["body"]
        assert isinstance(body, dict)
        self.assertEqual(body["model"], "cloudflare/clef")
        self.assertEqual(body["questions"]["answer"]["type"], "noul")
        self.assertTrue(str(body["images"][0]).startswith("data:image/jpeg;base64,"))
        self.assertEqual(seen["key"], "sk")


if __name__ == "__main__":
    unittest.main()
