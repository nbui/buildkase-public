#!/usr/bin/env python3
"""Add a free-text CG idea into the correct pending ideas.yaml bank.

Uses LM Studio to pick the target bank (unless --target is given), shapes the
entry to match that bank's format, then prints the result. Pass --write to
append into the bank (default is dry-run).
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

from openai import OpenAI

SKILL_ROOT = Path(__file__).resolve().parents[1]
RESEARCH_LIB = Path(
    "/Users/nghia/Downloads/workspace/social_content_gen/skills/cg-research/lib"
)
sys.path.insert(0, str(RESEARCH_LIB))

from cg_research.push import push_ideas  # noqa: E402
from cg_research.targets import ROUTING_HINTS, TARGETS, targets_catalog  # noqa: E402

LM_STUDIO_URL = os.environ.get("LM_STUDIO_BASE_URL", "http://127.0.0.1:1234/v1")
MODEL = os.environ.get("LM_STUDIO_MODEL", "qwen3.8-27b-mlx")
API_KEY = os.environ.get("LM_STUDIO_API_KEY", "lm-studio")

_SLUG_RE = re.compile(r"[^\w\s-]", re.UNICODE)

TARGET_ALIASES = {
    "chat_message": "chat",
    "chat_message_vitamins": "chat_vitamins",
    "explain": "chat_explain",
    "explain_heart": "chat_explain_heart",
    "explain_vitamins": "chat_explain_vitamins",
    "slides_story": "story",
    "slides_meme": "meme",
    "meme_yuba": "meme_yuba",
    "meme_heartkase": "meme_heartkase",
    "chat_v2": "chat_v2",
    "chat_v2_can": "chat_v2_can",
    "chat_can": "chat_can",
    "chat_can_heart": "chat_can_heart",
    "chat_can_short": "chat_can",
    "chat_can_heart_short": "chat_can_heart",
    "note_analyze": "note_analyze",
    "note_analyze_heart": "note_analyze_heart",
    "meal_vid": "meal",
    "before_after_food_gen": "meal",
    "metric_signals": "metric_signals",
    "metric_video": "metric_video",
}


def _slug(text: str, *, max_len: int = 56) -> str:
    slug = text.strip().lower()
    slug = _SLUG_RE.sub("", slug)
    slug = re.sub(r"[\s_-]+", "_", slug).strip("_")
    return (slug[:max_len] or "idea").rstrip("_")


def _normalize_target(raw: str) -> str:
    tid = (raw or "").strip().lower()
    return TARGET_ALIASES.get(tid, tid)


def _extract_json(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    fence = re.match(r"^```(?:json)?\s*([\s\S]*?)\s*```$", cleaned, re.IGNORECASE)
    if fence:
        cleaned = fence.group(1).strip()
    try:
        payload = json.loads(cleaned)
    except json.JSONDecodeError:
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        if start < 0 or end <= start:
            raise ValueError(f"LLM did not return JSON object:\n{text[:500]}")
        payload = json.loads(cleaned[start : end + 1])
    if not isinstance(payload, dict):
        raise ValueError("LLM JSON was not an object")
    return payload


def _catalog_for_prompt() -> str:
    lines: list[str] = []
    for t in targets_catalog():
        lines.append(
            f"- {t['id']}: {t['label']} | brand={t['brand']} | "
            f"keys={','.join(t['format_keys'])} | file={t['ideas_path']}\n"
            f"  {t['description']}"
        )
    return "\n".join(lines)


def _local_shape(idea_text: str, target: str) -> dict[str, Any]:
    text = idea_text.strip()
    return {
        "target": target,
        "id": _slug(text),
        "title": text,
        "prompt": text,
        "topic": text,
        "rationale": f"Forced target {target} (--no-llm).",
    }


def route_and_shape(
    idea_text: str,
    *,
    target: str | None,
    client: OpenAI | None,
    model: str,
    use_llm: bool,
) -> dict[str, Any]:
    if target and not use_llm:
        return _local_shape(idea_text, target)
    if client is None:
        raise SystemExit("LM Studio required unless --target is set with --no-llm")

    allowed = ", ".join(sorted(TARGETS.keys()))
    force = (
        f'Target is forced to "{target}". Still fill all required fields.'
        if target
        else "Pick the single best target id."
    )
    system = f"""You route a content idea into a Yuba CG idea bank.

{ROUTING_HINTS}

{force}

Return ONLY a JSON object with:
- target: one of [{allowed}]
- id: snake_case slug
- title: short title (when the bank uses title)
- prompt: the core idea line (always useful)
- topic: short topic string
- category: short category / theme id when useful
- kind: story|meme when the bank shares story+meme (optional)
- angle: one-sentence angle / why it works (optional)
- statements: list of 1-3 short meme lines when kind is meme / meme_* CTA (optional)
- query: food-photo search query when target is meal (optional)
- metric: metric id when target is metric_signals or metric_video (optional)
- signal: rising|falling|high|low when target is metric_signals (optional)
- unit: unit string when target is metric_video (optional)
- hook_form: do|want|track when target is meme_yuba / meme_heartkase (+ glib) (optional)
- rationale: one sentence why this target fits

Do not wrap in markdown. JSON only.
"""
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {
                "role": "user",
                "content": (
                    "Target catalog:\n"
                    f"{_catalog_for_prompt()}\n\n"
                    f"Idea to add:\n{idea_text.strip()}"
                ),
            },
        ],
        temperature=0.2,
    )
    content = response.choices[0].message.content or ""
    data = _extract_json(content)
    tid = _normalize_target(str(target or data.get("target") or ""))
    if tid not in TARGETS:
        raise SystemExit(
            f"Unknown target {tid!r}. Valid: {', '.join(sorted(TARGETS.keys()))}"
        )
    data["target"] = tid
    if not data.get("id"):
        data["id"] = _slug(str(data.get("title") or data.get("prompt") or idea_text))
    if not data.get("prompt"):
        data["prompt"] = idea_text.strip()
    if not data.get("title"):
        data["title"] = str(data.get("prompt") or idea_text).strip()
    if not data.get("topic"):
        data["topic"] = str(data.get("title") or data["prompt"]).strip()
    return data


def _print_plan(idea: dict[str, Any], *, write: bool) -> None:
    tid = idea["target"]
    path = TARGETS[tid].ideas_path
    print("\n" + "#" * 70)
    print("ADD IDEA PLAN")
    print("#" * 70)
    print(f"target:  {tid}")
    print(f"bank:    {path}")
    print(f"id:      {idea.get('id')}")
    print(f"title:   {idea.get('title')}")
    print(f"prompt:  {idea.get('prompt')}")
    if idea.get("rationale"):
        print(f"why:     {idea.get('rationale')}")
    print("-" * 70)
    print(json.dumps(idea, indent=2, ensure_ascii=False))
    print("#" * 70)
    quoted = json.dumps(str(idea.get("prompt") or idea.get("title") or ""))
    print("\nEQUIVALENT COMMAND")
    print(f"{SKILL_ROOT / 'scripts' / 'add_idea.sh'} --write --target {tid} {quoted}")
    if not write:
        print("\n(dry-run — bank not modified. Pass --write to append.)\n")
    else:
        print("\n(--write: appending into bank)\n")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Route a free-text idea into the correct CG ideas.yaml bank via LM Studio. "
            "Default dry-run prints the plan; pass --write to append."
        )
    )
    parser.add_argument("idea", nargs="*", help="Free-text idea (prompted if omitted).")
    parser.add_argument(
        "--target",
        "-t",
        default="",
        help=f"Force target id. Valid: {', '.join(sorted(TARGETS.keys()))}",
    )
    parser.add_argument(
        "--write",
        "-w",
        action="store_true",
        help="Append the idea into the bank (default: dry-run print only).",
    )
    parser.add_argument(
        "--position",
        choices=("top", "bottom"),
        default="top",
        help="Insert at top (default) or bottom of pending ideas.",
    )
    parser.add_argument(
        "--no-llm",
        action="store_true",
        help="Skip LM Studio; requires --target (minimal local shape).",
    )
    parser.add_argument(
        "--list-targets",
        action="store_true",
        help="Print known targets and exit.",
    )
    args = parser.parse_args()

    if args.list_targets:
        for t in targets_catalog():
            print(f"{t['id']}\t{t['ideas_path']}\t{t['description']}")
        return 0

    idea_text = " ".join(args.idea).strip()
    if not idea_text:
        print("Idea to add?")
        idea_text = input("> ").strip()
    if not idea_text:
        print("No idea provided.", file=sys.stderr)
        return 1

    forced = _normalize_target(args.target) if args.target.strip() else None
    if forced and forced not in TARGETS:
        print(
            f"Unknown --target {forced!r}. Valid: {', '.join(sorted(TARGETS.keys()))}",
            file=sys.stderr,
        )
        return 1
    if args.no_llm and not forced:
        print("--no-llm requires --target.", file=sys.stderr)
        return 1

    use_llm = not args.no_llm
    client: OpenAI | None = None
    if use_llm:
        client = OpenAI(base_url=LM_STUDIO_URL, api_key=API_KEY)
        print(f"LM Studio: {LM_STUDIO_URL}  model={MODEL}")
    else:
        print(f"Local shape (no LLM)  target={forced}")

    shaped = route_and_shape(
        idea_text,
        target=forced,
        client=client,
        model=MODEL,
        use_llm=use_llm,
    )
    _print_plan(shaped, write=args.write)

    summary = push_ideas(
        [shaped],
        targets=[shaped["target"]],
        position=args.position,
        dry_run=not args.write,
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    pushed = summary.get("pushed") or []
    skipped = summary.get("skipped") or []
    if args.write and not pushed:
        print("Nothing written.", file=sys.stderr)
        return 1 if skipped else 0
    if args.write and pushed:
        p0 = pushed[0]
        print(f"\nWrote {p0.get('id')} → {p0.get('path')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
