# CG Loop overview

`cg_loop.py` is a [Jev Ultrafast](https://github.com/browser-use/jev-ultrafast)-style
agent: **observe → indexed action space → one operation + target → act**.

Jev's operations are `CLICK`, `TYPE_TEXT`, `SELECT`, `SCROLL_*`, `WAIT`,
`DONE`, `BLOCKED`. This loop adds **terminal and workflow steps**:

```text
page → element table → operation
                     │ click_target
                     │ type_text_target
                     │ term_target          ← not in Jev
                     │ extract_target
                     └─ execute the matching head
TYPE_TEXT → small LLM → text → browser
TERM      → small LLM → command → shell   (skipped when the YAML already has the command)
```

It is not a content generator itself. `generate story` shells out to
`cg-remix-article`. `term` runs `run_cucumber.sh` and other skill scripts.

## Workflow YAML

Pass a file instead of a free-form goal:

```bash
bash scripts/cg_loop.sh ../../workflows/wf-research-content.yaml
```

`config.env` values become `$VARS` in `term` and `load` lines. `$article` expands
to the extracted URL. `TOPIC` is set from the article title for cucumber runs.
`--param KEY=VALUE` overlays `config` (unknown keys overlay `config.env`); the
merged values are what the run uses. `llm: local` uses LM Studio. `llm: openrouter`
with `model: deepseek/deepseek-v3.2` uses OpenRouter (`OPENROUTER_API_KEY`) for
python compile. Von, configured in `workflows/workflows-app.yaml`,
picks the tool for a step with no `/browser`, `/python`, `/term`, `/clef`, `/hug`, or `/lmstudio-` prefix.
Each tool lists its actions and their top-level inputs and outputs in that file.
`browser-tool-model` chooses browser actions. The default `von` runs Von
locally. cg-loop loads those weights before the first step when the decision model
is `von` and a step will call it. A different decision model skips the load. `venv` in that file is the one Python environment for every workflow.
A workflow file's `config.venv` replaces it. `env-file` and `env` in that file are the process environment. `env-file` loads first, `env` replaces those keys, and a value already set in the shell wins. A workflow file's `config.env` replaces both for that file. `layla` runs Laya locally. cg-loop installs Laya into that venv when it is missing and loads it before the first step that calls it. `jev-latest` calls Jev through OpenRouter's
System One API with `OPENROUTER_API_KEY`. Known tools execute in process.
Compile does not write a `.py` wrapper for them. The python provider in that
app config is what generates code. The `workflows` folder in the same file is
the default catalog, so a command can omit the YAML path.
A `load … from $DRAFT_ROOT $APPROVED_ROOT` step reads `source_url.txt` (then
`run_meta.json` / `facts.json`) from those folders; `get first url not in $seen`
skips URLs already used. Remix writes `source_url.txt` into the output folder.

`wf_<name>` keys are peer groups. They run in file order, sharing variables.
The value may be more steps, a YAML path, a name from `WORKFLOW_PATH`, or a
mapping with `steps`, `auto`, and `config`. `auto` steps run in the agent loop
and are not compiled. `config` overrides the file config for that group.
`--only wf_slides` (or `--only slides`) runs just that group. `--only wf_all`
runs every group. With no `--only`, a file that has one group runs that group.
`--line N` runs the step that contains line N of the workflow file. The group
is the one that owns that line. A nested step runs by itself. The condition
line runs that condition. `--line N --end M` runs the steps from line N through
line M, so a highlight of two steps runs those steps together.
`--line N` runs the step that contains line N of the workflow file. The group
is the one that owns that line. A nested step runs by itself. The condition
line runs that condition. `--line N --end M` runs the steps from line N through
line M, so a highlight of two steps runs those steps together.
`--line N` runs the step that contains line N of the workflow file. The group
is the one that owns that line. A nested step runs by itself. The condition
line runs that condition. `--line N --end M` runs the steps from line N through
line M, so a highlight of two steps runs those steps together.
A file with several groups does not run until you name one or pass `wf_all`.

A step `{msg, type: workflow, params}` looks up `msg` as the workflow name in
`WORKFLOW_PATH`. One group runs as itself. `wf_all` or `wf_research|wf_slides`
runs more than one. `msg: "wf-contet-post wf_post"` runs one group. `params` overlay the child
the same way for every selected group.

Every step is compiled once into `<project>/cache/<workflow_file>/<group>/<step>/b-compile.py` and reused. That cache sits beside `workflows-app.yaml`, not inside the workflows catalog or cg-loop. The step folder also holds `a_01-context.json`, `a-` prompts and config, and `b_01-context.json`. Compiled `load`, `goto`, `extract`, and `term` scripts call the existing tools.

The current run is `<project>/cache/<workflow_file>/<group>/c-run.log`, and each step writes `c-run.log` plus `c-01-context.json` in its folder. Compile attempts, including the request, thinking, and script, are in `c-compile.log`. Each `wf_*` group has its own folder. Running one group leaves the others in place. `z-data/` is that run's working folder (`ctx["data"]`, `$DATA`). Files written there are stored as `01-name`, `02-name`, in the order they are created. Config `data-numbers: false`, a step that says `no numbers`, or `set_config DATA_NUMBERS=false` keeps the plain filename. The next run copies the group folder to `archived/<stamp>/`, then deletes `c-` files and `z-data`. Prompts and `b-compile.py` stay. `log-keep` (default 5) is how many archived runs to retain. A cached script is reused when it parses, defines `run`, and calls that step's tool; a failed check rewrites it once. When a group starts, step folders that are not steps of that group are deleted. Archived runs stay. The log ends with total, compile, LLM, and step time, and compiled / reused / recompiled / failed recompile counts.

`set-config browser-reusetab=youtube` attaches the session to an open YouTube tab, or opens a new tab, and later `/browser` steps stay on it. Config `browser-reusetab` does the same when the session opens. A workflow file's config replaces the app value, and this step replaces it again from that point. A term starts with `/` and an action param starts with `+`, as in `/browser +click subscribe box` or `/browser +verify Content`. A `/browser` goal is compiled when that step runs, from the text of the page already open, and then reused.
Other ambiguous browser goals use the Jev loop until `DONE`. A goal that resolves to
TERM is compiled into the same cache.

## Typical goals

| User says | Agent should lean toward |
|-----------|--------------------------|
| run wf-research-content.yaml | EXTRACT first RSS URL, `term` remix-article, slides term |
| generate / make / invent slides meme_yuba | `TERM` → `cg-slides` `run_cucumber.sh` `--tags @meme_yuba` |
| post chat_can to yt/tt/ig | `TERM` → `cg-post-from-folder` tags |
| open Wikipedia Gödel article | browser loop: CLICK / TYPE_TEXT / DONE |
| add idea: leftover chicken protein | `add_idea.sh --write "…"` |

## Operating rules

1. Browser actions copy an offered role selector (`role=button[name="Next"s]`). Do not invent a selector and do not pick a snapshot index. Other steps act on an observed index or a native step op.
2. Prefer catalog / SKILL.md commands when TERM must be written.
3. One operation per tick. Diagnose failures instead of blind retries.
4. Content TERM runs can take a long time; wait for exit codes.
5. Never claim success without a successful exit (or a dry-run skip).

## Safety

Dangerous TERM patterns (`rm -rf`, `sudo`, …) still print a confirm prompt
(`[y/N]`). Rejecting returns `status: rejected`.
